# Checking mobile apps, authentication methods, browser sessions and remediation

Under **Set requirements**, choose the account set, the scope and a required
outcome. Import requirements only after loading the tenant snapshot.

| Outcome | What a passing check establishes |
| --- | --- |
| MFA and app protection | Every admitted path in scope requires both controls. An OR policy can leave a gap; another applicable policy can supply the missing control. |
| MFA and user risk remediation | The selected user-risk levels require MFA and the remediation grant on admitted paths. Add **Every time** when that is part of the requirement. |
| Only selected authentication methods | Every admitted method combination is on your list. For FIDO2, optionally enter allowed key model IDs (AAGUIDs). One-time and multi-use Temporary Access Pass are distinct. Unknown or incomplete strength evidence can leave a result unverified. |
| Browser session must persist / must never persist | Browser access is covered by an enabled policy specifying that mode. Missing settings and an opposing mode are findings. Possible overlap of opposing settings requires review. These are configured controls; observing actual cookie behaviour requires a client. |
| Intune protection assigned to a mobile app | Exported targeting includes this account and the specified client bundle ID (iOS) or package name (Android). A CA block cannot satisfy an assignment check. Select one mobile platform per rule. |

The first four are minimum requirements on admitted sign-ins. Keep a separate
**Must be able to access** requirement wherever a usable access path is necessary.
A FIDO2 model ID identifies a key model, not an individual's enrolled key.

## Optional evidence

Run the export on your collection machine using its existing authentication
options. Add the switches only for the evidence you want:

```powershell
.\collection\Export-TenantSnapshot.ps1 -TenantId $tenantId -IncludeIntuneAppProtection -OutputPath .\snapshot.json
```

The Intune option reads iOS and Android app protection policies, their client apps,
assignments and the referenced groups. It uses the additional Graph permission
**DeviceManagementApps.Read.All**. Import the resulting snapshot to analyse it
offline. Enter the mobile client identifier from Intune; the CA resource app ID
identifies a different object. CALens verifies explicit apps with group includes
and exclusions. Incomplete collection, missing group membership and unresolved
assignment filters or target types can leave assignment unconfirmed. The check
assesses configured targeting. App installation, SDK enforcement, policy content
and delivery on a particular device require client or Intune deployment evidence.

To inspect observed remediation for selected users, add
`-RiskHistoryUserIds $userObjectId` to the export. This requests
**IdentityRiskyUser.Read.All** with interactive authentication. Use **Review
coverage → By account → Observed risk history** to inspect the exported events
and timestamps. A remediated state with a recognised user action is labelled
accordingly. History is historical evidence and does not attribute the event to
a particular CA policy. A failed read or empty history cannot establish completion.
Access to the live Graph services depends on the tenant's permissions and licensing.

Graph references: [Intune assignments](https://learn.microsoft.com/en-us/graph/api/intune-mam-targetedmanagedapppolicyassignment-list?view=graph-rest-1.0),
[iOS app protection and apps](https://learn.microsoft.com/en-us/graph/api/resources/intune-mam-iosmanagedappprotection?view=graph-rest-1.0),
[risky user history](https://learn.microsoft.com/en-us/graph/api/riskyuser-list-history?view=graph-rest-1.0).
