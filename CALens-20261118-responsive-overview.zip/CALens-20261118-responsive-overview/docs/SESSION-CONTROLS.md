# Policies with session controls

Session settings no longer cause an otherwise supported policy's MFA or device
grants to be discarded. The analyzer validates the exported settings, then checks
the grants against your declared requirements. It does not execute sessions.

Microsoft applies session controls after grant controls are satisfied. See
[policy evaluation](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-policies)
and the Graph [stable](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccesssessioncontrols?view=graph-rest-1.0)
and [beta](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccesssessioncontrols?view=graph-rest-beta)
session schemas.

## What the results establish

| Exported setting | Treatment for current requirements |
| --- | --- |
| Sign-in frequency | Select a maximum interval alongside MFA or phishing-resistant MFA. Enabled policies can supply the MFA and frequency controls separately where their scopes overlap. Every time satisfies any time-based maximum. Actual prompt timing requires sign-in evidence. |
| Persistent browser (`always` / `never`) | Assess an explicit always/never browser requirement. Overlapping opposing modes require review. Observing the actual cookie requires a client session. |
| Disable resilience defaults | Validate the Boolean; retain grants. Outage/session continuation is not assessed. |
| CAE disabled | Validate the mode; retain grants. Token lifetime is not assessed. |
| CAE strict modes, app-enforced restrictions, Defender for Cloud Apps, token protection, GSA filtering profile | Retain grants. Remaining possible access through the policy stays unverified because downstream enforcement could deny it. |

For example, **Require MFA + token protection** still establishes the MFA grant.
**Token protection alone** establishes neither MFA nor device compliance. It also
does not establish that access will be blocked: token/client support and runtime
binding need separate evidence.

Uncertainty is checked against the remaining violation regions and the policy's
actual account, app, client, platform, network and other conditions. A session
policy for App A does not make an independent App B gap unverified. If other
supported grants already protect every scenario, no downstream assumption is
needed to establish that minimum protection.

## Checking an approved access path

Choose **Must be able to access after MFA**, select the partner group and apps,
then choose a compliant or unmanaged device. The check models ordinary MFA and
a device without hybrid join. Browser, standard flow and no risk are the defaults.
Narrow the platforms and networks to the intended scenario. A block or an
unsatisfied grant produces a finding even when another policy requires MFA.
Check the restriction on other apps in a separate requirement. Application
assignment, licensing, resource permissions and actual sign-in success require
additional evidence.

## Export and configuration boundaries

The existing policy export carries these fields; no extra Graph calls or reader
permissions were added. Definitions and selected filtering-profile identifiers
stay in the snapshot for offline use. This does not collect Defender access
policies, GSA filtering contents, actual token binding, client support or runtime
session evidence. GSA filtering-session support is separate from the unsupported
compliant-network matching described in [trusted networks](NETWORK-TRUST.md).

Known controls with `isEnabled: false` contribute no enforcement. Unknown controls,
active future modes, malformed objects, non-Boolean flags and unsupported nested
fields cannot silently earn grant credit. A time-based sign-in-frequency setting
can omit `authenticationType`, as documented in the
[Graph schema](https://learn.microsoft.com/en-us/graph/api/resources/signinfrequencysessioncontrol?view=graph-rest-1.0).

Sanitization preserves known modes and consistently replaces profile identifiers.
Accepted possible gaps reopen when relevant downstream configuration changes,
even if the minimum-grant projection stays identical. This feature does not add
session-freshness, cookie-persistence or token-binding requirements to the builder;
those require additional models and runtime validation.
