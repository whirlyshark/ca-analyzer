# Start with CALens

Keep the whole folder together. Use Windows x64 with PowerShell 7.4 or later.
Double-click **Open-Analyzer.cmd** and keep its PowerShell window open while using
the app. To stop it, close that window or press Ctrl+C.

If the page is unavailable, start the app again. If another app uses port 8765,
run `pwsh -NoProfile -File ./Start-UI.ps1 -Port 8766` and open the address it prints.

## Your first check

1. **Import policies:** choose **Explore the demo**, then **Load demo**. For your
   organisation, choose one connection/export option or import an exported JSON
   file. An account-level check needs accounts and membership data as well as
   policies. Collection instructions are available beside your chosen option.
2. **Define accounts:** preview the included accounts. Add or edit reusable sets
   such as Guests, accounts from a chosen partner, or selected directory roles.
   Include eligible roles when your requirements need them. Define your emergency
   accounts explicitly; a set's name never changes an account's privileges.
3. **Set requirements:** describe what each set must be allowed to do and what
   protection it needs. Templates are editable starting points. Check the English
   sentence before saving. Save your setup with **Export definitions & requirements**.
4. **Review coverage:** select **Check coverage**. Open **By account** to check a
   person, or **By requirement** to investigate a rule. Summary tiles and chart
   groups open their matching accounts. Search and filters narrow the lists.

Try the demo's clean baseline, then a scenario such as **Separate-group member MFA
only covers browsers**. Check again with the same requirements to see what changed.

## Read a result

| Result | Meaning / next step |
|---|---|
| Requirement met | No violation was found in the scenarios that CALens could check. The result applies to this export and your chosen requirement. |
| Gap found / Not met | The modeled policies permit an example that falls short of your rule. Open its sign-in example and related policies. |
| Cannot confirm / Needs investigation | CALens cannot establish the answer. Open **See what needs checking** or the nearby explanation. Missing data and unsupported behavior remain visible. |
| Not applicable | This account is outside that requirement's account selection. |
| Accepted exception | Someone has acknowledged this scenario. Protection is still missing or unconfirmed; the exception does not fix the policy. Other scenarios stay open. |

Blocking access can meet a minimum-protection rule because the unsafe access is
prevented. It does not mean a person successfully signed in or completed MFA.

The percentage shows accounts meeting every requirement in scope. Incomplete
checks remain **Not scored**. Accepting an exception does not improve protection.
Policy counts and scenario counts overlap; use account counts to understand how
many people need attention.

Under **By requirement → Policy coverage**, CALens links contributing policies
automatically. In a gap, **Recommendations & related policies** gives review
options. Their wider effects are not simulated, and CALens does not change policies.

## Keep and repeat your work

Your account sets, requirements, exceptions and previous checks are saved in this
folder's `data` directory. Export your setup for reuse. Keep the `data` directory
when moving your own workspace. Different organisations have separate saved setups.
Completed tenant assessments are saved automatically. After returning to CALens,
choose **Open last assessment**, or use **Saved assessments** in the header to
find an earlier check. No Microsoft sign-in or new analysis is needed. New saved
assessments include the imported data and requirements used for that check.
Older reports still open, but may not include their original policy definitions.
The date shown is when the assessment ran; reopening does not refresh tenant data.

Keep the app's `data` folder when upgrading or moving your workspace. Saved
assessments are stored there on the computer running CALens, not in the browser.
Resetting saved assessments through Settings removes them. An unfinished check
is not a saved result; allow it to finish before closing the page.

Refresh your export to check a later tenant state. Rechecking an old export checks
that old state again; it does not inspect the current tenant. Analysis works offline
after you have the required exports. Authentication and collection are optional.

The browser file picker accepts snapshots up to 10 MiB. For larger exports, use
the offline PowerShell runner, which accepts up to 100 MiB per input file.

For repeated offline checks and scheduling, see
[PowerShell assessments](UNATTENDED-ASSESSMENTS.md). For the supported boundaries,
see [support matrix](SUPPORT-MATRIX.md) and [policy mapping](POLICY-MAPPING.md).

### Requirements needing review

If two or more requirements restrict the same accounts to apps, networks or devices
with no shared choice, CALens shows **Requirements needing review** above the list.
It explains the possible unintended blocking and provides **Edit requirement**
buttons for the rules involved. Save a change to check the overlap again.

MFA and phishing-resistant MFA can work together, as can MFA and a compliant device.
The warning does not stop a policy coverage check or change its score. This review
checks overlapping app, network and device restrictions using the loaded data;
it does not guarantee successful sign-in or identify every possible conflict.

## Background checks and faster saved results

Tenant checks now run as local background jobs. Closing or refreshing the browser
no longer cancels a submitted check. Reopen CALens and choose **View progress** or
**Open results**. Keep the CALens PowerShell process running; unfinished jobs do
not survive stopping the app or restarting Windows. **Cancel assessment** stops a
job without presenting a partial result as complete. Cancellation can take time
while a native calculation finishes. One assessment runs at a time.

Before checking, **Ready to check?** shows account selections, unresolved scope,
empty sets, explicit exclusions and the export date. Open account counts to
search or export the corresponding list. Exclusion never automatically labels
an account as emergency access.

**What needs attention** groups unaccepted findings by missing protection,
certainty and applying policies, with unique account counts and links to example
scenarios for each requirement. Groups are review starting points, not verified
root causes or fixes. Counts overlap between groups and should not be added.
Every underlying finding remains available in the existing investigation views
and full exports.
