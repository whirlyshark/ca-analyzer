# Assessment report storage

CALens keeps every finding. Disk-backed storage separates the amount of result
detail from the memory needed for one calculation. No tenant changes or tokens
are involved in this storage.

## Local lifecycle

Each assessment creates an isolated `calens-findings-<random id>` directory in
the current Windows user's temporary folder. Pages are compressed JSON, with
512 records per page and three pages cached. Page writes use a temporary file
and replacement. Save failures abort the operation instead of discarding data.
Mutable exception metadata is written when its page is evicted. Indexed finding
keys support selecting and accepting a finding without a full PowerShell scan.

A completed JSON report is saved atomically to the requested report location.
Its pages are self-contained; it does not depend on the temporary directory.
The store removes its temporary directory on disposal/garbage collection. A
crash can leave temporary pages, which may contain tenant identifiers and
findings. Treat reports and temporary pages as private tenant data.

## File and transport formats

Small reports keep normal `gaps` JSON. Medium reports may use the existing
`_calensDetailPool` version 1. Large reports contain `_calensFindingPages`:

```json
{"status":"completeWithinModel","_calensFindingPages":{"version":1,"count":437104,"pages":[{"gaps":["..."],"_calensDetailPool":{"version":1,"strings":[],"regions":[],"witnesses":[]}}]}}
```

The example is schematic. Every actual page contains complete pooled records;
there are no placeholder findings. List order and values are preserved. Read
with `ReportCodec.ReadFile`, which returns an ordinary report with a disk-backed,
indexable `gaps` collection. Use `.Count`, indexing or enumeration. The snapshot
JSON input size limit does not apply to this report-file reader.

Large streamed UI responses use `resultStart`, numbered `resultPage` events and
`resultEnd`. The browser requires a valid final count and every page in order.
An interrupted stream is an error, never a partial result shown as complete.
Exports use the paged JSON format above. The bundled browser decoder supports
both existing and paged report formats; third-party readers must support them.

The interactive review sends a compact index containing every finding's key,
account IDs, requirement, certainty and acceptance metadata. Full scenario details
are fetched from the current local report when selected. The assessment ID is
checked so a different open report cannot silently supply a scenario. JSON exports
still contain every full finding; the review index is not used as an export.

Compressed overview sidecars accompany temporary finding pages. Summary counts
read these small records without expanding scenario axes. Identical account sets
are unioned by requirement, certainty and acceptance for summary calculation only.
Neither full findings nor scenario regions are merged or removed by this step.

## Reopening saved assessments

New saved tenant assessments retain a `reviewContext` containing their imported
snapshot, account/requirement definitions and compiled model. This is private
tenant data, stored locally under `data/assessments`; connection tokens are not
part of the review context. Keep the data folder when moving or upgrading CALens.
The saved date and original result remain unchanged when opened. Opening does not
invoke the analyzer or contact Microsoft.

The catalog and history list read small `.header.json` sidecars. Missing, stale or
invalid sidecars fall back to reading the report header. Original reports without
review context can still display saved outcomes, scopes and scenario details;
CALens labels their unavailable original policy definitions instead of inventing
policy relationships. Import the original snapshot before running a fresh check.

## Accuracy boundary

Paging does not alter policy predicates, grant combination, scenario constraints,
account grouping or requirement evaluation. Exact fingerprints remain compatible.
Independent region/point tests and byte-exact roundtrips verify those boundaries.
Missing source facts remain explicit uncertainties; storage never invents facts
or declares unsupported checks successful.

## Indexed saved-result access

Saved reports now have a rebuildable `.review` folder containing compressed
finding pages, overview pages and a metadata index. Reopening reads this index,
validates its page/header checksums and the source report's size/write time, then
loads full detail pages only as needed. Editing an opened finding writes temporary
pages, never the historical saved pages. JSON remains the complete authoritative
export. Missing, stale or corrupt indexes fall back to reading the JSON and
rebuilding the index. The first opening of an older report therefore remains
slower. Keep these folders with the workspace to retain fast opening.

The browser still receives all compact finding metadata for complete filtering
and counts; indexed opening does not eliminate transport or rendering time.
