#Requires -Version 7.4
[CmdletBinding(DefaultParameterSetName='AzureCli')]
param(
    [Parameter(Mandatory)][guid]$TenantId,
    [Parameter(ParameterSetName='Interactive')][switch]$InteractiveLogin,
    [Parameter(ParameterSetName='Interactive')][string]$ClientId,
    [Parameter(ParameterSetName='Interactive')][switch]$UseDeviceCode,
    [Parameter(Mandatory,ParameterSetName='Token')][securestring]$AccessToken,
    [string]$OutputPath='./ca-tenant-snapshot.json',
    [switch]$IncludePimGroups,
    [switch]$IncludeApplicationAttributes,
    [switch]$IncludeIntuneAppProtection,
    [guid[]]$RiskHistoryUserIds=@(),
    [switch]$AllGroups,
    [string[]]$AdditionalGroupIds=@()
)
$ErrorActionPreference='Stop'
$connectedGraph=$false;$bearer=$null;$credential=$null
$extra=@{ReferencedGroupsOnly=(!$AllGroups);AdditionalGroupIds=$AdditionalGroupIds};if($IncludePimGroups){$extra.IncludePimGroups=$true}
if($RiskHistoryUserIds.Count){$extra.RiskHistoryUserIds=$RiskHistoryUserIds}
if($IncludeIntuneAppProtection){$extra.IncludeIntuneAppProtection=$true}
if($IncludeApplicationAttributes){$extra.IncludeApplicationAttributes=$true}
try {
    # The downloadable standalone script includes this shared function below.
    if(-not (Get-Command Get-CaTenantSnapshot -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'TenantSnapshot.ps1')}
    if($PSCmdlet.ParameterSetName -eq 'Interactive'){
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
        $connection=@{TenantId=$TenantId.ToString();Scopes=@('Policy.Read.All','Directory.Read.All','RoleManagement.Read.Directory');ContextScope='Process';NoWelcome=$true}
        if($RiskHistoryUserIds.Count){$connection.Scopes+='IdentityRiskyUser.Read.All'}
        if($IncludeIntuneAppProtection){$connection.Scopes+='DeviceManagementApps.Read.All'}
        if($IncludePimGroups){$connection.Scopes+=@('PrivilegedEligibilitySchedule.Read.AzureADGroup','PrivilegedAssignmentSchedule.Read.AzureADGroup')}
        if($IncludeApplicationAttributes){$connection.Scopes+=@('CustomSecAttributeDefinition.Read.All','CustomSecAttributeAssignment.Read.All')}
        if($ClientId){$connection.ClientId=$ClientId}
        if($UseDeviceCode){$connection.UseDeviceAuthentication=$true}
        Connect-MgGraph @connection;$connectedGraph=$true
        if((Get-MgContext).TenantId -ne $TenantId.ToString()){throw 'Wrong tenant.'}
        $snapshot=Get-CaTenantSnapshot -TenantId $TenantId.ToString() @extra -Request {param($uri) Invoke-MgGraphRequest -Method GET -Uri $uri -Headers @{ConsistencyLevel='eventual';Prefer='include-unknown-enum-members'} -OutputType Json}
    }else{
        if($PSCmdlet.ParameterSetName -eq 'Token'){
            $bearer=[Net.NetworkCredential]::new('',$AccessToken).Password -replace '^Bearer\s+',''
        }else{
            if(-not (Get-Command az -ErrorAction SilentlyContinue)){throw 'Azure CLI is required to reuse a session. Run this in Cloud Shell PowerShell, or choose a different connection option.'}
            $account=az account show --output json|ConvertFrom-Json
            if($LASTEXITCODE -ne 0 -or !$account.tenantId){throw 'No existing Azure CLI session. This mode does not start a new sign-in.'}
            if($account.tenantId -ne $TenantId.ToString()){throw 'The existing Azure CLI session is in a different tenant. Select the correct directory in Cloud Shell.'}
            $credential=az account get-access-token --tenant $TenantId.ToString() --resource https://graph.microsoft.com/ --output json|ConvertFrom-Json
            if($LASTEXITCODE -ne 0 -or !$credential.accessToken){throw 'The existing Azure CLI session could not obtain a Microsoft Graph token. No new sign-in or consent is requested.'}
            $bearer=$credential.accessToken
        }
        $snapshot=Get-CaTenantSnapshot -TenantId $TenantId.ToString() @extra -BearerToken $bearer
    }
    $snapshot|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $OutputPath -Encoding utf8
    Write-Host "Saved snapshot to $OutputPath. Policies: $($snapshot.policies.Count). Users: $($snapshot.users.Count). Collection issues: $($snapshot.errors.Count)."
}finally{
    $bearer=$null;$credential=$null;$AccessToken=$null
    if($connectedGraph){Disconnect-MgGraph|Out-Null}
}
