# Shared read-only collector. Used by OAuth and the standalone export script.
if(-not (Get-Command ConvertFrom-CaJson -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot '../engine/JsonData.ps1')}
function Get-CaTenantSnapshot {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$TenantId,[string]$BearerToken,[scriptblock]$Request,[switch]$IncludePimGroups,[switch]$IncludeIntuneAppProtection,[guid[]]$RiskHistoryUserIds=@(),[switch]$IncludeApplicationAttributes,[Collections.Concurrent.ConcurrentDictionary[string,object]]$ProgressState,[switch]$ReferencedGroupsOnly,[string[]]$AdditionalGroupIds=@())
    $ErrorActionPreference='Stop'
    $errors=[Collections.Generic.List[object]]::new()
    $complete=@{}
    $tracking=@{startedAtUtc=[DateTime]::UtcNow.ToString('o');lastResponseAtUtc=$null;collection='Tenant identity';pagesRead=0;recordsRead=0;completedReads=0;incompleteReads=0;currentPages=0;currentRecords=0;batchCompleted=0;batchTotal=0;batchLabel=''}
    function Report-Collection([string]$Message='',[int]$RetrySeconds=0){
        if($null -eq $ProgressState){return}
        $snapshot=@{};foreach($key in $tracking.Keys){$snapshot[$key]=$tracking[$key]}
        $snapshot.message=$Message;$snapshot.retrySeconds=$RetrySeconds;$snapshot.updatedAtUtc=[DateTime]::UtcNow.ToString('o')
        # Replace one immutable snapshot rather than sharing mutable counters.
        $ProgressState['latest']=$snapshot
    }
    function Start-CollectionRead([string]$Name){
        $tracking.collection=switch -Regex ($Name){
            '^members:' {'Group memberships';break}
            '^strengthConfigurations:' {'Authentication method restrictions';break}
            '^pimGroupEligibility:' {'People eligible for temporary group membership';break}
            '^pimGroupAssignments:' {'Temporary group assignments';break}
            '^groupDirectMembers:' {'Direct group memberships';break}
            '^organization$' {'Tenant identity';break}
            '^policies$' {'Conditional Access policies';break}
            '^users$' {'Accounts';break}
            '^groups$' {'Groups';break}
            '^roles$' {'Role definitions';break}
            '^roleAssignments$' {'Role assignments';break}
            '^roleEligibility$' {'PIM role eligibility';break}
            '^roleAssignmentScheduleInstances$' {'Role assignment schedules';break}
            '^authenticationStrengths$' {'Authentication strengths';break}
            '^namedLocations$' {'Named locations';break}
            '^compliantNetworkLocations$' {'Compliant network locations';break}
            '^applications$' {'Application names';break}
            '^applicationAttributeDefinitions$' {'Custom app attribute definitions';break}
            '^applicationAttributes$' {'Custom app attributes';break}
            '^deviceRegistrationPolicy$' {'Device registration settings';break}
            default {'Supporting configuration'}
        }
        $tracking.currentPages=0;$tracking.currentRecords=0;Report-Collection
    }
    Report-Collection 'Connecting to Microsoft Graph'
    function Read-Page([string]$uri) {
        $target=[uri]$uri
        if($target.Scheme -ne 'https' -or $target.Host -ne 'graph.microsoft.com' -or $target.UserInfo -or $target.Port -ne 443){throw 'Rejected non-Graph pagination URL.'}
        for($attempt=0;;$attempt++){
            try {
                $response=if($Request){& $Request $uri}else{(Invoke-WebRequest -Method Get -Uri $uri -Headers @{Authorization="Bearer $BearerToken";ConsistencyLevel='eventual';Prefer='include-unknown-enum-members'} -MaximumRedirection 0 -TimeoutSec 60).Content}
                if($response -is [string]){return ConvertFrom-CaJson $response}
                return $response
            }catch{
                $status=[int]$_.Exception.Response.StatusCode
                if($attempt -ge 3 -or $status -notin @(429,503,504)){throw}
                $delay=[int][Math]::Min(20,[Math]::Pow(2,$attempt+1))
                Report-Collection 'Microsoft asked us to wait before retrying' $delay
                Start-Sleep -Seconds $delay
                Report-Collection 'Retrying the read'
            }
        }
    }
    function Read-All([string]$name,[string]$path) {
        Start-CollectionRead $name
        Write-Progress -Activity 'Read-only tenant collection' -Status ('Reading '+($name -replace '^members:.*','group memberships'))
        $items=[Collections.Generic.List[object]]::new()
        $uri="https://graph.microsoft.com/$path"
        $visited=[Collections.Generic.HashSet[string]]::new()
        try {
            while($uri){
                if(-not $visited.Add($uri)){throw 'Repeated pagination link.'}
                $page=Read-Page $uri
                if($null -eq $page.value){throw 'Graph returned no collection.'}
                foreach($item in $page.value){$items.Add($item)}
                $tracking.pagesRead++;$tracking.currentPages++;$tracking.recordsRead+=@($page.value).Count;$tracking.currentRecords=$items.Count;$tracking.lastResponseAtUtc=[DateTime]::UtcNow.ToString('o');Report-Collection
                $uri=$page.'@odata.nextLink'
            }
            $complete[$name]=$true
            $tracking.completedReads++;Report-Collection
        }catch{
            $complete[$name]=$false
            $tracking.incompleteReads++;Report-Collection 'Some data could not be read; its limitations will appear with the loaded data'
            $errors.Add(@{collection=$name;message="Could not fully read $name. Check reader permissions, role requirements and connectivity."})
        }
        if($tracking.batchLabel -eq 'Temporary-group reads completed'){$tracking.batchCompleted++;Report-Collection}
        return ,@($items.ToArray())
    }
    function Read-Object([string]$name,[string]$path){
        Start-CollectionRead $name
        try{
            $object=Read-Page ("https://graph.microsoft.com/$path")
            if(!$object.id){throw 'Graph returned no settings object.'}
            $complete[$name]=$true;$tracking.pagesRead++;$tracking.recordsRead++;$tracking.currentPages=1;$tracking.currentRecords=1;$tracking.completedReads++;$tracking.lastResponseAtUtc=[DateTime]::UtcNow.ToString('o');Report-Collection;return $object
        }catch{$complete[$name]=$false;$tracking.incompleteReads++;Report-Collection 'Some data could not be read; its limitations will appear with the loaded data';$errors.Add(@{collection=$name;message="Could not read $name. Its dependent checks cannot be confirmed."});return $null}
    }
    $orgs=Read-All organization 'v1.0/organization?$select=id,displayName'
    if(-not $complete.organization){throw 'Could not read the tenant identity. Check authentication, reader permissions and connectivity.'}
    if($orgs.Count -ne 1 -or $orgs[0].id -ne $TenantId){throw 'Connected directory does not match the requested tenant.'}
    $policies=Read-All policies 'v1.0/identity/conditionalAccess/policies'
    $users=Read-All users 'v1.0/users?$select=id,displayName,userPrincipalName,userType,accountEnabled,mail,otherMails,jobTitle,department,companyName,creationType'
    # Role-linked groups are needed even when no CA policy names them.
    $roles=Read-All roles 'beta/roleManagement/directory/roleDefinitions?$select=id,templateId,displayName,isBuiltIn,isPrivileged'
    $assignments=Read-All roleAssignments 'v1.0/roleManagement/directory/roleAssignments'
    $eligible=Read-All roleEligibility 'v1.0/roleManagement/directory/roleEligibilityScheduleInstances'
    $assignmentSchedules=Read-All roleAssignmentScheduleInstances 'v1.0/roleManagement/directory/roleAssignmentScheduleInstances'
    $riskHistory=@{}
    foreach($riskUser in @($RiskHistoryUserIds | Sort-Object -Unique)){
        $riskId=$riskUser.ToString()
        $items=Read-All ('riskHistory:'+$riskId) ('v1.0/identityProtection/riskyUsers/'+$riskId+'/history?$select=userId,riskState,riskDetail,riskLastUpdatedDateTime,activity')
        $riskHistory[$riskId]=@(foreach($entry in $items){
            if($entry.userId -and $entry.userId -ne $riskId){$complete['riskHistory:'+$riskId]=$false;continue}
            @{state=$entry.riskState;detail=$entry.riskDetail;activity=$entry.activity.detail;updated=$entry.riskLastUpdatedDateTime}
        })
    }
    $intunePolicies=[Collections.Generic.List[object]]::new()
    if($IncludeIntuneAppProtection){
        foreach($platform in @('ios','android')){
            $path='v1.0/deviceAppManagement/'+$platform+'ManagedAppProtections'
            $list=Read-All ('intunePolicies:'+$platform) ('beta/deviceAppManagement/'+$platform+'ManagedAppProtections?$select=id,displayName,appGroupType')
            foreach($policy in $list){
                $policyId=[guid]::Parse($policy.id).ToString()
                $appsForPolicy=Read-All ('intuneApps:'+$policyId) ($path+'/'+$policyId+'/apps?$select=id,mobileAppIdentifier')
                $targets=Read-All ('intuneAssignments:'+$policyId) ($path+'/'+$policyId+'/assignments?$select=id,target')
                $intunePolicies.Add(@{id=$policyId;platform=$platform;appGroupType=$policy.appGroupType;displayName=$policy.displayName;apps=$appsForPolicy;assignments=$targets})
                foreach($assignment in $targets){
                    if($assignment.target.groupId){$AdditionalGroupIds+=@($assignment.target.groupId)}
                }
            }
        }
    }
    if($ReferencedGroupsOnly){
        $policyGroups=@($policies|ForEach-Object {$_.conditions.users.includeGroups;$_.conditions.users.excludeGroups}|Where-Object {$_}|Sort-Object -Unique)
        $userIds=[Collections.Generic.HashSet[string]]::new([string[]]@($users|ForEach-Object {$_.id}),[StringComparer]::OrdinalIgnoreCase)
        $rolePrincipals=@(@($assignments)+@($eligible)+@($assignmentSchedules)|ForEach-Object {$_.principalId}|Where-Object {$_ -and !$userIds.Contains($_)})
        $wanted=@(@($policyGroups)+@($rolePrincipals)+@($AdditionalGroupIds)|Sort-Object -Unique)
        $selected=[Collections.Generic.List[object]]::new();$groupReadsComplete=$true
        for($offset=0;$offset -lt $wanted.Count;$offset+=15){
            $batch=@($wanted|Select-Object -Skip $offset -First 15)
            foreach($id in $batch){if(![guid]::TryParse($id,[ref]([guid]::Empty))){throw 'A referenced group or role principal ID is invalid.'}}
            $filter=($batch|ForEach-Object {"id eq '$_'"}) -join ' or '
            $rows=Read-All groups ('v1.0/groups?$select=id,displayName,visibility,isAssignableToRole&$filter='+[uri]::EscapeDataString($filter))
            $groupReadsComplete=$groupReadsComplete -and $complete.groups
            foreach($row in $rows){$selected.Add($row)}
        }
        $groups=@($selected.ToArray());$complete.groups=$groupReadsComplete -and $complete.users -and $complete.roleAssignments -and $complete.roleEligibility -and $complete.roleAssignmentScheduleInstances
        $missing=@(@($policyGroups)+@($AdditionalGroupIds)|Where-Object {$_ -notin $groups.id})
        if($missing.Count){$complete.groups=$false;$errors.Add(@{collection='groups';message='Some policy or account-set groups could not be read. Their membership cannot be confirmed.'})}
    }else{$groups=Read-All groups 'v1.0/groups?$select=id,displayName,visibility,isAssignableToRole'}
    $groupMembers=@{}
    $tracking.batchTotal=$groups.Count;$tracking.batchCompleted=0;$tracking.batchLabel='Groups checked'
    foreach($group in $groups){
        $members=Read-All ("members:"+$group.id) ("v1.0/groups/"+$group.id+'/transitiveMembers/microsoft.graph.user?$select=id&$count=true')
        if($complete["members:"+$group.id]){$groupMembers[$group.id]=@($members|ForEach-Object {$_.id})}else{$groupMembers[$group.id]=$null}
        $tracking.batchCompleted++;Report-Collection
    }
    $tracking.batchTotal=0;$tracking.batchCompleted=0;$tracking.batchLabel=''
    $complete.groupMembers=$complete.groups -and @($groups|Where-Object {$null -eq $groupMembers[$_.id]}).Count -eq 0
    $strengths=Read-All authenticationStrengths 'v1.0/policies/authenticationStrengthPolicies'
    foreach($strength in $strengths){
        $configurations=Read-All ('strengthConfigurations:'+$strength.id) ('v1.0/policies/authenticationStrengthPolicies/'+$strength.id+'/combinationConfigurations')
        if($strength -is [Collections.IDictionary]){$strength['combinationConfigurations']=$configurations}else{$strength|Add-Member -NotePropertyName combinationConfigurations -NotePropertyValue $configurations -Force}
    }
    $locations=Read-All namedLocations 'v1.0/identity/conditionalAccess/namedLocations'
    # v1.0 does not document the compliant-network subtype. Retain a separate
    # beta read with its own completeness; failure must not erase IP locations.
    $compliantLocations=Read-All compliantNetworkLocations 'beta/identity/conditionalAccess/namedLocations?$filter=isof(''microsoft.graph.compliantNetworkNamedLocation'')'
    $apps=Read-All applications 'v1.0/servicePrincipals?$select=id,appId,displayName'
    $attributeDefinitions=@();$applicationAttributes=@()
    $complete.applicationAttributeDefinitions=$false;$complete.applicationAttributes=$false
    if($IncludeApplicationAttributes){
        $attributeDefinitions=Read-All applicationAttributeDefinitions 'v1.0/directory/customSecurityAttributeDefinitions'
        $applicationAttributes=Read-All applicationAttributes 'v1.0/servicePrincipals?$select=id,appId,customSecurityAttributes'
    }
    $deviceRegistration=Read-Object deviceRegistrationPolicy 'v1.0/policies/deviceRegistrationPolicy'
    $groupEligibility=[Collections.Generic.List[object]]::new();$groupAssignments=[Collections.Generic.List[object]]::new();$directMembers=@{}
    $complete.pimGroupEligibility=$false;$complete.pimGroupAssignments=$false;$complete.groupDirectMembers=$false
    if($IncludePimGroups){
        $tracking.batchTotal=3*$groups.Count;$tracking.batchCompleted=0;$tracking.batchLabel='Temporary-group reads completed'
        for($groupIndex=0;$groupIndex -lt $groups.Count;$groupIndex++){
            $group=$groups[$groupIndex]
            $filter=[uri]::EscapeDataString("groupId eq '"+([string]$group.id).Replace("'","''")+"'")
            foreach($item in (Read-All ('pimGroupEligibility:'+$group.id) ('v1.0/identityGovernance/privilegedAccess/group/eligibilityScheduleInstances?$filter='+$filter))){$groupEligibility.Add($item)}
            foreach($item in (Read-All ('pimGroupAssignments:'+$group.id) ('v1.0/identityGovernance/privilegedAccess/group/assignmentScheduleInstances?$filter='+$filter))){$groupAssignments.Add($item)}
            $direct=Read-All ('groupDirectMembers:'+$group.id) ('v1.0/groups/'+[uri]::EscapeDataString($group.id)+'/members?$select=id')
            $directMembers[$group.id]=if($complete['groupDirectMembers:'+$group.id]){@($direct|ForEach-Object {$_.id})}else{$null}
            if($ReferencedGroupsOnly){
                $dependencies=@(@($direct|Where-Object {$_.'@odata.type' -ne '#microsoft.graph.servicePrincipal'}|ForEach-Object {$_.id})+@($groupEligibility|Where-Object {$_.groupId -eq $group.id}|ForEach-Object {$_.principalId})+@($groupAssignments|Where-Object {$_.groupId -eq $group.id}|ForEach-Object {$_.principalId})|Where-Object {$_ -and !$userIds.Contains($_) -and $_ -notin $groups.id}|Sort-Object -Unique)
                if($dependencies.Count){
                    # Expand only membership sources needed by these PIM groups.
                    $tracking.batchLabel='';$tracking.batchTotal=0
                    foreach($dependency in $dependencies){
                        if(![guid]::TryParse($dependency,[ref]([guid]::Empty))){$complete['groupDirectMembers:'+$group.id]=$false;continue}
                        $wasComplete=$complete.groups
                        $extra=Read-All groups ('v1.0/groups?$select=id,displayName,visibility,isAssignableToRole&$filter='+[uri]::EscapeDataString("id eq '$dependency'"))
                        $complete.groups=$wasComplete -and $complete.groups
                        if(!$extra.Count){$complete['groupDirectMembers:'+$group.id]=$false;continue}
                        foreach($nested in $extra){
                            if($nested.id -in $groups.id){continue}
                            $groups+=,$nested
                            $nestedMembers=Read-All ('members:'+$nested.id) ('v1.0/groups/'+$nested.id+'/transitiveMembers/microsoft.graph.user?$select=id&$count=true')
                            $groupMembers[$nested.id]=if($complete['members:'+$nested.id]){@($nestedMembers|ForEach-Object {$_.id})}else{$null}
                        }
                    }
                    $tracking.batchLabel='Temporary-group reads completed';$tracking.batchTotal=3*$groups.Count
                }
            }
        }
        foreach($name in @('pimGroupEligibility','pimGroupAssignments','groupDirectMembers')){$complete[$name]=$complete.groups -and @($groups|Where-Object {!$complete[$name+':'+$_.id]}).Count -eq 0}
        $complete.groupMembers=$complete.groups -and @($groups|Where-Object {$null -eq $groupMembers[$_.id]}).Count -eq 0
    }
    return @{
        caGapSnapshotVersion=1;tenantId=$TenantId;tenantName=$orgs[0].displayName;capturedAtUtc=[DateTime]::UtcNow.ToString('o')
        groupCatalogScope=$(if($ReferencedGroupsOnly){'referenced'}else{'all'})
        policies=$policies;users=$users;groups=$groups;groupMembers=$groupMembers;roles=$roles;roleAssignments=$assignments;roleEligibility=$eligible;namedLocations=$locations;applications=$apps
        deviceRegistrationPolicy=$deviceRegistration;roleAssignmentScheduleInstances=$assignmentSchedules;authenticationStrengths=$strengths;completeness=$complete;errors=@($errors.ToArray())
        pimGroupEligibility=@($groupEligibility.ToArray());pimGroupAssignments=@($groupAssignments.ToArray());groupDirectMembers=$directMembers
        compliantNetworkLocations=$compliantLocations
        riskHistory=$riskHistory
        intuneAppProtections=$intunePolicies.ToArray()
        resourceGroups=@()
        applicationAttributeDefinitions=$attributeDefinitions;applicationAttributes=$applicationAttributes
        applicationAttributeReadScope='unverified'
        scopeNotes=@($(if($ReferencedGroupsOnly){'Group collection is limited to CA policy references, role-assignment principals and explicitly requested account-set groups. Other group membership remains unknown.'}else{'All directory groups were requested.'}),'Current group memberships, active role assignments, role eligibility and role assignment schedule instances are collected. PIM for Groups collection is optional and has separate completeness flags.','Privileged role classification uses the Microsoft Graph beta isPrivileged property.','External home-tenant IDs are not inferred from names or email addresses.')
    }
}
