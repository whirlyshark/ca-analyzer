'use strict';
const CoverageProgress={
 compile(source,profile,onProgress){
  return this.prepare(source,profile,onProgress,'compile');
 },
 review(source,profile){return this.prepare(source,profile,()=>{},'review');},
 prepare(source,profile,onProgress,action){
  return new Promise((resolve,reject)=>{
   const worker=new Worker('/coverage-worker.js');
   const finish=(error,value)=>{clearTimeout(timer);worker.terminate();error?reject(error):resolve(value);};
   const timer=setTimeout(()=>finish(Error('Preparing this data took too long. Try a smaller export or use the offline PowerShell command.')),120000);
   worker.onmessage=({data})=>{if(data.type==='progress')onProgress(data);else if(data.type==='compiled')finish(null,data.compiled);else if(data.type==='reviewed')finish(null,data.result);else if(data.type==='error')finish(Error(data.message));};
   worker.onerror=()=>finish(Error('Could not prepare this data in the background. Refresh CALens and try again.'));
   try{worker.postMessage({action,input:source.original||source.model,profile,key:source.key,name:source.name,kind:source.kind,isDemo:source.isDemo});}catch(error){finish(error);}
  });
 },
 async request(path,body,token,onProgress){
  const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':token,'X-Coverage-Progress':'1'},body:JSON.stringify({...body,streamProgress:true})});
  if(!response.ok){let error;try{error=await response.json();}catch{}throw Error(error?.error||'Could not start the coverage check.');}
  if(!response.body||!response.headers.get('content-type')?.includes('application/x-ndjson'))throw Error('Refresh CALens to connect to the updated local service.');
  return this.read(response.body.getReader(),onProgress);
 },
 async read(reader,onProgress){
  const decoder=new TextDecoder();let pending='',result,finished=false,paged=false,expected=0,pageIndex=0;
  function consume(line){
   if(!line.trim())return;
   let event;try{event=JSON.parse(line);}catch{throw Error('The local service sent an invalid progress update. Please check again.');}
   if(!event||typeof event!=='object')throw Error('The local service sent an invalid progress update. Please check again.');
   if(finished)throw Error('The service returned data after the final result.');
   if(event.type==='progress')onProgress(event);
   else if(event.type==='resultStart'){if(paged||!event.result||typeof event.result.status!=='string'||!Number.isSafeInteger(event.findingCount)||event.findingCount<0)throw Error('Invalid coverage result header.');paged=true;expected=event.findingCount;result={...event.result,gaps:[]};onProgress({stage:'results',message:'Opening findings',completed:0,total:expected,unit:'findings'});}
   else if(event.type==='resultPage'){if(!paged||event.index!==pageIndex++)throw Error('Missing or repeated finding page.');const decoded=ReportCodec.decode(event.page);if(!Array.isArray(decoded.gaps))throw Error('Invalid finding page.');for(const gap of decoded.gaps)result.gaps.push(gap);if(result.gaps.length>expected)throw Error('Unexpected finding count.');onProgress({stage:'results',message:'Opening findings',completed:result.gaps.length,total:expected,unit:'findings'});}
   else if(event.type==='resultEnd'){if(!paged||event.findingCount!==expected||event.pages!==pageIndex||result.gaps.length!==expected)throw Error('Incomplete finding pages.');finished=true;}
   else if(event.type==='result'){if(paged)throw Error('Conflicting coverage results.');if(!event.result||typeof event.result.status!=='string')throw Error('The coverage result was incomplete.');result=typeof ReportCodec!=='undefined'?ReportCodec.decode(event.result):event.result;finished=true;}
   else if(event.type==='error')throw Error(event.message||'The coverage check failed.');
   else if(event.type!=='heartbeat')throw Error('The service returned an unknown progress update.');
  }
  try{
   while(true){const {value,done}=await reader.read();if(done){pending+=decoder.decode();break;}pending+=decoder.decode(value,{stream:true});let newline;while((newline=pending.indexOf('\n'))>=0){consume(pending.slice(0,newline));pending=pending.slice(newline+1);}}
   if(pending.trim())consume(pending);
   if(!finished)throw Error('The connection ended before the coverage check finished. Please check again.');
   return result;
  }catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 }
};
if(typeof module!=='undefined')module.exports=CoverageProgress;
