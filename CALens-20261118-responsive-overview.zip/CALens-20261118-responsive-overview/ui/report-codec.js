'use strict';
// Lossless storage/transport for repeated scenario axes. No findings are sampled.
const ReportCodec=(()=>{
 const views=new WeakMap();
 const marker='_calensDetailPool',own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
 function decode(value){
  if(value&&own(value,'_calensReviewRows')){
   if(value._calensReviewRows!==1||!Array.isArray(value.strings)||value.strings.some(s=>typeof s!=='string')||!Array.isArray(value.rows))throw Error('Invalid finding index.');
   const str=i=>{if(i===-1)return null;if(!Number.isInteger(i)||i<0||i>=value.strings.length)throw Error('Invalid finding index reference.');return value.strings[i];};
   return {gaps:value.rows.map(row=>{
    if(!Array.isArray(row)||(row.length!==9&&row.length!==10)||typeof row[0]!=='string'||!Array.isArray(row[2])||row[2].length===0)throw Error('Invalid finding index row.');
    const g={key:row[0],requirementId:str(row[1]),identityIds:row[2].map(str),coverageIssueIndices:row[4]||[],acceptance:row[5],detailsDeferred:true,applicablePolicyIds:row.length===10?row[9].map(str):undefined,witness:{authentication:str(row[6]),compliant:str(row[7]),hybridJoined:str(row[8])}};
    if(row[3]!==-2)g.assessmentStatus=str(row[3]);return g;
   })};
  }

  if(value&&own(value,'_calensFindingPages')){
   const info=value._calensFindingPages;if(!info||info.version!==1||!Number.isSafeInteger(info.count)||info.count<0||!Array.isArray(info.pages)||own(value,'gaps'))throw Error('Invalid paged coverage result.');
   const gaps=[];for(const page of info.pages){const decoded=decode(page);if(!Array.isArray(decoded.gaps))throw Error('Missing finding page.');for(const gap of decoded.gaps)gaps.push(gap);}
   if(gaps.length!==info.count)throw Error('Incomplete finding pages.');const result={...value,gaps};delete result._calensFindingPages;return result;
  }
  if(!value||!own(value,marker))return value;
  const pool=value[marker];
  if(!pool||pool.version!==1||!Array.isArray(value.gaps)||!['strings','regions','witnesses'].every(k=>Array.isArray(pool[k])))throw Error('Unsupported shared coverage result.');
  if(value.gaps.length>1000000||['strings','regions','witnesses'].some(k=>pool[k].length>2000000))throw Error('Coverage result is too large.');
  if(pool.strings.some(a=>!Array.isArray(a)||a.some(s=>typeof s!=='string')))throw Error('Invalid shared coverage values.');
  const index=(v,rows)=>{if(!Number.isInteger(v)||v<0||v>=rows.length)throw Error('Invalid shared coverage reference.');return rows[v];};
  const caches={regions:new Map(),witnesses:new Map()};let cells=0;
  function details(ref,key,table){
   if(!ref||Object.keys(ref).length!==1||!own(ref,key))throw Error('Invalid shared coverage details.');
   const row=index(ref[key],pool[table]);let result=caches[table].get(ref[key]);
   if(!result){
    if(!Array.isArray(row)||!row.length)throw Error('Invalid shared coverage row.');
    const names=index(row[0],pool.strings),region=table==='regions';
    if(new Set(names).size!==names.length||(region?row.length!==names.length+1:row.length!==2))throw Error('Invalid shared coverage axes.');
    const values=region?null:index(row[1],pool.strings);if(values&&values.length!==names.length)throw Error('Invalid shared coverage witness.');
    result=Object.fromEntries(names.map((name,i)=>[name,region?index(row[i+1],pool.strings):values[i]]));caches[table].set(ref[key],result);
   }
   return {...result};
  }
  const output={...value,gaps:value.gaps.map(g=>{
   // Validate references now; create wide scenario maps only when inspected.
   for(const [field,key,table] of [['region','$region','regions'],['witness','$witness','witnesses']]){const ref=g[field];if(!ref||Object.keys(ref).length!==1||!own(ref,key))throw Error('Invalid shared coverage details.');index(ref[key],pool[table]);}
   let region,witness;const gap={...g};Object.defineProperties(gap,{region:{enumerable:true,configurable:true,get:()=>region??(region=details(g.region,'$region','regions'))},witness:{enumerable:true,configurable:true,get:()=>witness??(witness=details(g.witness,'$witness','witnesses'))}});
   views.set(gap,{region:()=>region||details(g.region,'$region','regions'),witness:()=>witness||details(g.witness,'$witness','witnesses')});
   for(const key of ['identityIds','applicablePolicyIds','nonApplicablePolicyIds'])if(own(g,key)){
    const ref=g[key];if(!ref||Object.keys(ref).length!==1||!own(ref,'$strings'))throw Error('Invalid shared coverage list.');gap[key]=index(ref.$strings,pool.strings);
   }return gap;
  })};delete output[marker];return output;
 }
 function encode(value,force=false){
  if(!value||!Array.isArray(value.gaps)||!value.gaps.length||own(value,marker))return value;
  if(!force&&value.gaps.length<256){let size=0;const widths=new WeakMap();for(const gap of value.gaps)for(const values of Object.values(gap.region||{})){if(!widths.has(values))widths.set(values,values.reduce((n,s)=>n+s.length+3,0));size+=widths.get(values);}if(size<1048576)return value;}
  if(!force&&value.gaps.length>4096){const pages=[];for(let i=0;i<value.gaps.length;i+=512)pages.push(encode({gaps:value.gaps.slice(i,i+512)},true));const result={...value,_calensFindingPages:{version:1,count:value.gaps.length,pages}};delete result.gaps;return result;}
  const pool={version:1,strings:[],regions:[],witnesses:[]},tables={strings:new Map(),regions:new Map(),witnesses:new Map()},refs=new WeakMap();
  function add(table,row){const key=JSON.stringify(row),map=tables[table];if(!map.has(key)){map.set(key,pool[table].length);pool[table].push(row);}return map.get(key);}
  function strings(a){if(!Array.isArray(a)||a.some(s=>typeof s!=='string'))throw Error('Invalid coverage values.');if(refs.has(a))return refs.get(a);const id=add('strings',a);refs.set(a,id);return id;}
  return {...value,gaps:value.gaps.map(g=>{
   const region=views.get(g)?.region()||g.region,witness=views.get(g)?.witness()||g.witness;const names=Object.keys(region),wnames=Object.keys(witness);
   const metadata=Object.fromEntries(Object.entries(Object.getOwnPropertyDescriptors(g)).filter(([key])=>key!=='region'&&key!=='witness').map(([key,descriptor])=>[key,descriptor.value]));
   const copy={...metadata,region:{$region:add('regions',[strings(names),...names.map(n=>strings(region[n]))])},witness:{$witness:add('witnesses',[strings(wnames),strings(wnames.map(n=>witness[n]))])}};
   for(const key of ['identityIds','applicablePolicyIds','nonApplicablePolicyIds'])if(own(g,key))copy[key]={$strings:strings(g[key])};return copy;
  }),[marker]:pool};
 }
 return {encode,decode};
})();
if(typeof module!=='undefined')module.exports=ReportCodec;
