'use strict';
const CoverageSummary={
 build(result,model,definitions=[]){
  const scoped=new Set();
  const identities=model.identities||[];
  const identityIds=new Set(identities.map(u=>u.id)),declared=definitions.filter(r=>r.enabled!==false),compiledIds=new Set((model.requirements||[]).map(r=>r.id)),issues=result.coverageIssues||[];
  const pending=new Map();
  for(const issue of issues){
   if(issue?.code!=='requirement-not-evaluated'||typeof issue.requirementId!=='string'||compiledIds.has(issue.requirementId)||!declared.some(r=>r.id===issue.requirementId)||!Array.isArray(issue.accountIds)||issue.accountIds.some(id=>typeof id!=='string'||!identityIds.has(id))||typeof issue.message!=='string'||!issue.message.trim())continue;
   if(!pending.has(issue.requirementId))pending.set(issue.requirementId,{requirementId:issue.requirementId,accountIds:new Set(),messages:new Set()});
   const check=pending.get(issue.requirementId);issue.accountIds.forEach(id=>check.accountIds.add(id));check.messages.add(issue.message);
  }
  for(const issue of issues)if(pending.has(issue?.requirementId)&&typeof issue.message==='string'&&issue.message.trim())pending.get(issue.requirementId).messages.add(issue.message);
  const unassessedChecks=[...pending.values()].map(c=>({...c,accountIds:[...c.accountIds],messages:[...c.messages]})),unassessedIds=new Set(unassessedChecks.flatMap(c=>c.accountIds));
  const scopes=new Map();
  const idsFor=r=>{
   if(scopes.has(r))return scopes.get(r);
   const include=new Set(r.includeUsers||['*']),exclude=new Set(r.excludeUsers||[]);
   const ids=identities.filter(u=>(r.scope!=='privileged'||u.privileged||u.pimEligible)&&(include.has('*')||include.has(u.id))&&!exclude.has('*')&&!exclude.has(u.id)).map(u=>u.id);
   scopes.set(r,ids);return ids;
  };
  for(const r of model.requirements||[])idsFor(r).forEach(id=>scoped.add(id));
  unassessedIds.forEach(id=>scoped.add(id));
  const affected=new Set(),review=new Set();
  for(const gap of result.gaps||[])for(const id of gap.identityIds){affected.add(id);if(!gap.acceptance)review.add(id);}
  unassessedIds.forEach(id=>{affected.add(id);review.add(id);});
  const complete=result.status==='completeWithinModel'&&!result.coverageIssues?.length;
  // An unresolved check must withhold the overall score, but a diagnostic for
  // one declared requirement does not invalidate a different completed check.
  // Unknown/global diagnostic scopes and engine limits remain conservative.
  const engineComplete=result.status==='completeWithinModel'||result.status==='unresolvedCoverage'&&result.engineStatus==='completeWithinModel';
  const belongs=(id,base)=>id===base||[':outside-network',':outside-apps',':outside-device'].some(s=>id===base+s);
  const knownScope=id=>typeof id==='string'&&(compiledIds.has(id)||pending.has(id)||declared.some(r=>(compiledIds.has(r.id)||pending.has(r.id))&&belongs(id,r.id)));
  const globalIssue=issues.some(i=>!i||!knownScope(i.requirementId));
  const passed=scoped.size-affected.size;
  const score=complete&&scoped.size?(passed===scoped.size?100:Math.min(99.9,Math.round(passed/scoped.size*1000)/10)):null;
  const byRequirement=new Map();
  for(const gap of result.gaps||[]){let rows=byRequirement.get(gap.requirementId);if(!rows)byRequirement.set(gap.requirementId,rows=[]);rows.push(gap);}
  const requirements=declared.map(r=>{
   const requirementGaps=[r.id,...[':outside-network',':outside-apps',':outside-device'].map(s=>r.id+s)].flatMap(id=>byRequirement.get(id)||[]);
   const matches=id=>belongs(id,r.id);
   const compiled=(model.requirements||[]).filter(c=>matches(c.id));
   const checked=new Set(compiled.flatMap(idsFor));
   const failed=new Set(requirementGaps.flatMap(g=>g.identityIds));
   const notEvaluated=pending.get(r.id)?.accountIds||new Set();notEvaluated.forEach(id=>{checked.add(id);failed.add(id);});
   const requirementComplete=engineComplete&&compiled.length>0&&checked.size>0&&!globalIssue&&!issues.some(i=>matches(i.requirementId))&&!(result.emptyRequirementIds||[]).some(matches);
   const confirmed=new Set(requirementGaps.filter(g=>(g.assessmentStatus==='gapWithinModel'||g.assessmentStatus===undefined&&requirementComplete)).flatMap(g=>g.identityIds));
   return {id:r.id,name:r.name,checked:checked.size,unassessed:notEvaluated.size,affected:failed.size,confirmedAffected:confirmed.size,unverifiedOnlyAffected:[...failed].filter(id=>!confirmed.has(id)).length,complete:requirementComplete,passed:requirementComplete?checked.size-failed.size:null};
  });
  const confirmed=new Set((result.gaps||[]).filter(g=>g.assessmentStatus==='gapWithinModel'||g.assessmentStatus===undefined&&(complete||requirements.some(r=>r.complete&&belongs(g.requirementId,r.id)))).flatMap(g=>g.identityIds));
  return {complete,score,checked:scoped.size,total:identities.length,unassessedAccounts:unassessedIds.size,unassessedChecks,affected:affected.size,confirmedAffected:confirmed.size,unverifiedOnlyAffected:[...affected].filter(id=>!confirmed.has(id)).length,toReview:review.size,acceptedOnly:[...affected].filter(id=>!review.has(id)).length,passed:complete?passed:null,unchecked:identities.length-scoped.size,requirements};
 },
 requirementLabel(r){
  if(!r.affected)return r.complete?'All meet requirement':'Not fully checked';
  if(r.complete)return `${r.affected} affected`;
  if(r.confirmedAffected&&r.unverifiedOnlyAffected)return `${r.confirmedAffected} affected / ${r.unverifiedOnlyAffected} to investigate`;
  return r.confirmedAffected?`${r.affected} affected / Check incomplete`:`${r.affected} to investigate`;
 }
};
if(typeof module!=='undefined')module.exports=CoverageSummary;
