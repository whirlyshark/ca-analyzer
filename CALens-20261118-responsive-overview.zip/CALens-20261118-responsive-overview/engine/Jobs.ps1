# A local job owns its worker independently of any browser connection.
$script:assessmentJob=$null
function Update-CaJob {
 $job=$script:assessmentJob;if(!$job){return}
 $entry=$null;while($job.queue.TryDequeue([ref]$entry)){$job.progress=$entry}
 if($job.status -in @('running','cancelling') -and $job.handle.IsCompleted){
  try{if($job.status -eq 'cancelling'){$job.status='cancelled';return};$output=@($job.worker.EndInvoke($job.handle));if($job.worker.HadErrors){throw $job.worker.Streams.Error[0]};if($output.Count -ne 1){throw 'No complete assessment was returned.'};$job.result=$output[0];$job.status='complete'}catch{$job.error=Get-CaAssessmentErrorMessage $_.Exception;$job.status='failed'}finally{$job.worker.Dispose()}
 }
}
function Start-CaJob($Body,[string]$Root){
 Update-CaJob
 if($script:assessmentJob -and $script:assessmentJob.status -in @('running','cancelling')){throw 'An assessment is already running. Open its progress or cancel it first.'}
 $queue=[Collections.Concurrent.ConcurrentQueue[object]]::new();$worker=[powershell]::Create()
 $null=$worker.AddScript({param($root,$body,$queue)
  $ErrorActionPreference='Stop';Import-Module (Join-Path $root 'CA.GapAnalyzer.psd1') -Force
  . (Join-Path $root 'engine/Interactive.ps1');. (Join-Path $root 'engine/Assessment.ps1');. (Join-Path $root 'engine/LocalState.ps1')
  $progress={param($event);$queue.Enqueue($event);while($queue.Count -gt 20){$discard=$null;$null=$queue.TryDequeue([ref]$discard)}}
  if($body.snapshot){Invoke-CaInteractiveAssessment $body.snapshot $body.profile -Progress $progress}
  else{$result=Invoke-CaAssessmentCore -Model $body.model -CoverageIssues @($body.coverageIssues) -Acceptances (Read-CaLocalState -Path (Join-Path $root 'data/acceptances.local.json')) -SourceKey ([string]$body.sourceKey) -AcceptanceEvidence $body.acceptanceEvidence -Progress $progress;$result.reviewContext=$body.reviewContext;return $result}
 }).AddArgument($Root).AddArgument($Body).AddArgument($queue)
 $script:assessmentJob=@{id=[guid]::NewGuid().ToString('N');status='running';startedAtUtc=[DateTime]::UtcNow.ToString('o');worker=$worker;queue=$queue;handle=$worker.BeginInvoke();progress=@{stage='prepare';message='Starting assessment'};result=$null;error=$null}
}
function Get-CaJobStatus {
 Update-CaJob;$job=$script:assessmentJob;if(!$job){return @{status='idle'}}
 return @{id=$job.id;status=$job.status;startedAtUtc=$job.startedAtUtc;progress=$job.progress;error=$job.error}
}
function Stop-CaJob([string]$Id){
 Update-CaJob;$job=$script:assessmentJob;if(!$job -or $job.id -cne $Id){throw 'Assessment no longer exists.'}
 if($job.status -eq 'running'){$job.status='cancelling';$null=$job.worker.BeginStop($null,$null)}
}
