function New-CaJavascriptEngine {
    $runtimeRoot=Join-Path (Split-Path $PSScriptRoot) 'dependencies/runtime/win-x64'
    if(-not $IsWindows -or [Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture -ne 'X64'){throw 'The bundled offline compiler currently requires Windows x64 PowerShell 7.4+. Browser-based analysis is platform independent.'}
    foreach($name in @('ClearScript.Core.dll','ClearScript.V8.ICUData.dll','ClearScript.V8.dll')){
        $path=Join-Path $runtimeRoot $name
        if(!(Test-Path -LiteralPath $path)){throw 'Offline compiler dependencies are missing. Run Initialize-Dependencies.ps1 once, then keep the dependencies folder with the analyzer.'}
        $null=[Reflection.Assembly]::LoadFrom($path)
    }
    $js=[Microsoft.ClearScript.V8.V8ScriptEngine]::new()
    try{
        $js.MaxRuntimeHeapSize=512MB
        # Inputs and compiler intermediates are JSON values. No CLR host object,
        # filesystem, network, require(), or arbitrary input script is exposed.
        $js.Execute('function structuredClone(value){return JSON.parse(JSON.stringify(value));}')
        foreach($file in @('report-codec.js','requirement-model.js','location-model.js','device-filter.js','external-users.js','role-schedules.js','pim-groups.js','resource-groups.js','session-controls.js','authentication-strengths.js','snapshot.js','coverage-summary.js','history-model.js','acceptance-model.js')){
            $js.Execute((Get-Content -LiteralPath (Join-Path (Split-Path $PSScriptRoot) ('ui/'+$file)) -Raw -Encoding utf8))
        }
        return $js
    }catch{$js.Dispose();throw}
}
