if(-not ('CaGapAnalyzer.ReportCodec' -as [type])){Add-Type -Path @((Join-Path $PSScriptRoot 'ReportCodec.cs'),(Join-Path $PSScriptRoot 'FindingStorage.cs'),(Join-Path $PSScriptRoot 'ReportHeaders.cs'))}
function ConvertTo-CaReportJson {param([AllowNull()]$Report);[CaGapAnalyzer.ReportCodec]::Serialize($Report)}
function ConvertTo-CaPackedReport {param([AllowNull()]$Report);return ,([CaGapAnalyzer.ReportCodec]::Pack($Report))}

function Write-CaReportFile {param($Report,[string]$Path);[CaGapAnalyzer.ReportCodec]::WriteFile($Report,$Path)}
