using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
namespace CaGapAnalyzer {
 public static class ReportHeaders {
  // Scan tokens without expanding or retaining the finding pages.
  public static string Read(string path){
   var wanted=new HashSet<string>(new[]{"sourceName","reviewContextVersion","sourceKey","assessmentVersion","coverageSummary","runAtUtc","snapshotCapturedAtUtc","status","modelHash"},StringComparer.Ordinal);
   using var file=File.OpenRead(path);using var output=new MemoryStream();using var writer=new Utf8JsonWriter(output);writer.WriteStartObject();
   byte[] buffer=new byte[65536];int held=0;var state=new JsonReaderState(new JsonReaderOptions{MaxDepth=100});bool capture=false;
   while(true){int read=file.Read(buffer,held,buffer.Length-held);bool final=read==0;int length=held+read;var reader=new Utf8JsonReader(buffer.AsSpan(0,length),final,state);
    while(reader.Read()){
     var token=reader.TokenType;int depth=reader.CurrentDepth;
     if(token==JsonTokenType.PropertyName&&depth==1){capture=wanted.Contains(reader.GetString());if(capture)writer.WritePropertyName(reader.GetString());continue;}
     if(!capture)continue;
     switch(token){
      case JsonTokenType.StartObject:writer.WriteStartObject();break;case JsonTokenType.EndObject:writer.WriteEndObject();break;
      case JsonTokenType.StartArray:writer.WriteStartArray();break;case JsonTokenType.EndArray:writer.WriteEndArray();break;
      case JsonTokenType.PropertyName:writer.WritePropertyName(reader.GetString());break;case JsonTokenType.String:writer.WriteStringValue(reader.GetString());break;
      case JsonTokenType.Number:writer.WriteRawValue(reader.ValueSpan,true);break;case JsonTokenType.True:writer.WriteBooleanValue(true);break;case JsonTokenType.False:writer.WriteBooleanValue(false);break;case JsonTokenType.Null:writer.WriteNullValue();break;
     }
     if(depth==1&&token!=JsonTokenType.StartObject&&token!=JsonTokenType.StartArray)capture=false;
    }
    int consumed=(int)reader.BytesConsumed;state=reader.CurrentState;held=length-consumed;if(held>0)Buffer.BlockCopy(buffer,consumed,buffer,0,held);
    if(final){if(held!=0)throw new JsonException("Incomplete report JSON.");break;}
    if(held==buffer.Length){if(buffer.Length>=16*1024*1024)throw new JsonException("Oversized report token.");Array.Resize(ref buffer,buffer.Length*2);}
   }
   writer.WriteEndObject();writer.Flush();return Encoding.UTF8.GetString(output.ToArray());
  }
 }
}
