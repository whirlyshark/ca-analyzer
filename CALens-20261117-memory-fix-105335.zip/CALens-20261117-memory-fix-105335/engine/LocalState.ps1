# Local JSON state is shared by app instances and unattended readers. Keep the
# entire read/modify/replace operation under an OS file lock, not just the write.
# Lock files remain in place; an abandoned process releases its file handle.
function Invoke-CaLocalStateLock {
    param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][scriptblock]$Action,[ValidateRange(1,60000)][int]$TimeoutMilliseconds=10000)
    $resolved=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
    $null=[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($resolved))
    $handle=$null;$clock=[Diagnostics.Stopwatch]::StartNew()
    try{
        while(!$handle){
            try{$handle=[IO.File]::Open(($resolved+'.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
            catch [IO.IOException]{
                if(($_.Exception.HResult -band 0xffff) -notin @(32,33)){throw}
                if($clock.ElapsedMilliseconds -ge $TimeoutMilliseconds){throw 'Another app instance is updating local settings. Please retry.'}
                [Threading.Thread]::Sleep(20)
            }
        }
        & $Action $resolved
    }finally{if($handle){$handle.Dispose()}}
}
function Read-CaLocalState {
    param([Parameter(Mandatory)][string]$Path,[AllowNull()]$DefaultValue=@{})
    if(!(Test-Path -LiteralPath $Path)){return ,$DefaultValue}
    Invoke-CaLocalStateLock -Path $Path -Action {param($resolved);if([IO.File]::Exists($resolved)){return ,(ConvertFrom-CaJson ([IO.File]::ReadAllText($resolved)))};return ,$DefaultValue}
}
function Update-CaLocalState {
    param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][scriptblock]$Update,[AllowNull()]$DefaultValue=@{})
    Invoke-CaLocalStateLock -Path $Path -Action {
        param($resolved)
        $current=if([IO.File]::Exists($resolved)){ConvertFrom-CaJson ([IO.File]::ReadAllText($resolved))}else{$DefaultValue}
        $updated=& $Update $current
        $temporary=$resolved+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try{
            $json=ConvertTo-Json -InputObject $updated -Depth 100 -Compress -ErrorAction Stop
            [IO.File]::WriteAllText($temporary,$json,[Text.UTF8Encoding]::new($false))
            [IO.File]::Move($temporary,$resolved,$true)
        }finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
        return ,$updated
    }
}
