# Reset only declared local app state. Never accept reset paths from the browser.
function Reset-CaLocalAppData {
    param([Parameter(Mandatory)][string]$Root)
    $rootPath=[IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $dataPath=[IO.Path]::GetFullPath((Join-Path $rootPath 'data'))
    function Assert-ResetPath([string]$Path){
        $resolved=[IO.Path]::GetFullPath($Path)
        if(!$resolved.StartsWith($rootPath+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Reset path escaped the app folder.'}
        $cursor=$resolved
        while($cursor){if(Test-Path -LiteralPath $cursor){if((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reset cannot move linked app-data paths.'}};if($cursor -eq $rootPath){break};$cursor=[IO.Path]::GetDirectoryName($cursor)}
        return $resolved
    }
    $null=Assert-ResetPath $dataPath
    Invoke-CaLocalStateLock -Path (Join-Path $dataPath 'reset.local.json') -Action {
        param($resetLock)
        $names=@('workspaces.local.json','acceptances.local.json','tag-rules.local.json','assessments')
        $targets=@(foreach($name in $names){$path=Assert-ResetPath (Join-Path $dataPath $name);if(Test-Path -LiteralPath $path){@{name=$name;path=$path;directory=[IO.Directory]::Exists($path)}}})
        # Reject links anywhere inside a history tree before moving any state.
        foreach($target in $targets){
            if($target.directory -ne ($target.name -eq 'assessments')){throw 'Unexpected app-data file type. Reset was not started.'}
            if($target.directory){$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($target.path);while($queue.Count){foreach($item in Get-ChildItem -LiteralPath $queue.Dequeue() -Force){$null=Assert-ResetPath $item.FullName;if($item.PSIsContainer){$queue.Enqueue($item.FullName)}}}}
        }
        if(!$targets.Count){return @{reset=$true;backup=$null;archivedItems=0}}
        $backupId=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
        $backupPath=Assert-ResetPath (Join-Path $dataPath "reset-backups/$backupId")
        $null=[IO.Directory]::CreateDirectory($backupPath)
        $moved=[Collections.Generic.List[object]]::new()
        try{
            foreach($target in $targets){
                $destination=Assert-ResetPath (Join-Path $backupPath $target.name)
                if($target.directory){[IO.Directory]::Move($target.path,$destination)}
                else{Invoke-CaLocalStateLock -Path $target.path -Action {param($path);if([IO.File]::Exists($path)){[IO.File]::Move($path,$destination)}}}
                $moved.Add(@{source=$target.path;destination=$destination;directory=$target.directory})
            }
            @{version=1;resetAtUtc=[DateTime]::UtcNow.ToString('o');items=@($targets|ForEach-Object {$_.name});restoration='Stop app instances, then move these archived items back into the app data folder. Preserve any newer state first.'}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $backupPath 'reset-info.json') -Encoding utf8
        }catch{
            $failure=$_
            for($index=$moved.Count-1;$index -ge 0;$index--){$item=$moved[$index];if(!(Test-Path -LiteralPath $item.source)){try{if($item.directory){[IO.Directory]::Move($item.destination,$item.source)}else{Invoke-CaLocalStateLock -Path $item.source -Action {param($path);[IO.File]::Move($item.destination,$path)}}}catch{throw "Reset could not finish. Archived state remains in data/reset-backups/$backupId; close other app instances before recovery."}}}
            throw $failure
        }
        return @{reset=$true;backup="data/reset-backups/$backupId";archivedItems=$moved.Count}
    }
}
