function Get-CaResourceGroupEvidence {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Snapshot,[Parameter(Mandatory)][guid]$UserId,[string[]]$ResourceIds,[string]$BearerToken,[scriptblock]$Request,[ValidateRange(1,10000)][int]$MaxResources=200)
    $ErrorActionPreference='Stop'
    $knownGroups=@('Office365','MicrosoftAdminPortals','797f4846-ba00-4fd7-ba43-dac1f8f63013')
    function Canonical-App([string]$Value){foreach($g in $knownGroups){if($Value -ieq $g){return $g}};if($Value -ieq 'All'){return 'All'};$parsed=[guid]::Empty;if([guid]::TryParse($Value,[ref]$parsed)){return $parsed.ToString()};return $Value}
    function Selector-Key($Assignment){
        if(!$Assignment){return $null}
        if($Assignment -isnot [Collections.IDictionary]){$Assignment=$Assignment|ConvertTo-Json -Depth 30|ConvertFrom-Json -AsHashtable -Depth 30}
        foreach($key in $Assignment.Keys){if($key -notin @('includeApplications','excludeApplications','includeUserActions','includeAuthenticationContextClassReferences','applicationFilter','@odata.type') -and $null -ne $Assignment[$key]){return $null}}
        if($null -ne $Assignment.applicationFilter -or $Assignment.includeUserActions -or $Assignment.includeAuthenticationContextClassReferences){return $null}
        $include=@($Assignment.includeApplications|ForEach-Object {Canonical-App $_}|Sort-Object -Unique);$exclude=@($Assignment.excludeApplications|ForEach-Object {Canonical-App $_}|Sort-Object -Unique)
        foreach($id in @($include)+@($exclude)){if($id -ne 'All' -and $id -notin $knownGroups -and ![guid]::TryParse([string]$id,[ref]([guid]::Empty))){return $null}}
        if(!$include.Count -or $exclude -contains 'All' -or !@($include+$exclude|Where-Object {$_ -in $knownGroups}).Count){return $null}
        return ($include -join ',')+'|'+($exclude -join ',')
    }
    if($Snapshot.caGapSnapshotVersion -ne 1 -or ![guid]::TryParse([string]$Snapshot.tenantId,[ref]([guid]::Empty))){throw 'Choose a tenant snapshot with a valid tenant ID.'}
    if($Snapshot.users -and $UserId.ToString() -notin $Snapshot.users.id){throw 'Choose a validation user present in the exported snapshot.'}
    $candidates=@{};foreach($p in $Snapshot.policies){if($p.state -notin @('enabled','enabledForReportingButNotEnforced') -or !$p.conditions.users -or $p.conditions.clientApplications){continue};$signature=Selector-Key $p.conditions.applications;if($signature){$candidates[[string]$p.id]=@{policy=$p;signature=$signature}}}
    if(!$candidates.Count){throw 'No resource-group policy can supply membership observations. Existing policy assignments were not changed.'}
    if(!$ResourceIds){$ResourceIds=@($Snapshot.applications.appId)+@($Snapshot.policies|ForEach-Object {$_.conditions.applications.includeApplications;$_.conditions.applications.excludeApplications}|Where-Object {[guid]::TryParse([string]$_,[ref]([guid]::Empty))})}
    $resources=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($id in $ResourceIds){$parsed=[guid]::Empty;if(![guid]::TryParse($id,[ref]$parsed)){throw 'ResourceIds must be application/resource GUIDs, not group names.'};$null=$resources.Add($parsed.ToString())}
    if(!$resources.Count){throw 'Select at least one resource ID.'}
    if($resources.Count -gt $MaxResources){throw "The snapshot has $($resources.Count) candidate resources. Select ResourceIds or explicitly raise MaxResources."}
    $facts=@{};foreach($g in $knownGroups){$facts[$g]=@{members=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase);nonMembers=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)}}
    $conflicts=[Collections.Generic.HashSet[string]]::new();$observations=[Collections.Generic.List[object]]::new();$headers=@{Authorization="Bearer $BearerToken"}
    try{foreach($resource in ($resources|Sort-Object)){
        $body=@{signInIdentity=@{'@odata.type'='#microsoft.graph.userSignIn';userId=$UserId.ToString()};signInContext=@{'@odata.type'='#microsoft.graph.applicationContext';includeApplications=@($resource)};signInConditions=@{clientAppType='browser';devicePlatform='windows';signInRiskLevel='none';userRiskLevel='none';ipAddress='203.0.113.42';deviceInfo=@{isCompliant=$false}};appliedPoliciesOnly=$false}
        $response=$null
        if($Request){$response=& $Request $body}else{
            if(!$BearerToken){throw 'A current Graph access token is required.'}
            for($attempt=0;$attempt -lt 8;$attempt++){try{$response=Invoke-RestMethod -Method Post -Uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/evaluate' -Headers $headers -ContentType application/json -Body ($body|ConvertTo-Json -Depth 30) -TimeoutSec 60;break}catch{
                $status=[int]$_.Exception.Response.StatusCode
                if($status -ne 429 -or $attempt -eq 7){throw "What If collection failed (HTTP $status). No sign-in, policy or permission was changed."}
                $delay=30;$retry=$_.Exception.Response.Headers.RetryAfter;if($retry.Delta){$delay=[Math]::Min(60,[Math]::Max(1,[Math]::Ceiling($retry.Delta.TotalSeconds)))};Write-Verbose "What If throttled; retrying after $delay seconds.";Start-Sleep -Seconds $delay
            }}
        }
        if($null -eq $response.value){throw 'What If did not return a policy result collection.'}
        foreach($row in $response.value){
            if(!$candidates.ContainsKey([string]$row.id) -or $row.policyApplies -isnot [bool]){continue}
            $candidate=$candidates[[string]$row.id];if((Selector-Key $row.conditions.applications) -cne $candidate.signature){continue}
            $condition=if($row.policyApplies -and $row.analysisReasons -ceq 'notSet'){$true}elseif(!$row.policyApplies -and $row.analysisReasons -ceq 'application'){$false}else{$null}
            if($null -eq $condition){continue}
            $a=$row.conditions.applications;$include=@($a.includeApplications|ForEach-Object {Canonical-App $_});$exclude=@($a.excludeApplications|ForEach-Object {Canonical-App $_})
            if(@($exclude|Where-Object {$_ -notin $knownGroups}) -contains $resource){continue}
            $inGroups=@($include|Where-Object {$_ -in $knownGroups}|Sort-Object -Unique);$outGroups=@($exclude|Where-Object {$_ -in $knownGroups}|Sort-Object -Unique)
            $constant=$include -contains 'All' -or @($include|Where-Object {$_ -notin $knownGroups}) -contains $resource
            $inGroups=@($inGroups|Where-Object {$_ -notin $outGroups})
            if(!$constant -and !$inGroups.Count){continue}
            $derived=@{}
            if($condition){foreach($g in $outGroups){$derived[$g]=$false};if(!$constant -and $inGroups.Count -eq 1){$derived[$inGroups[0]]=$true}}
            elseif($constant -and $outGroups.Count -eq 1){$derived[$outGroups[0]]=$true}
            elseif(!$constant -and !$outGroups.Count){foreach($g in $inGroups){$derived[$g]=$false}}
            foreach($g in $derived.Keys){$positive=$derived[$g];$pair=$g+'|'+$resource;$otherKey=if($positive){'nonMembers'}else{'members'};$targetKey=if($positive){'members'}else{'nonMembers'};$other=$facts[$g][$otherKey];$target=$facts[$g][$targetKey]
                if($other.Contains($resource)){$null=$conflicts.Add($pair);$null=$other.Remove($resource);$null=$target.Remove($resource)}
                elseif(!$conflicts.Contains($pair)){$null=$target.Add($resource)}
                $observations.Add(@{resourceId=$resource;groupId=$g;member=$positive;policyId=[string]$row.id})
            }
        }
    }}finally{$headers.Clear()}
    $observed=[DateTime]::UtcNow.ToString('o')
    $entries=@(foreach($g in $knownGroups){@{id=$g;members=@($facts[$g].members|Sort-Object);nonMembers=@($facts[$g].nonMembers|Sort-Object);complete=$false;provenance=@{kind='whatIf';observedAtUtc=$observed;description='Unambiguous Graph applicationContext resource-selector observations. Service dependencies, token scopes and successful sign-in are not inferred.'}}})
    return @{resourceGroupEvidenceVersion=1;tenantId=([guid]$Snapshot.tenantId).ToString();observedAtUtc=$observed;resourceGroups=$entries;queriedResourceIds=@($resources|Sort-Object);observations=@($observations.ToArray());conflictingFacts=@($conflicts|Sort-Object);scope='Partial resource membership evidence only. Ambiguous, missing, stale-selector and indeterminate responses leave membership unknown. Existing tokens/permissions are reused; no policy or sign-in is changed.'}
}
