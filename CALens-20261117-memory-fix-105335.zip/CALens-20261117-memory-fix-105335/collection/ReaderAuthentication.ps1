# App-only authentication for a dedicated read-only collection identity.
# No credentials are persisted, no permissions are granted and no browser is opened.
function Get-CaReaderCertificate {
    [CmdletBinding(DefaultParameterSetName='Store')]
    param(
        [Parameter(Mandatory,ParameterSetName='Store')][string]$CertificateThumbprint,
        [Parameter(ParameterSetName='Store')][ValidateSet('CurrentUser\My','LocalMachine\My')][string]$CertificateStore='CurrentUser\My',
        [Parameter(Mandatory,ParameterSetName='File')][string]$CertificatePath,
        [Parameter(ParameterSetName='File')][securestring]$CertificatePassword
    )
    if($PSCmdlet.ParameterSetName -eq 'Store'){
        $thumbprint=$CertificateThumbprint.Replace(' ','').Replace(':','')
        if($thumbprint -notmatch '^[a-fA-F0-9]{40}$'){throw 'Supply the reader certificate thumbprint (40 hexadecimal characters).'}
        try{return Get-Item -LiteralPath "Cert:\$CertificateStore\$thumbprint" -ErrorAction Stop}catch{throw 'The reader certificate is unavailable to this Windows identity. Check its store and private-key access.'}
    }
    try{
        $file=Get-Item -LiteralPath $CertificatePath -ErrorAction Stop
        if($file.PSIsContainer -or $file.Length -gt 1MB){throw 'Invalid certificate file.'}
        return [Security.Cryptography.X509Certificates.X509Certificate2]::new($file.FullName,$CertificatePassword,[Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    }catch{throw 'Could not open the reader certificate file. Check its path and password.'}
}
function New-CaReaderAssertion {
    param([Parameter(Mandatory)][guid]$TenantId,[Parameter(Mandatory)][guid]$ClientId,[Parameter(Mandatory)][Security.Cryptography.X509Certificates.X509Certificate2]$Certificate)
    $now=[DateTimeOffset]::UtcNow
    if(!$Certificate.HasPrivateKey -or $Certificate.NotBefore.ToUniversalTime() -gt $now.UtcDateTime -or $Certificate.NotAfter.ToUniversalTime() -le $now.UtcDateTime){throw 'The reader certificate must be currently valid and have an accessible private key.'}
    $rsa=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Certificate)
    if(!$rsa){throw 'Use an RSA reader certificate.'}
    try{
        if($rsa.KeySize -lt 2048){throw 'Use an RSA reader certificate with a key of at least 2048 bits.'}
        function Url64([byte[]]$Bytes){[Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+','-').Replace('/','_')}
        $header=@{alg='PS256';typ='JWT';'x5t#S256'=(Url64 ([Security.Cryptography.SHA256]::HashData($Certificate.RawData)))}
        $claims=@{aud="https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token";iss=$ClientId.ToString();sub=$ClientId.ToString();jti=[guid]::NewGuid().ToString();iat=$now.ToUnixTimeSeconds();nbf=$now.ToUnixTimeSeconds();exp=$now.AddMinutes(5).ToUnixTimeSeconds()}
        $unsigned=(Url64 ([Text.Encoding]::UTF8.GetBytes(($header|ConvertTo-Json -Compress))))+'.'+(Url64 ([Text.Encoding]::UTF8.GetBytes(($claims|ConvertTo-Json -Compress))))
        $signature=$rsa.SignData([Text.Encoding]::ASCII.GetBytes($unsigned),[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pss)
        $unsigned+'.'+(Url64 $signature)
    }finally{$rsa.Dispose()}
}
function Get-CaReaderToken {
    param([Parameter(Mandatory)][guid]$TenantId,[Parameter(Mandatory)][guid]$ClientId,[Parameter(Mandatory)][Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,[scriptblock]$AssertionFactory=${function:New-CaReaderAssertion})
    $assertion=& $AssertionFactory -TenantId $TenantId -ClientId $ClientId -Certificate $Certificate
    try{
        $response=Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token" -ContentType 'application/x-www-form-urlencoded' -Body @{client_id=$ClientId.ToString();scope='https://graph.microsoft.com/.default';grant_type='client_credentials';client_assertion_type='urn:ietf:params:oauth:client-assertion-type:jwt-bearer';client_assertion=$assertion} -MaximumRedirection 0 -TimeoutSec 60 -ErrorAction Stop
        $seconds=0
        if($response.access_token -isnot [string] -or !$response.access_token -or $response.token_type -ine 'Bearer' -or ![int]::TryParse([string]$response.expires_in,[ref]$seconds) -or $seconds -lt 120 -or $seconds -gt 86400){throw 'Invalid token response.'}
        @{accessToken=$response.access_token;expiresAtUtc=[DateTimeOffset]::UtcNow.AddSeconds($seconds)}
    }catch{throw 'Reader authentication failed. Check the app, uploaded certificate, consent and connectivity. No interactive sign-in was attempted.'}
    finally{$assertion=$null;$response=$null}
}
function New-CaCertificateGraphRequest {
    param([Parameter(Mandatory)][guid]$TenantId,[Parameter(Mandatory)][guid]$ClientId,[Parameter(Mandatory)][Security.Cryptography.X509Certificates.X509Certificate2]$Certificate)
    $readerTenant=$TenantId;$readerClient=$ClientId;$readerCertificate=$Certificate
    # GetNewClosure creates a dynamic module. Capture private helpers explicitly
    # so invocation from a nested command script does not rely on global scope.
    $getReaderToken=${function:Get-CaReaderToken};$makeReaderAssertion=${function:New-CaReaderAssertion}
    $tokenState=@{credential=$null}
    {
        param([string]$Uri)
        $target=[uri]$Uri
        if($target.Scheme -ne 'https' -or $target.Host -ne 'graph.microsoft.com' -or $target.UserInfo -or $target.Port -ne 443){throw 'Rejected non-Graph request.'}
        for($refresh=0;$refresh -le 1;$refresh++){
            if(!$tokenState.credential -or $tokenState.credential.expiresAtUtc -le [DateTimeOffset]::UtcNow.AddSeconds(60)){$tokenState.credential=& $getReaderToken -TenantId $readerTenant -ClientId $readerClient -Certificate $readerCertificate -AssertionFactory $makeReaderAssertion}
            try{return (Invoke-WebRequest -Method Get -Uri $Uri -Headers @{Authorization='Bearer '+$tokenState.credential.accessToken;ConsistencyLevel='eventual';Prefer='include-unknown-enum-members'} -MaximumRedirection 0 -TimeoutSec 60 -ErrorAction Stop).Content}
            catch{
                if($refresh -eq 0 -and [int]$_.Exception.Response.StatusCode -eq 401){$tokenState.credential=$null;continue}
                throw
            }
        }
    }.GetNewClosure()
}
