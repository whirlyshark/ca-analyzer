#Requires -Version 7.4
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SnapshotPath,
    [Parameter(Mandatory)][string]$ModelPath,
    [Parameter(Mandatory)][string]$CasesPath,
    [string]$OutputPath='./data/whatif-validation.local.json'
)
$ErrorActionPreference='Stop'
$snapshot=Get-Content -LiteralPath $SnapshotPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$model=Get-Content -LiteralPath $ModelPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$cases=Get-Content -LiteralPath $CasesPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$tenant=([guid]$snapshot.tenantId).ToString()
$account=az account show -o json|ConvertFrom-Json
if($LASTEXITCODE -or $account.tenantId -ne $tenant){throw 'Azure CLI must be signed into the snapshot tenant.'}
$credential=az account get-access-token --tenant $tenant --resource https://graph.microsoft.com -o json|ConvertFrom-Json
if($LASTEXITCODE -or !$credential.accessToken){throw 'Could not obtain a Graph token.'}
$headers=@{Authorization="Bearer $($credential.accessToken)"}
$results=[Collections.Generic.List[object]]::new()
try{
    # Fail if the policy snapshot changed before validation. This endpoint only reads.
    $current=Invoke-RestMethod -Uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies' -Headers $headers
    $policies=@($current.value)
    while($current.'@odata.nextLink'){
        $next=[uri]$current.'@odata.nextLink'
        if($next.Scheme -ne 'https' -or $next.Host -ne 'graph.microsoft.com' -or $next.Port -ne 443 -or $next.UserInfo){throw 'Invalid Graph pagination URL.'}
        $current=Invoke-RestMethod -Uri $next -Headers $headers;$policies+=@($current.value)
    }
    $expectedVersions=@($snapshot.policies|ForEach-Object {"$($_.id)|$($_.modifiedDateTime)"}|Sort-Object)
    $actualVersions=@($policies|ForEach-Object {"$($_.id)|$($_.modifiedDateTime)"}|Sort-Object)
    if(($expectedVersions -join "`n") -ne ($actualVersions -join "`n")){throw 'Tenant policies changed since export. Collect again before comparing.'}
    foreach($case in $cases){
        if($case.userId -notin $model.identities.id -or $case.applicationId -notin $model.dimensions.application){throw 'Validation case is outside the model.'}
        $point=@{application=$case.applicationId;accessTarget='application';client='browser';platform='windows';signInRisk='none';userRisk='none';flow='standard';compliant='false';hybridJoined='false';network='outside-known-locations'}
        if($model.dimensions.ContainsKey('userAction')){$point.userAction='none'}
        if($model.dimensions.network -notcontains $point.network){
            if(!$case.networkId -or !$case.ipAddress -or $case.networkId -notin $model.dimensions.network){throw 'Partitioned-network cases require a matching networkId and representative ipAddress. Use the lab matrix validator for automatic IP classification.'}
            $point.network=$case.networkId
        }
        foreach($dimension in $model.dimensions.Keys|Where-Object {$_ -like 'authenticationContext.*'}){$point[$dimension]='false'}
        if($case.authenticationContextId){
            if(!$model.dimensions.ContainsKey('authenticationContext.'+$case.authenticationContextId)){throw 'Context case is outside the model.'}
            $point.accessTarget='authenticationContext';$point['authenticationContext.'+$case.authenticationContextId]='true'
        }
        $expected=@(foreach($policy in $model.policies){
            if($policy.state -ne 'enabled' -or ($policy.includeUsers -notcontains '*' -and $policy.includeUsers -notcontains $case.userId) -or $policy.excludeUsers -contains $case.userId -or $policy.excludeUsers -contains '*'){continue}
            $matches=$true
            foreach($dimension in $policy.conditions.Keys){
                if(!$point.ContainsKey($dimension)){throw "Case does not specify policy condition $dimension"}
                $selector=$policy.conditions[$dimension];$value=$point[$dimension]
                if(($selector.include.Count -gt 0 -and $selector.include -notcontains $value) -or $selector.exclude -contains $value){$matches=$false;break}
            }
            if($matches){($policy.id -split ':context:')[0]}
        })|Sort-Object -Unique
        $body=@{signInIdentity=@{'@odata.type'='#microsoft.graph.userSignIn';userId=$case.userId};signInContext=@{'@odata.type'='#microsoft.graph.applicationContext';includeApplications=@($case.applicationId)};signInConditions=@{devicePlatform='windows';clientAppType='browser';signInRiskLevel='none';userRiskLevel='none';deviceInfo=@{isCompliant=$false}};appliedPoliciesOnly=$false}
        if($case.authenticationContextId){$body.signInContext=@{'@odata.type'='#microsoft.graph.authContext';authenticationContextValue=$case.authenticationContextId}}
        if($case.ipAddress){$body.signInConditions.ipAddress=$case.ipAddress}
        $response=Invoke-RestMethod -Method POST -Uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/evaluate' -Headers $headers -ContentType application/json -Body ($body|ConvertTo-Json -Depth 20)
        if($null -eq $response.value){throw 'What If returned no analysis collection.'}
        $actual=@($response.value|Where-Object {$_.state -eq 'enabled' -and $_.policyApplies -eq $true}|ForEach-Object {$_.id}|Sort-Object -Unique)
        $indeterminate=@($response.value|Where-Object {$_.state -eq 'enabled' -and ($_.policyApplies -isnot [bool] -or $_.analysisReasons -match 'notEnoughInformation|invalidCondition|invalidPolicy|unknownFutureValue')})
        $missing=@($snapshot.policies|Where-Object {$_.state -eq 'enabled' -and $_.id -notin $response.value.id})
        $match=($expected -join ',') -eq ($actual -join ',') -and !$indeterminate.Count -and !$missing.Count
        $results.Add(@{name=$case.name;request=$body;expected=@($expected);actual=$actual;match=$match;response=$response;indeterminateCount=$indeterminate.Count})
        Write-Host "$($case.name): $(if($match){'MATCH'}else{'MISMATCH'}) ($($expected.Count) offline / $($actual.Count) Microsoft applicable policies)"
    }
    $evidence=@{capturedAtUtc=[DateTime]::UtcNow.ToString('o');tenantId=$tenant;snapshotCapturedAtUtc=$snapshot.capturedAtUtc;validationScope='Representative application and single authentication-context requests; policy applicability only. Does not prove successful authentication, actual context invocation, session timing, or all scenarios.';cases=$results.ToArray()}
    $evidence|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $OutputPath
    if(@($results|Where-Object {!$_.match}).Count){throw 'What If applicability mismatches require investigation.'}
    Write-Host "Saved $($results.Count) read-only What If comparisons to $OutputPath."
}finally{$headers.Clear();$credential=$null}
