function New-CaOAuthTransaction {
    param([guid]$TenantId,[guid]$ClientId,[string]$RedirectUri,[switch]$IncludePimGroups,[switch]$IncludeApplicationAttributes)
    function Url64([byte[]]$bytes){[Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')}
    $verifier=Url64 ([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
    $state=Url64 ([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
    $cookie=Url64 ([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
    $challenge=Url64 ([Security.Cryptography.SHA256]::HashData([Text.Encoding]::ASCII.GetBytes($verifier)))
    $scopes='https://graph.microsoft.com/Policy.Read.All https://graph.microsoft.com/Directory.Read.All https://graph.microsoft.com/RoleManagement.Read.Directory'
    if($IncludePimGroups){$scopes+=' https://graph.microsoft.com/PrivilegedEligibilitySchedule.Read.AzureADGroup https://graph.microsoft.com/PrivilegedAssignmentSchedule.Read.AzureADGroup'}
    if($IncludeApplicationAttributes){$scopes+=' https://graph.microsoft.com/CustomSecAttributeDefinition.Read.All https://graph.microsoft.com/CustomSecAttributeAssignment.Read.All'}
    $params=[ordered]@{client_id=$ClientId.ToString();response_type='code';redirect_uri=$RedirectUri;response_mode='query';scope=$scopes;state=$state;code_challenge=$challenge;code_challenge_method='S256';prompt='select_account'}
    $query=($params.GetEnumerator()|ForEach-Object {[uri]::EscapeDataString($_.Key)+'='+[uri]::EscapeDataString($_.Value)}) -join '&'
    return @{tenantId=$TenantId.ToString();clientId=$ClientId.ToString();redirectUri=$RedirectUri;verifier=$verifier;state=$state;cookie=$cookie;expires=[DateTime]::UtcNow.AddMinutes(10);scopes=$scopes;includePimGroups=[bool]$IncludePimGroups;includeApplicationAttributes=[bool]$IncludeApplicationAttributes;authorizeUrl="https://login.microsoftonline.com/$TenantId/oauth2/v2.0/authorize?$query"}
}
function Test-CaOAuthCallback {
    param($Transaction,[string]$State,[string]$Cookie)
    return $null -ne $Transaction -and [DateTime]::UtcNow -lt $Transaction.expires -and $State -ceq $Transaction.state -and $Cookie -ceq $Transaction.cookie
}

