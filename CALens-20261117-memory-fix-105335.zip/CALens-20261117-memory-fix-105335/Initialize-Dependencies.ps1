#Requires -Version 7.4
[CmdletBinding()]
param([switch]$VerifyOnly)
$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot 'dependencies'
$runtime=Join-Path $root 'runtime/win-x64'
$manifestPath=Join-Path $root 'runtime.lock.json'
if($VerifyOnly){
    $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
    foreach($file in $manifest.files){if((Get-FileHash -LiteralPath (Join-Path $root $file.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw "Dependency integrity check failed: $($file.path)"}}
    Write-Host 'Offline runtime dependency hashes verified.';return
}
$version='7.5.1.1'
$packages=@('microsoft.clearscript.core','microsoft.clearscript.v8','microsoft.clearscript.v8.icudata','microsoft.clearscript.v8.native.win-x64')
$null=New-Item -ItemType Directory -Path $runtime -Force
$cache=Join-Path ([IO.Path]::GetTempPath()) ('ca-dependencies-'+[guid]::NewGuid().ToString('N'))
$null=New-Item -ItemType Directory -Path $cache
$packageEvidence=@()
try{
    foreach($package in $packages){
        $uri="https://api.nuget.org/v3-flatcontainer/$package/$version/$package.$version.nupkg"
        $archive=Join-Path $cache ($package+'.zip');Invoke-WebRequest $uri -OutFile $archive
        $registration=Invoke-RestMethod "https://api.nuget.org/v3/registration5-semver1/$package/$version.json"
        $catalogUri=[uri]$registration.catalogEntry
        if($catalogUri.Scheme -ne 'https' -or $catalogUri.Host -ne 'api.nuget.org'){throw 'Unexpected NuGet catalog URL.'}
        $catalog=Invoke-RestMethod $catalogUri
        if($catalog.packageHashAlgorithm -ne 'SHA512'){throw 'Unexpected NuGet package hash algorithm.'}
        $expected=$catalog.packageHash
        $actual=[Convert]::ToBase64String([Security.Cryptography.SHA512]::HashData([IO.File]::ReadAllBytes($archive)))
        if($actual -ne $expected){throw "NuGet package hash mismatch: $package"}
        $packageEvidence+=@{id=$package;version=$version;source=$uri;sha512=$actual}
        $unpacked=Join-Path $cache $package;[IO.Compression.ZipFile]::ExtractToDirectory($archive,$unpacked)
        $library=if($package.EndsWith('.icudata')){'lib/netstandard1.0'}elseif($package.Contains('.native.')){'runtimes/win-x64/native'}else{'lib/net5.0'}
        foreach($dll in Get-ChildItem -LiteralPath (Join-Path $unpacked $library) -Filter '*.dll'){Copy-Item -LiteralPath $dll.FullName -Destination $runtime -Force}
        $licenses=Join-Path $root ('licenses/'+$package);$null=New-Item -ItemType Directory -Path $licenses -Force
        Copy-Item -LiteralPath (Join-Path $unpacked 'License.txt') -Destination $licenses -Force
        if(Test-Path -LiteralPath (Join-Path $unpacked 'licenses')){Copy-Item -LiteralPath (Join-Path $unpacked 'licenses') -Destination $licenses -Recurse -Force}
    }
    $files=@(Get-ChildItem -LiteralPath $runtime -Filter '*.dll'|ForEach-Object {@{path='runtime/win-x64/'+$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant();bytes=$_.Length}})
    @{version=1;runtime='ClearScript V8';packages=$packageEvidence;files=$files}|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $manifestPath -Encoding utf8
    Write-Host 'Portable offline compiler initialized. No global installation was made.'
}finally{
    # The temporary extraction directory is freshly created under the OS temp
    # directory; verify that exact boundary before recursive cleanup.
    $resolved=[IO.Path]::GetFullPath($cache);$tempRoot=[IO.Path]::GetFullPath([IO.Path]::GetTempPath())
    if($resolved.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($resolved).StartsWith('ca-dependencies-')){Remove-Item -LiteralPath $resolved -Recurse -Force}
}
