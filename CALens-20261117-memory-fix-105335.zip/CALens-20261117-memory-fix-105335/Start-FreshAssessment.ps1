#Requires -Version 7.4
[CmdletBinding(DefaultParameterSetName='Store')]
param(
    [Parameter(Mandatory)][guid]$TenantId,
    [Parameter(Mandatory)][guid]$ClientId,
    [Parameter(Mandatory)][string]$RequirementsPath,
    [Parameter(Mandatory,ParameterSetName='Store')][string]$CertificateThumbprint,
    [Parameter(ParameterSetName='Store')][ValidateSet('CurrentUser\My','LocalMachine\My')][string]$CertificateStore='CurrentUser\My',
    [Parameter(Mandatory,ParameterSetName='File')][string]$CertificatePath,
    [Parameter(ParameterSetName='File')][securestring]$CertificatePassword,
    [string]$SnapshotDirectory=(Join-Path $PSScriptRoot 'data/snapshots'),
    [string]$StateDirectory=(Join-Path $PSScriptRoot 'data/assessments'),
    [string]$AcceptancePath=(Join-Path $PSScriptRoot 'data/acceptances.local.json'),
    [string]$AssessmentName='default',
    [switch]$IncludePimGroups,
    [switch]$IncludeApplicationAttributes
)
$ErrorActionPreference='Stop';$certificate=$null
try{
    Import-Module (Join-Path $PSScriptRoot 'CA.GapAnalyzer.psd1') -Force
    . (Join-Path $PSScriptRoot 'collection/FreshAssessment.ps1')
    $certOptions=if($PSCmdlet.ParameterSetName -eq 'File'){@{CertificatePath=$CertificatePath;CertificatePassword=$CertificatePassword}}else{@{CertificateThumbprint=$CertificateThumbprint;CertificateStore=$CertificateStore}}
    $certificate=Get-CaReaderCertificate @certOptions
    $run=Invoke-CaFreshAssessment -TenantId $TenantId -ClientId $ClientId -Certificate $certificate -RequirementsPath $RequirementsPath -SnapshotDirectory $SnapshotDirectory -StateDirectory $StateDirectory -AcceptancePath $AcceptancePath -AssessmentName $AssessmentName -IncludePimGroups:$IncludePimGroups -IncludeApplicationAttributes:$IncludeApplicationAttributes
    $run|ConvertTo-Json -Depth 100
    if($run.assessment.status -ne 'completeWithinModel'){exit 2}
    if($run.assessment.coverageSummary.toReview -gt 0){exit 1}
    exit 0
}catch{Write-Error $_ -ErrorAction Continue;exit 3}
finally{if($certificate){$certificate.Dispose()};$CertificatePassword=$null}
