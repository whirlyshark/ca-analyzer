# Authentication-strength coverage

The analyzer checks the minimum authentication required by a strength, including
custom strengths. It does not assume that every custom strength grants MFA, or
that a familiar display name proves phishing resistance.

| Configuration | Minimum used for coverage |
| --- | --- |
| Known built-in MFA or passwordless MFA strength | MFA |
| Known built-in phishing-resistant MFA strength | Phishing-resistant MFA |
| Custom strength containing only documented phishing-resistant MFA combinations | Phishing-resistant MFA, with consistent MFA-claim metadata |
| Custom strength containing other documented MFA combinations | MFA, with consistent MFA-claim metadata |
| Custom strength allowing a single-factor route | Single factor remains possible; it does not establish MFA |

The `password` value in the normalized model is a legacy name for the lowest
authentication category. The interface calls it **Single-factor authentication**;
it can represent password, SMS sign-in, email or single-factor federation/certificate
routes. It does not identify the exact method used by a real person.

## Export consistency

Full snapshots already include strength definitions and combination restrictions.
No extra read or consent is required by this change. Inline policy metadata and
the separately exported definition must agree on security-relevant fields. Their
reads can straddle a change, so neither is silently preferred when they conflict.
Duplicate definition IDs also remain unverified.

Known built-in identifiers retain their documented minimum. An exported built-in
row cannot redefine SMS as phishing-resistant MFA when classifying a custom
strength. Inconsistent claim metadata, unsupported combinations and missing facts
produce scoped uncertainty. An unresolved strength supplies no assumed protection;
other AND grants remain necessary, while an OR route is not made mandatory.
Other policies can still establish protection. Unrelated apps/accounts/conditions
do not inherit the uncertainty when an exact scope check proves it irrelevant.

Method flags and lists are sets: ordering, case, whitespace and repeated equivalent
entries do not change their minimum. Sanitization preserves these relationships,
including `deviceBasedPush`. Unknown method names are not promoted to a known tier.
Changes to unresolved definition evidence reopen accepted findings.

## Boundaries

Multiple strengths do not imply an empty intersection of methods and therefore
blocked access: Microsoft documents that a user can satisfy multiple strengths
using multiple methods. Registration interrupt-mode priority is preserved.
Mixed-OR precedence remains unverified, as do actual method registration,
authentication-method policy reachability, prompts and token issuance.

The known-combination fixture comes from Microsoft's documented API and strength
categories. A tenant-pinned read-only catalog request under the existing lab CLI
session returned 403; no permissions were changed or recovery identity used.
This phase does not claim live catalog or sign-in conformance.

Sources: [documented combinations](https://learn.microsoft.com/en-us/graph/api/authenticationstrengthroot-list-authenticationmethodmodes?view=graph-rest-1.0),
[strength metadata](https://learn.microsoft.com/en-us/graph/api/resources/authenticationstrengthpolicy?view=graph-rest-1.0),
[built-in categories](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strengths),
[multiple strengths and registration priority](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strength-how-it-works).
