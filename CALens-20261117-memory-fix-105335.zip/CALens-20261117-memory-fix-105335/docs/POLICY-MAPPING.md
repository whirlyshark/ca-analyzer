# Automatic policy mapping

No manual linking is required. Open Review coverage → By requirement → Policy coverage. Expand a policy to inspect its conditions. Export mapping saves that requirement’s attribution as JSON.

The mapping uses the same normalized accounts, conditions, valid-scenario constraints and grant alternatives as the analyzer. A policy contributes when it prevents a sign-in that would violate the requirement. Several policies may protect different parts of a requirement, or combine to prevent weaker authentication. Overlapping and redundant contributions are possible; account counts must not be added together. Blocking access can satisfy a minimum-protection requirement and is labelled explicitly.

The mapping is bounded and keeps analysis limits visible. Coverage claims are withheld if the selected requirement has unresolved checks or if the mapping disagrees with the coverage result. Disabled and report-only policies receive no protection credit. Snapshot policies that were not translated are listed separately; their relevance is not guessed from their names.

## Gap recommendations

In an account finding, open Recommendations & related policies. This explains matching policies that permit the example and related protection with an account or condition mismatch. A candidate scope edit requires a single known mismatch in an editable policy condition. Explicit exclusions take priority over unrelated positive selections, such as a separate medium-risk-only policy. Internal role-activation and group-membership coordinates are not proposed as editable policy conditions. Multi-condition differences are context, not an automatic fix recommendation. Existing blocking policies are not suggested for expansion to satisfy a minimum-MFA requirement.

Suggestions include reviewing scope, reviewing weaker grant alternatives, reviewing report-only enforcement where it has been evaluated, or adding a separate policy for the uncovered access. An unconfirmed finding instead directs you to resolve missing information. Suggestions have not been simulated for wider side effects. No policy is changed or created, and no proposed fix is presented as verified. Accepted exceptions do not add protection.

The initial panel shows one policy candidate and the separate-policy option, where available. Other candidates remain expandable. Scope edits that add resources are placed after other scope candidates; this is a presentation preference, not a determination of the best fix. Potential-impact notes explain that changing a policy affects its other matching sign-ins and combines with other policies. Impact has not been calculated or simulated.

## Offline PowerShell export

Uses the runtime already bundled with CALens; no sign-in, Graph calls, Node installation or app permissions are required.

```powershell
pwsh -NoProfile -File ./Export-PolicyMapping.ps1 -SnapshotPath ./tenant-snapshot.json -RequirementsPath ./requirements.json -OutputPath ./policy-mapping.json
```

Add `-RequirementId "your-requirement-id"` to export one enabled requirement. By default all enabled requirements are mapped. Use a new output filename; existing files are never overwritten. The exporter reruns the offline assessment to check attribution agreement, writes no assessment history or saved workspace changes, and reports unconfirmed or limited mappings explicitly. `attributionVerified` means the mapping completed and agreed with the assessment. `requirementMet` is a separate true/false result, or null when it cannot be confirmed. Results apply to the supplied finite model, not a successful real-world sign-in.

## Validation

Focused fixtures compare joint and individual attribution with the C# analyzer, including account exclusions, PIM eligibility, conditions, scenario constraints, OR grants, combined protection, blocking, report-only states, provenance grouping and incomplete evidence. Resource budgets fail closed rather than returning partial coverage claims.
