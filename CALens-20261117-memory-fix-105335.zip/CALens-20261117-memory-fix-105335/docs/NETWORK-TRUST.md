# Trusted networks and offline exports

An “All trusted locations” exclusion can exempt more than the IP locations in
the policy export. To assess it offline, the analyzer needs the named locations,
legacy MFA trusted-IP evidence, and Global Secure Access location metadata.
Missing evidence leaves this part of coverage **unverified**.

A partial named-location catalog can still supply complete, explicitly selected
IP/country definitions. The analyzer retains those predicates and their exact
overlap/complement behavior. This does not close **All trusted**: an unread page
may contain another trusted location. Missing/unsupported types, conflicting IDs
or per-definition pagination links cannot supply a trusted set or an empty set.
Unresolved location facts also bind exception fingerprints; a changed definition
reopens the exception, while a later capture with identical facts retains it.

If a policy references an unavailable location, the analyzer credits no protection
from that policy. For a known passive IP location, validated account, app, action,
client, platform, device, risk and role/group conditions limit which possible gaps need investigation.
An unrelated request can retain a confirmed result; another policy can prove
protection independently. The location type is not guessed, and no empty or
Boolean network definition is invented. Malformed selections and unsupported
additional conditions retain their conservative errors. Changing an unresolved
policy's grants or location evidence reopens its accepted exception.

For known passive location kinds, MFA, compliant-device and hybrid-join grants can prove that a
particular request would be allowed by the policy whichever location matches.
For example, an ordinary MFA grant cannot enforce phishing-resistant MFA on a
request that already satisfies MFA. These grant-permission bounds only refine
gap certainty; they never supply protection from an unknown location. AND/OR
semantics are preserved. Unknown AND controls, strength method restrictions,
unverified registration-strength projections and downstream session restrictions
remain conservative where permission cannot be proved. A missing bound in an
older imported model supplies no permission proof. The normalized model also
requires explicit `locationMatchingOnly: true` before using these bounds.

GPS collection can deny access independently of grants, even in report-only
policies. GPS locations, missing location types and future/unknown lookup methods
therefore supply no permission proof. The analyzer retains account/group/role and
resource assignments to bound this uncertainty. It does not assume other request
conditions short-circuit collection: their ordering needs runtime evidence.
Report-only grants never supply protection. Source policy states remain unchanged;
an internal uncertainty record accounts for possible location-collection denial.
Independent policies can still prove minimum protection, since denied access does
not violate a minimum-authentication requirement. This does not prove access works.

An omitted country lookup method uses Graph's documented `clientIpAddress`
default. Explicit null, GPS and unknown future values remain unverified.
See Microsoft's [GPS collection and report-only behavior](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-assignment-network#countries)
and [country lookup methods](https://learn.microsoft.com/en-us/graph/api/resources/countrynamedlocation?view=graph-rest-1.0).
The grant combinations follow Microsoft's
[all/one selected-control semantics](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-grant).

Graph distinguishes [individual IP definitions](https://learn.microsoft.com/en-us/graph/api/resources/ipnamedlocation?view=graph-rest-1.0)
from [the catalog](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-list-namedlocations?view=graph-rest-1.0)
and [ID-based policy inclusion/exclusion](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccesslocations?view=graph-rest-1.0).

## Collection

The collector keeps the regular v1.0 named locations and separately reads:

```text
GET /beta/identity/conditionalAccess/namedLocations?$filter=isof('microsoft.graph.compliantNetworkNamedLocation')
```

The snapshot stores `compliantNetworkLocations` and
`completeness.compliantNetworkLocations`. This uses the existing `Policy.Read.All`
permission; it does not enable Global Secure Access or change policies. A failed
beta read is recorded independently. It does not invalidate unrelated direct IP
location checks or unconditional protection. The beta schema may change.

Older exports without this collection cannot establish its absence. Re-export
when possible; do not add an empty array merely to suppress uncertainty.
Legacy MFA trusted IPs also need explicit, accurate exported evidence; an empty
array means there are none, not that their configuration was unavailable.
The IPv4 ranges are combined with trusted named IP locations using an exact
union, including overlaps and single-address `/32` entries. IPv6 addresses remain
outside the legacy IPv4 ranges; trusted IPv6 named locations still work.

The separate **Skip MFA for federated users on my intranet** setting also matters:
Microsoft documents that an `insidecorporatenetwork` claim can make a request
trusted when this option is enabled. An IP list alone cannot prove the full scope.
Unknown or enabled federated-intranet trust leaves dependent checks unverified;
claim-based matching still needs runtime validation. See Microsoft's
[legacy MFA settings documentation](https://learn.microsoft.com/en-us/entra/identity/authentication/howto-mfa-mfasettings#trusted-ips).

## Supply the legacy settings

After loading a snapshot, select **Review legacy MFA trusted networks**:

1. Choose **Not checked**, **No trusted IP ranges**, or **Trusted IP ranges configured**.
2. If configured, enter up to 50 IPv4 CIDR ranges, one per line.
3. Record the federated-intranet setting as **Not checked**, **Off**, or **On**.
4. Select **Use these settings**, then **Save snapshot** to retain them offline.

The dialog changes only the local snapshot. It never changes tenant settings.
“Not checked” removes the corresponding assertion; it never means “Off.”
Ranges are validated together, so an invalid entry cannot silently narrow an
exclusion. Requirements can also select **All trusted locations**, including
requiring access from that set and blocking every other network.

The snapshot fields are `legacyMfaTrustedIpRanges` (an array of IPv4 CIDR strings)
and `legacyMfaFederatedIntranetEnabled` (a Boolean). Both must be supplied accurately
to use the IP-only legacy model. The collector does not automatically retrieve
these legacy service settings or carry manual assertions into a fresh collection.
Fresh collection remains unverified where the new snapshot lacks these facts.

## What is supported

Complete, consistent metadata showing no trusted Global Secure Access location
allows the analyzer to use the ordinary trusted-IP partition. Missing or
conflicting trust metadata, unknown location types, duplicate IDs and trusted
Global Secure Access locations prevent a definite “All trusted” conclusion.
Other independently supported locations remain usable.

**Global Secure Access location matching itself is not implemented.** It needs
the compliant-network runtime signal and Microsoft's automatic infrastructure
resource exclusions to be validated together. Selecting such a location in a
policy or requirement stays unverified, including when it would otherwise look
like an empty requirement scope. No protection credit is given for it.

Microsoft documents the [compliant-network location type](https://learn.microsoft.com/en-us/graph/api/resources/compliantnetworknamedlocation?view=graph-rest-beta)
and [automatic resource exclusions](https://learn.microsoft.com/en-us/entra/global-secure-access/how-to-compliant-network).
The documented What If [sign-in conditions](https://learn.microsoft.com/en-us/graph/api/resources/signinconditions?view=graph-rest-1.0)
have no compliant-network input. A successful metadata read is therefore not a
matching or enforcement conformance test.

## Sanitization

The standalone sanitizer preserves the type, trust flag, collection completeness
and compliant-network enum, while replacing location IDs and names consistently
across policies and requirements. Legacy trusted-IP ranges use the same IP
mapping as other ranges. Known collection-error categories remain recognizable;
identifier suffixes and identifying messages are pseudonymized. This preserves
whether a failed optional read affects the assessment.
