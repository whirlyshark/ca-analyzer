# Device requirements

In **Set requirements**, choose **A hybrid-joined device**, or choose MFA and
select **Also require a hybrid-joined device**. Compliance is a separate choice;
select both device options only when both must be required.

The **Managed devices** templates include **MFA and a hybrid-joined device for
Windows apps**. Choose its apps before enabling it. Its Windows scope is editable;
the analyzer never infers that scope from the requirement name.

The offline requirement is evaluated against all applicable policies and their
AND/OR alternatives. `domainJoinedDevice` establishes the hybrid-join grant.
`compliantDevice` establishes compliance; neither implies the other. MFA OR hybrid
join does not meet an MFA AND hybrid-join requirement. Another applicable policy
can supply the missing protection. A policy that blocks access also meets these
minimum-protection requirements.

Findings identify **Hybrid-joined device missing** and show whether the example
has a hybrid-join claim. Device-filter predicates share the existing join-state
model: for example, excluding `device.trustType -eq "ServerAD"` from a block
policy blocks other device states. Registration/join actions cannot require a
device that is already hybrid joined; unsupported action requirements remain
unverified. No device inventory or account label is used to infer future claims.

This checks Conditional Access grant configuration. It does not certify a device's
physical join status, actual client/flow support or successful token acquisition.
Existing request/device-filter/runtime uncertainty remains applicable. Microsoft's
[grant documentation](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-grant)
describes hybrid-join platform and device-code limitations. Platform signals are
not treated as an authoritative inventory of physical join state.

For a JSON requirements profile:

```json
{
  "id": "sensitive-windows-apps",
  "name": "Windows app access needs MFA and hybrid join",
  "accountSetId": "all",
  "outcome": "mfa",
  "protections": ["mfa", "hybridJoined"],
  "platforms": ["windows"],
  "apps": ["your-resource-app-id"]
}
```

Validation covers 17 raw and sanitized scenario cases, 6,144 independently
evaluated configuration points across 32 generated policy sets, embedded V8/C#,
and HTTP-to-PowerShell parity. This is synthetic configuration validation, not a
live hybrid-device sign-in conformance claim.
