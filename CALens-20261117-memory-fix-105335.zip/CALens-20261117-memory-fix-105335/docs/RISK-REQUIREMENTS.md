# Risk-based requirements

In **Set requirements**, expand **Risk levels** under conditions. Select either
**Sign-in risk** or **User risk**, choose **Selected risk levels**, then check the
levels to include. **Any risk level** leaves that signal unrestricted. A selected
list must contain at least one level before the rule can be saved.

- Medium and high in one list means either level.
- Selecting both signals means both conditions must hold.
- No risk, hidden/not disclosed and unknown future values are separate states.
  They are never assumed to mean high, or silently dropped from an unrestricted rule.

Example preview:

> All accounts must use phishing-resistant MFA when accessing any app. Check only
> when sign-in risk is medium or high. User risk must also be high.

Risk conditions also apply to generated rules that block access outside approved
apps, networks or device filters. They do not silently become unconditional
blocks. Matching risks are shown in the finding's sign-in example.

The template catalogue includes phishing-resistant MFA for medium/high sign-in
risk, a stricter high-risk blocking option, and phishing-resistant MFA for high
user risk. Each is editable and removable. These are minimum-protection
requirements, not a complete reproduction of Microsoft's deployment recipes.
In particular, authentication freshness, registered-method availability, risk
remediation completion and Identity Protection licensing/detection are not proved
by these templates. No Breakglass exclusions are added automatically.

Offline analysis checks how the exported CA set would enforce a requirement for
the modeled risk signals. It does not predict Microsoft's risk score, claim an
account is currently risky, or reconstruct a multi-step remediation flow.
No current user-risk/sign-in inventory or new Graph permission is required for
these scenario checks. Existing missing-data/runtime uncertainty remains explicit.

For JSON requirements, use `signInRiskLevels` and `userRiskLevels`, each containing
zero or more of `none`, `low`, `medium`, `high`, `hidden`, `unknownFutureValue`.
Omitted/empty lists mean unrestricted. Unknown values, duplicates, nulls and
non-list values are rejected; imported finite models must contain the selected
risk dimensions. Changing a risk selection changes the requirement's semantic
history and exception scope; empty defaults do not.

Microsoft sources checked November 16, 2026:

- [Risk-based sign-in authentication guidance](https://learn.microsoft.com/en-us/entra/identity/conditional-access/howto-conditional-access-policy-risk)
- [User-risk remediation guidance](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-risk-based-user)
- [Graph condition sets and risk enums](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessconditionset?view=graph-rest-1.0)
- [Authentication-strength limitations](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strengths)

The last source also documents that the MFA grant and authentication-strength
grant cannot coexist in one CA policy. Such imported configurations are rejected
rather than credited as protection. MFA and strength requirements supplied by
separate valid policies continue to compose normally.
