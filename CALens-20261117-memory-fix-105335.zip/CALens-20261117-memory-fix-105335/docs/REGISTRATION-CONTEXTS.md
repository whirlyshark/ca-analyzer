# Registration resource and flow contexts

Registration is an action, but it can happen while requesting a resource. A
policy export alone does not establish which resource/token request triggered
registration or whether the user was interrupted during sign-in.

In **Set requirements**, select a registration activity. Leave **Specify the
registration resource and flow** unchecked to assess without that information.
The analyzer credits universal All-resources and explicit action policies, and
leaves unresolved gaps when resource-specific protection could change the result.

Missing resource information affects only the accounts and remaining scenarios
that the app policy could cover. Its flow, network, client, platform, risk,
device and account conditions still apply. For example, a device-code-only app
policy cannot make standard-flow registration inconclusive. Independent policies
can also remove the uncertain scenarios while leaving confirmed gaps elsewhere.
App protection is retained for app access; it is never assumed to protect
registration through an unknown resource. Declared resource contexts keep their
separate checks.

Known grant routes can also settle a missing-resource check. If an All-resources
policy requires MFA and an app policy only adds MFA, an MFA sign-in still falls
short of a phishing-resistant requirement, whichever resource triggered
registration. A compliant or hybrid-joined device can likewise satisfy a known
grant route. The example shows those device conditions when certainty depends on
them.

These are permission proofs: they rule out a possible grant denial and add no
registration protection. Unknown AND controls, Terms of Use, provider/app/session
enforcement and authentication-strength method restrictions retain uncertainty.
A known OR route can suffice without asserting that the other route succeeds.
Missing permission metadata retains uncertainty. Each supplied permission must
fit a complete necessary grant route; overlap with part of an AND grant is not
enough. Actual method availability, prompts and token issuance remain outside
this proof. These bounds also require a known passive location kind. GPS and
missing/unknown location types can deny independently of grants, including in
report-only policies. Those requests retain investigation status, bounded by
account/resource assignments without assuming other conditions stop collection
first. See [network evidence](NETWORK-TRUST.md) and
[Graph grant composition](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessgrantcontrols?view=graph-rest-1.0).

When the context is known, enable that option and choose the resource, experience
and flow. The builder records this as a **declared context**, not an observed
sign-in. Duplicate the requirement for other contexts. The selection is saved in
the requirements JSON, so later assessment works offline with the same snapshot.

For security-information registration:

- **Manage** means visiting security-information management directly.
- **Interrupt** means registration interrupted a resource sign-in. Applicable
  action-strength policies take priority over universal All-resources strengths.
  The partition preserves account exclusions, group and active-role assignments,
  PIM activation possibilities, device filters, platform, network, flow and risk.
  Other AND grants remain in force.
- Mixed OR grants containing both strength and another control retain an explicit
  uncertainty pending stronger validation. They are not converted into mandatory
  device controls.

Device-registration contexts have no manage/interrupt strength selection. The
exported tenant-wide device-registration MFA setting remains a separate
prerequisite, checked only for requirements that assess device registration.

Missing, inconsistent or unsupported authentication-strength definitions now
retain the other grants and leave only dependent remaining gaps unverified.
An unknown action strength in interrupt mode cannot silently restore the inherited
global strength; manage-mode global protection remains in force. See
[strength evidence](AUTHENTICATION-STRENGTHS.md). Mixed-OR precedence and actual
method registration/reachability remain separate open validation cases.

Exported requirements include the selected context, for example:

```json
{
  "id": "security-registration-app-a",
  "name": "Register securely while signing in to App A",
  "accountSetId": "all",
  "outcome": "phishingResistant",
  "userAction": "registerSecurityInformation",
  "registrationContext": {
    "resourceId": "replace-with-resource-app-id",
    "mode": "interrupt",
    "flow": "standard",
    "provenance": {
      "kind": "declared",
      "description": "Organisation-defined context to assess"
    }
  }
}
```

`flow` can be `standard`, `deviceCodeFlow` or `authenticationTransfer`. For device
registration, use `userAction: registerOrJoinDevices` and
`mode: deviceRegistration`. A provenance description is mandatory. Imported
`signInLog` provenance should identify the retained evidence; the analyzer does
not infer registration mode from an app name, or independently authenticate that
claim. Editing the context in the builder makes it declared again.

Results establish coverage within that declared context. They do not prove the
context is reachable, an authentication method is registered, registration will
finish, a prompt will appear, or a token will be issued. The action-only What If
input lacks a resource, so it cannot verify these combinations by itself.

Sources: [combined registration modes](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-registration-mfa-sspr-combined),
[registration strength priority](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-authentication-strength-how-it-works#how-multiple-authentication-strength-policies-are-evaluated-for-registering-security-info),
[What If user action inputs](https://learn.microsoft.com/en-us/graph/api/resources/useractioncontext?view=graph-rest-1.0).
