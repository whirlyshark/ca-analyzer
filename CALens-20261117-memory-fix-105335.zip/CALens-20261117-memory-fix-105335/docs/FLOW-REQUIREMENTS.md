# Authentication-flow requirements

In **Set requirements**, add an authentication-flow template or open a requirement
and expand **Authentication flows**. Choose device code, authentication transfer,
or standard / untracked sign-in. The requirement summary shows the selection.
Leaving the scope at **Any** checks all three classes.

The two editable templates require device-code or authentication-transfer app
access to be blocked. They exclude the account set named Breakglass; define that
set yourself. Customize accounts, apps and approved exceptions before using them.
These templates check app access, not every registration experience.

The flow means the session's original transfer method. Microsoft retains this
classification through subsequent token refreshes, even when the current request
uses a different protocol. This is a request-class analysis, not a replay of
sessions or proof that a particular sign-in is reachable.

## Device Registration Service

Microsoft enforces authentication-flow policies on Device Registration Service
only when the policy targets **All resources**. Selecting that resource alone
does not enforce the flow control. Excluding it from All resources removes it
from the control. The analyzer retains this exception and explains it in policy
details. Ordinary policies without a flow condition retain their usual scope.

The public resource ID is `01cb2876-7ebd-4aa4-9cc9-d28bd4d359a9`; sanitization
preserves it so the same rules apply to sanitized exports.

## Combined access restrictions

"Only these apps", "only these networks" and "only these devices" each impose
a restriction. A request outside two restrictions still violates the requirement.
"When" conditions instead limit where the entire requirement applies. The analyzer
checks outside-app, outside-network and outside-device regions without counting
the same request twice. Authentication-flow selections apply to every region.

Checks saved before this correction start a fresh history comparison baseline.
Previously accepted exceptions require review under the corrected check scope.

## Offline data and current limits

Full tenant snapshots contain raw policy flow conditions; no online lookup is
needed for these checks. Imported finite models must include the selected flow
classes. Missing classes produce **Requirement not checked**, with affected
accounts listed, rather than a passing result or invented sign-in gaps.

The policy value `none` means no flow restriction. Flow conditions on security
information registration, device registration and authentication contexts are
supported. These rules were checked against retained Microsoft What If output
and independent request truth. A requirement can select the relevant flow offline.
Unknown future values and unsupported flag combinations remain unverified.

What If reports a directly selected DRS flow policy as applicable in two retained
cases, despite Microsoft's published All-resources enforcement rule. The analyzer
keeps the documented rule and credits no protection from that selection. This
discrepancy remains an open runtime-validation case; it is not counted as a match.
What If establishes policy applicability, not actual authentication or enforcement.

Sources: [Microsoft authentication-flow semantics](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-authentication-flows)
and [Microsoft flow-blocking recommendations](https://learn.microsoft.com/en-us/entra/identity/conditional-access/policy-block-authentication-flows).
