# Sanitise an export

Copy `Sanitize-CaExport.ps1` anywhere. It runs offline in PowerShell 7.4 or later;
there are no modules to install, credentials, network calls or companion files.

```powershell
pwsh -NoProfile -File ./Sanitize-CaExport.ps1 -InputPath ./ca-policies.json -OutputPath ./ca-policies.sanitized.json
```

Then import `ca-policies.sanitized.json` in the analyzer. Accepted input shapes are
a policy array, Graph `value` envelope, single policy, or full version-1 tenant
snapshot. Without `-OutputPath`, it creates `<input-name>.sanitized.json` beside
the original. Existing output requires `-Force`; overwriting the input is refused.
Exports containing a pagination link are rejected: collect all pages first.

For account-level gap testing, sanitise a **full snapshot**, which also contains
users, groups, transitive memberships and roles:

```powershell
pwsh -NoProfile -File ./Sanitize-CaExport.ps1 -InputPath ./ca-tenant-snapshot.json -OutputPath ./tenant.sanitized.json
```

Policy-only exports remain suitable for policy inventory/support checks. They
cannot establish per-account protection without the directory dependencies.

## What changes

- Tenant, policy, user, group, role, application and location IDs become synthetic
  GUIDs. Every reference to the same identifier gets the same replacement,
  including membership-map keys, completeness keys and GUID literals in filters.
- Policy names, descriptions, account attributes, app/group/location names,
  domains, email addresses, URLs and unknown free text become synthetic labels.
  Unknown property names are replaced too, so custom field names cannot retain
  organisational names. Their new names may make them unsupported by the analyzer.
- Metadata timestamps, OData metadata links and credential fields are removed. Unknown
  numeric fields are zeroed; recognised control values such as sign-in frequency
  are retained. Nulls, booleans, empty arrays and collection shapes are preserved.
- Snapshot capture and schedule start/end dates become synthetic instants around
  **1 January 2000**. Ordering and equality are preserved, including past/future
  status at the exported capture time; original calendar dates and durations are
  removed. Null end dates remain null, missing dates stay missing, and malformed
  timestamps remain invalid. This preserves current PIM coverage, not real expiry
  durations or a future calendar timeline. No missing capture time is invented.
- IP addresses and CIDRs use a per-run transformation that preserves equality,
  prefix lengths, subnet overlap and containment within each IP family. The
  synthetic addresses can fall in public space: never use them for real policies.
  IP geolocation and private/public categories are not retained.

Control vocabulary remains intact: enabled/report-only state, include/exclude
structure, AND/OR operators, MFA/device/block controls, platform/client/risk values,
country codes, built-in app bundles, authentication context IDs, root directory
scope `/`, public built-in authentication-strength IDs and Microsoft's public
Device Registration Service app ID. Other GUIDs, including
role IDs and authenticator-model AAGUIDs, are replaced consistently.
Non-root directory/application scopes retain their path structure with synthetic
identifiers, so an administrative-unit role cannot become tenant-wide after
sanitisation. The PIM regression checks assessment status and affected accounts
before and after sanitising all 35 current PIM group scenarios.

## What to review

Mappings exist only in memory; no reversal map is written. Identifier replacements
are random on each run, so put related policies and directory data in **one file**.
Do not mix separately sanitised policies with an original or separately sanitised
directory snapshot.

Filter operators and schema attributes are retained; quoted identifying literals
are replaced consistently. Exact equality survives for shared values, but text
prefix/substring relationships can change. Review name-based device/app filters,
custom authentication-method restrictions and IP-dependent country behavior before
using them as correctness fixtures. Unsupported filter syntax causes a failure
before output is written.

This is pseudonymisation, not a guarantee of anonymity: policy counts, targeting
relationships, control choices, countries and network structure remain visible.
Review the resulting JSON before sharing it outside your organisation. Keep the
original export private.

Resource-group membership evidence retains consistent resource identifiers and
partial/complete status. Provenance descriptions are pseudonymised. The public
Azure Management, Azure AD Graph and Microsoft Graph resource identifiers remain
unchanged because they affect evaluation semantics, as do built-in strength IDs.
Schedule instants retain exact ordering and equality at 100-nanosecond precision;
an expiry one tick after capture must not collapse onto the capture instant.
The input reader preserves strings literally before sanitisation. Invalid dates
such as an hour of 24 are never normalized into valid expired schedules; invalid
timing remains unresolved after sanitisation rather than concealing a gap.

Custom security attribute definitions, assigned values and filter references are
sanitised together. Exact and ordinal case-insensitive string equality and
collection membership survive, including case-distinct attribute names and Unicode
values. Attribute types, collection shape, null/empty values and read-completeness
metadata are retained. Include the definitions and assignments in the same input
as the policies.

For full snapshots, scalar custom-attribute prefix/substring filters are rejected
before output: opaque labels cannot preserve those relationships. Policy-only
exports may lack the definition needed to distinguish scalar text from a collection;
review them before using them as correctness fixtures. Numeric/order predicates
are not covered by the string-parity guarantee. None of this enables application-
filter evaluation in the analyzer; Microsoft runtime matching remains unverified.

Compliant-network location metadata and legacy MFA trusted IP ranges retain
consistent references and trust semantics; see [trusted networks](NETWORK-TRUST.md).
Known collection-error names are preserved so optional read failures do not become
unrelated blocking errors. Identifier suffixes and messages remain pseudonymized.

IP syntax is validated before .NET address parsing. Shorthand/octal/hexadecimal
IPv4, signed or whitespace-containing CIDR prefixes, bracketed/scoped IPv6 and
embedded IPv4-in-IPv6 are rejected before writing output. They must not become
valid evidence through .NET's permissive normalization. Legacy MFA trusted-IP
configuration and the Boolean federated-intranet flag retain their meaning;
unknown or enabled claim-based trust remains unverified after sanitization.

Known session-control modes, including `strictLocation` and Defender modes, are
preserved. Filtering-profile IDs use the consistent identifier mapping; changing
downstream configuration cannot silently inherit an accepted possible gap.

Authentication method flags preserve known case/order variants and
`deviceBasedPush`. Equivalent repeated flags/list entries retain their set
meaning; contradictory strength metadata and unknown methods remain unverified
after sanitization rather than becoming a stronger authentication category.
