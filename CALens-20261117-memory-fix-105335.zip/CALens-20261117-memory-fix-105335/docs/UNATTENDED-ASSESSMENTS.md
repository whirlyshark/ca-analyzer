# PowerShell assessments and scheduling

The unattended runner uses the same JavaScript compiler, C# engine, completeness
rules and coverage summary as the UI. It needs Windows x64 PowerShell 7.4+ and
the included `dependencies` folder. Node, a browser and a running web server are
not required. It makes no network calls during analysis.

## First run

Export a full tenant snapshot using an Import policies connection/export option.
In Set requirements, use **Export definitions & requirements** to save your setup.
Then run from the analyzer folder:

```powershell
pwsh -NoProfile -File ./Start-Assessment.ps1 `
  -SnapshotPath ./my-tenant-snapshot.json `
  -RequirementsPath ./my-requirements.json
```

A fictional working example is included:

```powershell
pwsh -NoProfile -File ./Start-Assessment.ps1 `
  -SnapshotPath ./examples/reference-snapshot.json `
  -RequirementsPath ./examples/reference-requirements.json
```

The JSON response includes `reportPath` and `htmlReportPath`. Open the HTML report
directly; it contains no scripts, remote fonts or external resources. JSON retains
the complete finding regions and affected IDs. Results contain organisation data;
keep them in an appropriate local/private location.

## History and review

By default, reports and the latest comparison are kept under `data/assessments/`.
Each tenant and named assessment has separate history. Use `-AssessmentName` for
different requirement profiles in the same tenant. A run reports new/resolved
account/requirement coverage and whether the model/completeness changed.
History writes are locked against concurrent updates of the same named scope.

The UI saves full-snapshot checks to this same default tenant history. Its
coverage overview shows changes since the previous check; **Saved checks** lists
the latest 20 runs with score, affected-account count, checked scope and snapshot
time. **Export check** downloads the original saved JSON result. These entries
survive restarting the UI. Named CLI assessments and custom state directories
remain separate; the UI uses the default assessment in this folder.

UI history is available for full tenant snapshots, including the reference tenant.
The older finite-model architecture demo does not have a stable tenant identity
and does not write tenant history. Reimport successive snapshots with the same
tenant ID and keep the folder's `data` directory to retain comparisons.

Comparison uses the union of unprotected scenarios, rather than the number or
ordering of grouped rows. It refines IP ranges and device predicates into a common
domain and maps newly inventoried applications/home tenants into the old catchall.
Adding an irrelevant named location or a redundant device-filter policy therefore
does not invent new gaps. Cosmetic requirement titles and provenance descriptions
are ignored. Protection changes still produce added/reduced gap coverage for each
account and requirement; an account can have improvements in one scenario and new
gaps in another.

The report shows unique accounts with new gaps and with some gaps closed. JSON
`newFindings` and `resolvedFindings` count account/requirement checks with coverage
additions or reductions, rather than region fragments. Newly assessed accounts
with gaps count as new findings. Removed accounts/checks are recorded as scope
retirements, never as protection fixes. Edited requirements are listed separately
and establish a new comparison baseline for those checks.

Old reports without semantic domain evidence establish a new baseline. Incomplete
assessments, unsupported comparison evidence or exhausted comparison budgets do
not claim zero changes or resolved gaps. Comparison currently has a five-second,
20,000-region and 250,000 comparable account/requirement-scope guard. A bounded
comparison does not change the current assessment's protection result. Preserve
the source tenant ID and named assessment to compare successive full exports.
Anonymous finite-model/policy inputs cannot establish the same stable tenant
identity when their fingerprint changes.

Accepted exceptions use `data/acceptances.local.json`, shared with the UI.
Changed relevant scope or unverified evidence reopens review; equivalent complete
scopes can retain an exception. Acceptance never raises the protection score.
See [accepted exceptions](ACCEPTED-EXCEPTIONS.md), including the one-time review
for older tenant-unscoped records.
Use `-AcceptancePath` or `-StateDirectory` to isolate another assessment workspace.
Use `-NoHistory` to avoid history writes; `-OutputPath` can still save a report.

Exit codes:

| Code | Meaning |
|---|---|
| 0 | Complete assessment with no unaccepted findings |
| 1 | Complete assessment with findings to review |
| 2 | Incomplete or unresolved assessment; no passing score |
| 3 | Invalid input, dependency, runtime or filesystem failure |

## Scheduling

Use Windows Task Scheduler to run `pwsh.exe` with `-NoProfile -File`, the absolute
path to `Start-Assessment.ps1`, and absolute snapshot/requirements paths. Choose
your organisation's desired frequency and a Windows identity with access to the
folder. No schedule is installed automatically.

The offline runner has been tested through actual Windows Task Scheduler from a
relocated portable folder containing spaces. A clock trigger launched the first
check; subsequent task runs detected new/unchanged gaps and returned the documented
0/1/2/3 exit codes. Incomplete history did not claim confirmed fixes. This used the
existing logged-on Windows identity, the least run level and no stored password.
It does not prove execution while logged off or live certificate-based collection.

For development, `tests/Test-ScheduledOffline.ps1` creates a uniquely named
temporary task, exercises six fictional offline cases and removes the task. It
verifies the task's owner, action and execution settings before every operation.
The unified development runner includes this integration check only with
`-IncludeScheduler`; ordinary validation does not install tasks. Its evidence
records the task name, so a process interruption can be investigated in Task
Scheduler without touching other tasks.

Reassessing the same export checks that export, not the live tenant. Refresh the
snapshot first when you want new policy/directory changes. Existing interactive
CLI sessions can expire; the export command fails rather than opening a prompt
or requesting consent. Do not use the recovery principal for routine collection.

To collect and assess automatically without a user session, use
`Start-FreshAssessment.ps1` with a separately consented certificate reader. See
[fresh scheduled collection](SCHEDULED-COLLECTION.md) for permissions, setup,
commands, task arguments and failure behavior. Offline `Start-Assessment.ps1`
remains available when a supplied snapshot is all you want to assess.

## Portable dependencies

Keep `dependencies/runtime`, its lock manifest and licences with the project.
The bundled ClearScript V8 compiler uses pinned NuGet packages and includes package
SHA-512 and runtime file SHA-256 hashes. Verify the copied folder with:

```powershell
pwsh -NoProfile -File ./Initialize-Dependencies.ps1 -VerifyOnly
```

If the runtime folder is absent, run `Initialize-Dependencies.ps1` once on an
internet-connected machine, then copy the complete folder to the offline machine.
It installs nothing globally. Analysis itself never downloads dependencies.
