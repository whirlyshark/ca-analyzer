# Application-filter investigation and exports

**Current status:** application-filter policy matching remains unverified and is
not credited as protection. Exporting attributes supplies offline investigation
data; it does not make these policies fully supported yet. Independent policies
can still prove a requirement, and gaps outside a filter policy's known account
or request conditions remain assessable. Possible gaps that depend on it remain
unverified. Workload identity policies remain out of scope.

## How uncertainty is isolated

A well-shaped enabled filter policy retains its validated user, group, role,
platform, client, risk, flow, network and device conditions as an upper bound.
No resource/filter relationship or grant protection is assumed. This upper bound
also covers potential registration and authentication-context token requests;
absence of an ordinary app target is not evidence of irrelevance there.

The assessment checks whether this upper bound overlaps remaining violations.
Only a proof of no overlap, or independent full protection, discharges the issue.
The backend binds the diagnostic to typed policy flags, preventing omission or a
swapped denial-mode query from hiding it. The C# engine rejects any protection
grant attached to an unverified filter projection. Policy traces say **May apply**
and explain that its matching/grants are unverified. Notes remain in UI and
unattended reports even when independent policies establish full coverage.

The requirements overview separately shows completed requirements and those
needing investigation. A filter-dependent Windows check does not relabel a fully
evaluated Android check as uncertain. Its findings retain their normal detail
labels. The overall score remains withheld while any check is incomplete.
Unknown/global diagnostic scopes and engine limits do not acquire this narrower
completion. Findings within the same requirement now also retain their own
classification when a bounded per-finding check proves every unresolved policy
irrelevant to that entire region and identity set. Known policy conditions now
split a partially overlapping group into separate account/request regions before
that proof. For example, an uncertain Windows policy can leave a definite Android
gap visible under the same requirement. Scenario buttons include the platform.
Invalid queries, unsupported bounds and exhausted proofs remain unverified. This
does not evaluate the filter expression or credit its grants. Mixed rows count accounts
with a confirmed gap separately from accounts with possible gaps only.

Splitting preserves exactly the original account/request coverage. It shares the
context time/region limits and falls back atomically to the original groups if a
limit is reached; `gapRefinement` records that outcome. Unchanged parent exceptions
also cover their split children. Changed model, source or physical evidence must
still pass the existing exception rules. Reopening a shared exception refreshes
all affected scenarios.

Overlapping potential scopes are combined as a union. Once a piece is inside
that union it is not split again at every other uncertain policy boundary. The
remaining pieces expose definite gaps outside every supported uncertainty scope.
The per-finding check still runs against the resulting groups, and invalid or
unsupported diagnostics remain conservative. The UI places definite scenarios
before those needing investigation.

Refinement also bounds expanded account references to the larger of the original
report's references and `MaxRegions × 64`. Identity partitions are shared across
request cells while building the split. An `identityReferenceLimit` outcome keeps
the original groups; it does not discard sign-in coverage or assert protection.

Explicitly null filters are ordinary policies. Malformed filter objects, mixed
filter/action/context targets and other rejected policy shapes remain validation
issues. Opaque rule strings are retained as data and never executed. Exported
attribute nulls, positive assignments or a caller's claimed verified read scope
never by themselves enable matching or grant credit.

Filter policies, definitions, assignments, read completeness/scope and strength
definitions are captured once as supplemental diagnostic evidence in the model.
This data participates in the SHA-256-backed exception fingerprint; it is never
interpreted as a grant. Rejected policy settings also remain bound to evidence.
Changing an unresolved attribute value or rejected setting cannot silently reuse
an old exception merely because its projected regions/error text remain the same.

Microsoft describes application filters as matching custom security attributes
on resource service principals at token issuance. String attributes are supported;
the filter mode is include or exclude. The ordinary application inventory does
not export these attributes. See
[Microsoft's application-filter guide](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-filter-for-applications)
and [Graph resource selectors](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessapplications?view=graph-rest-1.0).

## Export the missing facts

Select **Include app-filter attributes** before connecting or copying the full
export command in the Import policies tab. The selection is independent of PIM
group eligibility and is off by default.

For an existing Cloud Shell/CLI session or explicit token export:

```powershell
./Export-TenantSnapshot.ps1 -TenantId '<tenant-guid>' -IncludeApplicationAttributes
```

The same switch is available on `Start-FreshAssessment.ps1`. Existing-token
collection does not open a sign-in or request new consent. The interactive export
and UI sign-in request extra read scopes only when the option is selected.

The reader app needs **CustomSecAttributeDefinition.Read.All** and
**CustomSecAttributeAssignment.Read.All**, using delegated permissions for the
interactive reader or application permissions for the certificate reader.
Delegated users also need the applicable attribute reader roles and scope.
Global Administrator/Global Reader alone is not evidence of access to all custom
attributes. No write permission or automatic grant is added by this option.
See [definition read permissions](https://learn.microsoft.com/en-us/graph/api/directory-list-customsecurityattributedefinitions?view=graph-rest-1.0)
and [service principal attribute reads](https://learn.microsoft.com/en-us/graph/api/serviceprincipal-get?view=graph-rest-1.0).

The full snapshot retains separate `applicationAttributeDefinitions` and
`applicationAttributes` arrays, with separate completeness flags. Definitions
identify the attribute set/name, type and collection shape. Assignments retain
service principal object ID, application ID and raw `customSecurityAttributes`.
Strings, case distinctions, arrays and explicit nulls are preserved.
Graph responses are decoded using the literal JSON reader; even date-looking
attribute strings remain strings. Bearer/certificate reads do not follow
redirects. The standalone downloaded export embeds the reader, and the optional
Graph SDK export requests raw JSON before decoding it.

**A null value is not proof that no attribute is assigned.** Microsoft's service
principal API documents the same null response when the caller cannot access the
attributes. The collector therefore records `applicationAttributeReadScope` as
`unverified`, even after successful pagination. Do not turn that flag into
tenant-wide absence evidence. A denied definition read can coexist with successful
assignment reads; one source never overwrites the other's completeness.

Attribute read failures stay in the snapshot's error list. They do not invalidate
ordinary requirements that do not depend on app filters. Remaining filter-dependent
checks stay incomplete until matching is supported; independently provable checks
can complete without these reads.

## Remaining validation

The global-cloud lab's existing user CLI session retrieved six CA policies with
no application filters; the custom attribute definition endpoint returned 403.
No app, attribute, role, policy or consent was changed during that read probe. Evidence is recorded in
`data/application-filter-read-probe.local.json`.

A subsequent isolated report-only probe created its baseline policy, but Microsoft
returned HTTP 403 on the first application-filter policy. No filter applicability
cases ran. All eight temporary objects were removed; independent reads confirmed
their absence, unchanged existing policies and unchanged protected accounts.
Evidence: `data/application-filter-lab-safety-review.local.json`. Live filter
validation requires separately approved access; it has not been completed.

Microsoft's Graph beta policy example uses a qualified property such as
`CustomSecurityAttribute.AttributeSet_AttributeName`. Its separate identity
research sample uses a dotted form. They are not interchangeable evidence of
runtime behavior. Before crediting filters, validate accepted grammar, scalar
versus collection operators, case and null handling, explicit-resource/filter
combination, exclusions, resource groups and registration/resource contexts.
Sources: [Graph policy example](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-post-policies?view=graph-rest-beta),
[Microsoft identity research sample](https://microsoft.github.io/identity-spiffe/platform-learnings/Conditional-Access-Learnings/).

## Sanitized investigation data

Sanitization links exported definitions, assignments and filter references. It
preserves exact and ordinal case-insensitive string equality and collection
membership, including case-distinct names, Unicode values, nulls and empty arrays.
An independent 120-point check compares these predicates before and after
sanitization. This establishes structural parity, not Microsoft's runtime matching
behavior. Numeric ordering and scalar substring relationships are not established.

With a full snapshot, scalar substring filters fail before output is written;
opaque replacement values cannot preserve those relationships. Review policy-only
exports because attribute shape may be unavailable. The analyzer continues to
report dependent application-filter matching as unverified until live matching is
verified. A safe rejection by the sanitizer is not a matching/conformance result.
