# External-user targeting

Keep **User type** and **External-user category** distinct. A directory Member
can be a B2B collaboration member; a Guest can have credentials managed locally.
Neither name, email domain, invitation state nor the `#EXT#` sign-in-name pattern
establishes the full CA external-user category or home tenant.

The translator supports modern `includeGuestsOrExternalUsers` and
`excludeGuestsOrExternalUsers` selectors, their category flags and all/enumerated
tenant lists. User/group/role inclusion is OR; exclusions take priority.

The lab What If comparison exposed two important distinctions:

- The legacy `GuestsOrExternalUsers` value in `includeUsers`/`excludeUsers`
  follows the directory UserType: Guest matches, Member does not. It must not be
  substituted for the modern selection when external Members need protection.
- Selecting the local `internalGuest` category applies to those local Guests
  regardless of an external-tenant enumeration. Tenant enumeration narrows the
  external categories, not that local category.

The corrected translator matches all 288 policy decisions in 32 hypothetical
external-category/home-tenant What If scenarios. The tests used only an isolated
group, disabled test users and report-only exclusion policies, with all four
protected accounts excluded. Cleanup of all 16 fixtures was verified. The original
oracle mistakes and pre-fix mismatches are retained; this is applicability
evidence, not a successful external authentication test.

The latest matrix also supplies overlapping collaboration/direct-connect flags.
Microsoft documents overlap for eligible users in Teams/SharePoint contexts.
Treating categories as mutually exclusive could miss mutually excluded policies:
one protects collaboration except direct connect, another protects direct connect
except collaboration, and their shared category remains uncovered.

## Offline facts and missing information

An enriched snapshot may include explicit per-user `externalUserType` and
`externalTenantId` facts. Supported categories are `none`, `internalGuest`,
`b2bCollaborationGuest`, `b2bCollaborationMember`, `b2bDirectConnectUser`,
`otherExternalUser` and `serviceProvider`. Multiple applicable flags are supplied
as a comma-separated string; `none` must stand alone. Enumerated home-tenant IDs must be GUIDs.
Keep the source and scope of any supplied classification evidence with the export.
A hypothetical What If category does not establish the actual account's category.
An explicit category value declares the complete category set for the assessed
context. A single observed flag is insufficient to rule out overlapping flags in
other application/sign-in contexts; leave the field absent when that is unknown.

Standard directory collection does not supply a definitive external category or
home-tenant ID for every account. Missing facts stay unknown. The analyzer uses
one shared category set and home-tenant state across all policies for a sign-in. It
checks all 64 subsets of the six flags and the exact tenant classes referenced by policy,
plus the remaining tenant class. Known exported facts restrict those states.
This is a conservative superset: exported configuration does not establish that
every flag combination is reachable. A remaining gap depending on unknown flags
stays unverified; hypothetical What If acceptance does not prove reachability.

Complementary policies can therefore prove protection without knowing the home
tenant: a policy for partner tenant A and another covering everyone except those
same users can collectively satisfy MFA. Changing the second policy to exclude
tenant B leaves a counterexample specifically for B. Policies cannot independently
assume different categories or home tenants for the same sign-in. Unlisted known
home tenants share a class only when all policy selectors treat them identically;
this avoids a separate scenario for every tenant in the directory.

If protection holds across every possible state, missing identity facts do not
prevent a complete result. Remaining gaps that depend on those facts stay
unverified and unscored. One notice per requirement lists the affected account
and policy IDs; the example shows the relevant category and tenant condition.

Directory exports also do not enumerate every B2B direct-connect or service
provider actor without a local user object. Account totals count identities in
the supplied snapshot. These results cannot establish coverage for absent actors;
they need explicit scenario identities and context.

## Organisation-defined contractor rules

Account definitions can use **Email address → Ends with → @partner.example**,
or an explicit group, user selection or known external home-tenant ID. The email
rule defines your cohort; it does not infer a Microsoft external-user category or
home tenant. Standard collection now exports `mail` and `otherMails`, so these
definitions can run offline. Missing attributes remain unresolved. Member/Guest
values are kept exactly as exported, and no Employee/Contractor label is inferred.

References: [CA external selections](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessguestsorexternalusers?view=graph-rest-1.0),
[external user categories](https://learn.microsoft.com/en-us/entra/external-id/authentication-conditional-access),
[overlapping CA assignments](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-users-groups),
[What If identity inputs](https://learn.microsoft.com/en-us/graph/api/resources/usersignin?view=graph-rest-1.0).
