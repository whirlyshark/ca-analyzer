# Export policies for an intent review

Copy **Export-CaIntent.ps1** into PowerShell Cloud Shell and run:

```powershell
./Export-CaIntent.ps1
```

Download **ca-intent.sanitized.json** afterwards. The script reuses the current
Azure CLI session. It does not start a sign-in or ask for consent in this mode.
Your existing session and account must already have permission to read CA policies.
If access is denied, the script stops without writing an export.

To use a Microsoft Graph access token from your browser session instead:

```powershell
./Export-CaIntent.ps1 -UseAccessToken
```

Paste the token at the hidden prompt. Do not paste a cookie, a full request header,
or put the token into the command itself. A leading `Bearer ` is accepted. This mode
requires no Azure CLI or Graph PowerShell module, starts no sign-in or consent, and
does not save or print the token. The token must be unexpired, issued for Microsoft
Graph, and authorised for the configuration reads; it cannot bypass a permission
denial. Use a session in the intended tenant: `-TenantId` cannot be combined with
this mode. The script does not inspect token claims or independently verify the
tenant. Microsoft Graph validates the token when processing each request.

If you already hold a SecureString in a local PowerShell variable, you can pass
`-UseAccessToken -AccessToken $token`. The script leaves your SecureString intact;
the hidden prompt is the simpler option. No real token should be shared in chat.

For an existing Microsoft Graph PowerShell connection:

```powershell
./Export-CaIntent.ps1 -UseGraphSession
```

For local browser sign-in, install the authentication module once, then run:

```powershell
Install-Module Microsoft.Graph.Authentication -Scope CurrentUser
./Export-CaIntent.ps1 -InteractiveLogin -TenantId '<tenant-guid>'
```

Browser sign-in requests read-only **Policy.Read.All**; admin consent may be needed.
An optional `-ClientId '<app-guid>'` can use your own delegated reader registration.
Cloud Shell needs no PowerShell modules. All modes require PowerShell 7.4 or later.
Use `-OutputPath './another-name.json'` for another export; existing files are refused.
Use optional `-TenantId '<tenant-guid>'` to check that an existing session is in the
expected tenant. The script never switches directories automatically.

The file contains user CA policies (including disabled and report-only policies),
named locations, and referenced authentication strengths with their method restrictions.
Workload-only policies are omitted. Only GET requests are made. No account inventory,
group memberships, role assignments, app inventory, sign-in logs, Intune assignments
or credentials are exported. Tenant identity is omitted. Raw responses stay in memory;
only sanitised JSON is written. No reverse mapping is saved.

Policy and named-location **names are deliberately retained**. Review those names
before sharing: they can contain identifying details. Descriptions and other text,
tenant-specific IDs and filter literals are replaced consistently within a run;
new runs use different identifiers. Named-location references still match their
definitions, and IP ranges retain subnet/overlap relationships. Country codes,
control settings, public role-template IDs and selected public Microsoft app IDs
remain readable. Custom app and group names are not looked up.

This small bundle is for discussing likely requirements. It is **not an account-level
CALens snapshot or deployable backup**. We cannot determine who belongs to a group,
prove that policies reflect intended business rules, or verify enforcement from this
file alone. Filter substring relationships can change after sanitisation, and the
synthetic IPs do not retain real geography. Referenced authentication-context IDs
remain in policy conditions; their separate definitions are not collected.

The Graph API permissions are documented for
[CA policies](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-list-policies?view=graph-rest-1.0)
and [authentication strengths](https://learn.microsoft.com/en-us/graph/api/authenticationstrengthroot-list-policies?view=graph-rest-1.0).
