# PIM for Groups

A group assigned a privileged role can have eligible members who are absent from
its current member list. Ordinary directory role eligibility exports do not
include that separate PIM for Groups membership eligibility.

The analyzer now includes exported eligible members of a privileged-role group
in privileged requirements. Eligibility through another principal group is
expanded to possible users, including chains. Eligible ownership is kept distinct
from eligible membership. Account filters can select `eligibleGroupIds` explicitly.
Missing or malformed PIM group evidence leaves dependent classifications
unresolved; an empty current member list cannot establish that no one is eligible.

Collect the optional facts using an existing Cloud Shell/Azure CLI session:

```powershell
./Export-TenantSnapshot.ps1 -TenantId '<tenant-guid>' -IncludePimGroups
```

The account/token must already be allowed to read these Graph APIs. Reusing a
Cloud Shell session does not add permissions or grant consent. The extra APIs use
**PrivilegedEligibilitySchedule.Read.AzureADGroup** and
**PrivilegedAssignmentSchedule.Read.AzureADGroup**. For delegated access, the
signed-in user also needs the relevant reader rights; Microsoft lists Global
Reader for both role-assignable and non-role-assignable groups.

The optional switch reads each group's eligibility/assignment schedule instances
and direct members, with pagination and separate completeness flags. Default
collection does not request the additional APIs. A denied collection is recorded
as incomplete. No group membership, role, policy or permission is modified.
The explicit `-InteractiveLogin -IncludePimGroups` export variant requests these
extra read scopes through Graph PowerShell; its normal consent requirements apply.
In the local UI, select **Include PIM group eligibility** before connecting. Direct
sign-in requests the two extra delegated read scopes only when selected; the app
registration needs those permissions and consent. Existing-token collection uses
the token's existing permissions. The Cloud Shell command gains the optional
switch when selected. Choosing it never grants permissions by itself.

The snapshot stores `pimGroupEligibility`, `pimGroupAssignments` and
`groupDirectMembers`. The sanitizer preserves references, completeness keys and
membership/ownership/assignment vocabulary across those collections.

## Offline membership and role states

The raw-export translator now couples individual PIM membership activation,
nested group membership, CA group inclusions/exclusions and active roles assigned
to groups. A permanent group role follows membership; it cannot independently
become active while the person is outside the group. Separate direct role
assignments and eligibility remain independent sources of role access.

Current transitive membership alone is insufficient: an activated member may
deactivate, and an eligible non-member may activate. Complete direct memberships
and assignment instances distinguish permanent membership from temporary PIM
activation. Ownership does not confer membership. An eligible principal group
allows its eligible people to activate individually, not the whole group.

Schedule windows use the snapshot's `capturedAtUtc`, never the analysis machine's
clock. Future/expired eligibility is not treated as currently available. A missing
end date is distinct from an explicit null (permanent) end date. Contradictory
direct/transitive membership, expired activation still in the member list,
missing schedule dates, unknown assignment types and nesting cycles leave checks
unverified. This assesses configuration in force at the exported time, plus
eligible activation/deactivation states; it does not forecast future expiry.

This also covers time-bounded **assigned** memberships: a future or expired
assignment still present in the member list cannot be treated as permanent
protection. A separate matching current assignment can explain an older expired
row. Null/malformed schedule collections are not successful empty reads.

PIM completeness is tracked per group. Explicit
`pimGroupEligibility:<group-id>`, `pimGroupAssignments:<group-id>` and
`groupDirectMembers:<group-id>` flags take precedence over aggregate flags.
Independent successful reads remain usable when another group fails. If a source
group is incomplete, uncertainty follows nested-membership and inherited-
eligibility dependencies to the affected groups and roles. An unrelated group's
error or nesting cycle does not erase known membership in a separate group.

Account filters retain confirmed eligible group IDs and explicitly unknown group
IDs. A positive match on confirmed eligibility remains usable; a match or NOT
condition depending on an unknown group stays unresolved. Privilege classification
uses the groups assigned privileged roles, rather than requiring every unrelated
group in the directory to be complete. Group GUID references in per-collection
flags are canonicalized, and conflicting spellings are rejected.

PIM uncertainty is also checked against the remaining findings. An unverified
group policy for one app does not make an independent gap in another app
unverified. The same check respects client/platform/network scope, explicit
account exclusions, confirmed membership bounds and grant alternatives. For
example, a policy whose MFA grant is already satisfied cannot close a finding
that requires access to be blocked.

Policy/account relationships remain paired: uncertainty about one person in one
policy is not copied to another person in a different policy. Only membership and
role coordinates are relaxed; other request conditions retain their meaning.
If the check is invalid, unsupported or exceeds its computation budget, the
original uncertainty remains. This refinement applies to PIM-group diagnostics;
other missing-data diagnostics keep their own conservative checks.

When PIM evidence is missing, relevant group membership stays symbolic rather
than being fixed to current members. Complementary policies can still prove
protection across every possible membership state. Remaining possible gaps stay
unverified and unscored. A privileged-group classification also needs the complete
PIM facts, so an empty current group cannot imply that no one is eligible.

**Remaining validation boundaries:** eligibility inherited through a group whose
own membership can change, and role activation depending on changing group
eligibility, retain activation-lifetime uncertainty. The model checks a superset
of possible states and only resolves that uncertainty when every state is
protected. Actual activation requirements, claim propagation delays and token
lifetimes are separate from this settled-configuration model. Live PIM group
validation still needs an authorized lab token; the existing Azure CLI session
returned HTTP 403 on a read-only eligibility probe. No permissions were changed.

The normalized evaluator now supports per-identity `scenarioConstraints`: AND
groups of OR rectangles, combined with that identity's rectangular `conditions`
and the global constraints. Equivalent identity grouping includes these coupled
facts. The independent oracle checks 28,800 points, overlapping clauses,
different relationships for otherwise identical people and impossible-state
rejection. The raw PIM translator additionally has 49 known-answer cases,
16,992 independent raw-policy point comparisons and UI/PowerShell parity.
The 10,000-account/20-policy PIM fixture has 5,001 eligibility rows and 1,667
active instances: four identity profiles prove compensation without enumerating
every person's full Cartesian product. A second fixture gives every one of 1,000
people 20 independent eligible memberships (1,048,576 combinations per person),
with 21 compensating group/role policies. Exact role-to-group substitutions and
leaf-membership variables avoid redundant equality dimensions. The point oracle
also includes non-aliased direct role sources, so substitution is checked against
raw policy semantics. UI examples show the named group and Member/Not a member;
the JSON retains complete scenario regions.

For direct CA role targeting, only an explicitly tenant-scoped (`directoryScopeId:
"/"`) assignment to a confirmed built-in role is credited. Administrative-unit,
object and application scopes do not count as tenant-wide assignments. Missing
scope, inconsistent scope metadata or unresolved referenced role definitions
leave role-dependent assessments unverified. Privilege classification also stays
unknown when an account's assigned role definition is missing. Ordinary app-wide
requirements do not become incomplete merely because unused role scope is absent.

Directory role schedules and PIM group windows now use the same strict,
100-nanosecond clock. Current/future/expired eligibility and assignment-instance
evidence are described in [role schedule timing](ROLE-SCHEDULES.md).

Sources: [PIM group concepts and nesting](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/concept-pim-for-groups),
[eligibility collection and permissions](https://learn.microsoft.com/en-us/graph/api/privilegedaccessgroup-list-eligibilityscheduleinstances?view=graph-rest-1.0),
[assignment collection and permissions](https://learn.microsoft.com/en-us/graph/api/privilegedaccessgroup-list-assignmentscheduleinstances?view=graph-rest-1.0).

Role scope references: [CA supported roles](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-users-groups),
[Graph role assignment scopes](https://learn.microsoft.com/en-us/graph/api/resources/unifiedroleassignment?view=graph-rest-1.0).
