# Role assignments and PIM schedule timing

Analysis uses the snapshot's `capturedAtUtc`, not the computer's current time.
Reassessing the same export therefore checks the same point in time. Refresh the
export to assess subsequent expiry or newly effective eligibility.

Built-in role assignments may reference either the role's directory-specific
definition ID or its shared template ID. Both resolve through the exported role
catalog before matching assignments, eligibility and schedule instances. Mixed
references therefore preserve the same fixed/temporary membership, privilege
classification and role-based account definitions. Only an explicitly built-in
definition establishes a template alias. A custom role's arbitrary template value
cannot inherit built-in CA targeting. Unknown references remain unresolved;
colliding template/definition mappings are rejected as an inconsistent catalog.
The original export is retained unchanged.

The collector exports current `roleAssignments`, `roleEligibility` schedule
instances and `roleAssignmentScheduleInstances`. Eligibility is current when
`startDateTime <= capturedAtUtc < endDateTime`; an explicit null end is unbounded.
Missing dates, invalid calendar values, unsupported precision, contradictory
intervals or missing capture time remain uncertain. Future and expired known
eligibility do not classify an account as currently eligible.

An active assignment is credited as fixed CA role membership only when a matching
current **Assigned / Direct** schedule establishes its origin, principal, role
and scope. A current **Activated** instance remains able to deactivate, including
when its eligibility has already ended. Historical activations do not override a
verified current assigned instance. Missing instances, conflicting types, origin
mismatches and current instances absent from the active-assignment export cannot
silently establish fixed membership or hide a potentially privileged account.

Incomplete timing affects dependent CA role policies, automatic privileged-account
selection and role-based account filters. It does not invalidate unrelated checks
whose protection is proved without that fact. Unknown privileged membership cannot
silently exclude an account from an organization's requirement. Explicit manual
account lists remain independent of automatic privilege classification.

Directory and PIM group schedules share a strict clock with 100-nanosecond
precision. The sanitizer preserves ordering/equality at that precision while
replacing identifying dates and durations with a synthetic timeline. These are
configuration/settled-state checks; they do not prove token propagation, activation
workflow success or method-specific authentication reachability. Inherited group
eligibility with unresolved source/lifetime relationships remains unverified.

## Collecting the facts

The direct-reader registration already requests **RoleManagement.Read.Directory**,
which covers both directory schedule reads. A delegated user also needs a supported
reader role, such as Global Reader. Existing Cloud Shell/CLI tokens do not gain
those scopes merely because the user can read ordinary role assignments. On a
403 the collector records incomplete data; analysis does not substitute an empty
successful schedule collection. No permission changes are made by analysis.

The current lab CLI session could read nine active assignments but returned 403
for both schedule collections. Saved probe evidence is
`data/role-schedule-read-probe.local.json`. This establishes the read limitation,
not live schedule conformance. The test fixtures supply explicit fictional
dates/types/origins; `examples/fictional-role-facts.cjs` is development-only and is
never used to enrich tenant exports or included in the portable product.

Sources: [eligibility instance fields](https://learn.microsoft.com/en-us/graph/api/resources/unifiedroleeligibilityscheduleinstance?view=graph-rest-1.0),
[assignment ID alternatives](https://learn.microsoft.com/en-us/graph/api/rbacapplication-post-roleassignments?view=graph-rest-1.0#example-1-create-a-role-assignment-with-tenant-scope),
[role definition fields](https://learn.microsoft.com/en-us/graph/api/resources/unifiedroledefinition?view=graph-rest-1.0),
[assignment instance fields](https://learn.microsoft.com/en-us/graph/api/resources/unifiedroleassignmentscheduleinstance?view=graph-rest-1.0),
[eligibility read permissions](https://learn.microsoft.com/en-us/graph/api/rbacapplication-list-roleeligibilityscheduleinstances?view=graph-rest-1.0),
[assignment read permissions](https://learn.microsoft.com/en-us/graph/api/rbacapplication-list-roleassignmentscheduleinstances?view=graph-rest-1.0).
