# Additional grant requirements

The analyzer retains provable minimum protection when a policy also requires an approved client, app protection, Terms of Use, a custom control, password change or risk remediation.

| Policy grants | What can be proved offline |
| --- | --- |
| MFA AND Terms of Use | MFA is required. |
| MFA OR app protection | MFA is not guaranteed by this policy. Whether the alternative actually permits access needs enforcement evidence. |
| MFA AND password change | MFA is required in the targeted user-risk scenarios. |
| Phishing-resistant strength AND risk remediation | The strength is required in the targeted user-risk scenarios. |

These additional controls never stand in for MFA, phishing resistance, compliant devices or blocked access. They are modeled as potentially satisfiable restrictions: this preserves necessary grant conditions without asserting that an app, device, agreement or remediation flow can actually complete. Remaining possible gaps are unverified where those restrictions apply. An unrelated app is not made unverified; independent policies that fully prove the requirement discharge the uncertainty.

The current requirement builder does not assess the content or assignment of Intune app protection policies, agreement acceptance, custom-provider outcomes, password-change completion or risk remediation completion. Those require further exported/runtime evidence and separate requirement types. This is grant-composition support, not a complete implementation of those downstream services.

Malformed lists, unknown grants/operators, mixed Block grants, and remediation configurations that violate Microsoft's documented prerequisites are rejected as unsupported policies. Their grants are never credited. Unresolved security configuration participates in acceptance keys, so changing an agreement/control reopens review. History uses a new model version rather than treating changed translation as a tenant improvement.

The MFA grant and authentication-strength grant cannot coexist in a single CA
policy. Both AND and OR versions of that invalid combination are rejected.
Separate valid policies can require MFA and an authentication strength together.

Microsoft's current documentation says existing enabled approved-client policies remain enforced after the control became read-only on June 30, 2026. The analyzer does not silently remove this grant based on its retirement date.

Sources checked November 16, 2026:

All built-in Graph reader transports request `Prefer: include-unknown-enum-members`,
including each pagination page and certificate-token retries. Microsoft requires
this preference to return `riskRemediation` rather than an evolvable-enum sentinel.
Existing external exports that contain `unknownFutureValue` remain unsupported;
the analyzer never guesses which control the sentinel represents. Re-export with
the updated collector to preserve the actual value. This header adds no permission
or sign-in requirement.

- [Graph grant controls and remediation prerequisites](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessgrantcontrols?view=graph-rest-1.0)
- [Approved client migration and continued enforcement](https://learn.microsoft.com/en-us/entra/identity/conditional-access/migrate-approved-client-app)
- [Custom controls](https://learn.microsoft.com/en-us/entra/identity/conditional-access/controls)

Validation: `Test-GrantEngine.ps1` exercises raw exported policies through C# and embedded V8; `Test-GrantProperties.ps1` checks 3,072 independently evaluated necessary-access points across 32 generated policy sets; `Test-SanitizedGrants.ps1` checks offline pseudonymization. These tests establish the conservative composition model, not live downstream enforcement conformance.
