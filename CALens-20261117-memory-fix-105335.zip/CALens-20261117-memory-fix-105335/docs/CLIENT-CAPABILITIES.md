# Client capabilities and offline coverage

Legacy clients cannot satisfy MFA or send device state. An enforced policy that
requires MFA, compliance or hybrid join can therefore block them. Blocking meets
a minimum-protection requirement; it does not make the client capable of MFA.

For example, an all-client MFA policy meets a phishing-resistant minimum for a
legacy-only scope by blocking it. A policy scoped only to modern clients leaves
legacy password access uncovered unless another policy blocks it. Report-only
and disabled grants do not protect either scope. AND/OR alternatives still apply.

Snapshot analysis represents `other`, `exchangeActiveSync` and the older
`easSupported` subset with single-factor authentication and no compliant,
hybrid-joined or registered-device claim. Device attributes follow the existing
unregistered-device partitions. Absence of a compliance attribute is not silently
equated with a literal false attribute; those separate observations remain where
the filter's answer depends on them.

Graph defines Exchange ActiveSync as covering supported and unsupported EAS
platforms. Selecting it in a policy or requirement therefore includes the older
supported subset. The reverse inclusion is not assumed. The UI names that subset
explicitly. Duplicate subset selections do not reconfigure a saved requirement.

These protocol facts belong to raw snapshot translation and physical history
comparison. The generic normalized-model engine still evaluates the domain that
its caller declares. Adding a device filter must not invent registered legacy
requests in an earlier saved check. Raw policy-only source identity also retains
original report-only grants and conditions.

Modern browser/mobile/desktop clients retain their existing possibilities.
Legacy basic-auth requests use the ordinary flow partition. They do not initiate
OAuth device-code or authentication-transfer sessions. Consequently a modern-client
block of those flows does not leave a confirmed legacy-protocol flow gap; it still
does not block ordinary basic-auth access. A requirement restricted entirely to an
impossible legacy/flow combination is reported as an empty feasible scope, not a
successful coverage result.

Basic-auth mail requests also cannot themselves register security information,
join/register a device, or request an OAuth authentication-context claim. A
registration interrupt or claims challenge uses a separate modern request.
Legacy classes are therefore confined to application access, not these action
or context targets. A legacy-only registration/context requirement reports an
empty feasible scope. Ordinary legacy app gaps remain assessable.

Microsoft documents flow tracking through OAuth token refreshes. CALens retains
the flow marker on modern requests rather than assuming every marked request is
the initial device-code or QR-code interaction. It does not simulate token chains.
This does not prove an individual app, authentication method or OAuth flow is
reachable. In particular, ROPC is not declared MFA-capable merely because its
client is classified as modern. Further protocol/flow feasibility validation
remains part of release testing.

Sources: [Microsoft client capabilities](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-conditions#client-apps),
[Graph client selectors](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessconditionset?view=graph-rest-1.0),
[authentication flows and protocol tracking](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-authentication-flows).
The exclusion of basic-auth/OAuth combinations is a protocol inference from these
documents, not a new live sign-in observation.
The action/context inference also follows Microsoft's
[combined registration experience](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-registration-mfa-sspr-combined)
and [OAuth claims-challenge protocol](https://learn.microsoft.com/en-us/entra/identity-platform/claims-challenge).
