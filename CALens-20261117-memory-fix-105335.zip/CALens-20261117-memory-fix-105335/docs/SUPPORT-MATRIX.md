# First-release candidate support matrix

This defines the candidate's working boundary: exported configuration coverage, not a live sign-in simulator. Exact package and validation evidence are identified separately. Product feedback can change this boundary; unsupported capabilities are retained visibly rather than silently removed.

| Area | Offline assessment | Additional evidence / boundary |
|---|---|---|
| Identities and account sets | Exported users, Member/Guest, explicit fields, manual/filter sets, configured role selections | Missing relevant identity fields or inventory completeness remains unconfirmed. Names do not infer business categories. |
| Groups and PIM | Exported direct/nested memberships, active and eligible role/group facts, coupled group activation and role partitions at snapshot time | Missing source/lifetime relationships and conflicting schedules remain unverified. These are settled-state/eligible-state checks, not token-propagation or activation-workflow proof. Eligibility does not mean a role is always active. |
| Policy union | Enabled policy assignments, exclusions, supported conditions, AND/OR grants and blocking | Report-only and disabled policies supply no enforcement. Blocked access meets a minimum-protection requirement by preventing access; it does not prove successful MFA. |
| Authentication | Minimum MFA, supported authentication strengths and their combinations | Does not establish registered method availability, successful prompts, token issuance or a usable login. Unsupported strength combinations stay unconfirmed. |
| Apps and request targets | Explicit applications and supported user actions/authentication contexts | Resource groups, service dependencies and token audiences require exported evidence where membership is unresolved. App/PIM context invocation is not proven. Application-filter matching remains unverified unless independently established. |
| Registration | Supported declared action/resource/mode/flow contexts and exported prerequisites | Ambiguous resource context, mixed strength precedence and recorded DRS/What If disagreements require explicit bounds. SSPR enrollment/completion and real device enrollment are not established by CA coverage. |
| Clients and flows | Supported client/platform/flow selections, EAS overlap and basic-auth protocol constraints | Basic-auth requests cannot claim MFA/device state or initiate OAuth flows, registration actions or context claims. Individual app/protocol reachability and token chains are not established; configuration examples are not proof of a live bypass. |
| Devices | Supported finite filter predicates and correlated claims | Unsupported predicates, missing relevant attributes and uncertain unregistered-device behavior remain unconfirmed. No proof of actual compliance/enrollment. |
| Locations | Exact exported IPv4/IPv6 named-location partitions, supported country metadata | AllTrusted needs relevant legacy trusted-IP configuration; GPS/runtime location evidence may remain unknown. |
| Risk and session controls | Supported risk conditions and explicitly modeled requirements | No proof of risk-generation accuracy, session timing, downstream enforcement, refresh or runtime method reachability. |
| Requirements and exceptions | User-defined intent, editable templates, region-scoped accepted findings | Acceptance acknowledges risk; it adds no protection and cannot resolve uncertainty. |
| Mapping and recommendations | Verified finite-model contributions, combined coverage, related policy candidates | Suggested changes are unevaluated until simulated separately. No automatic tenant remediation. |
| Import/export and execution | Complete snapshots, explicit policy-only review, local browser and offline/scheduled commands | Policy-only input cannot identify every affected account. Export completeness/freshness must stay visible; collection is optional and uses read-only authentication. |
| Workloads / hosting | Excluded from first-release scope | No workload identity CA, multi-user service or hosted deployment. |

Microsoft What If provides policy-applicability observations. It is not a successful-login or MFA-prompt oracle. Evidence-fed replay is distinguished from independent expectations. Missing information, resource-context deferrals and documented conflicts are reported separately from matching decisions.
