@echo off
where pwsh >nul 2>nul
if errorlevel 1 (
  echo PowerShell 7.4 or later is required. Install PowerShell 7 and try again.
  pause
  exit /b 1
)
pwsh -NoProfile -File "%~dp0Start-UI.ps1"
if errorlevel 1 pause
