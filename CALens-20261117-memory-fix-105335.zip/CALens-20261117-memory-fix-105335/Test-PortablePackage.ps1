#Requires -Version 7.4
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PSScriptRoot)
$manifest=Get-Content -LiteralPath (Join-Path $root 'package.manifest.json') -Raw|ConvertFrom-Json
if($manifest.version -ne 1 -or !$manifest.files.Count){throw 'Missing or unrecognized package inventory.'}
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($file in $manifest.files){
 $relative=[string]$file.path
 if([IO.Path]::IsPathRooted($relative) -or ($relative -split '[/\\]') -contains '..' -or !$seen.Add($relative)){throw 'Unsafe or duplicate package inventory path.'}
 $path=[IO.Path]::GetFullPath((Join-Path $root $relative))
 if(!$path.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Package inventory escaped the product folder.'}
 $item=Get-Item -LiteralPath $path
 if($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne $file.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw "Package integrity check failed: $relative"}
 $parent=$item.Directory
 while($parent.FullName -ne $root){if($parent.Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Linked package directories cannot be verified: $relative"};$parent=$parent.Parent}
}
foreach($required in @('Start-UI.ps1','Start-Assessment.ps1','engine/GapEngine.cs','dependencies/runtime.lock.json')){if(!$seen.Contains($required)){throw "Required package file missing: $required"}}
& (Join-Path $root 'Initialize-Dependencies.ps1') -VerifyOnly
Write-Host "Portable package verified: $($manifest.files.Count) files. Hashes detect changes; they are not a publisher signature."
