'use strict';
const ResourceGroups={
 ids:['Office365','MicrosoftAdminPortals','797f4846-ba00-4fd7-ba43-dac1f8f63013'],
 names:{Office365:'Office 365',MicrosoftAdminPortals:'Microsoft Admin Portals','797f4846-ba00-4fd7-ba43-dac1f8f63013':'Windows Azure Service Management API'},
 canonical:id=>{if(typeof id!=='string')return id;if(/^[a-f\d]{8}-(?:[a-f\d]{4}-){3}[a-f\d]{12}$/i.test(id))return id.toLowerCase();return {all:'All',office365:'Office365',microsoftadminportals:'MicrosoftAdminPortals'}[id.toLowerCase()]||id;},
 isGroup(id){return this.ids.includes(this.canonical(id));},
 merge(snapshot,evidence){
  if(snapshot?.caGapSnapshotVersion!==1)throw Error('Import the tenant snapshot before adding resource-group evidence.');
  if(evidence?.resourceGroupEvidenceVersion!==1||!Array.isArray(evidence.resourceGroups)||!evidence.resourceGroups.length)throw Error('Choose a version 1 resource-group evidence file.');
  if(typeof snapshot.tenantId!=='string'||typeof evidence.tenantId!=='string'||snapshot.tenantId.toLowerCase()!==evidence.tenantId.toLowerCase())throw Error('Resource-group evidence belongs to a different tenant.');
  const ids=evidence.resourceGroups.map(g=>this.canonical(g?.id));if(ids.some(id=>!this.isGroup(id))||new Set(ids).size!==ids.length)throw Error('Resource-group evidence contains unknown or duplicate group IDs.');
  const prepared=this.prepare([],['other-resource'],evidence.resourceGroups,ids);if(prepared.errors.size)throw Error([...prepared.errors.values()].join(' '));
  const next=structuredClone(snapshot);next.resourceGroups=[...(Array.isArray(next.resourceGroups)?next.resourceGroups:[]).filter(g=>!ids.includes(this.canonical(g?.id))),...structuredClone(evidence.resourceGroups).map(g=>({...g,id:this.canonical(g.id)}))];return next;
 },
 prepare(policies,applications,evidence=[],additional=[]){
  const groups=[...new Set([...policies.filter(p=>p.state==='enabled').flatMap(p=>[...p.conditions?.applications?.includeApplications||[],...p.conditions?.applications?.excludeApplications||[]]),...additional].filter(id=>this.isGroup(id)).map(id=>this.canonical(id)))];
  const apps=[...applications],facts=new Map(),errors=new Map(),dimensions={},constraints=[],unknown=new Map();
  for(const group of groups){
   dimensions['resourceGroup.'+group]=['false','true'];
   const entries=Array.isArray(evidence)?evidence.filter(e=>this.canonical(e?.id)===group):[];
   let entry=entries[0],valid=entries.length===1;
   if(valid){
    const keys=['id','members','nonMembers','complete','provenance'];
    valid=Object.keys(entry).every(k=>keys.includes(k))&&typeof entry.complete==='boolean'&&Array.isArray(entry.members)&&Array.isArray(entry.nonMembers)&&[...entry.members,...entry.nonMembers].every(id=>typeof id==='string'&&id.trim()&&id!=='other-resource'&&(!this.isGroup(id)||this.canonical(id).includes('-')))&&entry.provenance&&['declared','whatIf','microsoftDocumentation'].includes(entry.provenance.kind)&&typeof entry.provenance.description==='string'&&!!entry.provenance.description.trim();
    if(valid){const members=new Set(entry.members.map(this.canonical)),nonMembers=new Set(entry.nonMembers.map(this.canonical));valid=![...members].some(id=>nonMembers.has(id));if(valid)facts.set(group,{members,nonMembers,complete:entry.complete});}
   }
   if(entries.length&&!valid)errors.set(group,'Resource-group evidence is malformed or contradictory.');
   if(!valid)facts.set(group,{members:new Set(),nonMembers:new Set(),complete:false});
   const fact=facts.get(group);
   for(const id of [...fact.members,...fact.nonMembers])if(!apps.some(a=>this.canonical(a)===id))apps.push(id);
   if(group.includes('-')){fact.members.add(group);if(!apps.some(a=>this.canonical(a)===group))apps.push(group);if(fact.nonMembers.has(group)){errors.set(group,'A resource selector contradicts its own resource membership.');fact.nonMembers.delete(group);}}
  }
  for(const group of groups){
   const fact=facts.get(group),yes=[],no=[],maybe=[];
   for(const id of apps){const key=this.canonical(id);if(fact.members.has(key))yes.push(id);else if(fact.complete||fact.nonMembers.has(key))no.push(id);else maybe.push(id);}
   const clauses=[];if(yes.length)clauses.push({application:{include:yes},['resourceGroup.'+group]:{include:['true']}});if(no.length)clauses.push({application:{include:no},['resourceGroup.'+group]:{include:['false']}});if(maybe.length)clauses.push({application:{include:maybe}});
   constraints.push(clauses);unknown.set(group,maybe);
  }
  return {groups,applications:apps,dimensions,constraints,unknown,errors};
 },
 clauses(assignment,dimensions){
  const include=assignment.includeApplications||[],exclude=assignment.excludeApplications||[];
  if(!include.length||exclude.includes('All'))throw Error('Invalid resource inclusion/exclusion.');
  const groupExcluded=exclude.filter(id=>this.isGroup(id)).map(id=>'resourceGroup.'+this.canonical(id)),appExcluded=exclude.filter(id=>!this.isGroup(id));
  const base={...Object.fromEntries(groupExcluded.map(axis=>[axis,{include:['false']}]))};
  if(appExcluded.length)base.application={exclude:appExcluded};
  if(include.includes('All'))return [base];
  const clauses=[],direct=include.filter(id=>!this.isGroup(id)&&!appExcluded.includes(id));
  if(direct.length)clauses.push({...base,application:{include:direct,exclude:appExcluded}});
  for(const id of [...new Set(include.filter(id=>this.isGroup(id)).map(id=>this.canonical(id)))]){
   const axis='resourceGroup.'+id;if(!dimensions[axis])throw Error('Resource-group context is missing.');if(!groupExcluded.includes(axis))clauses.push({...base,[axis]:{include:['true']}});
  }
  return clauses;
 }
};
if(typeof module!=='undefined')module.exports=ResourceGroups;
