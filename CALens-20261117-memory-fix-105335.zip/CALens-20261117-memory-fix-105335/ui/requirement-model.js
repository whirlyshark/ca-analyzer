'use strict';
const RequirementModel={
 fields:['userType','accountEnabled','displayName','userPrincipalName','mail','otherMails','jobTitle','department','companyName','creationType','externalTenantId','externalUserType','groupIds','eligibleGroupIds','roleIds'],
 match(record,clause){
   if(!this.fields.includes(clause.field)||!['equals','startsWith','endsWith','contains','hasValue'].includes(clause.operator))throw Error('Unsupported account filter.');
   if(Object.hasOwn(clause,'not')&&typeof clause.not!=='boolean')throw Error('Account filter NOT must be true or false.');
   if(clause.field==='accountEnabled'){
     const expected=String(clause.value??'').trim().toLowerCase();
     if(clause.operator!=='equals'||!['true','false'].includes(expected))throw Error('Choose Equals and Enabled or Disabled for account status.');
     if(!Object.hasOwn(record,'accountEnabled')||typeof record.accountEnabled!=='boolean')return null;
     const matched=record.accountEnabled===(expected==='true');
     return clause.not?!matched:matched;
   }
   if(!Object.hasOwn(record,clause.field))return null;
   const raw=record[clause.field],list=Array.isArray(raw)||clause.field==='externalUserType',values=(Array.isArray(raw)?raw:clause.field==='externalUserType'&&typeof raw==='string'?raw.split(','):[raw]).map(x=>String(x??'').trim().toLowerCase());
   if(clause.field==='userType'&&!['Member','Guest'].includes(raw))return null;
   const expected=String(clause.value??'').trim().toLowerCase();
   const matched=clause.operator==='hasValue'?values.some(Boolean):values.some(v=>clause.operator==='equals'?v===expected:clause.operator==='contains'?(list?v===expected:v.includes(expected)):clause.operator==='endsWith'?v.endsWith(expected):v.startsWith(expected));
   const membership={groupIds:['uncertainGroupIds','groupIdsComplete','completeGroupIds'],eligibleGroupIds:['uncertainEligibleGroupIds','eligibleGroupIdsComplete','completeEligibleGroupIds'],roleIds:['uncertainRoleIds','roleIdsComplete',null]}[clause.field];
   if(membership){
     const [uncertainField,completeField,closedField]=membership,uncertain=new Set((record[uncertainField]||[]).map(v=>v.toLowerCase()));
     const matches=v=>clause.operator==='hasValue'?!!v:['equals','contains'].includes(clause.operator)?v===expected:clause.operator==='endsWith'?v.endsWith(expected):v.startsWith(expected);
     const guaranteed=values.filter(v=>!uncertain.has(v)).some(matches);
     // A partial catalog can still contain a fully collected specific group.
     // Other unseen IDs/prefixes stay open; absence from an array is not proof.
     const closed=closedField&&['equals','contains'].includes(clause.operator)&&(record[closedField]||[]).some(v=>v.toLowerCase()===expected);
     if(!guaranteed&&(record[completeField]===false&&!closed||[...uncertain].some(matches)))return null;
     return clause.not?!guaranteed:guaranteed;
   }
   return clause.not?!matched:matched;
 },
 resolve(sets,records){
   if(!Array.isArray(sets))throw Error('Account sets must be a list.');
   const resolved=new Map(), issues=[],recordIds=new Set(records.map(r=>r.id));
   const referenceId=id=>typeof id==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)?id.toLowerCase():id;
   const references=new Map(records.map(r=>[referenceId(r.id),r.id]));
   if(references.size!==recordIds.size)throw Error('Account IDs contain duplicate spellings of the same GUID.');
   resolved.set('all',{ids:records.map(r=>r.id),unknown:[]});
   for(const set of sets){
     if(!set.id||!set.name||resolved.has(set.id)||!['filter','manual','privileged'].includes(set.kind))throw Error('Account sets need unique IDs and names.');
     if(set.kind==='privileged'&&set.roleIds!==undefined&&(!Array.isArray(set.roleIds)||set.roleIds.some(id=>typeof id!=='string'||!id.trim())||new Set(set.roleIds.map(id=>id.toLowerCase())).size!==set.roleIds.length))throw Error('Selected roles must be a list of distinct role definition IDs.');
     const ids=[],unknown=[];
     if(set.kind==='manual'){
       for(const id of set.accountIds||[]){const actual=references.get(referenceId(id));if(actual!==undefined)ids.push(actual);else unknown.push(id);}
     }else for(const record of records){
       let state;
     if(set.kind==='privileged'){
       if(set.roleIds!==undefined){const matches=set.roleIds.map(id=>this.match(record,{field:'roleIds',operator:'equals',value:id}));state=matches.includes(true)?true:matches.includes(null)?null:false;}
       else state=record.privilegeTimingUncertain&&!record.privilegeTimingCertain?null:record.privileged===true||record.pimEligible===true?true:record.privilegeKnown===true?false:null;
     }
       else{
         if(!set.clauses?.length)throw Error(`Add a filter to ${set.name}.`);
         const results=set.clauses.map(c=>this.match(record,c));
         state=set.match==='any'?(results.includes(true)?true:results.includes(null)?null:false):(results.includes(false)?false:results.includes(null)?null:true);
       }
       if(state===true)ids.push(record.id);if(state===null)unknown.push(record.id);
     }
     resolved.set(set.id,{ids:[...new Set(ids)],unknown:[...new Set(unknown)]});
   }
   return {resolved,issues};
 },
 defaults(){return {version:1,sets:[
   {id:'members',name:'Members',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Member'}]},
   {id:'guests',name:'Guests',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Guest'}]},
   {id:'privileged',name:'Privileged accounts (including PIM eligible)',kind:'privileged'},
   {id:'breakglass',name:'Breakglass accounts',kind:'manual',accountIds:[]}
 ],requirements:[]};},
 scope(requirement,resolved){
   const who=resolved.get(requirement.accountSetId);if(!who)throw Error(`Choose an account set for ${requirement.name}.`);
   const excluded=new Set(),uncertainExclusions=new Set();
   for(const id of requirement.excludeSetIds||[]){const set=resolved.get(id);if(!set)throw Error('Unknown exclusion set.');set.ids.forEach(v=>excluded.add(v));set.unknown.forEach(v=>uncertainExclusions.add(v));}
   if(requirement.excludeSetIds?.includes(requirement.accountSetId))return {include:[],confirmed:[],unknown:[]};
   const include=who.ids.filter(id=>!excluded.has(id)),unknown=[...new Set([...who.unknown.filter(id=>!excluded.has(id)),...include.filter(id=>uncertainExclusions.has(id))])];
   return {include,confirmed:include.filter(id=>!uncertainExclusions.has(id)),unknown};
 },
 compile(profile,source){
   if(profile?.version!==1)throw Error('Unsupported requirements configuration version. Export a version 1 configuration from the analyzer.');
   if(!Array.isArray(profile.requirements)||new Set(profile.requirements.map(r=>r.id)).size!==profile.requirements.length)throw Error('Requirements must have unique IDs.');
   const D=typeof module!=='undefined'&&module.exports?require('./device-filter.js'):DeviceFilter;
   const S=typeof module!=='undefined'&&module.exports?require('./snapshot.js'):SnapshotModel;
   const G=typeof module!=='undefined'&&module.exports?require('./resource-groups.js'):ResourceGroups;
   const isResourceGroup=id=>G.isGroup(id)&&!!(source.original||source.model.dimensions['resourceGroup.'+G.canonical(id)]);
   for(const r of profile.requirements.filter(r=>r.enabled!==false))if(r.apps!==undefined&&(!Array.isArray(r.apps)||r.apps.some(id=>typeof id!=='string'||!id.trim()||['All','AllAgentIdResources'].includes(G.canonical(id)))))throw Error(`${r.name||'Requirement'}: apps must be a list of resource IDs or supported resource groups.`);
   const declaredBefore=new Set(source.declaredApplications||[]);
   const additionalApplications=[...new Set(profile.requirements.filter(r=>r.enabled!==false).flatMap(r=>r.apps||[]).map(G.canonical).filter(id=>!isResourceGroup(id)&&(!source.model.dimensions.application.includes(id)||declaredBefore.has(id))))];
   const resourceGroups=[...new Set(profile.requirements.filter(r=>r.enabled!==false).flatMap(r=>Array.isArray(r.apps)?r.apps:[]).filter(isResourceGroup).map(id=>G.canonical(id)))];
   const deviceRules=profile.requirements.filter(r=>r.enabled!==false&&r.deviceFilter).flatMap(r=>{const rule=D.requirementRule(r.deviceFilter);return [{id:'requirement-device:'+r.id,mode:'include',rule},{id:'requirement-device-outside:'+r.id,mode:'exclude',rule}];});
   const registrationContexts=profile.requirements.filter(r=>r.enabled!==false&&r.registrationContext).map(r=>{
     const c=r.registrationContext;
     for(const key of Object.keys(c))if(!['resourceId','mode','flow','provenance'].includes(key))throw Error('Unsupported registration context setting: '+key);
     if(!['registerSecurityInformation','registerOrJoinDevices'].includes(r.userAction)||typeof c.resourceId!=='string'||!c.resourceId.trim()||c.resourceId==='other-resource'||!['standard','deviceCodeFlow','authenticationTransfer'].includes(c.flow)||!(r.userAction==='registerSecurityInformation'?['manage','interrupt']:['deviceRegistration']).includes(c.mode))throw Error('Choose the registration resource, mode and authentication flow.');
     if(!c.provenance||!['declared','signInLog'].includes(c.provenance.kind)||typeof c.provenance.description!=='string'||!c.provenance.description.trim())throw Error('Record where the registration context came from.');
     return {...c,resourceId:G.canonical(c.resourceId),id:'registration:'+r.id,action:r.userAction};
   });
   let preparedDevices;
   if(deviceRules.length||registrationContexts.length||additionalApplications.length||declaredBefore.size||resourceGroups.some(id=>!source.model.dimensions['resourceGroup.'+id])){
     if(source.original?.caGapSnapshotVersion!==1)throw Error('Device and registration conditions require an original tenant snapshot. Import a full snapshot.');
     source={...S.normalize(source.original,{additionalDeviceRules:deviceRules,registrationContexts,additionalResourceGroups:resourceGroups,additionalApplications}),key:source.key,name:source.name,kind:source.kind};
     const policyRules=source.policies.filter(p=>p.state==='enabled'&&p.conditions?.devices?.deviceFilter).map(p=>({id:p.id,...p.conditions.devices.deviceFilter}));
     preparedDevices=D.prepare([...policyRules,...deviceRules]);
     for(const rule of deviceRules)if(preparedDevices.errors.has(rule.id))throw Error(preparedDevices.errors.get(rule.id));
   }
   const {resolved}=this.resolve(profile.sets,source.records), issues=[],requirements=[],knownIdentityIds=new Set(source.model.identities.map(u=>u.id));
   const resourcePartition=S.regions(source.model.dimensions);
   const combine=(left,right)=>{if(left==null)return right;if(right==null)return left;const result=[];for(const a of left)for(const b of right){const overlap=resourcePartition.intersect(resourcePartition.from(a),resourcePartition.from(b));if(overlap)result.push(resourcePartition.selectors(overlap));resourcePartition.check(result);}return result;};
   for(const r of profile.requirements.filter(r=>r.enabled===false&&r.pendingSetup?.length))issues.push({requirementId:r.id,message:`${r.name}: finish template setup before this requirement can be assessed.`});
   for(const original of profile.requirements.filter(r=>r.enabled!==false)){
     const r={...original,...(source.original&&Array.isArray(original.apps)?{apps:original.apps.map(G.canonical)}:{}),...(source.original&&Array.isArray(original.networks)?{networks:original.networks.map(G.canonical)}:{})};
     const graphAudienceUncertain=!!source.original&&r.apps?.includes('00000003-0000-0000-c000-000000000000');
     const known=['id','name','accountSetId','outcome','protections','excludeSetIds','apps','platforms','clients','flows','signInRiskLevels','userRiskLevels','networkMode','networks','authenticationContextId','userAction','registrationContext','blockOtherApps','deviceFilter','pendingSetup','enabled','origin'];
     for(const key of Object.keys(r))if(!known.includes(key))throw Error(`${r.name||'Requirement'}: unsupported setting ${key}. It cannot be silently ignored.`);
     if(!r.id||!r.name||!['mfa','phishingResistant','compliant','hybridJoined','block'].includes(r.outcome))throw Error('Requirement name and outcome are required.');
     for(const key of ['apps','platforms','clients'])if(r[key]!==undefined&&!Array.isArray(r[key]))throw Error(`${r.name}: ${key} must be a list.`);
     if(r.flows!==undefined&&(!Array.isArray(r.flows)||new Set(r.flows).size!==r.flows.length||r.flows.some(v=>!['standard','deviceCodeFlow','authenticationTransfer'].includes(v))))throw Error(`${r.name}: choose valid, distinct authentication flows.`);
     if(r.registrationContext&&r.flows?.length&&!r.flows.includes(r.registrationContext.flow))throw Error(`${r.name}: the selected flows conflict with the registration context's flow.`);
     for(const field of ['signInRiskLevels','userRiskLevels'])if(r[field]!==undefined&&(!Array.isArray(r[field])||new Set(r[field]).size!==r[field].length||r[field].some(v=>!['none','low','medium','high','hidden','unknownFutureValue'].includes(v))))throw Error(`${r.name}: choose valid, distinct ${field==='signInRiskLevels'?'sign-in':'user'} risk levels.`);
     if(r.pendingSetup?.length)throw Error(`Finish configuring ${r.name} before enabling it.`);
     const protections=r.protections||[r.outcome];
     if(!Array.isArray(protections)||!protections.length||protections.some(p=>!['mfa','phishingResistant','compliant','hybridJoined','block'].includes(p))||new Set(protections).size!==protections.length)throw Error('Choose valid, distinct protections.');
     if(protections.includes('hybridJoined')&&!source.model.dimensions.hybridJoined?.includes('true'))throw Error('This model does not include hybrid-joined device states. Import a tenant snapshot.');
     if(!protections.includes(r.outcome))throw Error('The primary outcome must be included in the selected protections.');
     if(protections.includes('block')&&protections.length!==1)throw Error('Blocked access cannot also require sign-in protections.');
     const scope=this.scope(r,resolved),include=[...new Set([...scope.include,...scope.unknown.filter(id=>knownIdentityIds.has(id))])],uncertain=scope.unknown.length;
     if(uncertain)issues.push({requirementId:r.id,code:'account-classification',accountIds:scope.unknown,message:`${r.name}: ${uncertain} ${uncertain===1?'account classification is':'account classifications are'} unresolved.${source.privilegeClassificationIssue?' '+source.privilegeClassificationIssue:''}`});
     if(!include.length)issues.push({requirementId:r.id,message:`${r.name}: no accounts are ${uncertain?'confirmed in scope yet':'in scope'}.`});
     if(r.flows?.length&&r.flows.some(v=>!source.model.dimensions.flow?.includes(v))){issues.push({requirementId:r.id,code:'requirement-not-evaluated',accountIds:include,message:`${r.name}: the selected authentication flows are not represented in this imported model. Import a full tenant snapshot to check them.`});continue;}
     if(graphAudienceUncertain){
       if(r.blockOtherApps)throw Error(`${r.name}: a Microsoft Graph allowlist needs underlying audience evidence before other apps can be classified as allowed or blocked.`);
       issues.push({requirementId:r.id,code:'graph-audience-context',resolveWhenProtected:true,message:`${r.name}: Microsoft Graph is an umbrella resource. Coverage is conservatively checked across possible underlying resources; remaining gaps need requested-scope and audience evidence.`});
     }
     if(source.directoryScopeUncertain&&!r.userAction&&!r.authenticationContextId)issues.push({requirementId:r.id,code:'directory-baseline-context',resolveWhenProtected:true,message:`${r.name}: low-privilege directory requests can follow different enforcement rules during Microsoft's rollout. Any remaining legacy-context gaps need tenant/request evidence; app exclusions alone cannot prove baseline-scope protection.`});
     const includedIdSet=new Set(include),externalDependencies=(source.externalIdentityUncertainties||[]).filter(u=>u.identityIds.some(id=>includedIdSet.has(id)));
     const strengthDependencies=source.strengthUncertainties||[];
     const filterDependencies=source.applicationFilterUncertainties||[];
     const locationPolicyIds=source.model.policies.filter(p=>p.unverifiedLocations).map(p=>p.id);
     if(locationPolicyIds.length)issues.push({requirementId:r.id,code:'location-enforcement-context',resolveWhenProtected:true,policyContext:{requirementId:r.id,policyIds:locationPolicyIds,identityIds:include,relaxedAxes:[],matchMode:'potentiallyDenied'},message:`${r.name}: some policy locations cannot be evaluated. No protection is credited from those policies; remaining possible access that their grants could deny needs location evidence.`});
     const filterPolicyIds=source.model.policies.filter(p=>filterDependencies.some(u=>u.policyId===(source.policyOrigins?.[p.id]||p.id))).map(p=>p.id);
     if(filterPolicyIds.length)issues.push({requirementId:r.id,code:'application-filter-context',resolveWhenProtected:true,filterEvidence:filterDependencies,policyContext:{requirementId:r.id,policyIds:filterPolicyIds,identityIds:include,relaxedAxes:[],matchMode:'applicable'},message:`${r.name}: application-filter matching is not verified. No protection is credited from those policies. Remaining possible access in their account/request scope needs filter and attribute evidence.`});
     const grantDependencies=source.grantUncertainties||[];
     const grantPolicyIds=source.model.policies.filter(p=>grantDependencies.some(u=>u.policyId===(source.policyOrigins?.[p.id]||p.id))).map(p=>p.id);
     const grantNames={approvedApplication:'approved client app',compliantApplication:'app protection',passwordChange:'password change',riskRemediation:'risk remediation',termsOfUse:'Terms of Use',customAuthenticationFactors:'custom authentication controls'};
     if(grantPolicyIds.length)issues.push({requirementId:r.id,code:'grant-enforcement-context',resolveWhenProtected:true,grantEvidence:grantDependencies,policyContext:{requirementId:r.id,policyIds:grantPolicyIds,identityIds:include,relaxedAxes:[],matchMode:'applicable'},message:`${r.name}: possible access depends on ${[...new Set(grantDependencies.flatMap(u=>u.controls).map(v=>grantNames[v]||v))].join(', ')}. Other grant requirements are checked; this access needs enforcement evidence.`});
     const strengthPolicyIds=source.model.policies.filter(p=>strengthDependencies.some(u=>u.policyId===(source.policyOrigins?.[p.id]||p.id))).map(p=>p.id);
     if(strengthPolicyIds.length)issues.push({requirementId:r.id,code:'strength-enforcement-context',resolveWhenProtected:true,strengthEvidence:strengthDependencies,policyContext:{requirementId:r.id,policyIds:strengthPolicyIds,identityIds:include,relaxedAxes:[],matchMode:'applicable'},message:`${r.name}: ${[...new Set(strengthDependencies.map(u=>u.message))].join(' ')} Remaining possible access needs authentication-strength evidence.`});
     const sessionDependencies=source.sessionRestrictions||[];
     const sessionPolicyIds=source.model.policies.filter(p=>sessionDependencies.some(u=>u.policyId===(source.policyOrigins?.[p.id]||p.id))).map(p=>p.id);
     const sessionNames={secureSignInSession:'token protection',applicationEnforcedRestrictions:'app restrictions',cloudAppSecurity:'Defender for Cloud Apps',continuousAccessEvaluation:'strict continuous evaluation',globalSecureAccessFilteringProfile:'GSA filtering'};
     const sessionLabels=[...new Set(sessionDependencies.flatMap(u=>u.controls).map(name=>sessionNames[name]||name))].join(', ');
     if(sessionPolicyIds.length)issues.push({requirementId:r.id,code:'session-enforcement-context',resolveWhenProtected:true,sessionEvidence:sessionDependencies,policyContext:{requirementId:r.id,policyIds:sessionPolicyIds,identityIds:include,relaxedAxes:[],matchMode:'applicable'},message:`${r.name}: coverage still depends on ${sessionLabels}. Runtime enforcement needs evidence.`});
     const groupDependencies=(source.groupStateUncertainties||[]).filter(u=>u.identityIds.some(id=>includedIdSet.has(id)));
     const locationDependencies=(source.locationUncertainties||[]).filter(u=>u.identityIds.some(id=>includedIdSet.has(id)));
     const countryDependent=(source.countryPolicyTargets||[]).some(u=>u.identityIds.some(id=>includedIdSet.has(id)))||r.networkMode&&r.networkMode!=='any'&&r.networks?.some(id=>source.countryLocationIds?.includes(id));
     if(countryDependent&&source.locationPartition?.countryCatalogUncertain)issues.push({requirementId:r.id,code:'country-catalog-context',resolveWhenProtected:true,unknownNetworks:source.locationPartition.cells.filter(c=>c.country?.other).map(c=>c.id),message:`${r.name}: possible access from country classifications outside the exported lists needs Microsoft's current country-catalog evidence.`});
     if(locationDependencies.length||source.locationPartition?.geographyUncertain&&r.networkMode&&r.networkMode!=='any'&&r.networks?.some(id=>source.countryLocationIds?.includes(id)))issues.push({requirementId:r.id,code:'ip-country-correlation',resolveWhenProtected:true,message:`${r.name}: country rules are checked across possible IP classifications. Remaining possible gaps need Microsoft's IP-to-country mapping; policy exports do not contain it.`});
     if(groupDependencies.length){
       const policyIds=[...new Set(groupDependencies.map(u=>u.policyId))];
       const policyContext={requirementId:r.id,policyIds:source.model.policies.filter(p=>policyIds.includes(source.policyOrigins?.[p.id]||p.id)).map(p=>p.id),identityIds:[...new Set(groupDependencies.flatMap(u=>u.identityIds))].filter(id=>includedIdSet.has(id)),relaxedAxes:Object.keys(source.model.dimensions).filter(n=>n.startsWith('groupMember.')||n.startsWith('roleActive.'))};
       policyContext.policyIdentityBindings=Object.fromEntries(policyContext.policyIds.map(id=>[id,[...new Set(groupDependencies.filter(u=>u.policyId===(source.policyOrigins?.[id]||id)).flatMap(u=>u.identityIds))].filter(user=>includedIdSet.has(user))]));
       // The common whole-tenant read failure has the same affected people for
       // every policy. Store that set once, retaining explicit bindings only
       // when policy/person relationships actually differ.
       const affected=new Set(policyContext.identityIds);
       if(Object.values(policyContext.policyIdentityBindings).every(ids=>ids.length===affected.size&&ids.every(id=>affected.has(id))))delete policyContext.policyIdentityBindings;
       issues.push({requirementId:r.id,code:'pim-group-context',resolveWhenProtected:true,policyIds,policyContext,message:`${r.name}: ${[...new Set(groupDependencies.map(u=>u.message))].join(' ')} Remaining possible gaps are unverified.`});
     }
     const resourceDependencies=(source.resourceGroupUncertainties||[]).filter(u=>u.identityIds.some(id=>includedIdSet.has(id))),selectedResourceGroups=(r.apps||[]).filter(isResourceGroup);
     let unknownApplications=[...new Set([...resourceDependencies.flatMap(u=>u.unknownApplications),...selectedResourceGroups.flatMap(id=>source.resourceGroupUnknown?.[G.canonical(id)]||[])])];
     if(r.apps?.length&&!selectedResourceGroups.length&&!r.blockOtherApps)unknownApplications=unknownApplications.filter(id=>r.apps.includes(id));
     if(unknownApplications.length)issues.push({requirementId:r.id,code:'resource-group-context',resolveWhenProtected:true,unknownApplications,policyIds:[...new Set(resourceDependencies.map(u=>u.policyId))],message:`${r.name}: resource-group membership is missing for some resources. Remaining gaps in that scope need membership evidence.`});
     if(externalDependencies.length){const accountIds=[...new Set(externalDependencies.flatMap(u=>u.identityIds.filter(id=>includedIdSet.has(id))))];issues.push({requirementId:r.id,code:'external-identity-context',resolveWhenProtected:true,policyIds:[...new Set(externalDependencies.map(u=>u.policyId))],accountIds,message:`${r.name}: external-user facts are missing for ${accountIds.length} ${accountIds.length===1?'account':'accounts'}. Remaining possible gaps need validation.`});}
     if(r.deviceFilter?.clauses.some(c=>c.property==='isCompliant'&&c.value.toLowerCase()==='false'))issues.push({requirementId:r.id,code:'device-compliance-runtime',resolveWhenProtected:true,message:`${r.name}: unregistered-device compliance may be absent or false; remaining dependent gaps need runtime validation.`});
     for(const uncertainty of source.deviceClaimUncertainties||[]){
       const excludedIds=new Set(uncertainty.excludeUsers);
       if(include.some(id=>uncertainty.includeUsers.includes(id)&&!excludedIds.has(id)))issues.push({requirementId:r.id,code:'device-compliance-runtime',resolveWhenProtected:true,message:`${r.name}: unregistered-device compliance can be absent or false. Coverage is checked against both; remaining gaps need runtime validation.`});
     }
     const conditions={};
     const contextId=r.authenticationContextId,action=r.userAction;
     if(contextId&&action)throw Error('Choose either an authentication context or a registration action.');
     if(action){
       if(!['registerSecurityInformation','registerOrJoinDevices'].includes(action))throw Error('Choose an available registration action.');
       for(const uncertainty of source.registrationUncertainties||[]){
         if(uncertainty.code==='registration-resource-context'&&source.registrationResourceContextSupported===true)continue;
         if(uncertainty.action&&uncertainty.action!==action)continue;
         if(r.registrationContext&&(uncertainty.code==='registration-resource-context'||uncertainty.code==='registration-strength-precedence'&&(r.registrationContext.mode==='manage'||r.registrationContext.mode==='interrupt'&&uncertainty.knownInterruptResolved===true)))continue;
         const excludedIds=new Set(uncertainty.excludeUsers);
         if(include.some(id=>uncertainty.includeUsers.includes(id)&&!excludedIds.has(id)))issues.push({requirementId:r.id,code:uncertainty.code,resolveWhenProtected:true,message:`${r.name}: ${uncertainty.message}`});
       }
       if(!source.model.dimensions.userAction?.includes(action)){issues.push({requirementId:r.id,code:'requirement-not-evaluated',accountIds:include,message:`${r.name}: registration actions cannot be assessed by this imported model.`});continue;}
       if(action==='registerOrJoinDevices'){
         if(protections.some(p=>!['mfa','phishingResistant'].includes(p))||r.clients?.length){issues.push({requirementId:r.id,code:'requirement-not-evaluated',accountIds:include,message:`${r.name}: device registration CA does not support these grants/client-app conditions.`});continue;}
         if(!source.registrationPrerequisites?.devicePolicyKnown||source.registrationPrerequisites.deviceMfaConfiguration!=='notRequired')issues.push({requirementId:r.id,message:`${r.name}: device-registration enforcement prerequisites are not verified in this export.`});
       }
       if(r.apps?.length)throw Error('Registration-action requirements cannot also target apps.');
       conditions.accessTarget={include:['userAction']};conditions.userAction={include:[action]};
       if(source.model.dimensions.registrationContext)conditions.registrationContext={include:[r.registrationContext?'registration:'+r.id:'unspecified']};
     }else if(contextId){
       if(!source.model.dimensions['authenticationContext.'+contextId])throw Error(`Choose an available authentication context for ${r.name}.`);
       if(r.apps?.length)throw Error('Authentication-context requirements cannot also target apps.');
       conditions.accessTarget={include:['authenticationContext']};
       conditions['authenticationContext.'+contextId]={include:['true']};
       if(source.model.dimensions.userAction)conditions.userAction={include:['none']};
     }else if(source.model.dimensions.accessTarget){
       conditions.accessTarget={include:['application']};
       if(source.model.dimensions.userAction)conditions.userAction={include:['none']};
       for(const dimension of Object.keys(source.model.dimensions).filter(k=>k.startsWith('authenticationContext.')))conditions[dimension]={include:['false']};
     }
     for(const [dimension,values] of Object.entries({application:r.apps||[],platform:r.platforms||[],client:source.original?S.clientSelection(r.clients||[]):r.clients||[],flow:r.flows||[],signInRisk:r.signInRiskLevels||[],userRisk:r.userRiskLevels||[]})){
       if(values.length){if(values.some(v=>!source.model.dimensions[dimension]?.includes(v)&&!(dimension==='application'&&isResourceGroup(v))))throw Error(`Refresh the ${{signInRisk:'sign-in risk',userRisk:'user risk'}[dimension]||dimension} selection in ${r.name}.`);if(!(dimension==='application'&&(selectedResourceGroups.length||graphAudienceUncertain)))conditions[dimension]={include:values};}
     }
     const networkMode=r.networkMode||'any';
     let networkValues=r.networks||[];
     if(!['any','when','must'].includes(networkMode))throw Error('Unknown network requirement.');
     if(networkMode!=='any'){
       if(!r.networks?.length)throw Error(`Select networks for ${r.name}.`);
       const known=new Set([...source.model.dimensions.network,...(source.locationChoices||[]).map(l=>l.id)]);
       if(r.networks.some(n=>!known.has(n)))throw Error('Network selection is not in this snapshot.');
       const unresolved=r.networks.some(n=>!source.model.dimensions.network.includes(n)&&!Object.hasOwn(source.locationSelectors||{},n));
       if(!source.networkEvaluationSupported||unresolved){issues.push({requirementId:r.id,code:'requirement-not-evaluated',accountIds:include,message:`${r.name}: selected locations cannot yet be fully evaluated from this snapshot.`});continue;}
       networkValues=[...new Set(r.networks.flatMap(n=>source.locationSelectors?.[n]||[n]))];
       conditions.network=networkValues.length?{include:networkValues}:{exclude:source.model.dimensions.network};
     }
     const item={id:r.id,scope:'all',includeUsers:include,conditions};
     const resourceScope=selectedResourceGroups.length&&!graphAudienceUncertain?G.clauses({includeApplications:r.apps},source.model.dimensions):null;
     const deviceScope=r.deviceFilter?D.compile(preparedDevices,'requirement-device:'+r.id):null;
     if(r.deviceFilter){
       if(action==='registerOrJoinDevices')throw Error('Device-registration requirements cannot use a device filter.');
       item.conditionAlternatives=deviceScope;
     }
     if(resourceScope!==null)item.conditionAlternatives=combine(resourceScope,deviceScope);
     if(protections.includes('block'))item.mustBlock=true;
     else if(protections.includes('compliant')||protections.includes('hybridJoined')){
       const alternative={};
       if(protections.includes('compliant'))alternative.compliant={include:['true']};
       if(protections.includes('hybridJoined'))alternative.hybridJoined={include:['true']};
       if(protections.includes('phishingResistant'))alternative.authentication={include:['phishingResistant']};
       else if(protections.includes('mfa'))alternative.authentication={include:['mfa','phishingResistant']};
       item.requiredAlternatives=[alternative];
     }else item.allowedAuthentication=protections.includes('phishingResistant')?['phishingResistant']:['mfa','phishingResistant'];
     requirements.push(item);
     if(networkMode==='must'){
       const outsideScope=combine(resourceScope,r.deviceFilter?.mode==='when'?deviceScope:null);
       requirements.push({id:r.id+':outside-network',includeUsers:include,conditions:{...conditions,network:{exclude:networkValues}},...(outsideScope!==null?{conditionAlternatives:outsideScope}:{}),mustBlock:true});
     }
     if(r.deviceFilter?.mode==='must')requirements.push({id:r.id+':outside-device',includeUsers:include,conditions:{...conditions},conditionAlternatives:combine(resourceScope,D.compile(preparedDevices,'requirement-device-outside:'+r.id)),mustBlock:true});
     if(r.blockOtherApps){
       if(action||contextId||!r.apps?.length)throw Error('Select apps before requiring all other apps to be blocked.');
       const outside={...conditions};delete outside.application;if(networkMode==='must')delete outside.network;
       const outsideResources=selectedResourceGroups.length?G.clauses({includeApplications:['All'],excludeApplications:r.apps},source.model.dimensions):[{application:{exclude:r.apps}}];
       requirements.push({id:r.id+':outside-apps',includeUsers:include,conditions:outside,conditionAlternatives:combine(outsideResources,r.deviceFilter?.mode==='when'?deviceScope:null),mustBlock:true});
     }
   }
   if(!requirements.length&&!issues.length)throw Error('Add at least one enabled requirement.');
   return {model:{...source.model,requirements},issues,source};
 }
};
if(typeof module!=='undefined')module.exports=RequirementModel;
