'use strict';
const GroupDirectory={
 merge(snapshot,evidence){
  if(snapshot?.caGapSnapshotVersion!==1)throw Error('Load a tenant snapshot before adding a group.');
  const next=structuredClone(snapshot),items=[evidence,...(evidence?.relatedGroups||[])];
  for(const item of items){
   if(typeof item?.group?.id!=='string'||!item.group.id||!Array.isArray(item.members)||item.members.some(id=>typeof id!=='string'||!id))throw Error('The group membership read was incomplete. No group was added.');
   const id=item.group.id;
   next.groups=[...(next.groups||[]).filter(g=>g.id.toLowerCase()!==id.toLowerCase()),item.group];
   next.groupMembers={...next.groupMembers,[id]:[...new Set(item.members)]};
   next.completeness={...next.completeness,['members:'+id]:true,['groupMembers:'+id]:true};
   next.errors=(next.errors||[]).filter(e=>!['members:'+id,'groupMembers:'+id].includes(e.collection));
   if(item.includePimGroups){
    for(const [field,value] of [['pimGroupEligibility',item.eligibility],['pimGroupAssignments',item.assignments]]){
     if(!Array.isArray(value))throw Error('The temporary group membership read was incomplete. No group was added.');
     next[field]=[...(next[field]||[]).filter(row=>row.groupId!==id),...value];next.completeness[field+':'+id]=true;
    }
    if(!Array.isArray(item.directMembers))throw Error('The group membership read was incomplete. No group was added.');
    next.groupDirectMembers={...next.groupDirectMembers,[id]:item.directMembers};next.completeness['groupDirectMembers:'+id]=true;
    next.errors=next.errors.filter(e=>!['pimGroupEligibility:'+id,'pimGroupAssignments:'+id,'groupDirectMembers:'+id].includes(e.collection));
   }
  }
  next.completeness.groupMembers=next.completeness.groups===true&&next.groups.every(g=>Array.isArray(next.groupMembers[g.id])&&(next.completeness['members:'+g.id]??snapshot.completeness.groupMembers)===true);
  // Adding selected groups never turns this into a whole-directory catalog.
  return next;
 }
};
if(typeof module!=='undefined')module.exports=GroupDirectory;
