'use strict';
// Notify the original window without transferring any credentials or snapshot data.
if(window.opener&&!window.opener.closed){
  try{
    window.opener.postMessage({type:'ca-oauth-complete'},location.origin);
    window.opener.focus();
    window.close();
  }catch{location.replace('/?signin=return');}
}else{
  location.replace('/?signin=return');
}
