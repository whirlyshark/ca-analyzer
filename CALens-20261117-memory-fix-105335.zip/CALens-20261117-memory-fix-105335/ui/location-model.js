'use strict';
const LocationModel={
 acquisitionRisk(locations,selection){
  if(selection===undefined||selection===null)return false;
  if(typeof selection!=='object'||Array.isArray(selection))return true;
  const refs=[];for(const key of ['includeLocations','excludeLocations']){if(selection[key]!==undefined&&!Array.isArray(selection[key]))return true;refs.push(...selection[key]||[]);}
  for(const id of refs){
   if(['All','AllTrusted','AllCompliantNetworkLocations'].includes(id))continue;
   const rows=(Array.isArray(locations)?locations:[]).filter(l=>l?.id===id),concrete=rows.filter(l=>l['@odata.type']!=='#microsoft.graph.namedLocation');
   if(!concrete.length)return true;
   for(const row of concrete){
    const type=String(row['@odata.type']||'').replace(/^#/,'');
    if(type==='microsoft.graph.ipNamedLocation'||type==='microsoft.graph.compliantNetworkNamedLocation')continue;
    if(type==='microsoft.graph.countryNamedLocation'&&(row.countryLookupMethod===undefined||row.countryLookupMethod==='clientIpAddress'))continue;
    return true;
   }
  }
  return false;
 },
 // Geographic witnesses, not a closed Microsoft IP-geolocation catalog.
 // UNSD M49 ISO-alpha2 table retrieved 2026-11-15:
 // https://unstats.un.org/unsd/methodology/m49/overview/
 // If all these codes are named, the remaining catchall stays unverified.
 countryWitnessCodes:'AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'.split(' '),
 parseAddress(text){
  if(typeof text!=='string'||text.includes('%'))throw Error('Unsupported IP address.');
  if(!text.includes(':')){
   const parts=text.split('.');if(parts.length!==4||parts.some(p=>!/^\d{1,3}$/.test(p)||Number(p)>255||p.length>1&&p[0]==='0'))throw Error('Invalid IPv4 address.');
   return {family:4,bits:32,value:parts.reduce((n,p)=>(n<<8n)+BigInt(p),0n)};
  }
  if(text.includes('.'))throw Error('Embedded or mapped IPv4-in-IPv6 needs separate normalization.');
  if((text.match(/::/g)||[]).length>1)throw Error('Invalid IPv6 address.');
  const compressed=text.includes('::'),halves=text.split('::'),left=halves[0]?halves[0].split(':'):[],right=compressed&&halves[1]?halves[1].split(':'):[];
  if([...left,...right].some(p=>!/^[0-9a-f]{1,4}$/i.test(p))||compressed&&left.length+right.length>=8||!compressed&&left.length!==8)throw Error('Invalid IPv6 address.');
  const groups=compressed?[...left,...Array(8-left.length-right.length).fill('0'),...right]:left;
  return {family:6,bits:128,value:groups.reduce((n,p)=>(n<<16n)+BigInt('0x'+p),0n)};
 },
 format(family,value){
  if(family===4)return [24n,16n,8n,0n].map(shift=>Number(value>>shift&255n)).join('.');
  return Array.from({length:8},(_,i)=>(value>>BigInt((7-i)*16)&65535n).toString(16)).join(':');
 },
 range(cidr){
  const parts=String(cidr).split('/');if(parts.length!==2||!/^\d+$/.test(parts[1]))throw Error('Invalid CIDR range.');
  const address=this.parseAddress(parts[0]),prefix=Number(parts[1]);if(prefix>address.bits)throw Error('CIDR prefix is too long.');
  const size=1n<<BigInt(address.bits-prefix),start=address.value/size*size;
  return {...address,prefix,start,end:start+size-1n};
 },
 parseLegacyTrustedRanges(value){
  if(!Array.isArray(value)||value.length>50)throw Error('Enter up to 50 legacy MFA IPv4 CIDR ranges.');
  return value.map(cidr=>{if(typeof cidr!=='string')throw Error('Legacy MFA trusted IPs must be IPv4 CIDR strings.');const r=this.range(cidr);if(r.family!==4)throw Error('Legacy MFA trusted IPs support IPv4 only.');return r;});
 },
 build(locations,{complete=true,legacyTrustedKnown=false,legacyTrustedIpRanges=[],legacyFederatedIntranetKnown=true,legacyFederatedIntranetEnabled=false,compliantNetworkLocations=[],compliantNetworksKnown=true}={}){
  const definitions=[],countries=[],unsupported=[],choices=[{id:'AllTrusted',name:'All trusted locations'}];
  const conflicting=new Set(),merged=new Map(),betaIds=new Set();let ambiguous=!Array.isArray(compliantNetworkLocations);
  const compliantType='#microsoft.graph.compliantNetworkNamedLocation';
  for(const location of locations){
   if(!location||typeof location!=='object'){ambiguous=true;unsupported.push({id:null,message:'Malformed named-location record.'});continue;}
   if(merged.has(location.id))conflicting.add(location.id);else merged.set(location.id,location);
  }
  for(const location of Array.isArray(compliantNetworkLocations)?compliantNetworkLocations:[]){
   const prior=merged.get(location?.id);
   if(prior&&location?.['@odata.type']&&![location['@odata.type'],'#microsoft.graph.namedLocation'].includes(prior['@odata.type']))conflicting.add(location.id);
   if(!location||typeof location.id!=='string'||!location.id||location['@odata.type']!==compliantType||location.compliantNetworkType!=='allTenantCompliantNetworks'||location.isTrusted!==undefined&&typeof location.isTrusted!=='boolean'){ambiguous=true;unsupported.push({id:location?.id,message:'Compliant-network metadata is incomplete or unsupported.'});continue;}
   if(betaIds.has(location.id))conflicting.add(location.id);betaIds.add(location.id);
   const old=merged.get(location.id),trusted=location.isTrusted??false;
   if(old&&(![compliantType,'#microsoft.graph.namedLocation'].includes(old['@odata.type'])||old.isTrusted!==undefined&&old.isTrusted!==trusted))conflicting.add(location.id);
   merged.set(location.id,{...old,...location,isTrusted:trusted});
  }
  if(compliantNetworksKnown&&locations.some(l=>l?.['@odata.type']===compliantType&&!betaIds.has(l.id)))ambiguous=true;
  locations=[...merged.values()];
  const unknownTrust=location=>{
   const type=String(location?.['@odata.type']||'').replace(/^#/,'');
   if(type==='microsoft.graph.countryNamedLocation'||type==='microsoft.graph.ipNamedLocation')return Object.hasOwn(location,'isTrusted')&&location.isTrusted!==false;
   if(type==='microsoft.graph.compliantNetworkNamedLocation')return location.isTrusted!==false;
   return true;
  };
  for(const location of locations){
   choices.push({id:location.id,name:location.displayName||location.id});
   try{
    if(typeof location.id!=='string'||!location.id)throw Error('Named location has no valid identifier.');
    if(['@odata.nextLink','ipRanges@odata.nextLink','countriesAndRegions@odata.nextLink'].some(key=>location[key]))throw Error('Named-location definition still contains a pagination link. Collect its complete definition.');
    if(conflicting.has(location.id))throw Error('Named-location versions contain conflicting identifiers or trust metadata.');
    if(Object.hasOwn(location,'isTrusted')&&typeof location.isTrusted!=='boolean')throw Error('Named-location trust metadata must be a Boolean.');
    if(location['@odata.type']===compliantType)throw Error('Global Secure Access needs compliant-network signal and automatic resource-exclusion validation.');
    const type=String(location['@odata.type']||'').replace(/^#/,'');
    if(type==='microsoft.graph.countryNamedLocation'){
     if(location.countryLookupMethod!==undefined&&location.countryLookupMethod!=='clientIpAddress')throw Error('GPS or unknown country lookup needs runtime location evidence.');
     if(!Array.isArray(location.countriesAndRegions)||location.countriesAndRegions.some(c=>typeof c!=='string'||!/^[A-Za-z]{2}$/.test(c))||location.includeUnknownCountriesAndRegions!==undefined&&typeof location.includeUnknownCountriesAndRegions!=='boolean'||location.isTrusted===true)throw Error('Malformed country location.');
     countries.push({id:location.id,name:location.displayName||location.id,codes:[...new Set(location.countriesAndRegions.map(c=>c.toUpperCase()))],unknown:location.includeUnknownCountriesAndRegions===true});continue;
    }
    if(type!=='microsoft.graph.ipNamedLocation'||!Array.isArray(location.ipRanges)||!location.ipRanges.length)throw Error('Unknown or malformed named location.');
    const ranges=location.ipRanges.map(r=>this.range(r.cidrAddress));definitions.push({id:location.id,name:location.displayName||location.id,trusted:location.isTrusted===true,ranges});
   }catch(e){unsupported.push({id:location.id,message:e.message});}
  }
  let legacyRanges=[],legacyIssue=null;
  try{
   if(!legacyTrustedKnown)throw Error('AllTrusted requires exported legacy MFA trusted-IP configuration.');
   // Validate the entire list before using any of it. A malformed entry must not
   // silently shrink the trusted set and turn an exclusion into protection.
   const parsed=this.parseLegacyTrustedRanges(legacyTrustedIpRanges);
   legacyRanges=parsed;
  }catch(e){legacyIssue=e.message;}
  const ipDefinitions=[...definitions,...(legacyRanges.length?[{legacy:true,name:'Legacy MFA trusted IPs',ranges:legacyRanges}]:[])];
  let cells=[];const bySignature=new Map();
  for(const family of [4,6]){
   const bits=family===4?32:128,bounds=new Set([0n,1n<<BigInt(bits)]);
   for(const definition of ipDefinitions)for(const range of definition.ranges.filter(r=>r.family===family)){bounds.add(range.start);bounds.add(range.end+1n);}
   const sorted=[...bounds].sort((a,b)=>a<b?-1:a>b?1:0);
   for(let i=0;i<sorted.length-1;i++){
    const start=sorted[i],end=sorted[i+1]-1n;
    const matching=ipDefinitions.filter(d=>d.ranges.some(r=>r.family===family&&r.start<=start&&r.end>=start));
    const ids=matching.filter(d=>!d.legacy).map(d=>d.id).sort(),legacy=matching.some(d=>d.legacy),signature=JSON.stringify([ids,legacy]);
    let cell=bySignature.get(signature);
    if(!cell){cell={id:'ip-region-'+cells.length,locationIds:ids,legacyMfaTrusted:legacy,label:matching.length?matching.map(d=>d.name).join(' + '):ipDefinitions.length?'Outside configured IP locations':'Any IP address',ipAddress:this.format(family,start),ranges:[]};cells.push(cell);bySignature.set(signature,cell);}
    cell.ranges.push({family,start:start.toString(),end:end.toString()});
   }
  }
  if(countries.length){
   // All country predicates share one classification. "Other" represents every
   // named country outside the exported lists; unknown is a separate state.
   const codes=[...new Set(countries.flatMap(d=>d.codes))].sort(),groups=new Map();
   for(const code of [...codes,'other','unknown']){
    const matching=countries.filter(d=>code==='unknown'?d.unknown:code!=='other'&&d.codes.includes(code));
    const ids=matching.map(d=>d.id).sort(),key=JSON.stringify(ids);
    let group=groups.get(key);if(!group){group={ids,names:matching.map(d=>d.name),codes:[],other:false,unknown:false};groups.set(key,group);}
    if(code==='other'||code==='unknown')group[code]=true;else group.codes.push(code);
   }
   let displayNames;try{if(typeof Intl!=='undefined'&&Intl.DisplayNames)displayNames=new Intl.DisplayNames(['en'],{type:'region'});}catch{}
   const countryLabels=new Map(codes.map(code=>{let name=code;try{name=displayNames?.of(code)||code;}catch{}return [code,name===code?code:name+' ('+code+')'];}));
   const countryGroups=[...groups.values()];
   cells=cells.flatMap(ip=>countryGroups.map((group,index)=>({...ip,
    id:'network-region-'+ip.id.slice(10)+'-'+index,
    locationIds:[...ip.locationIds,...group.ids].sort(),
    country:{codes:group.codes,other:group.other,unknown:group.unknown},
    label:(ipDefinitions.length?ip.label+' / ':'')+[...group.codes.slice(0,4).map(code=>countryLabels.get(code)),...(group.codes.length>4?['+'+(group.codes.length-4)+' more']:[]),...(group.other?['Other countries']:[]),...(group.unknown?['Unknown country']:[])].join(', ')
   })));
  }
  const selectors=Object.fromEntries([...definitions,...countries].map(d=>[d.id,cells.filter(c=>c.locationIds.includes(d.id)).map(c=>c.id)]));
  selectors.All=cells.map(c=>c.id);
  const trustIssue=!complete?'Named-location collection is incomplete.':legacyIssue||(!legacyFederatedIntranetKnown?'AllTrusted requires the legacy MFA federated-intranet setting.':legacyFederatedIntranetEnabled!==false?'Federated intranet trust requires runtime insidecorporatenetwork claim validation.':null)||(!compliantNetworksKnown||ambiguous||conflicting.size?'AllTrusted needs complete, consistent compliant-network trust metadata.':unsupported.some(u=>unknownTrust(locations.find(l=>l.id===u.id)))?'AllTrusted includes a trusted or unknown network type that cannot yet be evaluated.':null);
  if(!trustIssue)selectors.AllTrusted=cells.filter(c=>c.legacyMfaTrusted||c.locationIds.some(id=>definitions.find(d=>d.id===id)?.trusted)).map(c=>c.id);
  const countryCodes=[...new Set(countries.flatMap(d=>d.codes))].sort();
  return {cells,selectors,choices,unsupported,complete,trustIssue,countryCodes,otherCountryWitness:countries.length?this.countryWitnessCodes.find(c=>!countryCodes.includes(c)):undefined,countryCatalogUncertain:countries.length>0&&!this.countryWitnessCodes.some(c=>!countryCodes.includes(c)),geographyUncertain:countries.length>0&&ipDefinitions.length>0};
 },
 select(partition,ids){
  const result=new Set();
  for(const id of ids){if(!Object.hasOwn(partition.selectors,id))throw Error(id==='AllTrusted'?partition.trustIssue||'AllTrusted cannot yet be evaluated.':'This location cannot yet be evaluated: '+(partition.choices.find(c=>c.id===id)?.name||id)+(partition.unsupported.find(u=>u.id===id)?.message?'. '+partition.unsupported.find(u=>u.id===id).message:''));partition.selectors[id].forEach(value=>result.add(value));}
  return [...result];
 },
 countryMatches(cell,code,knownCodes){
  if(!cell.country)return true;
  if(code==='unknown')return cell.country.unknown;
  return cell.country.codes.includes(code)||cell.country.other&&!knownCodes.includes(code);
 },
 classify(partition,address,country){
  const ip=this.parseAddress(address);
  if(partition.cells.some(c=>c.country)&&country===undefined)throw Error('A Microsoft-resolved country or unknown classification is required.');
  if(country!==undefined&&country!=='unknown'&&(typeof country!=='string'||!/^[A-Za-z]{2}$/.test(country)))throw Error('Invalid country classification.');
  const code=country==='unknown'?country:country?.toUpperCase();
  return partition.cells.find(c=>this.countryMatches(c,code,partition.countryCodes||[])&&c.ranges.some(r=>r.family===ip.family&&BigInt(r.start)<=ip.value&&BigInt(r.end)>=ip.value))?.id;
 }
};
if(typeof module!=='undefined')module.exports=LocationModel;
