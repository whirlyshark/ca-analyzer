'use strict';
const RoleSchedules={
 instant(value){
  if(typeof value!=='string')return null;
  const m=/^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.(\d{1,7}))?(Z|[+-]\d\d:\d\d)$/i.exec(value);if(!m)return null;
  const [year,month,day,hour,minute,second]=m.slice(1,7).map(Number),leap=year%4===0&&(year%100!==0||year%400===0),days=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];
  if(year<1||month<1||month>12||day<1||day>days[month-1]||hour>23||minute>59||second>59)return null;
  if(m[8].toUpperCase()!=='Z'){const hours=Number(m[8].slice(1,3)),minutes=Number(m[8].slice(4));if(hours>14||minutes>59||hours===14&&minutes!==0)return null;}
  const milliseconds=Date.parse(value.replace(/\.\d+(?=Z|[+-]\d\d:\d\d$)/i,''));
  if(!Number.isFinite(milliseconds))return null;
  return BigInt(milliseconds)*10000n+BigInt((m[7]||'').padEnd(7,'0'));
 },
 interval(row,captured){
  const start=this.instant(row?.startDateTime),end=row?.endDateTime===null?null:this.instant(row?.endDateTime);
  if(captured===null||start===null||!Object.hasOwn(row||{},'endDateTime')||row.endDateTime!==null&&(end===null||end<=start))return 'unknown';
  return start<=captured&&(end===null||captured<end)?'current':'inactive';
 },
 prepare(snapshot){
  if(snapshot?.caGapSnapshotVersion===1)for(const key of ['roleAssignments','roleEligibility'])if(!Array.isArray(snapshot[key]))throw Error(`Snapshot ${key} must be an array; export a full snapshot again.`);
  // Graph accepts either a directory definition ID or a built-in template ID.
  // Resolve both before comparing assignment/schedule tuples. Custom template
  // strings are organization metadata and never establish a built-in alias.
  const definitions=Array.isArray(snapshot?.roles)?snapshot.roles:[],references=new Map();
  for(const role of definitions)if(typeof role?.id==='string'&&role.id.trim()){
   if(references.has(role.id))throw Error('Exported role definitions contain duplicate IDs. Export a fresh snapshot.');
   references.set(role.id,role.id);
  }
  for(const role of definitions)if(role?.isBuiltIn===true&&typeof role.id==='string'&&role.id.trim()&&typeof role.templateId==='string'&&role.templateId.trim()){
   if(references.has(role.templateId)&&references.get(role.templateId)!==role.id)throw Error('Ambiguous role definition reference: a built-in template identifies more than one definition. Export a fresh, consistent role catalog.');
   references.set(role.templateId,role.id);
  }
  const resolve=row=>row&&references.has(row.roleDefinitionId)&&references.get(row.roleDefinitionId)!==row.roleDefinitionId?{...row,roleDefinitionId:references.get(row.roleDefinitionId)}:row;
  snapshot={...snapshot,...Object.fromEntries(['roleAssignments','roleEligibility','roleAssignmentScheduleInstances'].filter(key=>Array.isArray(snapshot?.[key])).map(key=>[key,snapshot[key].map(resolve)]))};
  const captured=this.instant(snapshot?.capturedAtUtc),active=snapshot?.roleAssignments||[],eligibility=snapshot?.roleEligibility||[],schedules=Array.isArray(snapshot?.roleAssignmentScheduleInstances)?snapshot.roleAssignmentScheduleInstances:[],complete=snapshot?.completeness?.roleAssignmentScheduleInstances===true&&Array.isArray(snapshot?.roleAssignmentScheduleInstances);
  if([...active,...eligibility,...schedules].some(r=>!r||typeof r!=='object'||Array.isArray(r)))throw Error('Role schedule collections contain malformed rows. Export a full snapshot again.');
  if([...active,...eligibility].some(r=>typeof r.principalId!=='string'||!r.principalId||typeof r.roleDefinitionId!=='string'||!r.roleDefinitionId))throw Error('Role assignments and eligibilities need principal and role definition IDs. Export a full snapshot again.');
  if(schedules.some(r=>r.principalId!=null&&typeof r.principalId!=='string'||r.roleDefinitionId!=null&&typeof r.roleDefinitionId!=='string'))throw Error('Role schedule references must be strings. Export a full snapshot again.');
  const fixed=new Set(),classificationUnknown=new Set(),uncertainties=[],effectiveEligibility=[],effectiveAssignments=[...active],currentSchedules=[];
  const tuple=r=>JSON.stringify([r.principalId,r.roleDefinitionId,r.directoryScopeId??null,r.appScopeId??null]);
  const knownCurrentEligibility=new Set(eligibility.filter(r=>this.interval(r,captured)==='current'&&r.memberType==='Direct').map(tuple));
  const add=(row,message,{classification=false,membership=true}={})=>{if(classification)classificationUnknown.add(row);uncertainties.push({row,principalId:row.principalId,roleDefinitionId:row.roleDefinitionId,classification,membership,message});};
  for(const row of eligibility){
   const state=this.interval(row,captured);if(state==='inactive')continue;
   effectiveEligibility.push(row);
   if(state==='unknown'&&!knownCurrentEligibility.has(tuple(row)))add(row,'Role eligibility needs valid start/end dates and a snapshot capture time.',{classification:true});
   if(row.memberType!=='Direct'&&!knownCurrentEligibility.has(tuple(row)))add(row,'Role eligibility has missing or inherited membership metadata; its independent activation relationship is not established.',{classification:true});
  }
  const byOrigin=new Map(),inactiveOrigins=new Set(),activeKeys=new Set(active.filter(a=>a.id).map(a=>JSON.stringify([a.id,tuple(a)])));
  for(const row of schedules){
   const state=this.interval(row,captured);if(state==='inactive'){inactiveOrigins.add(row.roleAssignmentOriginId);continue;}
   const list=byOrigin.get(row.roleAssignmentOriginId)||[];list.push({row,state});byOrigin.set(row.roleAssignmentOriginId,list);
   currentSchedules.push(row);
  }
  for(const row of active){
   const candidates=row.id?byOrigin.get(row.id)||[]:[],matches=candidates.filter(x=>tuple(x.row)===tuple(row));
   const definite=matches.filter(x=>x.state==='current'&&x.row.memberType==='Direct');
   const conflicting=candidates.some(x=>tuple(x.row)!==tuple(row))||new Set(definite.map(x=>x.row.assignmentType)).size>1;
   if(complete&&!conflicting&&definite.some(x=>x.row.assignmentType==='Assigned')&&matches.every(x=>x.row.assignmentType==='Assigned'&&x.row.memberType==='Direct'))fixed.add(row);
   else if(complete&&!conflicting&&definite.length&&matches.every(x=>x.state==='current'&&x.row.assignmentType==='Activated'&&x.row.memberType==='Direct')){
    // A verified activation may deactivate, even after eligibility has ended.
   }else add(row,!complete?'Active role assignments lack schedule evidence to distinguish fixed role membership from a temporary PIM activation.':conflicting?'Role assignment and schedule metadata disagree. Collect a fresh snapshot.':'Active role assignments need a matching current schedule instance with dates, assignment type, membership and origin metadata.',{classification:conflicting||!!row.id&&inactiveOrigins.has(row.id)});
  }
  // A current schedule without its active assignment is contradictory evidence,
  // not permission to silently omit a potentially privileged principal.
  for(const row of currentSchedules){
   if(!row.principalId||!row.roleDefinitionId||activeKeys.has(JSON.stringify([row.roleAssignmentOriginId,tuple(row)])))continue;
   const synthetic={...row,id:row.roleAssignmentOriginId||'schedule:'+row.id};effectiveAssignments.push(synthetic);
   add(synthetic,'A role schedule instance has no matching active assignment. Collect a fresh snapshot.',{classification:true});
  }
  return {snapshot:{...snapshot,roleAssignments:effectiveAssignments,roleEligibility:effectiveEligibility,roleAssignmentScheduleInstances:currentSchedules},fixed,classificationUnknown,uncertainties};
 }
};
if(typeof module!=='undefined')module.exports=RoleSchedules;
