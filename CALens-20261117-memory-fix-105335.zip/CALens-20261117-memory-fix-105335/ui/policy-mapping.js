'use strict';
// Offline attribution over the analyzer's normalized finite model. Never edits policy data.
const MappingRegions=typeof module!=='undefined'&&module.exports?require('./snapshot.js'):SnapshotModel;
const PolicyMapping={
 belongs(id,base){return id===base||[':outside-network',':outside-apps',':outside-device'].some(s=>id===base+s);},
 targets(item,identity){return (item.includeUsers||['*']).some(id=>id==='*'||id===identity.id)&&!(item.excludeUsers||[]).some(id=>id==='*'||id===identity.id)&&(item.scope!=='privileged'||identity.privileged||identity.pimEligible);},
 original(id,origins){return Object.hasOwn(origins,id)&&typeof origins[id]==='string'?origins[id]:id;},
 build(model,requirementId,{origins={},maxRegions=20000,maxMilliseconds=750}={}){
  const started=Date.now(),partition=MappingRegions.regions(model.dimensions,{maxRegions,deadline:started+maxMilliseconds}),rules=(model.requirements||[]).filter(r=>this.belongs(r.id,requirementId));
  const rows=new Map(),groups=new Map(),universe=partition.from({});let validAccounts=0,badAccounts=0,uncoveredAccounts=0;
  const policies=model.policies||[],metadata=new Map();
  const intersect=(left,right)=>{const out=[];for(const a of left)for(const b of right){const r=partition.intersect(a,b);if(r)out.push(r);partition.check(out);}return out;};
  const union=clauses=>{let out=[];for(const clause of clauses){const rectangle=partition.from(clause);if(!rectangle)continue;let pieces=[rectangle];for(const old of out)pieces=partition.minus(pieces,old);out.push(...pieces);partition.check(out);}return out;};
  const constrain=(regions,groups)=>{for(const group of groups||[])regions=intersect(regions,union(group));return regions;};
  try{
   if(!universe||!rules.length)return {status:'empty',rows:[],validAccounts:0,badAccounts:0,uncoveredAccounts:0,jointlyCovered:false};
   const validUniverse=constrain([universe],model.scenarioConstraints),indexes=new Map([...policies,...rules].map(item=>[item,{include:new Set(item.includeUsers||['*']),exclude:new Set(item.excludeUsers||[])}]));
   const targets=(item,identity)=>{const index=indexes.get(item);return (index.include.has('*')||index.include.has(identity.id))&&!index.exclude.has('*')&&!index.exclude.has(identity.id)&&(item.scope!=='privileged'||identity.privileged||identity.pimEligible);};
   for(const p of policies){
    const id=this.original(p.id,origins);if(!rows.has(id))rows.set(id,{id,fragmentIds:[],state:p.state||'enabled',accounts:new Set(),matchingAccounts:new Set(),full:true,blocksOnly:true,unverified:false,conditions:[]});
    const row=rows.get(id);row.fragmentIds.push(p.id);row.blocksOnly&&=!(p.grantAlternatives||[]).length;row.conditions.push(p.conditions||{});row.unverified||=!!(p.unverifiedApplicationFilter||p.unverifiedLocations);
    const condition=partition.from(p.conditions||{});let denied=condition?[condition]:[];for(const grant of p.grantAlternatives||[]) {const allowed=partition.from(grant);if(allowed)denied=partition.minus(denied,allowed);}
    metadata.set(p.id,{condition,denied,index:metadata.size});
   }
   for(const identity of model.identities||[]){
    const scope=rules.map(r=>targets(r,identity)),policyTargets=policies.map(p=>targets(p,identity));if(!scope.some(Boolean))continue;
    const key=JSON.stringify([scope,policyTargets,identity.conditions||{},identity.scenarioConstraints||[]]);if(!groups.has(key))groups.set(key,{identity,scope,targets:policyTargets,ids:[]});groups.get(key).ids.push(identity.id);partition.check([]);
   }
   for(const group of groups.values()){
    const valid=constrain(intersect(validUniverse,[partition.from(group.identity.conditions||{})].filter(Boolean)),group.identity.scenarioConstraints);let anyScope=false,anyBad=false,anyUncovered=false;
    for(let index=0;index<rules.length;index++){
     if(!group.scope[index])continue;const rule=rules[index];let regions=intersect(valid,[partition.from(rule.conditions||{})].filter(Boolean));if(rule.conditionAlternatives!==undefined&&rule.conditionAlternatives!==null)regions=intersect(regions,union(rule.conditionAlternatives));if(!regions.length)continue;anyScope=true;
     let bad=regions;if(!rule.mustBlock){const alternatives=rule.requiredAlternatives??[{authentication:{include:rule.allowedAuthentication||[]}}];for(const allowed of alternatives){const rectangle=partition.from(allowed);if(rectangle)bad=partition.minus(bad,rectangle);}}
     if(!bad.length)continue;anyBad=true;
     let remaining=bad;
     for(const row of rows.values()){
      let individual=bad,matching=false,contribution=false;
      for(const fragmentId of row.fragmentIds){
       const meta=metadata.get(fragmentId),i=meta.index,p=policies[i];if(!group.targets[i])continue;
       matching||=!!meta.condition&&regions.some(r=>partition.intersect(r,meta.condition));
       if((p.state||'enabled')!=='enabled')continue;
       for(const denied of meta.denied){contribution||=bad.some(r=>partition.intersect(r,denied));individual=partition.minus(individual,denied);}
      }
      if(matching)group.ids.forEach(id=>row.matchingAccounts.add(id));
      if(contribution)group.ids.forEach(id=>row.accounts.add(id));if(individual.length)row.full=false;
     }
     for(let i=0;i<policies.length;i++)if(group.targets[i]&&(policies[i].state||'enabled')==='enabled')for(const denied of metadata.get(policies[i].id).denied)remaining=partition.minus(remaining,denied);
     anyUncovered||=remaining.length>0;
    }
    if(anyScope)validAccounts+=group.ids.length;if(anyBad)badAccounts+=group.ids.length;if(anyUncovered)uncoveredAccounts+=group.ids.length;
   }
   return {status:'complete',rows:[...rows.values()].map(row=>({...row,accounts:[...row.accounts],matchingAccounts:[...row.matchingAccounts],full:row.full&&row.accounts.size>0})),validAccounts,badAccounts,uncoveredAccounts,jointlyCovered:validAccounts>0&&uncoveredAccounts===0,elapsedMilliseconds:Date.now()-started};
  }catch(error){const limited=/budget|partition|limit/i.test(error.message||'');return {status:limited?'limited':'unavailable',rows:[],validAccounts:0,badAccounts:0,uncoveredAccounts:null,jointlyCovered:false,message:limited?'The policy mapping reached its analysis limit. Coverage results are unchanged.':'The policy mapping could not be completed. Coverage results are unchanged.',elapsedMilliseconds:Date.now()-started};}
 },
 explain(model,gap,{accountId=gap.identityIds?.[0],origins={},confirmed=gap.assessmentStatus==='gapWithinModel'}={}){
  const identity=(model.identities||[]).find(u=>u.id===accountId),witness=gap.witness||{},rows=[],rule=(model.requirements||[]).find(r=>r.id===gap.requirementId);
  if(!identity||!rule)return {status:'unavailable',rows:[],recommendations:[]};
  const matches=selectors=>Object.entries(selectors||{}).every(([axis,s])=>(!s.include?.length||s.include.includes(witness[axis]))&&!s.exclude?.includes(witness[axis]));
  const requiredAxes=rule.mustBlock?[]:rule.requiredAlternatives?Object.keys(Object.assign({},...rule.requiredAlternatives)):['authentication'];
  for(const p of model.policies||[]){
   const state=p.state||'enabled',assigned=this.targets(p,identity),excluded=(p.excludeUsers||[]).some(id=>id==='*'||id===identity.id),failures=[];
   if(!assigned)failures.push({axis:'account',kind:excluded?'excluded':'notIncluded'});
   for(const [axis,s]of Object.entries(p.conditions||{}))if(!matches({[axis]:s}))failures.push({axis,kind:s.exclude?.includes(witness[axis])?'excluded':'notIncluded',value:witness[axis]});
   const uncertain=!!(p.unverifiedApplicationFilter||p.unverifiedLocations||p.registrationResourceContext&&witness.accessTarget==='userAction'&&witness.registrationContext==='unspecified'),allows=(p.grantAlternatives||[]).some(matches),blocks=!(p.grantAlternatives||[]).length,controlRelated=rule.mustBlock?blocks:(p.grantAlternatives||[]).some(a=>requiredAxes.some(axis=>Object.hasOwn(a,axis)));
   const applies=!failures.length,reason=state!=='enabled'?'notEnforced':uncertain?'unverified':applies?(allows?'allowsExample':'deniesExample'):'outsideScope';
   // Only one known scope mismatch is an edit candidate. Other policies remain visible as context.
   const editableAxis=axis=>['account','application','network','platform','client','flow','signInRisk','userRisk','compliant','hybridJoined','externalUserType','externalTenantId'].includes(axis)||axis.startsWith('device.')||axis.startsWith('resourceGroup.');
   const scopeCandidate=state==='enabled'&&!uncertain&&!allows&&failures.length===1&&editableAxis(failures[0].axis)&&(assigned||excluded)&&(rule.mustBlock||!blocks);
   const grantCandidate=state==='enabled'&&!uncertain&&applies&&allows&&controlRelated;
   const reportCandidate=state==='reportOnly'&&!uncertain&&applies&&!allows;
   if(applies||scopeCandidate||controlRelated||rule.mustBlock&&blocks)rows.push({id:this.original(p.id,origins),fragmentId:p.id,state,reason,failures,blocks,allows,scopeCandidate,grantCandidate,reportCandidate});
  }
  const grouped=new Map();for(const row of rows){const rank=r=>r.grantCandidate?0:r.scopeCandidate?1:r.reportCandidate?2:r.reason==='allowsExample'?3:4;if(!grouped.has(row.id)||rank(row)<rank(grouped.get(row.id)))grouped.set(row.id,row);}
  const related=[...grouped.values()];const recommendations=[];if(confirmed&&related.some(r=>r.reason==='deniesExample'))return {status:'inconsistent',rows:related,recommendations:[]};
  if(!confirmed)recommendations.push({kind:'evidence',title:'Resolve the missing information first',detail:'Review what could not be checked before deciding whether a policy change is needed.'});
  else{
   const candidates=related.filter(r=>r.scopeCandidate||r.grantCandidate||r.reportCandidate),explicitExclusions=candidates.some(r=>r.scopeCandidate&&r.failures[0]?.kind==='excluded');
   for(const row of candidates.filter(r=>!explicitExclusions||!r.scopeCandidate||r.failures[0]?.kind==='excluded'))recommendations.push({difference:row.scopeCandidate?row.failures[0]:null,kind:row.grantCandidate?'grants':row.reportCandidate?'reportOnly':'scope',policyId:row.id,title:row.grantCandidate?'Review the protection controls':row.reportCandidate?'Review report-only enforcement':'Review this policy’s scope',detail:row.grantCandidate?'This policy applies, but one of its allowed alternatives permits the example. Review the controls and any OR alternatives.':row.reportCandidate?'This policy could block the example, but report-only mode does not enforce protection. Review its full impact before enabling it.':'This policy could prevent the example if this scope difference were changed. Check whether the exclusion or restriction is intentional.'});
   recommendations.push({kind:'newPolicy',mustBlock:!!rule.mustBlock,title:rule.mustBlock?'Block the uncovered access':'Add protection for the uncovered scope',detail:'Consider a separate policy for this uncovered scenario. Preserve intentional exclusions and review effects on other access.'});
  }
  return {status:confirmed?'confirmed':'unconfirmed',rows:related,recommendations};
 }
};
if(typeof module!=='undefined'&&module.exports)module.exports=PolicyMapping;
