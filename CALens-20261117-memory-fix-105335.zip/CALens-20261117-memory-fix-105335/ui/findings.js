// Presentation helpers. Loaded after app.js; uses the same local model and result.
function friendlyAccount(id) {
  return accountRecord(id)?.displayName || id;
}
function friendlyPolicy(id) {
  if(activeLab && labPack?.policyMetadata[id])return labPack.policyMetadata[id].name;
  return isExample ? ({'baseline-mfa':'Require MFA for everyone','member-b-browser-mfa':'Require MFA for Member B in browsers','admin-strength-outside-trusted-network':'Require phishing-resistant MFA outside trusted networks'}[id] || id) : id;
}
function requirementName(rule) {
  const auth=rule?.allowedAuthentication||[];
  if(auth.length===1 && auth[0]==='phishingResistant')return 'Phishing-resistant MFA';
  if(auth.length===2 && auth.includes('mfa') && auth.includes('phishingResistant'))return 'MFA';
  return auth.map(label).join(' or ') || 'Authentication requirement';
}
function gapTitle(gap) {
  const rule=model.requirements.find(r=>r.id===gap.requirementId);
  return `${requirementName(rule)} is not always required`;
}
function targetsAccount(policy,id) {
  const include=policy.includeUsers||['*'], exclude=policy.excludeUsers||[];
  return (include.includes('*')||include.includes(id))&&!exclude.includes('*')&&!exclude.includes(id);
}
function policyReason(policy,gap) {
  if(policy.state && policy.state!=='enabled')return policy.state==='reportOnly'?'Report-only; does not enforce access.':'Disabled.';
  const id=gap.identityIds[0];
  if((policy.excludeUsers||[]).some(x=>x==='*'||x===id))return 'Account excluded';
  if(!targetsAccount(policy,id))return 'Targets other accounts';
  for(const [dimension,selector] of Object.entries(policy.conditions||{})) {
    const value=gap.witness[dimension];
    if((selector.exclude||[]).includes(value))return `${label(dimension)} excluded: ${label(value)}`;
    if(selector.include?.length&&!selector.include.includes(value))return `${label(dimension)} not covered: ${label(value)}`;
  }
  return 'Applies, but permits this weaker sign-in';
}
function renderResults() {
  const open=result.gaps.filter(g=>!g.acceptance), accepted=result.gaps.length-open.length;
  $('#stat-open').textContent=open.length.toLocaleString();
  $('#stat-users').textContent=new Set(open.flatMap(g=>g.identityIds)).size.toLocaleString();
  $('#stat-accepted').textContent=accepted.toLocaleString();
  $('#stat-profiles').textContent=result.identityCount.toLocaleString();
  $('#run-meta').textContent=`${isExample?'Demo':sourceName} · ${new Date(result.runAtUtc).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;
  const complete=result.status==='completeWithinModel';
  $('#completion').classList.toggle('warning',!complete);
  $('#completion').textContent=complete?`${result.gaps.length?`${result.gaps.length} ${result.gaps.length===1?'gap found':'gaps found'}`:'No gaps found'} in the loaded ${isExample?'demo':'model'}. No real sign-ins were performed.`:'Check incomplete. The findings below are only partial.';
  $('#account-overview').innerHTML=accountSummary();
  const query=$('#search').value.trim().toLowerCase();
  const visible=result.gaps.filter(g=>(filter==='all'||(filter==='accepted'?!!g.acceptance:!g.acceptance))&&(!query||JSON.stringify([gapTitle(g),g.requirementId,g.identityIds.map(friendlyAccount),g.region]).toLowerCase().includes(query)));
  if(!visible.some(g=>g.key===selectedKey))selectedKey=visible[0]?.key||null;
  $('#findings-list').innerHTML=visible.length?visible.slice(0,150).map(g=>`<button class="finding ${selectedKey===g.key?'selected':''}" data-key="${g.key}" aria-pressed="${selectedKey===g.key}"><div class="finding-top"><span>${esc(g.identityIds.slice(0,2).map(friendlyAccount).join(', '))}${g.identityIds.length>2?` + ${g.identityIds.length-2}`:''}</span><span class="finding-status ${g.acceptance?'accepted':''}">${g.acceptance?'Accepted':'Gap'}</span></div><strong>${esc(gapTitle(g))}</strong><p>${esc((g.region.application||[]).map(label).join(', '))} · ${esc(label(g.witness.client||'Any client'))} · ${esc(label(g.witness.network||'Any network'))}</p><div class="finding-bottom"><span>Allowed: ${esc(label(g.witness.authentication))}</span><span>View gap →</span></div></button>`).join('')+(visible.length>150?'<p class="hint">First 150 gaps shown. Search to narrow results.</p>':''):`<div class="no-findings"><strong>${query?'No matching findings':filter==='accepted'?'No accepted gaps':complete?'No gaps to review':'Check incomplete'}</strong><p>${query?'Try another account.':filter==='accepted'?'Accepted gaps appear here.':complete?'All checked requirements are met, or the gaps are accepted.':'Rerun before drawing conclusions.'}</p></div>`;
  document.querySelectorAll('.finding').forEach(el=>el.onclick=()=>{selectedKey=el.dataset.key;renderResults();if(window.innerWidth<=1000)$('#detail').scrollIntoView({behavior:'smooth',block:'start'});});
  renderDetail(visible.find(g=>g.key===selectedKey));
  showPerformance();
}
function renderDetail(gap) {
  if(!gap){$('#detail').innerHTML='<div class="no-findings">Choose a gap to see what is missing.</div>';return;}
  const rule=model.requirements.find(r=>r.id===gap.requirementId);
  const path=['application','client','network'].filter(k=>gap.witness[k]);
  const fixable=isExample && !activeLab && ((gap.requirementId==='all-users-mfa'&&gap.identityIds.includes('member-b'))||(gap.requirementId==='privileged-phishing-resistant'&&gap.identityIds.includes('eligible-admin')));
  const tracePolicies=activeLab?model.policies.filter(p=>p.id===selectedFault?.policyId||gap.applicablePolicyIds.includes(p.id)):model.policies;
  const policyRows=tracePolicies.map(p=>`<div class="policy-reason"><strong>${esc(friendlyPolicy(p.id))}</strong><span>${esc(policyReason(p,gap))}</span></div>`).join('');
  $('#detail').innerHTML=`<div class="eyebrow">${esc(gap.identityIds.length>2?`${gap.identityIds.length.toLocaleString()} affected accounts`:gap.identityIds.map(friendlyAccount).join(', '))}</div><h2>${esc(gapTitle(gap))}</h2><div class="protection-compare"><div><span>You require</span><strong>${esc(requirementName(rule))}</strong></div><span class="compare-arrow">→</span><div class="weaker"><span>Policies allow</span><strong>${esc(label(gap.witness.authentication))}</strong></div></div><div class="detail-label">One example where this happens</div><div class="signin-path">${path.map(k=>`<div><small>${esc(label(k))}</small><strong>${esc(label(gap.witness[k]))}</strong></div>`).join('<span>→</span>')}</div><div class="detail-label">Why this sign-in slips through</div>${policyRows}${gap.acceptance?`<div class="accepted-note"><strong>Accepted</strong> · ${esc(gap.acceptance.reason)}</div>`:''}${fixable?`<div class="demo-fix"><button id="try-fix" class="primary">Try closing this gap →</button><small>Changes demo policies only.</small></div>`:''}<details><summary>All affected conditions & accounts</summary><div class="chips">${gap.identityIds.map(id=>`<span class="chip">${esc(friendlyAccount(id))}${AccountTags.classify(accountRecord(id),tagRules).length?` · ${esc(AccountTags.classify(accountRecord(id),tagRules).join(', '))}`:''}</span>`).join('')}</div>${Object.entries(gap.region).map(([k,v])=>`<div class="region-row"><span>${esc(label(k))}</span><div class="chips">${v.map(x=>`<span class="chip">${esc(label(x))}</span>`).join('')}</div></div>`).join('')}<p class="hint">Every combination above is a gap. Several sign-in combinations can be grouped into one finding.</p></details><div class="detail-actions"><span class="hint">Accepting a gap does not fix it.</span><button class="secondary" id="accept-finding">${gap.acceptance?'Reopen gap':'Accept gap…'}</button></div>`;
  $('#accept-finding').onclick=async()=>{
    if(gap.acceptance){try{await api('/api/accept',{key:gap.key,reopen:true});gap.acceptance=null;renderResults();toast('Gap reopened.');}catch(e){error(e);}}
    else{pendingKey=gap.key;$('#reason').value='';$('#accept-dialog').showModal();$('#reason').focus();}
  };
  if(fixable)$('#try-fix').onclick=async()=>{
    if(busy)return;
    if(gap.requirementId==='all-users-mfa'){
      const policy=model.policies.find(p=>p.id==='baseline-mfa');
      policy.excludeUsers=(policy.excludeUsers||[]).filter(id=>id!=='member-b');
      toast('Demo change: Member B now included in the MFA policy.');
    }else{
      const policy=model.policies.find(p=>p.id==='admin-strength-outside-trusted-network');
      policy.conditions={};
      toast('Demo change: admin strength policy now covers all networks.');
    }
    counts();await run();
  };
}
