let tagRules=[], accountDirectory=new Map();
function accountRecord(id) {
  if(activeLab)return accountDirectory.get(id);
  if(isExample && ['member-a','member-b','eligible-admin'].includes(id))return {id,userType:'Member',displayName:{'member-a':'Member A','member-b':'Member B','eligible-admin':'Member · PIM eligible'}[id]};
  return null;
}
function accountSummary() {
  return ['Member','Guest','Unknown'].map(type=>{
    const people=model.identities.filter(u=>(accountRecord(u.id)?.userType||'Unknown')===type);
    if(!people.length)return '';
    const ids=new Set(people.map(u=>u.id));
    const affected=new Set(result.gaps.flatMap(g=>g.identityIds).filter(id=>ids.has(id)));
    return `<div class="account-tile ${affected.size?'has-gap':''}"><span class="account-avatar">${affected.size?'!':'✓'}</span><div><strong>${people.length.toLocaleString()} ${type} accounts</strong><small>${affected.size?`${affected.size.toLocaleString()} with gaps`:result.status==='completeWithinModel'?'No authentication gaps found':'Check incomplete'}</small></div></div>`;
  }).join('');
}
async function initTags(){tagRules=(await api('/api/tag-rules')).rules;$('#add-tag').onclick=()=>{readTags(true);tagRules.push({enabled:true,tag:'',field:'displayName',operator:'startsWith',value:''});renderTags();};$('#save-tags').onclick=saveTags;}
function readTags(allowBlank=false){
  const rules=[...document.querySelectorAll('.tag-rule')].map(row=>({enabled:row.querySelector('.tag-enabled').checked,tag:row.querySelector('.tag-name').value.trim(),field:row.querySelector('.tag-field').value,operator:row.querySelector('.tag-operator').value,value:row.querySelector('.tag-value').value.trim()}));
  if(!allowBlank)AccountTags.validate(rules);
  tagRules=rules;return rules;
}
function renderTags(){
  $('#tag-rule-list').innerHTML=tagRules.length?tagRules.map((r,i)=>`<div class="tag-rule"><label class="tag-switch"><input type="checkbox" class="tag-enabled" ${r.enabled?'checked':''}>Enabled</label><label>Tag<input class="tag-name" value="${esc(r.tag)}" placeholder="Your label"></label><label>Attribute<select class="tag-field">${AccountTags.fields.map(f=>`<option ${r.field===f?'selected':''}>${f}</option>`).join('')}</select></label><label>Condition<select class="tag-operator">${AccountTags.operators.map(op=>`<option value="${op}" ${r.operator===op?'selected':''}>${{startsWith:'Starts with',equals:'Equals',hasValue:'Has a value'}[op]}</option>`).join('')}</select></label><label>Value<input class="tag-value" value="${esc(r.value)}" placeholder="e.g. svc"></label><button class="text-button remove-tag" data-tag-index="${i}">Remove</button></div>`).join(''):'<p>No tags configured. Account types remain Member or Guest.</p>';
  document.querySelectorAll('.remove-tag').forEach(b=>b.onclick=()=>{readTags(true);tagRules.splice(Number(b.dataset.tagIndex),1);renderTags();});
  previewTags();
}
function previewTags(){
  let rules;try{rules=AccountTags.validate(tagRules);}catch{rules=[];}
  const accounts=model.identities.map(u=>({id:u.id,record:accountRecord(u.id)}));
  const matched=accounts.map(u=>({...u,tags:AccountTags.classify(u.record,rules)})).filter(u=>u.tags.length);
  $('#tag-preview').innerHTML=`<h2>${matched.length.toLocaleString()} accounts tagged</h2><div class="tag-preview-table">${matched.slice(0,12).map(u=>`<div><strong>${esc(friendlyAccount(u.id))}</strong><span>${esc(u.record.userType)} · ${esc(u.tags.join(', '))}</span></div>`).join('')}</div>${matched.length>12?'<p class="hint">First 12 matches shown.</p>':''}`;
}
async function saveTags(){try{clearError();const rules=readTags();await api('/api/tag-rules',{rules});previewTags();toast('Tag rules saved. Policy targeting is unchanged.');}catch(e){error(e);}}
