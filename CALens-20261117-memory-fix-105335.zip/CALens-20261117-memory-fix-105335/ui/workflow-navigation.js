'use strict';
const WorkflowNavigation={
 steps:[{id:'data',name:'Import policies'},{id:'sets',name:'Define accounts'},{id:'requirements',name:'Set requirements'},{id:'results',name:'Review coverage'}],
 state({step='data',source,profile,result,busy=false,collecting=false}={}){
  const index=Math.max(0,this.steps.findIndex(s=>s.id===step)),current=this.steps[index],accounts=source?.records?.length||0;
  const enabled=(profile?.requirements||[]).filter(r=>r.enabled!==false),pending=enabled.filter(r=>r.pendingSetup?.length);
  const state={step:current.id,title:'Step '+(index+1)+' of '+this.steps.length+' · '+current.name,back:index?this.steps[index-1].id:null,backLabel:index?'← '+this.steps[index-1].name:'',backDisabled:busy,primaryId:index<2?'workflow-next':index===2?'run':result?'rerun':'empty-check',next:index<2?this.steps[index+1].id:null,label:index===0?'Define accounts →':index===1?'Set requirements →':index===2?'Check coverage →':result?'Check again':'Check coverage',disabled:busy||!accounts,message:''};
  if(index===0){
   state.disabled=busy||collecting||!accounts;
   state.message=collecting?'Finish signing in and collecting data to continue.':accounts?accounts.toLocaleString()+(accounts===1?' account':' accounts')+' loaded. Ready to continue.':source?'This file has no account list. Import policies and accounts to continue.':'Load policies and accounts to continue.';
  }else if(index===1){
   state.message=accounts?'Use All accounts, or customise your account sets before continuing.':'Load policies and accounts first.';
  }else{
   state.disabled=busy||!accounts||!enabled.length||!!pending.length;
   state.message=!accounts?'Load policies and accounts first.':pending.length?'Finish setting up the enabled requirements before checking coverage.':!enabled.length?'Add or enable a requirement before checking coverage.':index===2?enabled.length+(enabled.length===1?' enabled requirement':' enabled requirements')+'. Ready to check coverage.':result?'Review by account or requirement, or check again after a change.':'Ready to check your data against your requirements.';
  }
  if(busy)state.message='Checking coverage. Please wait…';
  return state;
 }
};
if(typeof module!=='undefined')module.exports=WorkflowNavigation;
