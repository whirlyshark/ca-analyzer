'use strict';
// The architecture example is stored as a historical mathematical fixture.
// Present it through the same Graph-format snapshot path as imported tenants.
const DemoSnapshot={
 profile(input){
  const profile=structuredClone(input),flows={deviceCode:'deviceCodeFlow',transfer:'authenticationTransfer'},clients={desktop:['mobileAppsAndDesktopClients'],legacy:['exchangeActiveSync','easSupported','other']};
  for(const r of profile.requirements||[]){
   if(Array.isArray(r.flows))r.flows=[...new Set(r.flows.map(v=>flows[v]||v))];
   if(Array.isArray(r.platforms))r.platforms=[...new Set(r.platforms.map(v=>v==='ios'?'iOS':v))];
   if(Array.isArray(r.clients))r.clients=[...new Set(r.clients.flatMap(v=>clients[v]||[v]))];
   if(r.registrationContext?.flow)r.registrationContext.flow=flows[r.registrationContext.flow]||r.registrationContext.flow;
  }
  return profile;
 },
 build(pack,{size=1000,scenario=''}={}){
  if(![100,1000,10000].includes(size))throw Error('Choose a supported demo size.');
  const model=structuredClone(pack.baseline),originals=model.identities,records=new Map(pack.directory.map(r=>[r.id,r])),mapping=new Map(originals.map(u=>[u.id,[]])),users=[];
  for(let i=0;i<size;i++){const original=originals[i%originals.length],copy=Math.floor(i/originals.length),id=copy?original.id+'-copy-'+(copy+1):original.id;mapping.get(original.id).push(id);const record=structuredClone(records.get(original.id)),guest=record.userType==='Guest';users.push({...record,id,accountEnabled:true,mail:guest?'guest'+i+'@partner-'+(i%2?'a':'b')+'.example.invalid':record.userPrincipalName,otherMails:[],jobTitle:record.jobTitle||null,department:guest?'External':'Operations',companyName:guest?'Example partner '+(i%2?'A':'B'):'Example organization',creationType:guest?'Invitation':null,externalUserType:guest?'b2bCollaborationGuest':'none',externalTenantId:guest?(i%2?'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa':'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'):null});}
  for(const p of model.policies)for(const key of ['includeUsers','excludeUsers'])if(p[key])p[key]=p[key].flatMap(id=>id==='*'?['*']:mapping.get(id)||[]);
  const fault=pack.faults.find(f=>f.id===scenario);
  if(fault){let target=model.policies.find(p=>p.id===fault.policyId);for(const key of fault.path.slice(0,-1))target=target[key];target[fault.path.at(-1)]=structuredClone(fault.value);}
  const start='2020-01-01T00:00:00Z',snapshot={caGapSnapshotVersion:1,tenantId:'demo-architecture-snapshot-v2',tenantName:fault?fault.name:'Architecture lab · Clean baseline',capturedAtUtc:'2026-11-16T12:00:00Z',users,groups:[],groupMembers:{},groupDirectMembers:{},pimGroupEligibility:[],pimGroupAssignments:[],roles:structuredClone((typeof module!=='undefined'&&module.exports?require('./builtin-role-catalog.js'):BuiltinRoleCatalog).roles),roleAssignments:[],roleAssignmentScheduleInstances:[],roleEligibility:[],applications:[],namedLocations:[],policies:[],errors:[],legacyMfaTrustedIpRanges:[],legacyMfaFederatedIntranetEnabled:false,compliantNetworkLocations:[],deviceRegistrationPolicy:{multiFactorAuthConfiguration:'notRequired'},scopeNotes:['Fictional demo. Role catalog uses published Microsoft role names and privileged labels, captured 16 November 2026. Assignments are fictional; tenant imports use exported role metadata.']};
  const assignment=(user,role,eligible)=>{role=snapshot.roles.find(r=>r.displayName===role)?.id||role;const row={id:(eligible?'eligible-':'assigned-')+user.id+'-'+role,principalId:user.id,roleDefinitionId:role,directoryScopeId:'/',appScopeId:null};if(eligible)snapshot.roleEligibility.push({...row,memberType:'Direct',startDateTime:start,endDateTime:null});else{snapshot.roleAssignments.push(row);snapshot.roleAssignmentScheduleInstances.push({...row,id:'schedule-'+row.id,roleAssignmentOriginId:row.id,assignmentType:'Assigned',memberType:'Direct',startDateTime:start,endDateTime:null});}};
  for(const [i,u] of users.entries()){
   for(const id of u.groupIds||[]){if(!snapshot.groupMembers[id]){snapshot.groups.push({id,displayName:id.replace(/-/g,' ')});snapshot.groupMembers[id]=[];snapshot.groupDirectMembers[id]=[];}snapshot.groupMembers[id].push(u.id);snapshot.groupDirectMembers[id].push(u.id);}
   if(u.privileged)assignment(u,'Global Administrator',false);if(u.pimEligible)assignment(u,'Privileged Role Administrator',true);
   if(!u.privileged&&!u.pimEligible&&u.userType==='Member'&&i%20===0)assignment(u,'Reports Reader',false);
   if(!u.privileged&&!u.pimEligible&&u.userType==='Member'&&i%37===0)assignment(u,'Reports Reader',true);
  }
  const appNames={sharepoint:'SharePoint',exchange:'Exchange Online',teams:'Microsoft Teams',azure:'Azure management',finance:'Finance app',hr:'HR app',crm:'CRM app','vpn-app':'VPN app','new-app':'New app'};
  snapshot.applications=model.dimensions.application.map(appId=>({appId,displayName:appNames[appId]||appId}));
  snapshot.namedLocations=[['office','Office network','192.0.2.0/26'],['vpn','Corporate VPN','192.0.2.64/26'],['internet','Internet example range','203.0.113.0/24'],['disallowed-region','Blocked example network','198.51.100.0/24']].map(([id,displayName,cidrAddress])=>({id,displayName,'@odata.type':'#microsoft.graph.ipNamedLocation',isTrusted:id==='office'||id==='vpn',ipRanges:[{'@odata.type':'#microsoft.graph.iPv4CidrRange',cidrAddress}]}));
  snapshot.resourceGroups=[['Office365',['sharepoint','exchange','teams']],['MicrosoftAdminPortals',['azure']],['797f4846-ba00-4fd7-ba43-dac1f8f63013',['azure']]].map(([id,members])=>({id,members,nonMembers:model.dimensions.application.filter(x=>!members.includes(x)),complete:true,provenance:{kind:'declared',description:'Complete fictional demo app-group membership.'}}));
  const flows={standard:'standard',deviceCode:'deviceCodeFlow',transfer:'authenticationTransfer'},clients={browser:['browser'],desktop:['mobileAppsAndDesktopClients'],legacy:['exchangeActiveSync','other']};
  for(const p of model.policies){
   const c={users:{includeUsers:(p.includeUsers||['*']).map(id=>id==='*'?'All':id),...(p.excludeUsers?{excludeUsers:p.excludeUsers.map(id=>id==='*'?'All':id)}:{})},applications:{includeApplications:p.conditions.application?.include||['All'],...(p.conditions.application?.exclude?{excludeApplications:p.conditions.application.exclude}:{})}};
   for(const [axis,s] of Object.entries(p.conditions)){
    if(axis==='application')continue;
    if(axis==='client'){const values=(s.include||model.dimensions.client).filter(v=>!s.exclude?.includes(v));c.clientAppTypes=[...new Set(values.flatMap(v=>clients[v]||[v]))];}
    else if(axis==='platform')c.platforms={includePlatforms:(s.include||['all']).map(v=>v==='ios'?'iOS':v),...(s.exclude?{excludePlatforms:s.exclude.map(v=>v==='ios'?'iOS':v)}:{})};
    else if(axis==='flow'){const values=(s.include||model.dimensions.flow).filter(v=>!s.exclude?.includes(v));if(values.length!==1||values[0]==='standard')throw Error('Demo flow policy needs one supported tracked flow.');c.authenticationFlows={transferMethods:flows[values[0]]||values[0]};}
    else if(axis==='network')c.locations={includeLocations:s.include||['All'],...(s.exclude?{excludeLocations:s.exclude}:{})};
    else if(axis==='signInRisk'||axis==='userRisk')c[axis==='signInRisk'?'signInRiskLevels':'userRiskLevels']=(s.include||model.dimensions[axis]).filter(v=>!s.exclude?.includes(v));
    else throw Error('Unsupported architecture demo condition: '+axis);
   }
   let grantControls;
   const control=entry=>{if(Object.keys(entry).length!==1)throw Error('Demo alternative must have one grant control.');if(entry.authentication){const a=entry.authentication.include;if(a.length===1&&a[0]==='phishingResistant')return 'phishingResistant';if(a.length===2&&a.includes('mfa')&&a.includes('phishingResistant'))return 'mfa';}if(entry.compliant?.include?.join()==='true')return 'compliantDevice';if(entry.hybridJoined?.include?.join()==='true')return 'domainJoinedDevice';throw Error('Unsupported architecture demo grant.');};
   const controls=p.grantAlternatives.map(control);
   if(!controls.length)grantControls={operator:'OR',builtInControls:['block']};else if(controls.includes('phishingResistant')){if(controls.length!==1)throw Error('Unsupported mixed demo authentication strength.');grantControls={operator:'OR',authenticationStrength:{id:'00000000-0000-0000-0000-000000000004'}};}else grantControls={operator:'OR',builtInControls:controls};
   snapshot.policies.push({id:p.id,displayName:pack.policyMetadata[p.id]?.name||p.id,state:p.state==='reportOnly'?'enabledForReportingButNotEnforced':p.state,conditions:c,grantControls});
  }
  for(const [id,target,strong] of [['demo-context',{includeAuthenticationContextClassReferences:['c1']},true],['demo-security-registration',{includeUserActions:['urn:user:registersecurityinfo']},false],['demo-device-registration',{includeUserActions:['urn:user:registerdevice']},false]])snapshot.policies.push({id,displayName:strong?'Sensitive action: phishing-resistant authentication':id==='demo-security-registration'?'Security information registration: require MFA':'Device registration: require MFA',state:'enabled',conditions:{users:{includeUsers:['All']},applications:target},grantControls:strong?{operator:'OR',authenticationStrength:{id:'00000000-0000-0000-0000-000000000004'}}:{operator:'OR',builtInControls:['mfa']}});
  snapshot.policies.push({id:'demo-directory-baseline',displayName:'Directory resource: require MFA',state:'enabled',conditions:{users:{includeUsers:['All']},applications:{includeApplications:['00000002-0000-0000-c000-000000000000']}},grantControls:{operator:'OR',builtInControls:['mfa']}});
  snapshot.completeness=Object.fromEntries(['policies','users','groups','groupMembers','groupDirectMembers','pimGroupEligibility','pimGroupAssignments','roles','roleAssignments','roleEligibility','roleAssignmentScheduleInstances','applications','namedLocations','compliantNetworkLocations','deviceRegistrationPolicy'].map(k=>[k,true]));
  return snapshot;
 }
};
if(typeof module!=='undefined')module.exports=DemoSnapshot;
