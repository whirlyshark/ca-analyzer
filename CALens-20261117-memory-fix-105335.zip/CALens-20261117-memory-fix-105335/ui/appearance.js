'use strict';
const Appearance={
 backgrounds:{light:['soft-grey','warm-grey','cool-grey'],dark:['slate','graphite','midnight']},
 accents:['green','blue','purple','gold','rose'],
 valid(value){return ['light','dark','system'].includes(value)?value:'system';},
 resolve(value,darkSystem=false){return this.valid(value)==='system'?(darkSystem?'dark':'light'):this.valid(value);},
 defaults(){return {mode:'system',light:'soft-grey',dark:'slate',accent:'green'};},
 normalize(input){const value=input&&typeof input==='object'?input:{};return {mode:this.valid(value.mode),light:this.backgrounds.light.includes(value.light)?value.light:'soft-grey',dark:this.backgrounds.dark.includes(value.dark)?value.dark:'slate',accent:this.accents.includes(value.accent)?value.accent:'green'};}
};
if(typeof module!=='undefined')module.exports=Appearance;
if(typeof document!=='undefined'){
 const media=window.matchMedia('(prefers-color-scheme: dark)');let settings=Appearance.defaults();
 try{const stored=localStorage.getItem('ca-gap-appearance-settings');settings=stored?Appearance.normalize(JSON.parse(stored)):Appearance.normalize({mode:localStorage.getItem('ca-gap-appearance')});}catch{}
 let ready=false;
 const apply=()=>{
  const mode=Appearance.resolve(settings.mode,media.matches),root=document.documentElement;root.dataset.theme=mode;root.dataset.palette=settings[mode];root.dataset.accent=settings.accent;
  if(ready){
   document.querySelector('#appearance-mode').value=settings.mode;
   const labels={'soft-grey':'Soft grey','warm-grey':'Warm grey','cool-grey':'Cool grey',slate:'Slate',graphite:'Graphite',midnight:'Midnight'};
   const background=document.querySelector('#appearance-background');background.replaceChildren(...Appearance.backgrounds[mode].map(value=>{const option=document.createElement('option');option.value=value;option.textContent=labels[value];return option;}));background.value=settings[mode];
   document.querySelector('#appearance-mode-note').textContent=settings.mode==='system'?'Following your system: '+mode+' mode.':'Using '+mode+' mode.';
   document.querySelectorAll('[data-appearance-accent]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.appearanceAccent===settings.accent)));
  }
 };
 const save=()=>{apply();try{localStorage.setItem('ca-gap-appearance-settings',JSON.stringify(settings));}catch{}};
 apply();media.addEventListener('change',apply);
 document.addEventListener('DOMContentLoaded',()=>{
  ready=true;apply();const dialog=document.querySelector('#appearance-dialog');
  document.querySelector('#open-appearance').addEventListener('click',()=>dialog.showModal());
  document.querySelector('#close-appearance').addEventListener('click',()=>dialog.close());
  document.querySelector('#appearance-mode').addEventListener('change',e=>{settings.mode=Appearance.valid(e.target.value);save();});
  document.querySelector('#appearance-background').addEventListener('change',e=>{const mode=Appearance.resolve(settings.mode,media.matches);settings[mode]=Appearance.backgrounds[mode].includes(e.target.value)?e.target.value:Appearance.defaults()[mode];save();});
  document.querySelectorAll('[data-appearance-accent]').forEach(button=>button.addEventListener('click',()=>{settings.accent=button.dataset.appearanceAccent;save();}));
  document.querySelector('#reset-appearance').addEventListener('click',()=>{settings=Appearance.defaults();save();});
 });
}
