'use strict';
// Project documented session controls onto the supported admission requirements.
// This validates configuration; it does not execute a browser/Defender/GSA session.
const SessionControls={
 prepare(input){
  if(input===undefined||input===null)return {details:[],uncertain:[]};
  if(typeof input!=='object'||Array.isArray(input))throw Error('Session controls must be an object.');
  const fields={signInFrequency:['isEnabled','authenticationType','frequencyInterval','type','value'],persistentBrowser:['isEnabled','mode'],applicationEnforcedRestrictions:['isEnabled'],cloudAppSecurity:['isEnabled','cloudAppSecurityType'],secureSignInSession:['isEnabled'],continuousAccessEvaluation:['mode'],disableResilienceDefaults:[],globalSecureAccessFilteringProfile:['isEnabled','profileId']};
  const details=[],uncertain=[];
  for(const [key,value] of Object.entries(input)){
   if(key.startsWith('@')||value===null||value===undefined)continue;
   if(!Object.hasOwn(fields,key))throw Error(`Session control ${key} is not yet evaluated.`);
   if(key==='disableResilienceDefaults'){
    if(typeof value!=='boolean')throw Error('Disable resilience defaults must be a Boolean.');
    details.push('Resilience defaults: '+(value?'disabled':'enabled')+'. Outage/session continuation is outside this assessment.');continue;
   }
   if(!value||typeof value!=='object'||Array.isArray(value))throw Error(`Session control ${key} must be an object.`);
   for(const field of Object.keys(value))if(!field.startsWith('@')&&!fields[key].includes(field))throw Error(`Session control ${key}: ${field} is not supported.`);
   const type=key+'SessionControl';
   if(value['@odata.type']!==undefined&&value['@odata.type']!=='#microsoft.graph.'+type&&value['@odata.type']!=='microsoft.graph.'+type)throw Error(`Session control ${key} has an unsupported type.`);
   if(key!=='continuousAccessEvaluation'){
    if(typeof value.isEnabled!=='boolean')throw Error(`Session control ${key} needs a Boolean isEnabled.`);
    if(!value.isEnabled)continue;
   }
   if(key==='signInFrequency'){
    if(!['everyTime','timeBased'].includes(value.frequencyInterval)||value.authenticationType!==undefined&&value.authenticationType!==null&&!['primaryAndSecondaryAuthentication','secondaryAuthentication'].includes(value.authenticationType)||value.frequencyInterval==='everyTime'&&!['primaryAndSecondaryAuthentication','secondaryAuthentication'].includes(value.authenticationType))throw Error('Unrecognized sign-in frequency settings.');
    if(value.frequencyInterval==='timeBased'&&(!['hours','days'].includes(value.type)||!Number.isInteger(value.value)||value.value<1||value.value>2147483647))throw Error('Invalid time-based sign-in frequency.');
    details.push(value.frequencyInterval==='everyTime'?'Reauthentication: every time. Timing is outside this assessment.':`Reauthentication: every ${value.value} ${value.type}. Timing is outside this assessment.`);
   }else if(key==='persistentBrowser'){
    if(!['always','never'].includes(value.mode))throw Error('Unrecognized persistent browser mode.');
    details.push('Browser persistence: '+value.mode+'. Cookie persistence is outside this assessment.');
   }else if(key==='continuousAccessEvaluation'){
    if(!['disabled','strictEnforcement','strictLocation'].includes(value.mode))throw Error('Unrecognized continuous access evaluation mode.');
    details.push('Continuous access evaluation: '+value.mode+'. Session reevaluation is outside this assessment.');
    if(value.mode!=='disabled')uncertain.push(key);
   }else{
    if(key==='cloudAppSecurity'&&!['mcasConfigured','monitorOnly','blockDownloads'].includes(value.cloudAppSecurityType))throw Error('Unrecognized cloud app security mode.');
    if(key==='globalSecureAccessFilteringProfile'&&(typeof value.profileId!=='string'||!value.profileId.trim()||value.profileId!==value.profileId.trim()))throw Error('Global Secure Access session control needs a profile identifier.');
    uncertain.push(key);
    const name={applicationEnforcedRestrictions:'App-enforced restrictions',cloudAppSecurity:'Defender for Cloud Apps',secureSignInSession:'Token protection',globalSecureAccessFilteringProfile:'Global Secure Access filtering'}[key];
    details.push(name+': configured. Grant controls are checked; downstream session enforcement needs separate evidence.');
   }
  }
  return {details,uncertain};
 }
};
if(typeof module!=='undefined')module.exports=SessionControls;
