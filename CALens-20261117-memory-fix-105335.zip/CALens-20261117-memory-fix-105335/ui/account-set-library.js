'use strict';
const AccountSetLibrary={
 catalog:[
  {id:'members',name:'Members',description:'Accounts marked Member in your directory.',set:{id:'members',name:'Members',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Member'}]}},
  {id:'guests',name:'Guests',description:'Accounts marked Guest in your directory.',set:{id:'guests',name:'Guests',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Guest'}]}},
  {id:'privileged',name:'Privileged role holders',description:'Microsoft privileged roles, including people eligible through PIM. You can change the roles.',set:{id:'privileged',name:'Privileged role holders',kind:'privileged'}},
  {id:'breakglass',name:'Emergency access accounts',description:'Select your recovery accounts yourself. No accounts are selected automatically.',set:{id:'breakglass',name:'Emergency access accounts',kind:'manual',accountIds:[]}},
  {id:'service-prefix',name:'Accounts with a naming prefix',description:'For example, service accounts starting with svc. Choose your own prefix.',set:{name:'Service accounts',kind:'filter',match:'all',clauses:[{field:'userPrincipalName',operator:'startsWith',value:''}]}},
  {id:'job-title',name:'Accounts with a job title',description:'Accounts with a populated job title. This does not automatically mean they are employees.',set:{name:'Accounts with a job title',kind:'filter',match:'all',clauses:[{field:'jobTitle',operator:'hasValue',value:''}]}},
  {id:'department',name:'Accounts in a department',description:'Choose a department name, such as Finance.',set:{name:'Department accounts',kind:'filter',match:'all',clauses:[{field:'department',operator:'equals',value:''}]}},
  {id:'partner',name:'Guests from a partner organisation',description:'Match Guest accounts by their Company property. Check that this property is populated in your export.',set:{name:'Partner guests',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Guest'},{field:'companyName',operator:'equals',value:''}]}},
  {id:'disabled',name:'Disabled accounts',description:'Accounts that are currently disabled. Useful for reviewing your account inventory.',set:{name:'Disabled accounts',kind:'filter',match:'all',clauses:[{field:'accountEnabled',operator:'equals',value:'false'}]}}
 ],
 validate(sets){
  if(!Array.isArray(sets)||sets.length>1000)throw Error('Choose a file containing up to 1,000 account sets.');
  const ids=new Set(),string=(v,max=300)=>typeof v==='string'&&v.trim().length>0&&v.length<=max;
  const list=v=>Array.isArray(v)&&v.length<=50000&&v.every(x=>string(x))&&new Set(v.map(x=>x.toLowerCase())).size===v.length;
  return sets.map(s=>{
   if(!s||!string(s.id,200)||s.id==='all'||ids.has(s.id)||!string(s.name,100)||!['filter','manual','privileged'].includes(s.kind))throw Error('Each account set needs a unique ID, a name and a supported definition.');
   ids.add(s.id);const clean={id:s.id,name:s.name,kind:s.kind};
   if(s.kind==='manual'){if(!list(s.accountIds??[]))throw Error('Selected account IDs must be a list without duplicates.');clean.accountIds=[...(s.accountIds||[])];}
   if(s.kind==='privileged'&&s.roleIds!==undefined){if(!list(s.roleIds)||!s.roleIds.length)throw Error('Choose at least one role, or use the Microsoft privileged-role preset.');clean.roleIds=[...s.roleIds];}
   if(s.kind==='filter'){
    if(!['all','any'].includes(s.match??'all')||!Array.isArray(s.clauses)||!s.clauses.length||s.clauses.length>100)throw Error('Filter sets need one or more conditions with All or Any matching.');
    clean.match=s.match??'all';clean.clauses=s.clauses.map(c=>{
     if(!c||!['userType','accountEnabled','displayName','userPrincipalName','mail','otherMails','jobTitle','department','companyName','creationType','externalTenantId','externalUserType','groupIds','eligibleGroupIds','roleIds'].includes(c.field)||!['equals','startsWith','endsWith','contains','hasValue'].includes(c.operator)||c.not!==undefined&&typeof c.not!=='boolean'||c.operator!=='hasValue'&&!string(c.value))throw Error('An account-set filter is missing a value or uses an unsupported condition.');
     if(c.field==='accountEnabled'&&(c.operator!=='equals'||!['true','false'].includes(c.value?.toLowerCase())))throw Error('Account status must be Equals Enabled or Disabled.');
     return {field:c.field,operator:c.operator,value:c.operator==='hasValue'?'':c.value,not:!!c.not};
    });
   }
   return clean;
  });
 },
 read(input){if(!input||!(input.accountSetsVersion===1||input.version===1&&Array.isArray(input.requirements)))throw Error('Choose an exported account-set file or a definitions and requirements file.');return this.validate(input.sets);},
 export(sets){return {accountSetsVersion:1,sets:this.validate(sets)};},
 status(existing,set){const prior=existing.find(s=>s.id===set.id);if(!prior)return 'new';return JSON.stringify(this.validate([prior])[0])===JSON.stringify(this.validate([set])[0])?'existing':'copy';},
 merge(existing,incoming,makeId){
  const additions=[],skipped=[];const known=this.validate(existing);
  for(const item of this.validate(incoming)){
   const state=this.status(known,item);if(state==='existing'){skipped.push(item.id);continue;}
   const copy=structuredClone(item);if(state==='copy'){copy.id=makeId();if(!copy.id||known.some(s=>s.id===copy.id)||copy.id==='all')throw Error('Could not create a unique ID for the imported copy.');copy.name=copy.name.slice(0,89)+' (imported)';}
   additions.push(copy);known.push(copy);
  }
  return {sets:[...structuredClone(existing),...additions],additions,skipped};
 }
};
if(typeof module!=='undefined')module.exports=AccountSetLibrary;
