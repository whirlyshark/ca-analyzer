function scaledBaseline() {
  const base=structuredClone(labPack.baseline), size=Number($('#lab-size').value);
  const originals=base.identities;
  const mapping=new Map(originals.map(u=>[u.id,[]]));
  base.identities=[];accountDirectory=new Map();const records=new Map(labPack.directory.map(r=>[r.id,r]));
  for(let i=0;i<size;i++){
    const original=originals[i%originals.length], copy=Math.floor(i/originals.length);
    const id=copy?`${original.id}-copy-${copy+1}`:original.id;
    base.identities.push({...original,id});accountDirectory.set(id,{...records.get(original.id),id});mapping.get(original.id).push(id);
  }
  for(const entry of [...base.policies,...base.requirements]){
    for(const key of ['includeUsers','excludeUsers'])if(entry[key])entry[key]=entry[key].flatMap(id=>id==='*'?['*']:(mapping.get(id)||[]));
  }
  return base;
}
async function initLab() {
  labPack=await api('/api/lab');
  $('#scenario').innerHTML='<option value="baseline">Architecture lab · Clean baseline</option>'+labPack.faults.map(f=>`<option value="${esc(f.id)}">Introduce gap: ${esc(f.name)}</option>`).join('')+'<option value="small">Simple three-account example</option>';
  // This last example deliberately makes no gap: overlapping policies still enforce MFA.
  const covered=$('#scenario').querySelector('option[value="covered"]');covered.textContent='Coverage test: remove redundant CRM policy';
  $('#scenario').onchange=()=>loadLab(true).catch(error);
  $('#lab-size').onchange=()=>loadLab(true).catch(error);
  await loadLab(false);
}
async function loadLab(assess) {
  if(busy)return;
  if($('#scenario').value==='small'){await example();return;}
  clearError();activeLab=true;isExample=true;
  selectedFault=labPack.faults.find(f=>f.id===$('#scenario').value)||null;
  model=scaledBaseline();
  if(selectedFault){
    const policy=model.policies.find(p=>p.id===selectedFault.policyId);
    let target=policy;
    for(const key of selectedFault.path.slice(0,-1))target=target[key];
    target[selectedFault.path.at(-1)]=structuredClone(selectedFault.value);
  }
  sourceName=selectedFault?selectedFault.name:'Architecture lab · Clean baseline';
  counts();resetResult();
  $('#lab-catalog').hidden=false;$('#lab-size-label').hidden=false;
  $('#lab-change').hidden=!selectedFault;
  if(selectedFault)$('#lab-change').innerHTML=`<strong>${esc(friendlyPolicy(selectedFault.policyId))}</strong><div class="change-line"><span>Before: ${esc(selectedFault.before)}</span><span>→</span><span>After: ${esc(selectedFault.after)}</span></div><button class="text-button" id="restore-baseline">Restore clean baseline ↶</button>`;
  if(selectedFault)$('#restore-baseline').onclick=()=>{if(busy)return;$('#scenario').value='baseline';loadLab(true).catch(error);};
  $('#policy-catalog').innerHTML='<div class="catalog-table">'+model.policies.map(p=>`<div><span>${esc(p.id)} · ${esc(p.state)}</span><strong>${esc(friendlyPolicy(p.id))}</strong><small>${labPack.policyMetadata[p.id].sources.map(id=>{const source=labPack.sources.find(s=>s.id===id);return `<a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">${esc(source.name)}</a>`;}).join(' · ')}</small></div>`).join('')+'</div><p class="hint">Original lab adaptations, not copied deployments or endorsements. Custom apps and explicit policy groups are lab choices. Sources describe patterns; this model represents only their supported parts.</p>';
  if(assess)await run();
}
function showPerformance() {
  $('#lab-performance').hidden=!result;
  if(!result)return;
  let combinations=BigInt(model.identities.length);
  for(const values of Object.values(model.dimensions))combinations*=BigInt(values.length);
  const baseline=result.comparison;
  $('#lab-performance').innerHTML=`<div><span>Clean baseline</span><strong>${baseline?baseline.baselineStatus==='completeWithinModel'?`${baseline.baselineGapRegions} gaps`:'Incomplete':'—'}</strong></div><div><span>This run</span><strong>${result.gaps.length} gap ${result.gaps.length===1?'region':'regions'}</strong></div><div><span>Engine / analysis call</span><strong>${result.elapsedMilliseconds.toLocaleString()} / ${(result.analysisMilliseconds??result.elapsedMilliseconds).toLocaleString()} ms</strong></div><div><span>Distinct policy profiles</span><strong>${result.identityProfileCount.toLocaleString()} of ${result.identityCount.toLocaleString()} accounts</strong></div><details><summary>Timing & scope</summary><p>${combinations.toLocaleString()} represented combinations, not individual sign-in executions. ${result.regionSubtractionCount.toLocaleString()} set-subtraction operations. Grouping uses actual targeting and requirements, never account tags. Analysis-call timing includes parsing and validation; it excludes browser transfer and first-start compilation.</p><p>${esc(activeLab?labPack.scope:result.limitation)}</p></details>`;
}
