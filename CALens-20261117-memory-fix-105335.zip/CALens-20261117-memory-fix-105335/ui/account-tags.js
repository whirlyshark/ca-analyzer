'use strict';
// Explicit user rules only. This module never changes userType or policy targeting.
const AccountTags = {
  fields:['displayName','userPrincipalName','jobTitle','userType'],
  operators:['startsWith','equals','hasValue'],
  validate(rules) {
    if(!Array.isArray(rules)||rules.length>50)throw new Error('Use at most 50 tag rules.');
    for(const rule of rules){
      if(!rule||typeof rule.enabled!=='boolean'||typeof rule.tag!=='string'||!rule.tag.trim()||rule.tag.length>40||!this.fields.includes(rule.field)||!this.operators.includes(rule.operator)||typeof rule.value!=='string'||rule.value.length>200||(rule.operator!=='hasValue'&&!rule.value.trim()))throw new Error('Each rule needs a tag, field and matching condition.');
    }
    return rules;
  },
  classify(record,rules) {
    this.validate(rules);
    if(!record)return [];
    const matches=[];
    for(const rule of rules){
      if(!rule.enabled)continue;
      const value=String(record[rule.field]??'').trim().toLowerCase(), expected=rule.value.trim().toLowerCase();
      if(rule.operator==='hasValue'?!!value:rule.operator==='equals'?value===expected:value.startsWith(expected))matches.push(rule.tag.trim());
    }
    return [...new Set(matches)];
  }
};
if(typeof module!=='undefined')module.exports=AccountTags;
