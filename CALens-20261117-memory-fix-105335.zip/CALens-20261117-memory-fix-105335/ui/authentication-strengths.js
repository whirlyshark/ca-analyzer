'use strict';
const AuthenticationStrengths={
 // Graph's documented combinations. An imported built-in row must not redefine
 // which known combinations establish phishing-resistant MFA.
 phishing:['fido2','windowsHelloForBusiness','x509CertificateMultiFactor'],
 multifactor:['fido2','windowsHelloForBusiness','x509CertificateMultiFactor','deviceBasedPush','temporaryAccessPassOneTime','temporaryAccessPassMultiUse','password,microsoftAuthenticatorPush','password,softwareOath','password,hardwareOath','password,sms','password,voice','federatedMultiFactor','federatedSingleFactor,microsoftAuthenticatorPush','federatedSingleFactor,softwareOath','federatedSingleFactor,hardwareOath','federatedSingleFactor,sms','federatedSingleFactor,voice'],
 singleFactor:['password','sms','email','federatedSingleFactor','x509CertificateSingleFactor'],
 canonical(value){
  if(typeof value!=='string')throw Error('Authentication-strength combinations must be strings.');
  const parts=value.split(',').map(p=>p.trim().toLowerCase());
  if(parts.some(p=>!p))throw Error('Authentication-strength combination is malformed.');
  return [...new Set(parts)].sort().join(',');
 },
 combinations(values){
  if(!Array.isArray(values)||!values.length)throw Error('Export the complete authentication-strength definition and its allowed combinations.');
  const result=values.map(v=>this.canonical(v));
  return [...new Set(result)].sort();
 },
 prepare(definitions){
  const rows=new Map(),duplicates=new Set();let malformed=false;
  if(definitions!==undefined&&definitions!==null&&!Array.isArray(definitions))malformed=true;
  for(const row of Array.isArray(definitions)?definitions:[]){
   if(!row||typeof row!=='object'||typeof row.id!=='string'||!row.id){malformed=true;continue;}
   if(rows.has(row.id))duplicates.add(row.id);else rows.set(row.id,row);
  }
  const phishing=new Set(this.phishing.map(v=>this.canonical(v))),mfa=new Set(this.multifactor.map(v=>this.canonical(v))),single=new Set(this.singleFactor.map(v=>this.canonical(v)));
  const builtIns=new Map([['00000000-0000-0000-0000-000000000002','mfa'],['00000000-0000-0000-0000-000000000003','mfa'],['00000000-0000-0000-0000-000000000004','phishingResistant']]);
  const evidence=row=>Object.fromEntries(['id','policyType','requirementsSatisfied','allowedCombinations','combinationConfigurations'].filter(key=>row&&Object.hasOwn(row,key)).map(key=>[key,row[key]]));
  return {evidence:reference=>({reference:evidence(reference),definitions:(Array.isArray(definitions)?definitions:[]).filter(row=>row?.id===reference.id).map(evidence)}),minimum:reference=>{
   if(!reference||typeof reference!=='object'||Array.isArray(reference)||typeof reference.id!=='string'||!reference.id)throw Error('Authentication strength needs a valid identifier.');
   if(malformed)throw Error('Authentication-strength definitions are malformed. Export a consistent snapshot.');
   if(duplicates.has(reference.id))throw Error('Duplicate authentication-strength definitions cannot establish coverage.');
   const row=rows.get(reference.id),builtin=builtIns.get(reference.id),merged={...reference,...row};
   for(const field of ['policyType','requirementsSatisfied','allowedCombinations']){
    const a=reference[field],b=row?.[field];if(a===undefined||a===null||b===undefined||b===null)continue;
    const canonical=value=>field==='allowedCombinations'?JSON.stringify(this.combinations(value)):value;
    if(canonical(a)!==canonical(b))throw Error('Inline and exported authentication-strength definitions conflict. Collect a fresh snapshot.');
   }
   for(const field of ['policyType','requirementsSatisfied','allowedCombinations'])if((merged[field]===undefined||merged[field]===null)&&reference[field]!==undefined)merged[field]=reference[field];
   if(merged.policyType!==undefined&&merged.policyType!==null&&(!['builtIn','custom'].includes(merged.policyType)||builtin&&merged.policyType!=='builtIn'))throw Error('Authentication-strength policy type is inconsistent with its identifier.');
   const claim=merged.requirementsSatisfied;
   if((claim!==undefined&&claim!==null&&!['none','mfa'].includes(claim))||(builtin&&claim!==undefined&&claim!==null&&claim!=='mfa'))throw Error('Authentication-strength MFA claim metadata is missing or inconsistent.');
   let combinations;
   if(merged.allowedCombinations!==undefined&&merged.allowedCombinations!==null)combinations=this.combinations(merged.allowedCombinations);
   if(!combinations){if(builtin)return builtin==='phishingResistant'?['phishingResistant']:['mfa','phishingResistant'];throw Error('Export the complete authentication-strength definition and its allowed combinations.');}
   if(combinations.some(v=>!mfa.has(v)&&!single.has(v)))throw Error('Authentication strength contains an unsupported authentication-method combination.');
   const allMfa=combinations.every(v=>mfa.has(v)),allPhishing=combinations.every(v=>phishing.has(v));
   if((claim==='mfa'&&!allMfa)||(claim==='none'&&allMfa)||(builtin&&(!allMfa||builtin==='phishingResistant'&&!allPhishing)))throw Error('Authentication-strength combinations and MFA claim metadata are inconsistent.');
   if(builtin)return builtin==='phishingResistant'?['phishingResistant']:['mfa','phishingResistant'];
   if(claim==='mfa')return allPhishing?['phishingResistant']:['mfa','phishingResistant'];
   if(claim==='none')return ['password','mfa','phishingResistant'];
   throw Error('Authentication-strength MFA claim metadata is missing or inconsistent.');
  }};
 }
};
if(typeof module!=='undefined')module.exports=AuthenticationStrengths;
