'use strict';
const CollectionProgress={
 timer:null,started:0,last:null,
 duration(ms){const seconds=Math.max(0,Math.floor(ms/1000));return seconds<60?seconds+'s':Math.floor(seconds/60)+'m '+seconds%60+'s';},
 start(){
  this.stop();this.started=Date.now();document.querySelector('#collection-progress').hidden=false;this.render();this.timer=setInterval(()=>this.render(),250);
 },
 update(progress){
  if(!this.timer)this.start();
  if(progress){this.last=progress;const started=Date.parse(progress.startedAtUtc);if(Number.isFinite(started))this.started=started;}
  this.render();
 },
 render(){
  const node=id=>document.querySelector('#collection-progress-'+id),p=this.last,now=Date.now(),bar=node('bar');
  node('title').textContent=p?'Reading '+p.collection+'…':'Connecting to Microsoft Graph…';
  node('elapsed').textContent='Elapsed '+this.duration(now-this.started);
  const total=Number(p?.batchTotal)||0,completed=Math.max(0,Math.min(total,Number(p?.batchCompleted)||0));
  if(total){bar.max=total;bar.value=completed;bar.setAttribute('aria-label',p.batchLabel);node('detail').textContent=`${p.batchLabel}: ${completed.toLocaleString()} of ${total.toLocaleString()}`;}
  else{bar.removeAttribute('value');bar.max=1;bar.setAttribute('aria-label','Reading '+(p?.collection||'tenant data'));node('detail').textContent=p?`${Number(p.currentRecords||0).toLocaleString()} records received · ${Number(p.currentPages||0).toLocaleString()} pages for this read`:'Waiting for the first response';}
  const since=p?.lastResponseAtUtc?Date.parse(p.lastResponseAtUtc):NaN;
  node('meta').textContent=p?`${Number(p.pagesRead||0).toLocaleString()} pages read in total${Number.isFinite(since)?' · Last response '+this.duration(now-since)+' ago':''}${p.incompleteReads?' · '+Number(p.incompleteReads).toLocaleString()+' incomplete reads':''}`:'Large directories can take several minutes.';
  const retryUntil=p?.retrySeconds?Date.parse(p.updatedAtUtc)+Number(p.retrySeconds)*1000:0;
  node('message').textContent=p?.retrySeconds?(retryUntil>now?`Microsoft asked us to wait. Retrying in ${Math.ceil((retryUntil-now)/1000)}s…`:'Retrying the read…'):p?.message||((Number.isFinite(since)&&now-since>15000)?'Waiting for Microsoft to respond. Collection is still running.':'The time remaining depends on directory size and Microsoft’s response speed.');
 },
 stop(){if(this.timer!==null)clearInterval(this.timer);this.timer=null;this.last=null;const panel=document.querySelector('#collection-progress');if(panel)panel.hidden=true;}
};
if(typeof module!=='undefined')module.exports=CollectionProgress;
