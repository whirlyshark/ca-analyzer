'use strict';
const ExternalUsers={
 types:['none','internalGuest','b2bCollaborationGuest','b2bCollaborationMember','b2bDirectConnectUser','otherExternalUser','serviceProvider'],
 labels:{none:'No external category',internalGuest:'Local Guest',b2bCollaborationGuest:'B2B collaboration Guest',b2bCollaborationMember:'B2B collaboration Member',b2bDirectConnectUser:'B2B direct connect',otherExternalUser:'Other external user',serviceProvider:'Service provider'},
 categorySet(value){
  if(typeof value!=='string')throw Error('Unrecognized exported external-user category.');const parts=[...new Set(value.split(',').map(v=>v.trim()))];
  if(!parts.length||parts.some(v=>!this.types.includes(v))||parts.includes('none')&&parts.length!==1)throw Error('Unrecognized exported external-user category.');
  return this.types.filter(v=>v!=='none'&&parts.includes(v));
 },
 categoryValues(){const flags=this.types.slice(1);return Array.from({length:2**flags.length},(_,mask)=>flags.filter((_,i)=>mask&(1<<i)).join(',')||'none');},
 valueLabels(){return Object.fromEntries(this.categoryValues().map(value=>[value,value==='none'?this.labels.none:this.categorySet(value).map(t=>this.labels[t]).join(' + ')]));},
 selector(value){
  if(!value||typeof value!=='object')throw Error('External-user selection is missing.');
  for(const key of Object.keys(value))if(!key.startsWith('@')&&!['guestOrExternalUserTypes','externalTenants'].includes(key))throw Error('Unsupported external-user selection: '+key);
  const types=typeof value.guestOrExternalUserTypes==='string'?value.guestOrExternalUserTypes.split(',').map(t=>t.trim()):[];
  if(!types.length||types.some(t=>!this.types.includes(t))||types.includes('none')&&types.length!==1)throw Error('Unrecognized external-user categories.');
  const tenants=value.externalTenants;
  if(types.length===1&&types[0]==='none'&&!tenants)return {types:[],tenants:null};
  if(!tenants||!['all','enumerated'].includes(tenants.membershipKind))throw Error('Choose all or enumerated external tenants.');
  for(const key of Object.keys(tenants))if(!key.startsWith('@')&&!['membershipKind','members'].includes(key))throw Error('Unsupported external-tenant selection: '+key);
  if(tenants.membershipKind==='enumerated'&&(!Array.isArray(tenants.members)||!tenants.members.length||tenants.members.some(id=>!this.guid(id))))throw Error('Enumerated external tenants require tenant GUIDs.');
  if(tenants.membershipKind==='all'&&tenants.members?.length)throw Error('All external tenants cannot also contain an enumerated list.');
  return {types:types.filter(t=>t!=='none'),tenants:tenants.membershipKind==='all'?null:tenants.members.map(id=>id.toLowerCase())};
 },
 guid(value){return typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value);},
 conditions(selection){
  if(!selection.types.length)return [];
  const values=this.categoryValues(),matches=value=>this.categorySet(value).some(t=>selection.types.includes(t));
  if(selection.tenants===null)return [{externalUserType:{include:values.filter(matches)}}];
  const clauses=[],local=value=>selection.types.includes('internalGuest')&&this.categorySet(value).includes('internalGuest');
  const localValues=values.filter(local),externalValues=values.filter(v=>matches(v)&&!local(v));
  if(localValues.length)clauses.push({externalUserType:{include:localValues}});
  if(externalValues.length)clauses.push({externalUserType:{include:externalValues},externalTenantId:{include:selection.tenants}});
  return clauses;
 },
 prepare(policies,records){
  const selectors=new Map(),errors=new Map(),tenants=new Set(['other-external-tenant']);let enabled=false;
  for(const p of policies.filter(p=>p.state==='enabled')){
   const entry={};for(const prefix of ['include','exclude'])if(p.conditions?.users?.[prefix+'GuestsOrExternalUsers']!==undefined&&p.conditions?.users?.[prefix+'GuestsOrExternalUsers']!==null){
    enabled=true;try{entry[prefix]=this.selector(p.conditions.users[prefix+'GuestsOrExternalUsers']);for(const id of entry[prefix].tenants||[])tenants.add(id);}catch(e){errors.set(p.id,e.message);}
   }selectors.set(p.id,entry);
  }
  const dimensions=enabled?{externalUserType:this.categoryValues(),externalTenantId:[...tenants]}:{};
  const identityConditions=record=>{
   if(!enabled)return {};const result={};
   if(record.externalUserType!==undefined&&record.externalUserType!==null)result.externalUserType={include:[this.categorySet(record.externalUserType).join(',')||'none']};
   if(record.externalTenantId){
    if(this.guid(record.externalTenantId)){const id=record.externalTenantId.toLowerCase();result.externalTenantId={include:[tenants.has(id)?id:'other-external-tenant']};}
    else if(record.externalUserType===undefined||!this.categorySet(record.externalUserType).every(t=>t==='internalGuest'))throw Error('Exported external tenant is not a GUID.');
   }
   return result;
  };
  return {dimensions,selectors,errors,identityConditions};
 },
 matches(record,selection,tenantId){
  if(!selection.types.length)return false;
  if(record.externalUserType===undefined||record.externalUserType===null)return null;
  const actual=this.categorySet(record.externalUserType);
  if(!actual.some(t=>selection.types.includes(t)))return false;
  // Verified in the lab: external tenant enumeration does not narrow local
  // internal guests. The category selection itself controls these accounts.
  if(actual.includes('internalGuest')&&selection.types.includes('internalGuest'))return true;
  if(selection.tenants===null)return true;
  const home=record.externalTenantId||(record.externalUserType==='internalGuest'?tenantId:null);
  if(!home)return null;if(!this.guid(home))throw Error('Exported external tenant is not a GUID.');
  return selection.tenants.includes(home.toLowerCase());
 },
 // The legacy reserved Users value uses directory UserType, unlike the modern
 // external category selector. Explicit What If category overrides do not alter it.
 legacy(record){return record.userType==='Guest'?true:record.userType==='Member'?false:null;}
};
if(typeof module!=='undefined')module.exports=ExternalUsers;
