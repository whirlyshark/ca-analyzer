'use strict';
// Review organisational restrictions only. No policies, scores or saved data are changed.
const ReviewRequirements=typeof module!=='undefined'&&module.exports?require('./requirement-model.js'):RequirementModel;
const ReviewSnapshot=typeof module!=='undefined'&&module.exports?require('./snapshot.js'):SnapshotModel;
const RequirementReview={
 check(profile,source,{maxMilliseconds=1500,maxRegions=5000,maxFindings=30}={}){
  const started=Date.now(),rules=(profile.requirements||[]).filter(r=>r.enabled!==false&&!r.pendingSetup?.length),findings=new Map();
  const candidates=rules.filter(r=>r.outcome!=='block'&&!(r.protections||[]).includes('block')&&(r.blockOtherApps||r.networkMode==='must'||r.deviceFilter?.mode==='must'));
  if(!candidates.length)return {status:'complete',findings:[]};
  let operations=0;
  try{
   const compiled=ReviewRequirements.compile({...profile,requirements:rules},source),model=compiled.model,dimensions=model.dimensions;
   const partition=ReviewSnapshot.regions(dimensions,{maxRegions,deadline:started+maxMilliseconds}),universe=partition.from({}),resolved=ReviewRequirements.resolve(profile.sets,compiled.source.records).resolved;
   const check=items=>{if(++operations>100000)throw Error('Review budget reached.');return partition.check(items);};
   const intersect=(left,right)=>{const out=[];for(const a of left)for(const b of right){check(out);const hit=partition.intersect(a,b);if(hit)out.push(hit);}return check(out);};
   const union=rectangles=>{let out=[];for(const rectangle of rectangles){if(!rectangle)continue;let pieces=[rectangle];for(const old of out)pieces=partition.minus(pieces,old);out.push(...pieces);check(out);}return out;};
   const constrain=(regions,groups)=>{for(const clauses of groups||[])regions=intersect(regions,union(clauses.map(c=>partition.from(c))));return regions;};
   const query=rule=>{
    if(!rule)return [];
    const base=partition.from(rule.conditions||{});if(!base)return [];
    return rule.conditionAlternatives==null?[base]:intersect([base],union(rule.conditionAlternatives.map(c=>partition.from(c))));
   };
   const project=(regions,remove)=>union(regions.map(region=>Object.fromEntries(Object.keys(dimensions).map(axis=>[axis,remove(axis)?dimensions[axis]:region[axis]]))));
   const deviceAxis=axis=>axis.startsWith('device.')||['compliant','hybridJoined'].includes(axis);
   const appAxis=axis=>axis==='application'||axis==='directoryScopeEnforcement'||axis.startsWith('resourceGroup.');
   const validUniverse=constrain([universe],model.scenarioConstraints),scope=new Map(candidates.map(r=>[r.id,ReviewRequirements.scope(r,resolved)]));
   const confirmed=new Map([...scope].map(([id,s])=>[id,new Set(s.confirmed)]));
   const addFinding=(kind,subset,group)=>{
    const ids=subset.map(r=>r.id).sort(),key=kind+':'+JSON.stringify(ids);
    if(!findings.has(key)){
     if(findings.size>=maxFindings)throw Error('Review result limit reached.');
     findings.set(key,{kind,requirementIds:ids,confirmed:new Set(),possible:new Set()});
    }
    const finding=findings.get(key);
    for(const id of group.ids){const known=ids.every(ruleId=>confirmed.get(ruleId).has(id));(known?finding.confirmed:finding.possible).add(id);}
   };
   for(const kind of ['apps','networks','devices']){
    const selected=candidates.filter(r=>kind==='apps'?r.blockOtherApps:kind==='networks'?r.networkMode==='must':r.deviceFilter?.mode==='must');
    if(!selected.length)continue;
    const categoryAxis=kind==='apps'?appAxis:kind==='networks'?axis=>axis==='network':deviceAxis;
    const suffix={apps:':outside-apps',networks:':outside-network',devices:':outside-device'}[kind];
    const prepared=selected.map(r=>{
     const base=model.requirements.find(item=>item.id===r.id),outside=model.requirements.find(item=>item.id===r.id+suffix);
     if(!base||!outside)throw Error('Some enabled restrictions need more setup or exported information before their overlap can be checked.');
     // Outside-app/network guards deliberately do not depend on other MUST-device
     // selections. App allowlists also apply outside a MUST-network selection.
     const otherAxis=axis=>(kind!=='devices'&&r.deviceFilter?.mode==='must'&&deviceAxis(axis))||(kind==='apps'&&r.networkMode==='must'&&axis==='network');
     const allowed=project(query(base),otherAxis);
     const guard=project([...query(base),...query(outside)],axis=>categoryAxis(axis)||otherAxis(axis));
     return {id:r.id,allowed,guard,targets:new Set([...scope.get(r.id).include,...scope.get(r.id).unknown])};
    });
    const groups=new Map();
    for(const identity of model.identities||[]){
     const included=prepared.map(r=>r.targets.has(identity.id));if(!included.some(Boolean))continue;
     const key=JSON.stringify([included,identity.conditions||{},identity.scenarioConstraints||[]]);
     if(!groups.has(key))groups.set(key,{identity,ids:[],rules:prepared.filter((r,i)=>included[i])});groups.get(key).ids.push(identity.id);check([]);
    }
    for(const group of groups.values()){
     const identityRegion=partition.from(group.identity.conditions||{});
     const valid=constrain(intersect(validUniverse,identityRegion?[identityRegion]:[]),group.identity.scenarioConstraints);
     let cells=valid.map(region=>({region,active:[]}));
     for(const rule of group.rules){
      const next=[];
      for(const cell of cells){
       for(const hit of intersect([cell.region],rule.guard))next.push({region:hit,active:[...cell.active,rule]});
       let rest=[cell.region];for(const cut of rule.guard)rest=partition.minus(rest,cut);
       next.push(...rest.map(region=>({region,active:cell.active})));check(next);
      }
      cells=next;
     }
     for(const cell of cells){
      if(cell.active.length<2)continue;
      // Feasibility partitions may fix a resource/device helper axis. Re-open
      // the category being compared, then re-apply feasibility to avoid treating
      // an unrelated resource-specific partition as an empty allowlist.
      const domain=constrain(intersect(project([cell.region],categoryAxis),validUniverse),group.identity.scenarioConstraints);
      const common=subset=>{let remaining=domain;for(const rule of subset){remaining=intersect(remaining,rule.allowed);if(!remaining.length)break;}return remaining;};
      if(common(cell.active).length||cell.active.some(rule=>!common([rule]).length))continue;
      // Find a small explanatory set, including clashes involving 3+ rules.
      let subset=[...cell.active];
      for(const rule of [...subset]){if(subset.length===1)break;const reduced=subset.filter(r=>r!==rule);if(!common(reduced).length)subset=reduced;}
      addFinding(kind,subset,group);
     }
    }
   }
   return this.result('complete',findings);
  }catch(error){return this.result('incomplete',findings,'Some overlaps could not be checked. '+error.message);}
 },
 result(status,findings,message){
  return {status,findings:[...findings.values()].map(f=>({kind:f.kind,requirementIds:f.requirementIds,accountIds:[...f.confirmed,...f.possible],confirmedAccountIds:[...f.confirmed],possibleAccountIds:[...f.possible]})),...(message?{message}:{})};
 }
};
if(typeof module!=='undefined')module.exports=RequirementReview;
