'use strict';
const PimScheduleTime=typeof module!=='undefined'&&module.exports?require('./role-schedules.js'):RoleSchedules;
// Settled directory membership states. PIM activation requirements, token claim
// propagation and eligibility inherited through changing groups need separate
// runtime validation; they must never be inferred from current transitive members.
const PimGroups={
 prepare(snapshot,records,{groupIds=[],roleIds=[],fixedRoleAssignments=new Set(),roleUnknownById=new Map(),roleUnknownGroupsById=new Map(),roleUnboundedGroupsById=new Map()}={}){
  const groups=snapshot?.groups||[],ids=new Set(groups.map(g=>g.id)),people=new Set(records.map(u=>u.id)),roles=new Map((snapshot?.roles||[]).map(r=>[r.id,r]));
  const assignmentRows=snapshot?.roleAssignments||[],eligibleRoles=snapshot?.roleEligibility||[],eligibility=snapshot?.pimGroupEligibility,assignments=snapshot?.pimGroupAssignments;
  const roleId=a=>roles.get(a.roleDefinitionId)?.templateId||a.roleDefinitionId;
  const root=a=>a.directoryScopeId==='/'&&(a.appScopeId==null||a.appScopeId==='')&&roles.get(a.roleDefinitionId)?.isBuiltIn===true&&typeof roles.get(a.roleDefinitionId)?.templateId==='string'&&!!roles.get(a.roleDefinitionId).templateId.trim();
  const activeByRole=new Map(roleIds.map(id=>[id,[]])),eligibleByRole=new Map(roleIds.map(id=>[id,[]]));
  const activeByPerson=new Map(roleIds.map(id=>[id,new Map()])),eligiblePeople=new Map(roleIds.map(id=>[id,new Set()]));
  for(const row of assignmentRows)if(root(row)&&activeByRole.has(roleId(row))){const role=roleId(row);activeByRole.get(role).push(row);if(people.has(row.principalId)){const indexed=activeByPerson.get(role);if(!indexed.has(row.principalId))indexed.set(row.principalId,[]);indexed.get(row.principalId).push(row);}}
  for(const row of eligibleRoles)if(root(row)&&eligibleByRole.has(roleId(row))){eligibleByRole.get(roleId(row)).push(row);if(people.has(row.principalId))eligiblePeople.get(roleId(row)).add(row.principalId);}
  const activeGroupRoles=new Map(roleIds.map(role=>[role,activeByRole.get(role).filter(row=>ids.has(row.principalId))]));
  const eligibleGroupRoles=new Map(roleIds.map(role=>[role,eligibleByRole.get(role).filter(row=>ids.has(row.principalId))]));
  const roleGroups=[...assignmentRows,...eligibleRoles].filter(a=>ids.has(a.principalId)&&roleIds.includes(roleId(a))&&root(a));
  const needed=new Set([...groupIds.filter(id=>ids.has(id)),...roleGroups.map(a=>a.principalId),...[...roleUnknownGroupsById.values(),...roleUnboundedGroupsById.values()].flatMap(s=>[...s].filter(id=>ids.has(id)))]),dimensions={},bounds=new Map(),constraints=new Map(),uncertain=new Set();
  const current=snapshot?.groupMembers||{},direct=snapshot?.groupDirectMembers||{};
  const directFor=id=>Array.isArray(direct[id])?direct[id]:[];
  const directSets=new Map(groups.map(g=>[g.id,new Set(directFor(g.id))]));
  const problems=new Set(),invalid=new Set(),reasons=new Map(groups.map(g=>[g.id,new Set()]));
  const invalidate=(message,id)=>{problems.add(message);for(const groupId of ids.has(id)?[id]:ids){invalid.add(groupId);reasons.get(groupId).add(message);}};
  // A failed read for one group does not erase a completed independent read.
  // Explicit per-group flags take precedence over aggregate flags.
  const collected=(key,id)=>{const specific=key+':'+id;return Object.hasOwn(snapshot?.completeness||{},specific)?snapshot.completeness[specific]===true:snapshot?.completeness?.[key]===true;};
  for(const g of groups){
   if(!Array.isArray(eligibility)||!Array.isArray(assignments)||!['pimGroupEligibility','pimGroupAssignments','groupDirectMembers'].every(k=>collected(k,g.id))||!Array.isArray(direct[g.id]))invalidate('Export complete PIM group eligibility, assignments and direct memberships with IncludePimGroups.',g.id);
   if(directFor(g.id).some(id=>typeof id!=='string'))invalidate('Direct group membership contains malformed IDs. Export the snapshot again.',g.id);
  }
  const instant=value=>PimScheduleTime.instant(value);
  const captured=instant(snapshot?.capturedAtUtc);
  const validRow=r=>r&&ids.has(r.groupId)&&(people.has(r.principalId)||ids.has(r.principalId))&&['member','owner'].includes(r.accessId);
  const activeAtCapture=r=>{
   // No wall clock: offline results must be reproducible from the export.
   if(captured===null||instant(r.startDateTime)===null||!Object.hasOwn(r,'endDateTime')||r.endDateTime!==null&&(instant(r.endDateTime)===null||instant(r.endDateTime)<=instant(r.startDateTime))){invalidate('PIM schedules need valid start/end dates and a snapshot capture time. Export the snapshot again.',r.groupId);return true;}
   return instant(r.startDateTime)<=captured&&(r.endDateTime===null||captured<instant(r.endDateTime));
  };
  if(!Array.isArray(eligibility)||!Array.isArray(assignments))invalidate('PIM group schedule collections are malformed.');
  for(const r of Array.isArray(eligibility)?eligibility:[])if(!validRow(r))invalidate('PIM group schedules contain unresolved principals or unsupported access types.',r?.groupId);
  for(const r of Array.isArray(assignments)?assignments:[])if(!validRow(r)||!['assigned','activated'].includes(r.assignmentType))invalidate('PIM group schedules contain unresolved principals or unsupported assignment types.',r?.groupId);
  const eligible=(Array.isArray(eligibility)?eligibility:[]).filter(r=>validRow(r)&&r.accessId==='member'&&activeAtCapture(r));
  const active=(Array.isArray(assignments)?assignments:[]).filter(r=>validRow(r)&&r.accessId==='member'&&activeAtCapture(r));
  const activatedByGroup=new Map(groups.map(g=>[g.id,new Set()])),assignedByGroup=new Map(groups.map(g=>[g.id,new Set()])),activeByGroup=new Map(groups.map(g=>[g.id,new Set()]));
  for(const r of active){activeByGroup.get(r.groupId).add(r.principalId);(r.assignmentType==='activated'?activatedByGroup:assignedByGroup).get(r.groupId).add(r.principalId);}
  for(const r of active)if(!directSets.get(r.groupId).has(r.principalId))invalidate('PIM schedules and current group memberships disagree. Collect a fresh snapshot.',r.groupId);
  for(const r of Array.isArray(assignments)?assignments:[])if(validRow(r)&&r.accessId==='member'&&directSets.get(r.groupId).has(r.principalId)&&!activeByGroup.get(r.groupId).has(r.principalId))invalidate('An inactive PIM assignment still appears in group membership. Collect a fresh snapshot.',r.groupId);
  const inheritedByGroup=new Map(groups.map(g=>[g.id,[]]));for(const e of eligible)if(ids.has(e.principalId))inheritedByGroup.get(e.groupId).push(e.principalId);
  const eligibleUsersByGroup=new Map(groups.map(g=>[g.id,new Set()]));for(const e of eligible)if(people.has(e.principalId))eligibleUsersByGroup.get(e.groupId).add(e.principalId);
  const children=new Map(groups.map(g=>[g.id,directFor(g.id).filter(id=>ids.has(id))]));
  const ownFixed=new Map(groups.map(g=>[g.id,new Set(directFor(g.id).filter(id=>people.has(id)&&(!activatedByGroup.get(g.id).has(id)||assignedByGroup.get(g.id).has(id))))]));
  const fixed=new Map([...ownFixed].map(([g,s])=>[g,new Set(s)])),possible=new Map(groups.map(g=>[g.id,new Set(current[g.id]||[])]));
  const activation=new Map(groups.map(g=>[g.id,new Set([...activatedByGroup.get(g.id)].filter(id=>people.has(id)))]));
  let steps=0;const deadline=Date.now()+5000,check=()=>{if(++steps>2000000||Date.now()>deadline)throw Error('PIM group relationship expansion exceeded its budget.');};
  const expand=(map,withEligibility)=>{let changed=true;while(changed){changed=false;for(const g of groups){check();const target=map.get(g.id);for(const child of children.get(g.id))for(const id of map.get(child)){if(!target.has(id)){target.add(id);changed=true;}}}if(withEligibility)for(const e of eligible){check();for(const id of people.has(e.principalId)?[e.principalId]:map.get(e.principalId)||[]){activation.get(e.groupId).add(id);if(!map.get(e.groupId).has(id)){map.get(e.groupId).add(id);changed=true;}}}}};
  // Reject nesting cycles: Boolean fixed-point equations alone would otherwise
  // admit self-supporting memberships with no user edge or activation.
  const visiting=new Set(),visited=new Set();const visit=id=>{check();if(visiting.has(id))throw Error('Group nesting contains a cycle.');if(visited.has(id))return;visiting.add(id);try{for(const child of children.get(id)||[])visit(child);}finally{visiting.delete(id);}visited.add(id);};
  try{
   for(const g of groups)try{visit(g.id);}catch(e){invalidate(e.message,g.id);}
   expand(fixed,false);expand(possible,true);
   // Direct membership and transitive membership are separate Graph collections.
   // A disagreement cannot establish permanent or temporary membership.
   for(const g of groups){const observed=new Set(current[g.id]||[]),derived=new Set(directFor(g.id).filter(id=>people.has(id)));for(const child of children.get(g.id))for(const id of current[child]||[])derived.add(id);if(observed.size!==derived.size||[...observed].some(id=>!derived.has(id)))invalidate('Direct and transitive group memberships disagree. Collect a fresh snapshot.',g.id);}
  }catch(e){invalidate(e.message);}
  // Membership depends on nested members and on eligible principal groups.
  // Propagate missing/contradictory evidence only along those dependency edges.
  let propagated=true;while(propagated){propagated=false;for(const g of groups){const bad=[...children.get(g.id),...inheritedByGroup.get(g.id)].find(id=>invalid.has(id));if(bad&&!invalid.has(g.id)){invalidate('A source group has incomplete or contradictory PIM membership evidence.',g.id);propagated=true;}}}
  const completeFor=id=>ids.has(id)&&!invalid.has(id),complete=Array.isArray(eligibility)&&Array.isArray(assignments)&&groups.every(g=>completeFor(g.id));
  const addDescendants=id=>{if(!ids.has(id))return;for(const child of children.get(id)||[])if(!needed.has(child)){needed.add(child);addDescendants(child);}};[...needed].forEach(addDescendants);
  for(const id of needed)dimensions['groupMember.'+id]=['false','true'];
  const select=(axis,value)=>({[axis]:{include:[value?'true':'false']}});
  const relation=(axis,sources,optional=false,optionalSources=[])=>[optional?select(axis,true):null,...[...new Set([...sources,...optionalSources])].map(s=>({...select(axis,true),...select(s,true)})),{...select(axis,false),...Object.assign({},...sources.map(s=>select(s,false)))}].filter(Boolean);
  // Exact substitution avoids materializing an equality for every single-group
  // role. Twenty independent leaf groups stay twenty independent booleans.
  const roleAliases={};
  const unboundedRolePeople=new Map(roleIds.map(role=>[role,new Set(roleUnknownById.get(role)||[])]));
  for(const role of roleIds)for(const group of roleUnboundedGroupsById.get(role)||[])for(const id of completeFor(group)?possible.get(group)||[]:people)unboundedRolePeople.get(role).add(id);
  const unknownRolePeople=new Map(roleIds.map(role=>[role,new Set(unboundedRolePeople.get(role))]));
  for(const role of roleIds)for(const group of roleUnknownGroupsById.get(role)||[])for(const id of completeFor(group)?possible.get(group)||[]:people)unknownRolePeople.get(role).add(id);
  for(const role of roleIds){const activeGroups=activeGroupRoles.get(role),providers=[...new Set(activeGroups.map(a=>a.principalId))];if(!unknownRolePeople.get(role).size&&providers.length===1&&activeGroups.every(a=>fixedRoleAssignments.has(a))&&!activeByPerson.get(role).size&&!eligibleByRole.get(role).length)roleAliases[role]='groupMember.'+providers[0];}
  const uncertainByGroup=new Map(groups.map(g=>[g.id,new Set()])),uncertainByRole=new Map(roleIds.map(id=>[id,new Set()]));
  const markGroup=(group,id)=>{uncertain.add(id);uncertainByGroup.get(group).add(id);},markRole=(role,id)=>{uncertain.add(id);uncertainByRole.get(role).add(id);};
  for(const record of records){
   const b={},cs=[];bounds.set(record.id,b);constraints.set(record.id,cs);
   for(const id of needed){const axis='groupMember.'+id;if(!completeFor(id)){markGroup(id,record.id);continue;}
    if(fixed.get(id).has(record.id)){Object.assign(b,select(axis,true));continue;}
    if(!possible.get(id).has(record.id)){Object.assign(b,select(axis,false));continue;}
    const sources=(children.get(id)||[]).map(g=>'groupMember.'+g),optional=activation.get(id).has(record.id);
    if(!sources.length){if(!optional)Object.assign(b,select(axis,false));}else cs.push(relation(axis,sources,optional));
    if(!eligibleUsersByGroup.get(id).has(record.id)&&!inheritedByGroup.get(id).some(group=>fixed.get(group)?.has(record.id))&&inheritedByGroup.get(id).some(group=>possible.get(group)?.has(record.id)&&!fixed.get(group)?.has(record.id)))markGroup(id,record.id);
   }
   let changed=true;while(changed){changed=false;for(const id of needed){
    if(uncertainByGroup.get(id).has(record.id)||fixed.get(id).has(record.id)||!possible.get(id).has(record.id))continue;
    if([...children.get(id),...inheritedByGroup.get(id)].some(source=>uncertainByGroup.get(source)?.has(record.id))){markGroup(id,record.id);changed=true;}
   }}
   for(const role of roleIds){
    if(roleAliases[role]){if(uncertainByGroup.get(roleAliases[role].slice('groupMember.'.length))?.has(record.id))markRole(role,record.id);continue;}
    const userActive=activeByPerson.get(role).get(record.id)||[];
    const userEligible=eligiblePeople.get(role).has(record.id);
    const fixedDirect=userActive.some(a=>fixedRoleAssignments.has(a));
    const axis='roleActive.'+role;
    if(fixedDirect){Object.assign(b,select(axis,true));continue;}
    const activeGroups=activeGroupRoles.get(role);
    const eligibleGroups=eligibleGroupRoles.get(role);
    let optional=userEligible||userActive.length>0||unboundedRolePeople.get(role).has(record.id);
    const optionalSources=[...roleUnknownGroupsById.get(role)||[]].filter(group=>!completeFor(group)||possible.get(group)?.has(record.id)).map(group=>'groupMember.'+group);
    if(unknownRolePeople.get(role).has(record.id))markRole(role,record.id);
    for(const a of eligibleGroups)if(!completeFor(a.principalId)||possible.get(a.principalId)?.has(record.id)){optional=true;if(!completeFor(a.principalId)||!fixed.get(a.principalId)?.has(record.id))markRole(role,record.id);}
    const sources=activeGroups.filter(a=>fixedRoleAssignments.has(a)).map(a=>'groupMember.'+a.principalId);
    if(activeGroups.some(a=>!fixedRoleAssignments.has(a))){optional=true;markRole(role,record.id);}
    for(const a of activeGroups)if(uncertainByGroup.get(a.principalId)?.has(record.id))markRole(role,record.id);
    if(sources.length||optionalSources.length)cs.push(relation(axis,sources,optional,optionalSources));else if(!optional)Object.assign(b,select(axis,false));
   }
  }
  return {dimensions,roleAliases,complete,completeFor,invalid,reasons,reason:[...problems][0]||'',needed,possible,fixed,activation,uncertain,uncertainByGroup,uncertainByRole,identity:id=>({conditions:bounds.get(id)||{},scenarioConstraints:constraints.get(id)||[]})};
 }
};
if(typeof module!=='undefined')module.exports=PimGroups;
