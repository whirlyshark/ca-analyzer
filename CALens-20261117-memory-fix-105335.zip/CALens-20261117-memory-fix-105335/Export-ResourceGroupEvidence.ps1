#Requires -Version 7.4
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SnapshotPath,[Parameter(Mandatory)][guid]$UserId,[string[]]$ResourceIds,[ValidateRange(1,10000)][int]$MaxResources=200,[string]$OutputPath='./ca-resource-groups.json')
$ErrorActionPreference='Stop'
if(!(Get-Command Get-CaResourceGroupEvidence -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'collection/ResourceGroupEvidence.ps1')}
$snapshot=Get-Content -LiteralPath $SnapshotPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$destination=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
if($destination -eq (Resolve-Path -LiteralPath $SnapshotPath).ProviderPath -or (Test-Path -LiteralPath $destination)){throw 'Choose a new output file; inputs and existing outputs are never overwritten.'}
$tenant=([guid]$snapshot.tenantId).ToString();$account=az account show --output json|ConvertFrom-Json
if($LASTEXITCODE -or $account.tenantId -ne $tenant){throw 'The existing Azure CLI/Cloud Shell session must match the snapshot tenant.'}
$credential=$null
try{
 $credential=az account get-access-token --tenant $tenant --resource https://graph.microsoft.com/ --output json|ConvertFrom-Json
 if($LASTEXITCODE -or !$credential.accessToken){throw 'The existing session could not provide a Graph token.'}
 $evidence=Get-CaResourceGroupEvidence -Snapshot $snapshot -UserId $UserId -ResourceIds $ResourceIds -MaxResources $MaxResources -BearerToken $credential.accessToken
 $json=$evidence|ConvertTo-Json -Depth 100
 $null=New-Item -ItemType Directory -Path (Split-Path $destination) -Force
 $stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$bytes=[Text.Encoding]::UTF8.GetBytes($json+"`n");$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 $count=@($evidence.resourceGroups|ForEach-Object {$_.members;$_.nonMembers}).Count
 Write-Host "$count membership facts saved from $($evidence.queriedResourceIds.Count) resource queries. All other membership remains unknown."
 if($evidence.conflictingFacts.Count){Write-Warning 'Conflicting observations were omitted. Investigate before relying on the affected resources.'}
}finally{$credential=$null}
