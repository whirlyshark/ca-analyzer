# Shared assessment finalization for UI and unattended runs.
. (Join-Path $PSScriptRoot 'JsonData.ps1')
. (Join-Path $PSScriptRoot 'ReportCodec.ps1')
function Get-CaAcceptanceSummary($Record,[string]$Key){
    if($Record -isnot [Collections.IDictionary] -or $Record['reason'] -isnot [string] -or $Record['reason'].Trim().Length -lt 3 -or $Record['reason'].Length -gt 1000){return $null}
    $summary=@{};foreach($field in $Record.Keys){if($field -notin @('semanticScope','recordKey','recordKeys','matchedSemantically')){$summary[$field]=$Record[$field]}}
    $summary.recordKey=$Key;$summary.recordKeys=@($Key);$summary.exceptionCount=1;$summary.reasons=@($Record['reason']);return $summary
}
function Assert-CaAssessmentFinished($Result){
    $cause=switch($Result.status){
        'incomplete:timeout' {'the configured time limit was reached'}
        'incomplete:regionLimit' {'the calculation exceeded its working region limit'}
        'incomplete:memoryLimit' {'the calculation exceeded its available memory'}
        'incomplete:resultSizeLimit' {'the findings exceeded the available result storage'}
    }
    if($cause){throw "Assessment failed $($Result.limitation) because $cause. No coverage result was published."}
}
function Invoke-CaStoredCalculation($ModelJson,$MaxRegions,$TimeoutSeconds,$Observer,$Progress){
    $store=[CaGapAnalyzer.PagedFindingRecords]::new($true)
    try{
        $report=[CaGapAnalyzer.Engine]::AnalyzeReportData($ModelJson,$MaxRegions,$TimeoutSeconds,$Observer,$store)
        if($report.status -in @('incomplete:regionLimit','incomplete:memoryLimit')){
            $store.Dispose()
            $store=[CaGapAnalyzer.PagedFindingRecords]::new($true)
            if($Progress){$null=& $Progress @{stage='assess';message='Checking smaller groups of scenarios'}}
            $report=[CaGapAnalyzer.Engine]::AnalyzePartitionedReport($ModelJson,$MaxRegions,$TimeoutSeconds,$Observer,$store)
        }
        Assert-CaAssessmentFinished $report
        return $report
    }catch{$store.Dispose();throw}
}
function Invoke-CaAssessmentCore {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Model,[object[]]$CoverageIssues=@(),[hashtable]$Acceptances=@{},[int]$MaxRegions=20000,[ValidateRange(0,3600)][int]$TimeoutSeconds=0,[string]$SourceKey='',$AcceptanceEvidence=$null,[scriptblock]$Progress)
    if(-not ('CaGapAnalyzer.Engine' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'GapEngine.cs')}
    $modelJson=$Model|ConvertTo-Json -Depth 100 -Compress
    function Hash([string]$Text){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Text))).ToLowerInvariant()}
    $modelHash=Hash $modelJson
    $exceptionContext=if($SourceKey){ConvertTo-Json -InputObject @('tenant-exception-v1',$SourceKey,(Hash (ConvertTo-Json -InputObject $AcceptanceEvidence -Depth 100 -Compress))) -Compress}else{''}
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $observer=$null;$analysisProgressState=@{completed=0}
    if($Progress){
        $observer=[Action[CaGapAnalyzer.AnalysisProgress]]{param($state)
            $analysisProgressState.completed=$state.CompletedAccounts
            $null=& $Progress @{stage='assess';message=$(if($state.RequirementId){'Checking requirements'}else{'Preparing scenario rules'});completed=$state.CompletedAccounts;total=$state.TotalAccounts;unit='accounts';requirementId=$state.RequirementId;requirementIndex=$state.RequirementIndex;requirementCount=$state.RequirementCount;profileIndex=$state.ProfileIndex;profileCount=$state.ProfileCount;regionOperations=$state.RegionOperations;gapGroups=$state.GapGroups}
        }
    }
    $result=Invoke-CaStoredCalculation $modelJson $MaxRegions $TimeoutSeconds $observer $Progress
    if($Progress){$message=if($result.status -like 'incomplete:*'){'The policy check stopped before finishing; preparing an explanation'}else{'Checking incomplete policy details'};$null=& $Progress @{stage='assess';message=$message;engineStatus=$result.status;gapGroups=$result.gaps.Count;regionOperations=$result.regionSubtractionCount}}
    $result.analysisMilliseconds=$timer.ElapsedMilliseconds
    $requirementIds=@($Model.requirements|ForEach-Object {$_.id});$findingIndex=[CaGapAnalyzer.ReportCodec]::IndexRequirements($result.gaps);$gapRequirementIds=@($findingIndex.Keys)
    $contextClock=[Diagnostics.Stopwatch]::StartNew()
    $domainChecks=[Collections.Generic.Dictionary[object,object]]::new([Collections.Generic.ReferenceEqualityComparer]::Instance)
    function Test-CaDiagnosticDomainCore($Issue,[string]$Field,[string]$Axis){
        if(!$Model.dimensions.Contains($Axis)){return $false}
        $values=@($Issue[$Field]);if(!$values.Count){return $false}
        foreach($value in $values){if($value -isnot [string] -or $value -cnotin $Model.dimensions[$Axis]){return $false}}
        return $true
    }
    function Test-CaDiagnosticDomain($Issue,[string]$Field,[string]$Axis){
        if(!$domainChecks.ContainsKey($Issue)){$domainChecks[$Issue]=@{}}
        $cache=$domainChecks[$Issue];$key=$Field+':'+$Axis
        if(!$cache.ContainsKey($key)){$cache[$key]=Test-CaDiagnosticDomainCore $Issue $Field $Axis}
        return $cache[$key]
    }
    $knownIdentityIds=[Collections.Generic.HashSet[string]]::new([string[]]@($Model.identities|ForEach-Object id),[StringComparer]::Ordinal)
    $unassessedRequirementIds=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach($issue in $CoverageIssues){
        if(!$issue -or $issue['code'] -cne 'requirement-not-evaluated' -or $issue['requirementId'] -isnot [string] -or !$issue['requirementId'].Trim() -or $issue['requirementId'] -cin $requirementIds -or $issue['accountIds'] -isnot [array] -or $issue['message'] -isnot [string] -or !$issue['message'].Trim()){continue}
        $valid=$true;foreach($id in $issue['accountIds']){if($id -isnot [string] -or !$knownIdentityIds.Contains($id)){$valid=$false;break}}
        if($valid){$null=$unassessedRequirementIds.Add($issue['requirementId'])}
    }
    function Test-CaClassificationScope($Issue){
        if($Issue['code'] -cne 'account-classification' -or $Issue['accountIds'] -isnot [array] -or !$Issue['accountIds'].Count){return $false}
        foreach($id in $Issue['accountIds']){if($id -isnot [string] -or !$knownIdentityIds.Contains($id)){return $false}}
        return $true
    }
    $issues=[object[]]@()
    if($CoverageIssues.Count){$issues=ConvertTo-Json -InputObject @($CoverageIssues) -Depth 100|ConvertFrom-CaJson}
    if($result.unverifiedApplicationFilterPolicyIds.Count){
        # Bind this diagnostic to the engine's typed policy flags. A caller must
        # not omit it, swap in a denial-mode query, or narrow its policy/person set.
        $issues=@($issues|Where-Object {$_ -and $_['code'] -ne 'application-filter-context'})
        $bases=@($requirementIds|ForEach-Object {$base=$_ -replace ':(outside-network|outside-apps|outside-device)$','';if($base -cin $requirementIds){$base}else{$_}}|Sort-Object -Unique -CaseSensitive)
        foreach($base in $bases){
            $ids=@(if($findingIndex.Contains($base)){$findingIndex[$base].ids})
            $issues+=[ordered]@{requirementId=$base;code='application-filter-context';resolveWhenProtected=$true;policyContext=[ordered]@{requirementId=$base;policyIds=@($result.unverifiedApplicationFilterPolicyIds);identityIds=$ids;relaxedAxes=@();matchMode='applicable'};message='Application-filter matching is not verified. No protection is credited from those policies. Remaining possible access in this account/request scope needs filter and attribute evidence.'}
        }
    }
    if($result.unverifiedLocationPolicyIds.Count){
        # Derive location diagnostics from typed model flags, not caller-supplied
        # policy IDs or denial-mode queries that could conceal the uncertainty.
        $issues=@($issues|Where-Object {$_ -and $_['code'] -ne 'location-enforcement-context'})
        $bases=@($requirementIds|ForEach-Object {$base=$_ -replace ':(outside-network|outside-apps|outside-device)$','';if($base -cin $requirementIds){$base}else{$_}}|Sort-Object -Unique -CaseSensitive)
        foreach($base in $bases){
            $ids=@(if($findingIndex.Contains($base)){$findingIndex[$base].ids})
            $issues+=[ordered]@{requirementId=$base;code='location-enforcement-context';resolveWhenProtected=$true;policyContext=[ordered]@{requirementId=$base;policyIds=@($result.unverifiedLocationPolicyIds);identityIds=$ids;relaxedAxes=@();matchMode='potentiallyDenied'};message='Some policy locations cannot be evaluated. No protection is credited from those policies; remaining possible access in this account/request scope needs location evidence.'}
        }
    }
    if($result.registrationResourcePolicyIds.Count){
        # Mandatory typed applicability bounds, independent of supplied diagnostics.
        $bases=@($requirementIds|ForEach-Object {$base=$_ -replace ':(outside-network|outside-apps|outside-device)$','';if($base -cin $requirementIds){$base}else{$_}}|Sort-Object -Unique -CaseSensitive)
        foreach($base in $bases){
            if(!$findingIndex.Contains($base) -or !$findingIndex[$base].hasRegistration){continue}
            $ids=@(if($findingIndex.Contains($base)){$findingIndex[$base].ids})
            $issues+=[ordered]@{requirementId=$base;code='registration-resource-context';resolveWhenProtected=$true;policyContext=[ordered]@{requirementId=$base;policyIds=@($result.registrationResourcePolicyIds);identityIds=$ids;relaxedAxes=@();matchMode='registrationResource'};message='The registration resource is unknown. Specify it to check whether this policy applies.'}
        }
    }
    $contextIndices=[Collections.Generic.List[int]]::new();$contextQueries=[Collections.Generic.List[object]]::new();$contextAnswers=@{}
    if($result.status -eq 'completeWithinModel'){
        for($i=0;$i -lt $issues.Count;$i++){
            $issue=$issues[$i]
            if(!$issue -or $issue['resolveWhenProtected'] -ne $true -or $issue['requirementId'] -notin $requirementIds -or $issue['requirementId'] -notin $gapRequirementIds -or $issue['policyContext'] -isnot [Collections.IDictionary] -or $issue['policyContext']['requirementId'] -cne $issue['requirementId']){continue}
            $query=$issue['policyContext'];$mode=$query['matchMode']
            $safeMode=($issue['code'] -ceq 'registration-resource-context' -and $mode -ceq 'registrationResource') -or ($issue['code'] -eq 'pim-group-context' -and ($null -eq $mode -or $mode -ceq 'denied')) -or ($issue['code'] -ceq 'location-enforcement-context' -and $mode -ceq 'potentiallyDenied') -or ($issue['code'] -in @('session-enforcement-context','strength-enforcement-context','grant-enforcement-context','application-filter-context','location-enforcement-context') -and $mode -ceq 'applicable')
            if($safeMode){
                # A restriction whose entire policy set has validated location
                # bounds cannot deny a request that is proved to satisfy its
                # grants. Keep the stored diagnostic/evidence unchanged.
                if($mode -ceq 'applicable' -and $query['policyIds'] -is [array] -and $query['policyIds'].Count -and @($query['policyIds']|Where-Object {$_ -cnotin $result.unverifiedLocationPolicyIds}).Count -eq 0){
                    $bounded=[ordered]@{};foreach($key in $query.Keys){$bounded[$key]=$query[$key]};$bounded.matchMode='potentiallyDenied';$query=$bounded
                }
                $contextIndices.Add($i);$contextQueries.Add($query)
            }
        }
        if($contextQueries.Count){
            $answers=[CaGapAnalyzer.Engine]::RelevantPolicyContextsTyped($modelJson,[CaGapAnalyzer.Engine]::ReadReportGapList($result.gaps),(ConvertTo-Json -InputObject @($contextQueries.ToArray()) -Depth 100 -Compress),$MaxRegions,($TimeoutSeconds*1000))|ConvertFrom-CaJson
            if(@($answers).Count -eq $contextIndices.Count){for($i=0;$i -lt $contextIndices.Count;$i++){if($answers[$i] -is [bool]){$contextAnswers[$contextIndices[$i]]=$answers[$i]}}}
        }
    }
    $diagnosticAxes=$null
    if(@($issues|Where-Object {$_ -and $_['code'] -in @('resource-group-context','country-catalog-context','directory-baseline-context')}).Count){$diagnosticAxes=[CaGapAnalyzer.ReportCodec]::IndexDiagnosticAxes($result.gaps)}
    $unresolvedIndices=[Collections.Generic.List[int]]::new()
    $result.coverageIssues=@(for($issueIndex=0;$issueIndex -lt $issues.Count;$issueIndex++){
        if($Progress -and $issueIndex%10 -eq 0){$null=& $Progress @{stage='assess';message='Reviewing missing information';completed=$issueIndex;total=$issues.Count;unit='checks'}}
        $issue=$issues[$issueIndex]
        if($null -eq $issue){continue}
        $resolved=$issue['resolveWhenProtected'] -eq $true -and $issue['code'] -in @('registration-resource-context','registration-strength-precedence','device-compliance-runtime','external-identity-context','pim-group-context','session-enforcement-context','strength-enforcement-context','grant-enforcement-context','application-filter-context','location-enforcement-context','graph-audience-context','role-schedule-context','ip-country-correlation') -and $result.status -eq 'completeWithinModel' -and $issue['requirementId'] -in $requirementIds -and $issue['requirementId'] -notin $gapRequirementIds
        if($contextAnswers.ContainsKey($issueIndex) -and $contextAnswers[$issueIndex] -eq $false){$resolved=$true}
        if($issue['code'] -eq 'resource-group-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application') -and $result.status -eq 'completeWithinModel'){
            $unknown=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownApplications']),[StringComparer]::Ordinal)
            $relevant=$false
            if($diagnosticAxes.Contains($issue['requirementId']) -and $diagnosticAxes[$issue['requirementId']].ContainsKey('application')){$relevant=$unknown.Overlaps($diagnosticAxes[$issue['requirementId']]['application'])}
            $resolved=!$relevant
        }
        if($issue['code'] -eq 'country-catalog-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network') -and $result.status -eq 'completeWithinModel'){
            $unknownNetworks=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownNetworks']),[StringComparer]::Ordinal)
            $relevant=$false
            if($diagnosticAxes.Contains($issue['requirementId']) -and $diagnosticAxes[$issue['requirementId']].ContainsKey('network')){$relevant=$unknownNetworks.Overlaps($diagnosticAxes[$issue['requirementId']]['network'])}
            $resolved=!$relevant
        }
        if($issue['code'] -eq 'directory-baseline-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and $result.status -eq 'completeWithinModel' -and $Model.dimensions.Contains('directoryScopeEnforcement')){
            $resolved=!($diagnosticAxes.Contains($issue['requirementId']) -and $diagnosticAxes[$issue['requirementId']].ContainsKey('directoryScopeEnforcement') -and $diagnosticAxes[$issue['requirementId']]['directoryScopeEnforcement'].Contains('legacyBaseline'))
        }
        if(!$resolved){$unresolvedIndices.Add($issueIndex);$issue}
    })
    # Preserve per-finding proofs without changing global completeness or the
    # existing exception fingerprint. The batch retains the configured region limit.
    $gapContextAnswers=@{}
    $parentGapKeys=@{}
    $result.gapRefinement=[ordered]@{status='notNeeded';originalGroups=$result.gaps.Count;refinedGroups=$result.gaps.Count}
    if($result.status -eq 'completeWithinModel' -and $result.gaps.Count){
        $remainingQueries=[Collections.Generic.List[object]]::new();$remainingIndices=[Collections.Generic.List[int]]::new()
        for($finalIndex=0;$finalIndex -lt $unresolvedIndices.Count;$finalIndex++){
            $originalIndex=$unresolvedIndices[$finalIndex]
            $queryIndex=$contextIndices.IndexOf($originalIndex)
            if($queryIndex -ge 0){$remainingQueries.Add($contextQueries[$queryIndex]);$remainingIndices.Add($finalIndex)}
        }
        $cuts=[Collections.Generic.List[object]]::new()
        $people=@($Model.identities|ForEach-Object id)
        foreach($issue in $result.coverageIssues){
            if($issue['requirementId'] -cin $requirementIds -and (Test-CaClassificationScope $issue)){
                $cuts.Add([ordered]@{requirementId=$issue['requirementId'];identityIds=@($issue['accountIds']);conditions=[ordered]@{}});continue
            }
            if($issue['resolveWhenProtected'] -ne $true -or $issue['requirementId'] -cnotin $requirementIds){continue}
            $axis=$null;$values=@()
            if($issue['code'] -eq 'resource-group-context' -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application')){$axis='application';$values=@($issue['unknownApplications'])}
            if($issue['code'] -eq 'country-catalog-context' -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network')){$axis='network';$values=@($issue['unknownNetworks'])}
            if($issue['code'] -eq 'directory-baseline-context' -and $Model.dimensions.Contains('directoryScopeEnforcement') -and 'legacyBaseline' -cin $Model.dimensions.directoryScopeEnforcement){$axis='directoryScopeEnforcement';$values=@('legacyBaseline')}
            if($axis){$cuts.Add([ordered]@{requirementId=$issue['requirementId'];identityIds=$people;conditions=[ordered]@{$axis=[ordered]@{include=$values}}})}
        }
        if($remainingQueries.Count -or $cuts.Count){
            $original=$result.gaps
            $newStore=[CaGapAnalyzer.PagedFindingRecords]::new($true)
            $queryJson=ConvertTo-Json -InputObject $remainingQueries.ToArray() -Depth 100 -Compress
            $cutsJson=ConvertTo-Json -InputObject $cuts.ToArray() -Depth 100 -Compress
            $parentFingerprints=[CaGapAnalyzer.ReportCodec+FindingFingerprints]::new($exceptionContext+$modelHash+($result.coverageIssues|ConvertTo-Json -Depth 30 -Compress))
            try{
                $refinementStatus='complete'
                for($start=0;$start -lt $original.Count;){
                    $size=[Math]::Min(256,[Math]::Min($MaxRegions,$original.Count-$start))
                    $workRegions=$MaxRegions
                    do{
                        $rows=[Collections.Generic.List[object]]::new()
                        for($j=0;$j -lt $size;$j++){$rows.Add($original.Read($start+$j))}
                        $refined=[CaGapAnalyzer.Engine]::RefinePolicyContextGapsTypedData($modelJson,[CaGapAnalyzer.Engine]::ReadReportGaps($rows),$queryJson,$cutsJson,$workRegions,($TimeoutSeconds*1000))
                        if($refined.status -eq 'complete'){break}
                        if($refined.status -notin @('bounded:regionLimit','bounded:identityReferenceLimit')){throw "Assessment failed during finding verification ($($refined.status)). No coverage result was published."}
                        if($size -gt 1){$size=[int][Math]::Ceiling($size/2)}
                        elseif($workRegions -lt [int]::MaxValue){$workRegions=[int][Math]::Min([long][int]::MaxValue,2L*$workRegions)}
                        else{throw 'Assessment failed while subdividing one finding. No coverage result was published.'}
                    }while($true)
                    if($refined.status -ne 'complete'){$refinementStatus=$refined.status}
                    if($refined.gaps.Count -eq $size){foreach($row in $rows){$null=$newStore.Add($row)}}
                    else{
                        for($j=0;$j -lt $refined.gaps.Count;$j++){
                            if($Acceptances.Count){
                                $parent=$parentFingerprints.Hash($rows[$refined.parentGapIndices[$j]])
                                if($Acceptances.ContainsKey($parent)){$parentGapKeys[$newStore.Count]=$parent}
                            }
                            $null=$newStore.Add([CaGapAnalyzer.Engine]::GapRecord($refined.gaps[$j]))
                        }
                    }
                    $start+=$size
                    if($Progress){$null=& $Progress @{stage='assess';message='Checking finding evidence';completed=$start;total=$original.Count;unit='findings'}}
                }
                $result.gaps=$newStore
                $result.gapRefinement=[ordered]@{status=$refinementStatus;originalGroups=$original.Count;refinedGroups=$newStore.Count}
                $original.Dispose()
            }catch{$newStore.Dispose();$original.Dispose();throw}
        }
        if($remainingQueries.Count){
            # Each matrix row belongs to a single diagnostic. Store only proven
            # negative answers; unverified intersections retain their diagnostic.
            $queriesById=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
            for($q=0;$q -lt $remainingQueries.Count;$q++){
                $rid=$remainingQueries[$q].requirementId
                foreach($suffix in @('',':outside-network',':outside-apps',':outside-device')){
                    $id=$rid+$suffix
                    if(!$queriesById.ContainsKey($id)){$queriesById[$id]=[Collections.Generic.List[int]]::new()}
                    $queriesById[$id].Add($q)
                }
            }
            for($start=0;$start -lt $result.gaps.Count;){
                $size=[Math]::Min(512,[Math]::Min($MaxRegions,$result.gaps.Count-$start))
                $rows=[Collections.Generic.List[object]]::new()
                $needed=[Collections.Generic.SortedSet[int]]::new()
                for($j=0;$j -lt $size;$j++){
                    $record=$result.gaps.Read($start+$j);$rows.Add($record)
                    if($queriesById.ContainsKey($record.requirementId)){$needed.UnionWith($queriesById[$record.requirementId])}
                }
                $typed=[CaGapAnalyzer.Engine]::ReadReportGaps($rows)
                $ids=@($needed)
                $batchSize=[Math]::Max(1,[int][Math]::Floor($MaxRegions/$size))
                for($offset=0;$offset -lt $ids.Count;$offset+=$batchSize){
                    $indices=@($ids | Select-Object -Skip $offset -First $batchSize)
                    $queryJson=ConvertTo-Json -InputObject @($indices|ForEach-Object {$remainingQueries[$_]}) -Depth 100 -Compress
                    $matrix=[CaGapAnalyzer.Engine]::RelevantPolicyContextsTyped($modelJson,$typed,$queryJson,$MaxRegions,($TimeoutSeconds*1000),$true)|ConvertFrom-CaJson
                    for($q=0;$q -lt $indices.Count;$q++){
                        $index=$remainingIndices[$indices[$q]]
                        if(!$gapContextAnswers.ContainsKey($index)){$gapContextAnswers[$index]=[Collections.BitArray]::new($result.gaps.Count)}
                        for($j=0;$j -lt $size;$j++){
                            if($matrix[$q][$j] -is [bool] -and !$matrix[$q][$j]){$gapContextAnswers[$index][$start+$j]=$true}
                        }
                    }
                }
                $start+=$size
            }
        }
    }
    $result.contextResolutionMilliseconds=$contextClock.ElapsedMilliseconds
    $result.analysisMilliseconds=$timer.ElapsedMilliseconds
    foreach($id in $result.emptyRequirementIds){$result.coverageIssues+=[ordered]@{requirementId=$id;code='empty-requirement-scope';message="Requirement $id has no matching accounts and feasible scenarios. Check its scope before confirming coverage."}}
    if($result.coverageIssues.Count -and $result.status -eq 'completeWithinModel'){$result.engineStatus=$result.status;$result.status='unresolvedCoverage'}
    # Reuse ordinal sets across findings. A per-account scan of the full
    # unresolved account list turns large, mostly unknown directories quadratic.
    $classificationScopes=@{}
    for($i=0;$i -lt $result.coverageIssues.Count;$i++){
        $issue=$result.coverageIssues[$i]
        if($issue['requirementId'] -cin $requirementIds -and (Test-CaClassificationScope $issue)){
            $classificationScopes[$i]=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['accountIds']),[StringComparer]::Ordinal)
        }
    }
    # This evidence is identical for every gap. Serializing it once avoids
    # multiplying large uncertainty/account lists by the number of findings.
    $issueIndicesByRequirement=@{};$unknownApps=@{};$unknownNetworksByIssue=@{}
    foreach($rid in @($Model.requirements|ForEach-Object id)){
        $indices=[Collections.Generic.List[int]]::new()
        for($i=0;$i -lt $result.coverageIssues.Count;$i++){
            $issue=$result.coverageIssues[$i];$id=$issue['requirementId']
            if($id -is [string] -and $unassessedRequirementIds.Contains($id)){continue}
            if($id -is [string] -and $id -cin $requirementIds -and $rid -cne $id -and $rid -cne ($id+':outside-network') -and $rid -cne ($id+':outside-apps') -and $rid -cne ($id+':outside-device')){continue}
            $indices.Add($i)
        }
        $issueIndicesByRequirement[$rid]=$indices.ToArray()
    }
    for($i=0;$i -lt $result.coverageIssues.Count;$i++){
        $issue=$result.coverageIssues[$i]
        if($issue['code'] -eq 'resource-group-context' -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application')){$unknownApps[$i]=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownApplications']),[StringComparer]::Ordinal)}
        if($issue['code'] -eq 'country-catalog-context' -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network')){$unknownNetworksByIssue[$i]=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownNetworks']),[StringComparer]::Ordinal)}
    }
    $fingerprintPrefix=$exceptionContext+$modelHash+($result.coverageIssues|ConvertTo-Json -Depth 30 -Compress)
    $fingerprints=[CaGapAnalyzer.ReportCodec+FindingFingerprints]::new($fingerprintPrefix)
    $findingClock=[Diagnostics.Stopwatch]::StartNew();$lastFindingUpdate=-200L
    if($result.status -eq 'completeWithinModel' -and !$result.coverageIssues.Count -and !$Acceptances.Count -and !$parentGapKeys.Count){
        for($batch=0;$batch -lt $result.gaps.Count;$batch+=512){
            [CaGapAnalyzer.ReportCodec]::FinalizePlainBatch($result.gaps,$batch,[Math]::Min($batch+512,$result.gaps.Count),$fingerprints)
            if($Progress -and $findingClock.ElapsedMilliseconds-$lastFindingUpdate -ge 200){$lastFindingUpdate=$findingClock.ElapsedMilliseconds;$null=& $Progress @{stage='results';message='Preparing findings';completed=[Math]::Min($batch+512,$result.gaps.Count);total=$result.gaps.Count;unit='findings'}}
        }
    }else{
    for($gapIndex=0;$gapIndex -lt $result.gaps.Count;$gapIndex++){
        if($Progress -and ($findingClock.ElapsedMilliseconds-$lastFindingUpdate -ge 200 -or $gapIndex -eq $result.gaps.Count-1)){
            $lastFindingUpdate=$findingClock.ElapsedMilliseconds
            $null=& $Progress @{stage='results';message='Preparing findings';completed=$gapIndex;total=$result.gaps.Count;unit='findings'}
        }
        $gap=$result.gaps[$gapIndex]
        $key=$fingerprints.Hash($gap)
        $gap.key=$key;$gap.acceptance=if($Acceptances.ContainsKey($key)){Get-CaAcceptanceSummary $Acceptances[$key] $key}else{$null}
        if($parentGapKeys.ContainsKey($gapIndex) -and $Acceptances.ContainsKey($parentGapKeys[$gapIndex])){
            $parentKey=$parentGapKeys[$gapIndex];$parentAcceptance=Get-CaAcceptanceSummary $Acceptances[$parentKey] $parentKey
            if($parentAcceptance){
                if(!$gap.acceptance){$gap.acceptance=$parentAcceptance}else{
                    $gap.acceptance.recordKeys=@(@($gap.acceptance.recordKeys)+@($parentKey)|Sort-Object -Unique)
                    $gap.acceptance.exceptionCount=$gap.acceptance.recordKeys.Count
                    $gap.acceptance.reasons=@(@($gap.acceptance.reasons)+@($parentAcceptance.reason)|Sort-Object -Unique)
                }
                $gap.acceptance.matchedRefinement=$true
            }
        }
        $relevantIssues=[Collections.Generic.List[int]]::new()
        foreach($i in $issueIndicesByRequirement[$gap.requirementId]){
            $issue=$result.coverageIssues[$i];$id=$issue['requirementId']
            if($classificationScopes.ContainsKey($i) -and !$classificationScopes[$i].Overlaps([string[]]@($gap.identityIds))){continue}
            if($id -is [string] -and $id -cin $requirementIds -and $issue['resolveWhenProtected'] -eq $true){
                if($unknownApps.ContainsKey($i) -and !$unknownApps[$i].Overlaps([string[]]$gap.region.application)){continue}
                if($unknownNetworksByIssue.ContainsKey($i) -and !$unknownNetworksByIssue[$i].Overlaps([string[]]$gap.region.network)){continue}
                if($issue['code'] -eq 'directory-baseline-context' -and $Model.dimensions.Contains('directoryScopeEnforcement') -and 'legacyBaseline' -cnotin $gap.region.directoryScopeEnforcement){continue}
            }
            if($gapContextAnswers.ContainsKey($i) -and $gapContextAnswers[$i][$gapIndex]){continue}
            $relevantIssues.Add($i)
        }
        $engineComplete=$result.status -eq 'completeWithinModel' -or ($result.status -eq 'unresolvedCoverage' -and $result['engineStatus'] -eq 'completeWithinModel')
        $gap.assessmentStatus=if($engineComplete -and !$relevantIssues.Count){'gapWithinModel'}else{'needsInvestigation'}
        $gap.coverageIssueIndices=@($relevantIssues.ToArray())
    }
    }
    if($Progress){$null=& $Progress @{stage='results';message='Preparing findings';completed=$result.gaps.Count;total=$result.gaps.Count;unit='findings'}}
    $result.modelHash=$modelHash;$result.runAtUtc=[DateTime]::UtcNow.ToString('o')
    return $result
}

