# Performance measurements

Development measurement, 2026-11-16. Release acceptance is still pending.

The fresh-process offline command was measured against fictional exports containing 21 raw policies and seven requirements. Policies include overlapping Member/Guest groups, active and eligible roles, explicit exclusions and compensating protection, app-specific grants, legacy/flow blocks, IPv4/IPv6 networks, registration actions, authentication context, disabled and report-only policies. Six equivalent account profiles were found; this represents a patterned organisation, not every worst-case unique-identity policy set.

| Accounts | Case | Full CLI and JSON/HTML export | Engine | Peak process memory | Confirmed accounts needing attention |
|---|---|---:|---:|---:|---:|
| 1,000 | Covered | 3.90 seconds | 24 ms | 289 MiB | 0 |
| 1,000 | MFA AND compliance weakened to OR | 3.98 seconds | 28 ms | 294 MiB | 750 |
| 10,000 | Covered | 21.49 seconds | 135 ms | 704 MiB | 0 |
| 10,000 | MFA AND compliance weakened to OR | 23.64 seconds | 143 ms | 683 MiB | 7,500 |

Environment: Windows 10.0.26300 x64, 16 logical processors, PowerShell 7.6.9, .NET 10.0.14. Measurements ran while the separate validation suite was active, so these are observed results under concurrent local load, not a controlled performance guarantee. Input fixture generation is excluded; fresh PowerShell startup, input reading, V8 normalization/compilation, history evidence construction, .NET analysis, summaries and report export are included. History saving is disabled and the benchmark uses a new empty acceptance path. The child process has no Node/SDK on PATH and uses unusable external proxies; this is not an OS-enforced air gap.

A second frozen all-options run on PowerShell 7.4.22 / .NET 8.0.33 measured the same cases at 3.41 / 3.50 seconds for 1,000 accounts and 18.50 / 18.86 seconds for 10,000 accounts, retaining the exact independent results and input hashes. Peak memory was 283 / 294 / 651 / 680 MiB respectively. Evidence: `data/release-audit-20261116-213756.local/full-validation-02/release-journey-scale/results.json`. Use the final candidate's validation evidence for its exact measured timings rather than treating earlier observations as a service-level promise.

Independent expectations require the complete exact affected-account union and requirement, confirmed certainty, summary agreement, expected CLI exit status, HTML report and unchanged inputs. The changed policy permits MFA OR a compliant device, which leaves noncompliant requirements uncovered for six of the eight fictional account cohorts. Report findings retain four separate scenario regions; region count is not the affected-account count.

Reproduce from development source:

```powershell
pwsh -NoProfile -File tests/Measure-ReleaseJourney.ps1 -OutputDirectory ./data/new-release-measurement.local
```

Choose a new output folder. Evidence includes input hashes, logs, exported reports, environment and measurements. The all-options validation runner also includes this measurement. Initial evidence is under `data/release-audit-20261116-213756.local/release-journey-scale-01/results.json`.

Run time depends on distinct account profiles, overlapping policy conditions and the number of disjoint scenarios represented by each requirement.

Snapshot imports, account-set imports and authenticated bulk assessment requests use the available machine resources. Small control requests retain their separate request-size guard. Saved reports use disk pages. The standalone HTML summary shows examples, and the accompanying JSON contains the complete findings.

## Disk-backed findings (17 November 2026)

Tenant assessments and normalized-model commands now write findings into local
compressed pages as the engine produces them. A page contains up to 512 records;
only three mutable pages are cached. Eviction persists changes before discarding
a page. Exact finding keys, full regions, witnesses, policy references and
acceptance metadata survive page reloads. Owned temporary pages are removed when
the store is disposed; a process crash can leave temporary files behind.

**There is no 100,000-finding cutoff.** `MaxRegions` bounds the live regions in a
single calculation, rather than the accumulated result. Normal tenant and local UI assessments have no elapsed-time cutoff for the coverage
calculation or its policy-context checks. PowerShell callers can opt into a
calculation deadline with a positive `TimeoutSeconds`. The default is zero.
The fast calculation uses working targets of 100,000 live regions for tenant assessments and 20,000 for normalized UI checks. If it reaches its region or managed-memory target, CALens discards the unfinished attempt and subdivides the finite scenario space. Completed portions go into a fresh disk-backed result. Evidence refinement also works in batches, and missing evidence remains visible for the accounts it concerns.

A configured timeout, storage failure or calculation that cannot fit even after subdivision fails the assessment before a new coverage result is published. Runtime memory and disk availability still constrain what one machine can process.
An earlier interrupted report with its original inputs can be reopened to run
the assessment again. The compatibility `Engine.Analyze` expanded-JSON API
retains its separate safeguards.

Managed-memory safeguards still protect active calculations. They are not total
process-memory caps: snapshot translation, comparison and rendering also use
memory. A genuine computation failure must not be labelled a completed check.
There is no sampling or omission of findings to manufacture completion.

Large saved reports use `_calensFindingPages` version 1, containing independently
pooled pages (`_calensDetailPool` version 1). Encoding is page by page, rather than
constructing a second expanded result. Small reports keep their prior layout.
To reopen any size of report in PowerShell:

```powershell
. ./engine/Assessment.ps1
$report = [CaGapAnalyzer.ReportCodec]::ReadFile('C:/reports/check.json')
$report.gaps.Count
```

The browser receives large results as numbered pages and validates their order
and final count before displaying a complete assessment. Wide scenario maps are
created only when inspected; all finding metadata remains available for account
and requirement investigation. Saved-check listings scan report headers without
expanding findings. Exporting a report preserves every finding. See
[report storage](REPORT-STORAGE.md) for the format and lifecycle.

A synthetic full-pipeline test used **3,214 accounts, 60 groups, 20 CA policies,
17 requirements and 2,000 inventoried apps**, deliberately preventing account
profile reuse. It completed all 3,214 profiles and saved **437,104 findings** with
`completeWithinModel`, all 3,214 accounts checked and a score of 0 (all accounts
have deliberately introduced gaps). CLI assessment and JSON/HTML output took
about 180 seconds with peak process working set around 1.04 GiB on this machine.
The full JSON was about 176.8 MB. Only three finding pages were resident.

An independent oracle checked all 54,638 account/requirement pairs: each has
exactly eight disjoint regions covering the expected 233,309,160 finite-model
points. It validated every domain, account membership, witness and policy
reference. Reopening and rewriting the report preserved its SHA-256 byte for
byte. Reopening/oracle/export validation peaked around 1.43 GiB; this is measured
process memory, not a promise for all machines or policy sets.

A second automated test produces **122,061 findings with a working-region budget
of only 64**. It verifies eviction, mutable exceptions, indexed lookup, full
report roundtrips, history headers and transport counts. A browser-stream test
checks all 122,061 finding keys and rejects missing, repeated or truncated pages.
The actual user's snapshot was not available; these are reproducible synthetic
scale and correctness tests, alongside the existing semantic regression suite.

Run the larger reproducible test with:

```powershell
./tests/Test-DiskScale.ps1 -OutputDirectory ./data/my-scale-test.local
```

The review dialog shows account/requirement activity, scenario operations,
finding preparation and opening counts, and separate summary/save phases. Its
ETA uses measured progress over the latest 15 seconds, resets between stages
and withdraws stale estimates; it estimates the current counted stage only.

## Coverage optimizations (17 November 2026)

Requirement protection regions are compiled once. Identical requirement
calculations share results within one exact account profile, with a bounded
cache. Requirement IDs, scenario partition ordering and finding fingerprints
are preserved. Witnesses reuse already sorted axis values.

Read-only native context checks do not mark disk pages as modified. Context
queries use requirement indexes; missing-information existence checks share
exact app/network unions. These unions are only used to answer existence
questions, never as replacements for full scenario regions. Account scope
indexes are collected while the engine emits findings and invalidated on
mutable access. Findings with no unresolved diagnostics or acceptances use
compiled batch finalization; complex acceptance/refinement paths retain their
existing handling. Summary calculations use requirement indexes. Saving the
latest report copies the completed report instead of serializing it again.

An unchanged saved assessment can reuse its completed analysis only when the
freshly prepared model, evidence, original inputs and analyzer implementation
hashes all match. Missing-information and refined-result cases are excluded.
Acceptances are cleared and reapplied from current local state. Snapshot
normalization still runs, so changes in time-sensitive modeled state invalidate
reuse. This does not refresh a snapshot from Microsoft. Cross-input incremental
reuse and concurrent solver workers are not enabled.

The final paired fresh-process measurement used the same synthetic 3,214-account,
60-group, 20-policy, 17-requirement, 2,000-app snapshot on the same machine:

| Stage | Previous package | Optimized package |
|---|---:|---:|
| Core calculation, including initial finding storage | 30.512 s | 17.288 s |
| Post-engine scope/index preparation | 19.249 s | 0.123 s |
| Complete CLI assessment and JSON/HTML export | 141.506 s | 98.492 s |

The complete run was 30.4% faster. Timing excludes fixture generation and the
subsequent independent verification. History was disabled, so this measures a
fresh assessment, not cached reuse. The benchmark recorded stage transitions
in memory in both versions; earlier measurements that wrote every progress
event to disk are not directly comparable. These are single paired observations,
not a guaranteed speedup for other policy sets or computers.

All 437,104 finding records, keys, scenario regions, witnesses, policy references,
certainty/acceptance metadata, model hash, diagnostic list and coverage summary
matched byte for byte in the canonical report (SHA-256
`B518CB5DDE44D3E8F70B3582323DEB2F24D254BBAD1687D8EC7578DDD2A0DDF6`).
The independent oracle verified exact disjoint coverage for all 54,638
account/requirement pairs. The final default regression suite passed 197/197
checks. Optimization, rerun-invalidation and 122,061-finding disk-storage tests
also passed on PowerShell 7.4.22 / .NET 8.0.33. Evidence is in
`data/optimization-20261117.local/` in the development workspace.

## Review and saved-results optimizations (2026-11-17)

A second paired measurement compares the coverage-optimized package above with
this build. Both used fresh processes, the same synthetic fixture and machine,
and no history reuse. These are single paired observations, not guarantees for
other tenants. Times exclude subsequent correctness checks.

| Stage | Before | After |
|---|---:|---:|
| Count account and requirement coverage | 22.264 s | 5.708 s |
| Save JSON and build HTML report | 22.456 s | 4.398 s |
| Complete CLI assessment and JSON/HTML export | 100.390 s | 69.657 s |
| Prepare interactive review response from a loaded report | 24.196 s | 5.488 s |
| Compare identical full finding detail | 13.131 s | 4.295 s |

The complete assessment was 30.6% faster. The core calculation was not changed
in this pass (19.735 s before; 21.567 s after, illustrating run-to-run variability).
The review response decreased from 176,795,230 to 41,311,140 bytes. This measurement
writes responses to disk; it is not browser first-paint time or network latency.
Reading the full saved report itself still took 24.510 s in the new build, before
preparing the response. Opening a very large assessment is not instantaneous.

Every one of the 437,104 complete findings, the diagnostic list, model hash and
coverage summary matched the prior canonical SHA-256 shown above. The independent
oracle again verified exact, disjoint coverage for all 54,638 account/requirement
pairs. Every deferred review row was compared against its full original row;
account scopes, requirement IDs, certainty, acceptances and the rebuilt coverage
summary matched. Selected details and full exports were tested separately.

Overview indexes avoid decoding wide scenario lists to count outcomes. Already
packed finding pages are streamed directly when saving. History comparison skips
identical packed pages and inspects changed pages with the original evidence
comparison. The UI retains summary and account indexes while changing selection
or search, invalidating them after result or acceptance changes. Opening a saved
assessment restores its stored review context; it does not execute the analyzer.

Evidence and benchmark scripts: `data/review-20261117.local/` in the development
workspace. No tenant services were queried for these measurements.

## Background jobs and indexed reopening (2026-11-17)

Completed a final paired saved-file loading measurement after the regression
suite finished, using the full 184,861,334-byte assessment including its snapshot,
requirements and compiled review context (3,214 accounts, 17 requirements,
437,104 findings). Full JSON load: **27.828 s**. Indexed load with header and page
checksum verification: **0.639 s** (97.7% less file-loading time). Building the
reusable index took **9.072 s**. New saved assessments pay that additional indexing
cost; older assessments build the index on first opening. These are single paired
measurements on this machine, not guaranteed timings. Browser metadata transfer,
rendering, and selected-detail loading are additional work. The solver was not
changed in this pass.

The entire full JSON roundtrip matched byte for byte (SHA-256
`568AF17EF951F6C0C6B7FB0DF194354E172C0742CB8FD43C92F680B5D200BFE7`).
The background-job assessment independently matched the established canonical
437,104-finding hash `B518CB5DDE44D3E8F70B3582323DEB2F24D254BBAD1687D8EC7578DDD2A0DDF6`.
Tests cover isolated edits to historical pages, damaged index/page recovery,
rejection of conflicting jobs, cancellation without a completed saved assessment,
and complete detail/export equivalence. The regression suite passed 200/200,
with additional focused readiness, action-grouping and index tests. The packaged
UI was checked on PowerShell 7.4, including refresh/reopen and detail exports.

Background jobs survive browser disconnection while the local server remains
running. They do not resume after stopping the server or restarting Windows.
Grouping findings changes presentation only; every underlying finding remains.
Evidence: `data/improvements-20261117.local/` in the development workspace.
