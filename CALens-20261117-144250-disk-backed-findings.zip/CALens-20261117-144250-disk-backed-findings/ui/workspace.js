'use strict';

const $=s=>document.querySelector(s), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const names={directoryScopeEnforcement:'Directory scope enforcement',ordinary:'Ordinary resource request',legacyBaseline:'Low-privilege scopes: legacy enforcement (unverified)',currentBaseline:'Low-privilege scopes: current enforcement',userAction:'Activity',registerSecurityInformation:'Register security information',registerOrJoinDevices:'Register or join a device',android:'Android',windows:'Windows',linux:'Linux','outside-known-locations':'Other networks',accessTarget:'Access type',authenticationContext:'Authentication context',application:'Application',authentication:'Authentication',network:'Network',platform:'Platform',client:'Client',flow:'Authentication flow',standard:'Standard flow',deviceCodeFlow:'Device-code flow',authenticationTransfer:'Authentication transfer',low:'Low',medium:'Medium',high:'High',none:'None',mfa:'MFA',phishingResistant:'Phishing-resistant MFA',password:'Single-factor authentication',compliant:'Compliant device',block:'Blocked access',browser:'Browser',desktop:'Desktop client',mobileAppsAndDesktopClients:'Mobile & desktop clients',exchangeActiveSync:'Exchange ActiveSync',easSupported:'Exchange ActiveSync (supported platforms)',other:'Other / legacy clients',office:'Office network',internet:'Public internet',vpn:'Corporate VPN',sharepoint:'SharePoint',exchange:'Exchange Online',teams:'Teams',azure:'Azure management',finance:'Finance app',hr:'HR app',crm:'CRM app','new-app':'New app','vpn-app':'VPN app',true:'Yes',false:'No',hybridJoined:'Hybrid joined',signInRisk:'Sign-in risk',userRisk:'User risk'};
Object.assign(names,{hidden:'Hidden / not disclosed',unknownFutureValue:'Unknown future value'});

const label=v=>String(v).startsWith('authenticationContext.')?'Authentication context '+String(v).slice('authenticationContext.'.length):String(v).startsWith('resourceGroup.')?'Resource group: '+appName(String(v).slice(14)):String(v).startsWith('groupMember.')?'Group: '+(source?.groupNames?.[String(v).slice(12)]||String(v).slice(12)):String(v).startsWith('groupActivation.')?'PIM activation: '+(source?.groupNames?.[String(v).slice(16)]||String(v).slice(16)):String(v).startsWith('roleActive.')?'Role active: '+(source?.roleNames?.[String(v).slice('roleActive.'.length)]||String(v).slice('roleActive.'.length)):names[v]?names[v]:String(v).startsWith('device.')?'Device '+String(v).slice(7).replace(/([A-Z])/g,letter=>' '+letter.toLowerCase()).replace(/\./g,' '):names[v]||v;

const scenarioValue=(key,value)=>key==='application'?appName(value):key==='network'?source.networkNames?.[value]||label(value):key.startsWith('resourceGroup.')?(value==='true'?'Included':'Not included'):key.startsWith('groupMember.')?(value==='true'?'Member':'Not a member'):key.startsWith('groupActivation.')?(value==='true'?'Activated':'Not activated'):key.startsWith('roleActive.')?(value==='true'?'Active':'Not active'):(key==='registrationContext'?source?.registrationContextNames?.[value]:null)||source?.externalValueNames?.[key]?.[value]||source?.deviceValueNames?.[key]?.[value]||label(value);
const accountClauseValue=c=>c.field==='accountEnabled'?(String(c.value).trim().toLowerCase()==='true'?'Enabled':'Disabled'):['groupIds','eligibleGroupIds'].includes(c.field)?source?.groupNames?.[String(c.value).toLowerCase()]||source?.groupNames?.[c.value]||c.value:c.field==='roleIds'?source?.roleNames?.[c.value]||c.value:c.value;
const accountFieldName=field=>({userType:'User type (Member / Guest)',accountEnabled:'Account status',displayName:'Display name',userPrincipalName:'Sign-in name',mail:'Email address',otherMails:'Other email addresses',jobTitle:'Job title',department:'Department',companyName:'Company',creationType:'Account creation type',externalTenantId:'External home tenant ID',externalUserType:'External-user category',groupIds:'Group membership',eligibleGroupIds:'Eligible group membership',roleIds:'Directory role'}[field]||field);
Object.assign(names,{registrationContext:'Registration context',externalUserType:'External-user category',externalTenantId:'External home tenant','device.deviceOwnership':'Device ownership','device.deviceId':'Device ID','device.mdmAppId':'MDM application ID','device.isCompliant':'Device compliance','device.registered':'Registered device','device.trustType':'Device join type'});

let policyMappingGeneration=0,policyMappingCache=new Map();
let assessmentModel=null,selectedGapKey=null,accountCheckId=null,accountPickerPage=0,scenarioPage=0,scenarioAccountId=null,manualPage=0,appChoicePage=0,reviewSetMemberships=new Map(),accountDisplayCounts=new Map();
let reviewPane='overview',selectedReviewRequirement=null,requirementAccountPage=0,coverageAccountGroups=null;
let sessionToken,source=null,profile=null,result=null,lab=null,filter='open',selection=null,editingSet=null,editingRequirement=null,manualSelection=new Set(),pendingAcceptance=null,busy=false,pollTimer=null,authGeneration=0,signinWindow=null;
let workflowStep='data',workflowCollecting=false;
function updateWorkflowFooter(){
 const state=WorkflowNavigation.state({step:workflowStep,source,profile,result,busy,collecting:workflowCollecting});
 $('#workflow-step').textContent=state.title;$('#workflow-status').textContent=state.message;
 const back=$('#workflow-back');back.hidden=!state.back;back.disabled=state.backDisabled;back.textContent=state.backLabel;back.dataset.target=state.back||'';
 for(const id of ['workflow-next','run','rerun','empty-check']){const button=$('#'+id);button.hidden=id!==state.primaryId;button.disabled=state.disabled;}
 const next=$('#'+state.primaryId);next.textContent=state.label;$('#workflow-next').dataset.target=state.next||'';
}


async function api(path,body){const r=await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':sessionToken},body:JSON.stringify(body)});let data;try{data=await r.json();}catch{throw Error('The local service did not return a valid response.');}if(!r.ok)throw Error(data.error||'Request failed.');return ReportCodec.decode(data);}

function fail(e,target='#error'){const el=$(target);el.textContent=e.message||String(e);el.hidden=false;if(target==='#error')window.scrollTo({top:0,behavior:'smooth'});}

function clearError(){$('#error').hidden=true;}

function toast(text){$('#toast').textContent=text;$('#toast').hidden=false;setTimeout(()=>$('#toast').hidden=true,3500);}

function showTab(id){if(busy)return;if(id!=='data'&&!source){toast('Load a demo, snapshot or policy export first.');return;}if(id!=='data'&&!source.records.length){toast('This file has policies but no account list. Export accounts too, then import the new file.');return;}document.querySelectorAll('.page').forEach(el=>el.hidden=el.id!==id);document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));document.querySelectorAll('[data-tab]').forEach(b=>{if(b.dataset.tab===id)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');});if(id==='sets')renderSets();if(id==='requirements')renderRequirements();workflowStep=id;updateWorkflowFooter();window.scrollTo({top:0,behavior:'smooth'});}
$('#workflow-back').onclick=()=>showTab($('#workflow-back').dataset.target);
$('#workflow-next').onclick=()=>showTab($('#workflow-next').dataset.target);
updateWorkflowFooter();


function download(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(ReportCodec.encode(value),null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function downloadServerReport(path,body,name){
 const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':sessionToken},body:JSON.stringify(body)});
 if(!response.ok){let error;try{error=await response.json();}catch{}throw Error(error?.error||'Could not export this check.');}
 const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}

function parseImportedJson(text){try{return JSON.parse(text);}catch{throw Error('This file is not valid JSON. Choose a JSON export and try again.');}}

async function saveProfile(next=profile){if(busy)throw Error('Wait for the coverage check to finish before changing its requirements.');const previousSource=source,generation=authGeneration;await api('/api/workspace/save',{key:previousSource.key,profile:next});if(source!==previousSource||generation!==authGeneration)return false;profile=next;resetResults('Your account sets or requirements changed. Check coverage again to see the current results.');return true;}

function resetResults(message){$('#result-subtitle').textContent=source?'Check '+source.name+' against your requirements.':'Run a check after defining your requirements.';policyMappingGeneration++;policyMappingCache.clear();result=null;selection=null;scenarioPage=0;scenarioAccountId=null;$('#result-empty').hidden=false;$('#result-body').hidden=true;$('#download-results').disabled=true;$('#result-empty-copy').textContent=message||(profile?.requirements.some(r=>r.enabled!==false)?'Ready to check your data against your saved requirements.':'Define the protection your accounts need, then check coverage.');$('#empty-check').hidden=!profile?.requirements.some(r=>r.enabled!==false);updateWorkflowFooter();}

function accountName(id){const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id)),name=u?.displayName||u?.userPrincipalName||id;return accountDisplayCounts.get(name)>1?name+' · …'+id.slice(-8):name;}

function appName(id){return source.appNames?.[id]||label(id);}
function selectableApps(){return [...new Set([...source.model.dimensions.application,...source.resourceGroupChoices||[]])];}

function policyName(id){return source.policyNames?.[id]||id;}

function resolvedSets(){return RequirementModel.resolve(profile.sets,source.records).resolved;}

function uniqueId(prefix){return prefix+'-'+crypto.randomUUID();}

function options(values,selected=[],formatter=label){return values.map(v=>`<option value="${esc(v)}" ${selected.includes(v)?'selected':''}>${esc(formatter(v))}</option>`).join('');}

function chosen(id){return [...$(id).selectedOptions].map(o=>o.value);}

function beginSourceLoad(){
 const generation=++authGeneration;clearTimeout(pollTimer);CollectionProgress.stop();
 if(signinWindow&&!signinWindow.closed){try{signinWindow.close();}catch{}}
 signinWindow=null;workflowCollecting=false;
 $('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#cancel-token').hidden=true;$('#disconnect').hidden=true;
 $('#connection-state').textContent='';$('#token-connection-state').textContent='';updateWorkflowFooter();
 return generation;
}

async function adopt(next,original,{demo=false,generation=authGeneration}={}){

 if(generation!==authGeneration)return false;

 if(busy)throw Error('Wait for the coverage check to finish before replacing its data.');

 clearError();

 const stored=await api('/api/workspace/load',{key:next.key});
 if(generation!==authGeneration)return false;
 if(busy)throw Error('Wait for the coverage check to finish before replacing its data.');
 let nextProfile=stored.profile||RequirementModel.defaults();if(demo)nextProfile=DemoSnapshot.profile(nextProfile);

 if(!stored.profile&&demo)nextProfile.requirements=[{id:'demo-mfa',name:'All accounts require MFA',origin:'demo',accountSetId:'all',outcome:'mfa',enabled:true},{id:'demo-admin',name:'Privileged accounts require phishing-resistant MFA',origin:'demo',accountSetId:'privileged',outcome:'phishingResistant',enabled:true}];

 RequirementModel.resolve(nextProfile.sets,next.records);

 workflowCollecting=false;source=next;source.original=original;source.recordById=new Map(source.records.map(u=>[u.id,u]));profile=nextProfile;accountDisplayCounts=new Map();for(const u of source.records){const name=u.displayName||u.userPrincipalName||u.id;accountDisplayCounts.set(name,(accountDisplayCounts.get(name)||0)+1);}
 assessmentModel=null;coverageAccountGroups=null;accountCheckId=null;accountPickerPage=0;selectedReviewRequirement=null;requirementAccountPage=0;reviewPane='overview';reviewSetMemberships.clear();
 $('#account-check-search').value='';$('#account-check-type').value='all';$('#account-check-protection').value='all';$('#search').value='';$('#origin-filter').value='all';
 $('#edit-network-trust').hidden=!Array.isArray(original?.users)||!Array.isArray(original?.policies);

 $('#source-label').textContent=(source.isDemo||source.kind==='demo'?'Demo':source.name)+' · '+source.records.length.toLocaleString()+' accounts · '+source.policies.length.toLocaleString()+' policies';$('#source-label').title=source.name+' — Review loaded data';$('#source-label').disabled=false;

 $('#source-summary').hidden=false;$('#source-name').textContent=source.name;

 $('#source-readiness').innerHTML=ReviewPresentation.readiness(original).map(row=>`<div class="readiness-item ${row.kind}"><strong>${esc(row.label)}</strong><span>${row.kind==='met'?'✓':'!'} ${esc(row.text)}${row.count===null?'':' · '+row.count.toLocaleString()}</span></div>`).join('');
 $('#import-next-step').innerHTML=source.records.length?'Next: define the account sets you want to protect, then choose what protection they need.':'This file has no accounts. You can view its policies below, but need an export with accounts to find who has a gap. <button id="get-complete-export" class="text-button">Export policies and accounts →</button>';
 $('#import-next-step').hidden=source.records.length>0;

 if(!source.records.length)$('#get-complete-export').onclick=()=>{selectImportMethod('cloudshell');$('#import-selection').scrollIntoView({behavior:'smooth'});};
 $('#source-counts').textContent=`${source.policies.length.toLocaleString()} ${source.policies.length===1?'policy':'policies'} · ${source.records.length.toLocaleString()} ${source.records.length===1?'account':'accounts'}`;

 const issues=source.issues;

 $('#source-issues').innerHTML=issues.length?`<div class="notice warning">${issues.length} coverage ${issues.length===1?'issue needs':'issues need'} review. <a href="#source-summary" id="expand-support">Show details</a></div>`:'';

 if(issues.length)$('#expand-support').onclick=e=>{e.preventDefault();$('#source-summary details').open=true;};

 $('#policy-list').innerHTML=source.policies.map(p=>{const issue=issues.filter(i=>i.policyId===p.id);const state=p.state||'unknown';return `<div class="inventory-row"><strong>${esc(policyName(p.id))}</strong><span>${esc(state)}</span><span>${esc(issue.length?issue.map(i=>i.message).join(' '):state==='enabled'?((Object.hasOwn(source.policyDetails||{},p.id)||source.model.policies.some(p2=>p2.id===p.id))?'Evaluated'+(source.policyDetails?.[p.id]?.length?' · '+source.policyDetails[p.id].join(' '):''):'Outside supported user scope'):state==='reportOnly'||state==='enabledForReportingButNotEnforced'?'Report-only; not enforced':'Not enforced')}</span></div>`;}).join('')+(issues.some(i=>!i.policyId)?`<ul>${issues.filter(i=>!i.policyId).map(i=>`<li>${esc(i.message)}</li>`).join('')}</ul>`:'');

 resetResults();renderSets();renderRequirements();showTab('data');$('#source-summary').scrollIntoView({behavior:'smooth',block:'start'});
 return true;

}

async function loadDemo(){
 if(busy)return;if(!lab)throw Error('Demo data is still loading. Try again in a moment.');const generation=beginSourceLoad();
 const snapshot=DemoSnapshot.build(lab,{size:Number($('#demo-size').value),scenario:$('#demo-scenario').value});
 const next={...SnapshotModel.normalize(snapshot),key:'demo:architecture',isDemo:true};
 if(await adopt(next,snapshot,{demo:true,generation}))toast('Demo loaded. It replaces the previously loaded data.');
}

function renderSets(){if(!source||!profile)return;const sets=resolvedSets();$('#set-list').innerHTML=`<article class="card set-card"><div class="row"><h2>All accounts</h2><span class="badge">Built-in</span></div><button class="count account-count" data-preview-set="all" aria-label="Preview all ${source.records.length.toLocaleString()} accounts">${source.records.length.toLocaleString()}</button><p class="small">Every account present in this snapshot.</p></article>`+profile.sets.map(s=>{const resolved=sets.get(s.id);return `<article class="card set-card"><div class="row"><h2>${esc(s.name)}</h2><span class="badge ${resolved.unknown.length?'warn':''}">${s.kind==='manual'?'Selected accounts':s.kind==='privileged'?'Role-based':'Filters'}</span></div><button class="count account-count" data-preview-set="${esc(s.id)}" aria-label="Preview ${esc(s.name)}: ${resolved.ids.length.toLocaleString()} accounts">${resolved.ids.length.toLocaleString()}</button><p class="small">${s.kind==='manual'?'Selected explicitly by account ID.':s.kind==='privileged'?(s.roleIds?s.roleIds.length+' selected roles, including PIM eligible.':'Microsoft privileged roles, including PIM eligible.'):s.clauses.map(c=>`${c.not?'NOT ':''}${accountFieldName(c.field)} ${{equals:'=',startsWith:'starts with',endsWith:'ends with',contains:'contains',hasValue:'has a value'}[c.operator]} ${c.operator==='hasValue'?'':accountClauseValue(c)}`).map(esc).join(s.match==='any'?' OR ':' AND ')}${resolved.unknown.length?`<br><strong>${resolved.unknown.length} unresolved accounts</strong>`:''}</p><div class="row"><button class="text-button" data-edit-set="${esc(s.id)}">Edit definition</button><button class="text-button" data-export-set="${esc(s.id)}">Export ↓</button>${['members','guests','privileged','breakglass'].includes(s.id)?'':`<button class="text-button" data-remove-set="${esc(s.id)}">Remove</button>`}</div></article>`;}).join('');document.querySelectorAll('[data-export-set]').forEach(b=>b.onclick=()=>download(AccountSetLibrary.export(profile.sets.filter(s=>s.id===b.dataset.exportSet)),'ca-account-sets.json'));document.querySelectorAll('[data-preview-set]').forEach(b=>b.onclick=()=>openSetPreview(b.dataset.previewSet));document.querySelectorAll('[data-edit-set]').forEach(b=>b.onclick=()=>openSet(b.dataset.editSet));document.querySelectorAll('[data-remove-set]').forEach(b=>b.onclick=async()=>{try{if(profile.requirements.some(r=>r.accountSetId===b.dataset.removeSet||(r.excludeSetIds||[]).includes(b.dataset.removeSet)))throw Error('This set is used by a requirement. Update that requirement first.');await saveProfile({...profile,sets:profile.sets.filter(s=>s.id!==b.dataset.removeSet)});renderSets();}catch(e){fail(e);}});}

let groupPickerTarget=null,groupPickerGeneration=0;
function renderGroupChoices(groups,online=false,hasMore=false){
 const query=$('#group-picker-search').value.trim().toLowerCase(),matches=online?groups:groups.filter(g=>(g.displayName+' '+g.id).toLowerCase().includes(query));
 $('#group-picker-results').innerHTML=matches.map(g=>`<button type="button" class="group-choice" data-choose-group="${esc(g.id)}"><strong>${esc(g.displayName||g.id)}</strong><small>${esc(g.id)}</small><span>${online?'Add to snapshot':'Use this group'}</span></button>`).join('')||'<p class="small">No matching groups. Search the connected tenant to find more.</p>';
 $('#group-picker-status').textContent=hasMore?'More than 50 matches. Type more of the name and search again.':`${matches.length} ${matches.length===1?'group':'groups'} ${online?'found online':'in your snapshot'}.`;
 $('#group-picker-results').querySelectorAll('[data-choose-group]').forEach(button=>button.onclick=()=>chooseDirectoryGroup(button.dataset.chooseGroup,online));
}
function openGroupPicker(input,button,field){
 groupPickerGeneration++;groupPickerTarget={input,button,field,source};$('#group-picker-search').value=input.value&&!(source.original?.groups||[]).some(g=>g.id===input.value)?input.value:'';$('#group-picker-online').disabled=false;$('#group-picker-results').setAttribute('aria-busy','false');renderGroupChoices(source.original?.groups||[]);$('#group-picker-dialog').showModal();
}
async function searchDirectoryGroups(){
 const target=groupPickerTarget,generation=++groupPickerGeneration;if(!target||source!==target.source)return;
 $('#group-picker-online').disabled=true;$('#group-picker-status').textContent='Searching this tenant…';
 try{const result=await api('/api/groups/search',{tenantId:source.original?.tenantId,query:$('#group-picker-search').value.trim()});if(generation!==groupPickerGeneration||source!==target.source||!$('#group-picker-dialog').open)return;renderGroupChoices(result.groups,true,result.hasMore);}
 catch(e){if(generation===groupPickerGeneration&&source===target.source&&$('#group-picker-dialog').open)$('#group-picker-status').textContent=e.message;}
 finally{if(generation===groupPickerGeneration)$('#group-picker-online').disabled=false;}
}
async function chooseDirectoryGroup(id,online){
 const target=groupPickerTarget,generation=++groupPickerGeneration;if(!target||source!==target.source)return;
 $('#group-picker-online').disabled=true;$('#group-picker-results').setAttribute('aria-busy','true');$('#group-picker-results').querySelectorAll('button').forEach(b=>b.disabled=true);
 try{
  const needsPim=target.field==='eligibleGroupIds',complete=source.original?.completeness||{};
  const needsRead=online||needsPim&&complete.pimGroupEligibility!==true&&complete['pimGroupEligibility:'+id]!==true;
  if(needsRead){
   $('#group-picker-status').textContent='Adding group and reading its memberships…';
   const evidence=await api('/api/groups/read',{tenantId:source.original?.tenantId,groupId:id,includePimGroups:needsPim||complete.pimGroupEligibility===true||complete['pimGroupEligibility:'+id]===true});
   if(generation!==groupPickerGeneration||source!==target.source||!$('#group-picker-dialog').open)return;
   const original=GroupDirectory.merge(source.original,evidence),normalized=SnapshotModel.normalize(original);
   source={...normalized,key:source.key,name:source.name,kind:source.kind,isDemo:source.isDemo,original};
   resetResults('A group was added to your snapshot. Check coverage again to include its membership.');
  }
  const group=source.original?.groups?.find(g=>g.id===id);target.input.value=id;target.button.textContent=group?.displayName||id;target.button.title=id;
  $('#group-picker-dialog').close();renderSetPreview();
 }catch(e){if(generation===groupPickerGeneration&&source===target.source&&$('#group-picker-dialog').open){$('#group-picker-status').textContent=e.message;$('#group-picker-results').querySelectorAll('button').forEach(b=>b.disabled=false);}}
 finally{if(generation===groupPickerGeneration){$('#group-picker-online').disabled=false;$('#group-picker-results').setAttribute('aria-busy','false');}}
}
// Group picker bindings
$('#group-picker-search').oninput=()=>{groupPickerGeneration++;$('#group-picker-online').disabled=false;renderGroupChoices(source?.original?.groups||[]);};
$('#group-picker-online').onclick=searchDirectoryGroups;
$('#group-picker-search').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();searchDirectoryGroups();}};
$('#group-picker-dialog').addEventListener('close',()=>{groupPickerGeneration++;groupPickerTarget=null;});

function clauseRow(c={field:'userType',operator:'equals',value:'Member'}){
 const row=document.createElement('div');row.className='clause';
 row.innerHTML=`<select aria-label="Account attribute">${options(RequirementModel.fields,[c.field],accountFieldName)}</select><select aria-label="Filter condition">${options(['equals','startsWith','endsWith','contains','hasValue'],[c.operator],v=>({equals:'Equals',startsWith:'Starts with',endsWith:'Ends with',contains:'Has this ID',hasValue:'Has a value'}[v]))}</select><input aria-label="Filter value" value="${esc(c.value)}" placeholder="Value or group/role ID"><select aria-label="Account status value" hidden>${options(['true','false'],[String(c.value).toLowerCase()],v=>v==='true'?'Enabled':'Disabled')}</select><button class="text-button" type="button" aria-label="Remove condition">×</button><label class="check"><input type="checkbox" ${c.not?'checked':''}>NOT</label>`;
 const selects=row.querySelectorAll('select'),value=row.querySelector('input:not([type=checkbox])'),status=selects[2];
 const groupButton=document.createElement('button');groupButton.type='button';groupButton.className='secondary group-filter-choice';value.after(groupButton);groupButton.onclick=()=>openGroupPicker(value,groupButton,selects[0].value);
 function update(){const boolean=selects[0].value==='accountEnabled';value.hidden=boolean;status.hidden=!boolean;
  const group=['groupIds','eligibleGroupIds'].includes(selects[0].value);groupButton.hidden=!group;if(group){value.hidden=true;groupButton.textContent=source.original?.groups?.find(g=>g.id===value.value)?.displayName||value.value||'Choose a group…';groupButton.title=value.value;groupButton.disabled=selects[1].value==='hasValue';}
  for(const option of selects[1].options)option.disabled=boolean&&option.value!=='equals';
  if(boolean)selects[1].value='equals';value.disabled=selects[1].value==='hasValue';
  selects[1].querySelector('option[value=contains]').textContent=['groupIds','eligibleGroupIds','roleIds','otherMails','externalUserType'].includes(selects[0].value)?'Has this value':'Contains';
 }
 selects[0].onchange=()=>{if(['groupIds','eligibleGroupIds'].includes(selects[0].value)&&!['groupIds','eligibleGroupIds'].includes(c.field))value.value='';update();};selects[1].onchange=update;update();row.querySelector('[aria-label="Remove condition"]').onclick=()=>{row.remove();renderSetPreview();};return row;
}

let roleSelection=new Set(),roleSelectionCustom=false,previewRows=[],previewPage=0;
function roleCatalog(){const roles=(source.original?.roles||[]).map(r=>({...r,name:r.displayName||r.id}));for(const id of roleSelection)if(!roles.some(r=>r.id===id))roles.push({id,name:id,isPrivileged:null});return roles.sort((a,b)=>Number(b.isPrivileged===true)-Number(a.isPrivileged===true)||a.name.localeCompare(b.name));}
function defaultRoleSelection(){return new Set((source.original?.roles||[]).filter(r=>r.isPrivileged===true).map(r=>r.id));}
function renderRoles(){const query=$('#role-search').value.trim().toLowerCase(),catalog=roleCatalog();$('#role-catalog-note').textContent=source.original?.completeness?.roles===true?(roleSelectionCustom?roleSelection.size+' selected roles':'Microsoft privileged roles selected by default'):'Role catalog is incomplete. Import role definitions to see every available role.';$('#role-list').innerHTML=catalog.filter(r=>(r.name+' '+r.id).toLowerCase().includes(query)).map(r=>`<label class="check role-choice"><input type="checkbox" value="${esc(r.id)}" ${roleSelection.has(r.id)?'checked':''}><span>${esc(r.name)} <small class="badge ${r.isPrivileged===true?'warn':''}">${r.isPrivileged===true?'Privileged':r.isPrivileged===false?'Other role':'Classification unavailable'}</small></span></label>`).join('')||'<p class="small">No matching roles in this export.</p>';$('#role-list').querySelectorAll('input').forEach(box=>box.onchange=()=>{roleSelectionCustom=true;if(box.checked)roleSelection.add(box.value);else roleSelection.delete(box.value);renderRoles();renderSetPreview();});}
function openSet(id=null,draft=null){if(!source)return;editingSet=id;$('#set-dialog-title').textContent=profile.sets.some(s=>s.id===id)?'Edit account set':'Create an account set';const set=draft||profile.sets.find(s=>s.id===id)||{name:'',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Member'}],accountIds:[]};$('#set-name').value=set.name;$('#set-kind').value=set.kind;$('#set-match').value=set.match||'all';manualSelection=new Set(set.accountIds||[]);manualPage=0;roleSelectionCustom=Array.isArray(set.roleIds);roleSelection=roleSelectionCustom?new Set(set.roleIds):defaultRoleSelection();$('#role-search').value='';$('#manual-search').value='';$('#clause-list').replaceChildren(...(set.clauses||[{field:'userType',operator:'equals',value:'Member'}]).map(clauseRow));$('#set-form-error').hidden=true;renderRoles();toggleSetKind();$('#set-dialog').showModal();}
function readSetDraft(){const set={id:editingSet||'preview-account-set',name:$('#set-name').value.trim()||'Account set preview',kind:$('#set-kind').value,match:$('#set-match').value,accountIds:[...manualSelection],clauses:[...$('#clause-list').children].map(row=>{const selects=row.querySelectorAll('select');return {field:selects[0].value,operator:selects[1].value,value:selects[0].value==='accountEnabled'?selects[2].value:row.querySelector('input:not([type=checkbox])').value.trim(),not:row.querySelector('input[type=checkbox]').checked};})};if(set.kind==='privileged'&&roleSelectionCustom)set.roleIds=[...roleSelection];return set;}
function renderSetPreview(){if(!source)return;try{const draft=readSetDraft();if(draft.kind==='filter'&&(!draft.clauses.length||draft.clauses.some(c=>c.operator!=='hasValue'&&!c.value))||draft.kind==='privileged'&&draft.roleIds?.length===0)throw Error('Incomplete definition');const resolved=RequirementModel.resolve([draft],source.records).resolved.get(draft.id);$('#set-live-preview').innerHTML=`<strong>${resolved.ids.length} accounts included${resolved.unknown.length?' · '+resolved.unknown.length+' cannot confirm':''}</strong><button type="button" class="text-button" id="preview-draft-set">Preview accounts</button>`;$('#preview-draft-set').onclick=()=>openSetPreview(draft);}catch(e){$('#set-live-preview').textContent='Complete the definition to preview matching accounts.';}}
function toggleSetKind(){$('#filter-editor').hidden=$('#set-kind').value!=='filter';$('#manual-editor').hidden=$('#set-kind').value!=='manual';$('#role-editor').hidden=$('#set-kind').value!=='privileged';renderManual();renderSetPreview();}
function renderManual(){
 if(!source)return;const query=$('#manual-search').value.trim().toLowerCase();
 const records=source.records.filter(u=>[u.displayName,u.userPrincipalName,u.id].join(' ').toLowerCase().includes(query)),page=ReviewPresentation.page(records,manualPage);manualPage=page.index;
 $('#manual-list').innerHTML=page.items.map(u=>`<label class="check"><input type="checkbox" value="${esc(u.id)}" ${manualSelection.has(u.id)?'checked':''}><span><strong>${esc(accountName(u.id))}</strong><small>${esc(u.userPrincipalName||u.id)} · ${esc(u.userType||'Account')}</small></span></label>`).join('')||'<p class="small">No accounts match. Try another name, address or ID.</p>';
 $('#manual-selection-count').textContent=manualSelection.size.toLocaleString()+(manualSelection.size===1?' account selected':' accounts selected');$('#manual-page').textContent=page.label;$('#manual-previous').disabled=page.index===0;$('#manual-next').disabled=page.index===page.pages-1;
 $('#manual-list').querySelectorAll('input').forEach(input=>input.onchange=()=>{if(input.checked)manualSelection.add(input.value);else manualSelection.delete(input.value);$('#manual-selection-count').textContent=manualSelection.size.toLocaleString()+(manualSelection.size===1?' account selected':' accounts selected');renderSetPreview();});
}


async function saveSet(e){e.preventDefault();try{if(!$('#set-name').value.trim())throw Error('Name the account set.');const set=readSetDraft();set.id=editingSet||uniqueId('set');if(set.kind==='filter'&&set.clauses.some(c=>c.operator!=='hasValue'&&!c.value))throw Error('Enter a value for each filter.');if(set.kind==='privileged'&&set.roleIds?.length===0)throw Error('Select at least one role.');const next={...profile,sets:[...profile.sets.filter(s=>s.id!==editingSet),set]};RequirementModel.resolve(next.sets,source.records);await saveProfile(next);$('#set-dialog').close();renderSets();toast('Account definition saved.');}catch(e){fail(e,'#set-form-error');}}
function openSetPreview(value){const set=typeof value==='string'?profile.sets.find(s=>s.id===value):value,resolved=value==='all'?{ids:source.records.map(u=>u.id),unknown:[]}:RequirementModel.resolve([set],source.records).resolved.get(set.id);$('#set-preview-title').textContent=set?.name||'All accounts';$('#set-preview-count').textContent=resolved.ids.length+' included'+(resolved.unknown.length?' · '+resolved.unknown.length+' cannot confirm':'');previewRows=[...resolved.ids.map(id=>({id,unknown:false})),...resolved.unknown.map(id=>({id,unknown:true}))].sort((a,b)=>Number(a.unknown)-Number(b.unknown)||accountName(a.id).localeCompare(accountName(b.id)));previewPage=0;$('#set-preview-search').value='';renderSetAccounts();$('#set-preview-dialog').showModal();}
function renderSetAccounts(){const query=$('#set-preview-search').value.trim().toLowerCase(),rows=previewRows.filter(r=>{const u=source.recordById.get(r.id);return [accountName(r.id),u?.userPrincipalName,r.id,u?.userType].join(' ').toLowerCase().includes(query);}),pages=Math.max(1,Math.ceil(rows.length/50));previewPage=Math.min(previewPage,pages-1);$('#set-preview-list').innerHTML=rows.slice(previewPage*50,previewPage*50+50).map(row=>{const u=source.recordById.get(row.id);return `<div class="set-account-row"><strong>${esc(accountName(row.id))}</strong><span>${esc(u?.userPrincipalName||row.id)}</span><small>${esc(u?.userType||'Account')}${u?.eligibleRoleIds?.length||u?.pimEligible?' · PIM eligible':''}${u?.accountEnabled===false?' · Disabled':''}</small>${row.unknown?'<span class="badge warn">Cannot confirm membership</span>':''}</div>`;}).join('')||'<p>No matching accounts.</p>';$('#set-preview-page').textContent=rows.length?(previewPage*50+1)+'–'+Math.min(rows.length,previewPage*50+50)+' of '+rows.length:'0 accounts';$('#set-preview-previous').disabled=previewPage===0;$('#set-preview-next').disabled=previewPage>=pages-1;}
$('#role-search').oninput=renderRoles;$('#default-roles').onclick=()=>{roleSelectionCustom=false;roleSelection=defaultRoleSelection();renderRoles();renderSetPreview();};$('#all-roles').onclick=()=>{roleSelectionCustom=true;roleSelection=new Set(roleCatalog().map(r=>r.id));renderRoles();renderSetPreview();};$('#set-form').addEventListener('input',e=>{if(!['role-search','manual-search'].includes(e.target.id))renderSetPreview();});$('#set-form').addEventListener('change',renderSetPreview);$('#set-preview-search').oninput=()=>{previewPage=0;renderSetAccounts();};$('#set-preview-previous').onclick=()=>{previewPage--;renderSetAccounts();};$('#set-preview-next').onclick=()=>{previewPage++;renderSetAccounts();};

let editorChoices={apps:new Set(),networks:new Set(),clients:new Set(),platforms:new Set(),signInRiskLevels:new Set(),userRiskLevels:new Set()};
function deviceClauseRow(c={property:'deviceOwnership',operator:'eq',value:'Company'}){
 const row=document.createElement('div');row.className='clause';
 const properties=[...Object.keys(DeviceFilter.properties),...Array.from({length:15},(_,i)=>'extensionAttribute'+(i+1))];
 row.innerHTML=`<select aria-label="Device attribute">${options(properties,[c.property],v=>label('device.'+v))}</select><select aria-label="Device comparison">${options(['eq','ne','startswith','notstartswith','endswith','notendswith','contains','notcontains'],[c.operator],v=>({eq:'Equals',ne:'Does not equal',startswith:'Starts with',notstartswith:'Does not start with',endswith:'Ends with',notendswith:'Does not end with',contains:'Contains',notcontains:'Does not contain'}[v]))}</select><input aria-label="Device value" value="${esc(c.value)}" placeholder="Value"><button type="button" class="text-button" aria-label="Remove device condition">Remove</button>`;
 row.querySelector('button').onclick=()=>{row.remove();updateRequirementPreview();};return row;
}
$('#add-device-condition').onclick=()=>{$('#req-device-clauses').append(deviceClauseRow());updateRequirementPreview();};
function builderContext(){return {sets:profile.sets,appNames:Object.fromEntries(selectableApps().map(id=>[id,appName(id)])),networkNames:{...Object.fromEntries((source.model.dimensions.network||[]).map(id=>[id,label(id)])),...Object.fromEntries((source.locationChoices||[]).map(n=>[n.id,n.name])),...source.networkNames}};}
let requirementReviewGeneration=0,requirementReviewTimer;
function renderRequirementReview(review){
 const panel=$('#requirement-review'),findings=review.findings||[];
 panel.hidden=!findings.length&&review.status==='complete';
 if(panel.hidden){panel.innerHTML='';return;}
 panel.innerHTML='<h2>Requirements needing review</h2><p>'+(findings.length?'These restrictions may block more access than intended. Your policy coverage is checked separately.':'The requirements review could not finish. You can still check policy coverage.')+'</p>'+findings.map(f=>{
  const names={apps:'apps',networks:'networks',devices:'devices'},count=f.confirmedAccountIds.length,possible=f.possibleAccountIds.length;
  const who=[count?`${count} ${count===1?'account is':'accounts are'} in all these scopes`:'',possible?`${possible}${count?' more':''} ${possible===1?'account may':'accounts may'} be in scope`:''].filter(Boolean).join('; ');
  return `<article class="requirement-review-item"><h3>No shared ${names[f.kind]||'selection'}</h3><p>${esc(who)}. Where these requirements apply together, none of the selected ${names[f.kind]||'choices'} meet them all. Blocking access could satisfy them — check whether that is what you intended.</p><div class="requirement-review-rules">${f.requirementIds.map(id=>{const rule=profile.requirements.find(r=>r.id===id);return `<div><button type="button" class="secondary" data-review-requirement="${esc(id)}">Edit requirement: ${esc(rule?.name||id)}</button><p>${esc(rule?RequirementBuilder.describe(rule,builderContext()):'')}</p></div>`;}).join('')}</div></article>`;
 }).join('')+(review.status!=='complete'?'<p class="requirement-review-limit" role="status">'+esc(review.message||'Try again after completing your requirement selections.')+'</p>':'')+'<details><summary>What this review checks</summary><p>Looks for overlapping “only these apps”, “only these networks” and “only these devices” requirements with no shared selection. It uses the accounts and details in your loaded data. It does not test whether sign-in will succeed or rule out every possible conflict. Stronger MFA and additional device protection can work together.</p></details>';
 panel.querySelectorAll('[data-review-requirement]').forEach(button=>button.onclick=()=>openRequirement(button.dataset.reviewRequirement));
}
function reviewRequirements(){
 const generation=++requirementReviewGeneration,reviewSource=source,reviewProfile=profile,panel=$('#requirement-review');
 clearTimeout(requirementReviewTimer);panel.hidden=true;panel.innerHTML='';
 requirementReviewTimer=setTimeout(async()=>{
  try{const review=await CoverageProgress.review(reviewSource,reviewProfile);if(generation!==requirementReviewGeneration||source!==reviewSource||profile!==reviewProfile)return;renderRequirementReview(review);}
  catch{if(generation!==requirementReviewGeneration||source!==reviewSource||profile!==reviewProfile)return;renderRequirementReview({status:'incomplete',findings:[],message:'Refresh CALens to try the requirements review again. You can still check policy coverage.'});}
 },200);
}
function renderRequirements(){
 if(!source||!profile)return;const resolved=resolvedSets(),context=builderContext();
 $('#requirement-list').innerHTML=profile.requirements.length?profile.requirements.map(r=>{
  let scope;try{scope=RequirementModel.scope(r,resolved);}catch{scope={confirmed:[],unknown:[]};}const count=scope.confirmed.length,scopeLabel=`${count} ${count===1?'account':'accounts'} ${scope.unknown.length?'confirmed ':''}in scope${scope.unknown.length?' / '+scope.unknown.length+(scope.unknown.length===1?' needs':' need')+' scope confirmation':''}`;
  const state=r.pendingSetup?.length?'NEEDS SETUP':r.enabled===false?'DISABLED':r.origin?.includes(':customized')?'CUSTOMIZED TEMPLATE':r.origin?.startsWith('template')?'TEMPLATE REQUIREMENT':'YOUR REQUIREMENT';
  return `<article class="card requirement-card"><div class="row"><div><div class="eyebrow">${state}</div><h2>Requirement: ${esc(r.name)}</h2><p class="requirement-sentence">${esc(RequirementBuilder.describe(r,context))}</p><span class="small">${esc(scopeLabel)}${r.enabled===false?' / Not included in checks':''}</span></div><div><button class="secondary" data-edit-req="${esc(r.id)}">Edit</button><button class="text-button" data-duplicate-req="${esc(r.id)}">Duplicate</button><button class="text-button" data-remove-req="${esc(r.id)}">Delete</button></div></div></article>`;
 }).join(''):'<div class="empty requirements-empty"><h2>No requirements yet</h2><p>Choose a template or describe the protection your accounts need.</p><div class="button-actions"><button type="button" id="empty-templates" class="primary">Browse templates</button><button type="button" id="empty-requirement" class="secondary">Create a requirement</button></div></div>';
 $('#new-requirement').hidden=!profile.requirements.length;$('#requirements .template-bar').hidden=!profile.requirements.length;$('#requirements .template-sources').hidden=!profile.requirements.length;
 if($('#empty-templates'))$('#empty-templates').onclick=openTemplates;
 if($('#empty-requirement'))$('#empty-requirement').onclick=()=>openRequirement();
 document.querySelectorAll('[data-edit-req]').forEach(b=>b.onclick=()=>openRequirement(b.dataset.editReq));
 document.querySelectorAll('[data-remove-req]').forEach(b=>b.onclick=async()=>{try{await saveProfile({...profile,requirements:profile.requirements.filter(r=>r.id!==b.dataset.removeReq)});renderRequirements();}catch(e){fail(e);}});
 document.querySelectorAll('[data-duplicate-req]').forEach(b=>b.onclick=async()=>{try{const copy=structuredClone(profile.requirements.find(r=>r.id===b.dataset.duplicateReq));copy.id=uniqueId('req');copy.name+=' (copy)';await saveProfile({...profile,requirements:[...profile.requirements,copy]});renderRequirements();openRequirement(copy.id);}catch(e){fail(e);}});
 reviewRequirements();
}
function renderEditorChoices(field,values=[],nameFor=label){
 const query=field==='apps'?$('#req-app-search').value.trim().toLowerCase():'';
 const matches=values.filter(id=>!query||[nameFor(id),id].join(' ').toLowerCase().includes(query)),page=ReviewPresentation.page(matches,field==='apps'?appChoicePage:0,field==='apps'?50:Math.max(1,matches.length)),shown=page.items;if(field==='apps')appChoicePage=page.index;
 $('#req-'+field).innerHTML=shown.map(id=>`<label class="check"><input type="checkbox" data-rule-choice="${field}" value="${esc(id)}" ${editorChoices[field].has(id)?'checked':''}><span>${esc(nameFor(id))}</span></label>`).join('')+(!shown.length?'<p class="small">No matching choices.</p>':'');
 if(field==='apps'&&page.pages>1){const pager=document.createElement('div');pager.className='account-picker-pages';pager.innerHTML='<button type="button" class="secondary" data-app-page="previous">Previous</button><span class="small">'+esc(page.label)+'</span><button type="button" class="secondary" data-app-page="next">Next</button>';for(const button of pager.querySelectorAll('button')){button.disabled=button.dataset.appPage==='previous'?page.index===0:page.index===page.pages-1;button.onclick=()=>{appChoicePage+=button.dataset.appPage==='previous'?-1:1;renderEditorChoices(field,values,nameFor);};}$('#req-'+field).append(pager);}
 if(field==='apps'&&source.original?.caGapSnapshotVersion===1&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(query)&&!values.includes(query)){
  const button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='Use this application ID';button.onclick=()=>{editorChoices.apps.add(query);$('#req-app-search').value='';appChoicePage=0;renderEditorChoices('apps',selectableApps(),appName);updateRequirementPreview();};$('#req-apps').append(button);
 }
 document.querySelectorAll(`[data-rule-choice="${field}"]`).forEach(box=>box.onchange=()=>{if(box.checked)editorChoices[field].add(box.value);else editorChoices[field].delete(box.value);updateRequirementPreview();});
}
function readRequirementEditor(){
 const prior=profile.requirements.find(r=>r.id===editingRequirement),target=$('#req-target').value,scope=$('#req-app-scope').value,outcome=$('#req-outcome').value;
 const rule={...prior,id:editingRequirement||'preview',name:$('#req-name').value.trim(),accountSetId:$('#req-set').value,outcome,protections:[outcome,...($('#req-also-device').checked&&['mfa','phishingResistant','hybridJoined'].includes(outcome)?['compliant']:[]),...($('#req-also-hybrid').checked&&['mfa','phishingResistant','compliant'].includes(outcome)?['hybridJoined']:[])],flows:$('#req-flow-mode').value==='selected'?[...editorChoices.flows]:[],signInRiskLevels:$('#req-signin-risk-mode').value==='selected'?[...editorChoices.signInRiskLevels]:[],userRiskLevels:$('#req-user-risk-mode').value==='selected'?[...editorChoices.userRiskLevels]:[],apps:target==='apps'&&scope!=='all'?[...editorChoices.apps]:[],blockOtherApps:target==='apps'&&scope==='only',userAction:target.startsWith('action:')?target.slice(7):undefined,authenticationContextId:target.startsWith('context:')?target.slice(8)||undefined:undefined,networkMode:$('#req-network-mode').value,networks:[...editorChoices.networks],clients:[...editorChoices.clients],platforms:[...editorChoices.platforms],excludeSetIds:[...(prior?.excludeSetIds||[]).filter(id=>id!=='breakglass'),...($('#req-exclude-breakglass').checked?['breakglass']:[])],enabled:$('#req-enabled').checked};
 if($('#req-device-mode').value==='any')delete rule.deviceFilter;
 else rule.deviceFilter={mode:$('#req-device-mode').value,match:$('#req-device-match').value,clauses:[...$('#req-device-clauses').children].map(row=>({property:row.querySelectorAll('select')[0].value,operator:row.querySelectorAll('select')[1].value,value:row.querySelector('input').value.trim()}))};
 if(rule.userAction&&$('#req-registration-specific').checked){
   const context={resourceId:$('#req-registration-resource').value,mode:rule.userAction==='registerOrJoinDevices'?'deviceRegistration':$('#req-registration-mode').value,flow:$('#req-registration-flow').value};
   context.provenance=prior?.registrationContext&&['resourceId','mode','flow'].every(k=>prior.registrationContext[k]===context[k])?prior.registrationContext.provenance:{kind:'declared',description:'Context selected in the requirements builder; not an observed sign-in.'};rule.registrationContext=context;rule.flows=[];
 }else delete rule.registrationContext;
 if(rule.pendingSetup){rule.pendingSetup=RequirementBuilder.pending(rule);if(!rule.pendingSetup.length)delete rule.pendingSetup;}
 return rule;
}
function updateRequirementPreview(){
 const target=$('#req-target').value;
 $('#req-registration-context').hidden=!target.startsWith('action:');$('#req-registration-details').hidden=!$('#req-registration-specific').checked;$('#req-registration-mode-wrap').hidden=target!=='action:registerSecurityInformation';
 $('#req-device-selection').hidden=$('#req-device-mode').value==='any';
 $('#req-app-picker').hidden=target!=='apps';$('#req-app-selection').hidden=$('#req-app-scope').value==='all';$('#req-network-selection').hidden=$('#req-network-mode').value==='any';$('#req-device-wrap').hidden=!['mfa','phishingResistant','hybridJoined'].includes($('#req-outcome').value);$('#req-hybrid-wrap').hidden=!['mfa','phishingResistant','compliant'].includes($('#req-outcome').value);
 $('#req-flow-section').hidden=target.startsWith('action:')&&$('#req-registration-specific').checked;$('#req-flow-selection').hidden=$('#req-flow-mode').value!=='selected';
 const rule=readRequirementEditor();for(const [field,id] of [['signInRiskLevels','signin'],['userRiskLevels','user']]){const selected=$('#req-'+id+'-risk-mode').value==='selected';$('#req-'+id+'-risk-selection').hidden=!selected;if(selected&&!rule[field].length)rule.pendingSetup=[...new Set([...(rule.pendingSetup||[]),field])];}if(!rule.registrationContext&&$('#req-flow-mode').value==='selected'&&!rule.flows.length)rule.pendingSetup=[...new Set([...(rule.pendingSetup||[]),'flows'])];$('#req-preview').textContent=RequirementBuilder.describe(rule,builderContext());
 $('#req-app-chips').innerHTML=[...editorChoices.apps].map(id=>`<button type="button" class="chip" data-remove-app="${esc(id)}">${esc(appName(id))} / remove</button>`).join('');
 document.querySelectorAll('[data-remove-app]').forEach(b=>b.onclick=()=>{editorChoices.apps.delete(b.dataset.removeApp);appChoicePage=0;renderEditorChoices('apps',selectableApps(),appName);updateRequirementPreview();});
 const pending=RequirementBuilder.pending(rule);
 $('#req-readiness').textContent=pending.length?'Finish setup: '+pending.map(f=>({apps:'choose apps',networks:'choose networks',accountSetId:'choose accounts',authenticationContextId:'choose an available context',signInRiskLevels:'choose sign-in risk levels',userRiskLevels:'choose user risk levels',flows:'choose authentication flows'}[f]||f)).join(', '):rule.userAction?'Checks registration protection, including All-resources policies. It does not check whether accounts have registered methods.':rule.networkMode!=='any'&&(!source.networkEvaluationSupported||rule.networks.some(id=>source.locationSelectors&&!Object.hasOwn(source.locationSelectors,id)))?'Not yet assessable: named-location evaluation is not available for this snapshot.':'';
}
function openRequirement(id=null){appChoicePage=0;
 if(!source)return;editingRequirement=id;const r=profile.requirements.find(r=>r.id===id)||{name:'',accountSetId:'all',outcome:'mfa',enabled:true};
 $('#req-name').value=r.name;$('#req-set').innerHTML=options([...(r.accountSetId?[]:['']),'all',...profile.sets.map(s=>s.id)],[r.accountSetId||''],id=>id===''?'Choose an account set':id==='all'?'All accounts':profile.sets.find(s=>s.id===id).name);
 $('#req-outcome').value=r.outcome;$('#req-also-device').checked=(r.protections||[]).includes('compliant')&&r.outcome!=='compliant';$('#req-also-hybrid').checked=(r.protections||[]).includes('hybridJoined')&&r.outcome!=='hybridJoined';
 const contexts=Object.keys(source.model.dimensions).filter(k=>k.startsWith('authenticationContext.')).map(k=>'context:'+k.slice('authenticationContext.'.length));
 const targets=['apps','action:registerSecurityInformation','action:registerOrJoinDevices',...contexts];if(r.pendingSetup?.includes('authenticationContextId'))targets.push('context:');
 const selected=r.userAction?'action:'+r.userAction:r.authenticationContextId?'context:'+r.authenticationContextId:r.pendingSetup?.includes('authenticationContextId')?'context:':'apps';
 $('#req-target').innerHTML=options(targets,[selected],id=>id==='apps'?'Access an app':id==='action:registerSecurityInformation'?'Register security information (MFA / SSPR)':id==='action:registerOrJoinDevices'?'Register or join a device':id==='context:'?'Select an authentication context (export required)':'Authentication context '+id.slice(8));
 $('#req-registration-specific').checked=!!r.registrationContext;
 const resources=[...new Set([...source.model.dimensions.application.filter(id=>id!=='other-resource'),...(r.registrationContext?[r.registrationContext.resourceId]:[])])];
 $('#req-registration-resource').innerHTML=options(['',...resources],[r.registrationContext?.resourceId||''],id=>id?appName(id):'Choose a resource');$('#req-registration-mode').value=r.registrationContext?.mode==='interrupt'?'interrupt':'manage';$('#req-registration-flow').value=r.registrationContext?.flow||'standard';
 $('#req-app-scope').value=r.blockOtherApps?'only':r.apps?.length||r.pendingSetup?.includes('apps')?'selected':'all';$('#req-app-search').value='';
 $('#req-network-mode').value=r.networkMode||'any';$('#req-exclude-breakglass').checked=(r.excludeSetIds||[]).includes('breakglass');$('#req-exclude-breakglass').disabled=!profile.sets.some(s=>s.id==='breakglass');
 $('#req-device-mode').value=r.deviceFilter?.mode||'any';$('#req-device-match').value=r.deviceFilter?.match||'all';$('#req-device-clauses').replaceChildren(...(r.deviceFilter?.clauses||[{property:'deviceOwnership',operator:'eq',value:'Company'}]).map(c=>deviceClauseRow(c)));
 editorChoices=Object.fromEntries(['apps','networks','clients','platforms','flows','signInRiskLevels','userRiskLevels'].map(field=>[field,new Set(r[field]||[])]));
 renderEditorChoices('apps',selectableApps(),appName);
 renderEditorChoices('networks',source.locationChoices?.length?source.locationChoices.map(l=>l.id):source.model.dimensions.network,id=>builderContext().networkNames?.[id]||label(id));renderEditorChoices('clients',source.model.dimensions.client);renderEditorChoices('platforms',source.model.dimensions.platform);
 for(const [field,id,axis] of [['signInRiskLevels','signin','signInRisk'],['userRiskLevels','user','userRisk']]){$('#req-'+id+'-risk-mode').value=r[field]?.length?'selected':'any';$('#req-'+id+'-risk-mode').disabled=!source.model.dimensions[axis];renderEditorChoices(field,source.model.dimensions[axis]||[],v=>({none:'No risk',hidden:'Hidden / not disclosed',unknownFutureValue:'Unknown future value'}[v]||label(v)));}$('#req-risk-section').open=!!(r.signInRiskLevels?.length||r.userRiskLevels?.length);
 $('#req-flow-mode').value=r.flows?.length?'selected':'any';renderEditorChoices('flows',['standard','deviceCodeFlow','authenticationTransfer'],v=>({standard:'Standard / untracked sign-in',deviceCodeFlow:'Device code',authenticationTransfer:'Authentication transfer'}[v]));$('#req-flow-section').open=!!r.flows?.length;
 $('#req-enabled').checked=r.pendingSetup?.length?true:r.enabled!==false;$('#req-form-error').hidden=true;updateRequirementPreview();$('#requirement-dialog').showModal();
}
async function saveRequirement(e){
 e.preventDefault();try{
  const prior=profile.requirements.find(r=>r.id===editingRequirement),r=readRequirementEditor();r.id=editingRequirement||uniqueId('req');
  if(!r.name)r.name=(r.accountSetId==='all'?'All accounts':profile.sets.find(s=>s.id===r.accountSetId)?.name||'Accounts')+' - '+label(r.outcome);
  r.origin=prior?.origin?.startsWith('template')?prior.origin.replace(/:customized$/,'')+':customized':prior?.origin||'organization';
  for(const [field,id,name] of [['signInRiskLevels','signin','sign-in'],['userRiskLevels','user','user']])if($('#req-'+id+'-risk-mode').value==='selected'&&!r[field].length)throw Error('Select at least one '+name+' risk level.');
  if(!r.registrationContext&&$('#req-flow-mode').value==='selected'&&!r.flows.length)throw Error('Select at least one authentication flow.');
  if($('#req-target').value==='apps'&&$('#req-app-scope').value!=='all'&&!r.apps.length)throw Error('Select at least one app.');
  const next={...profile,requirements:[...profile.requirements.filter(r=>r.id!==editingRequirement),r]};if(r.enabled)RequirementModel.compile(next,source);
  await saveProfile(next);$('#requirement-dialog').close();renderRequirements();toast('Requirement saved.');
 }catch(e){fail(e,'#req-form-error');}
}
function openTemplates(){
 if(!source){toast('Load data first.');return;}
 const packs=[...new Set(RequirementBuilder.templates.map(t=>t.pack))];
 $('#template-catalog').innerHTML=packs.map(pack=>`<section class="template-pack"><h3>${esc(pack)}</h3>${RequirementBuilder.templates.filter(t=>t.pack===pack).map(t=>{const already=profile.requirements.some(r=>r.origin?.replace(/:customized$/,'')==='template:'+t.id);const preview=RequirementBuilder.create(t.id,'preview');return `<label class="template-choice"><input type="checkbox" data-template-id="${t.id}" ${already?'disabled':''}><span><strong>${esc(t.name)}${already?' / Already added':''}</strong><span class="small">${esc(t.description)}</span><span class="template-preview">${esc(RequirementBuilder.describe(preview,builderContext()))}</span>${t.setup?.length?'<span class="badge warn">Choose your apps, networks or context after adding</span>':''}</span></label>`;}).join('')}</section>`).join('');
 const update=()=>{const count=document.querySelectorAll('[data-template-id]:checked').length;$('#add-selected-templates').disabled=!count;$('#add-selected-templates').textContent=count?'Add '+count+' selected '+(count===1?'template':'templates'):'Select templates to add';};
 document.querySelectorAll('[data-template-id]').forEach(box=>box.onchange=update);update();$('#template-dialog').showModal();
}
$('#template-form').onsubmit=async e=>{e.preventDefault();try{const additions=[...document.querySelectorAll('[data-template-id]:checked')].map(box=>{const r=RequirementBuilder.create(box.dataset.templateId,uniqueId('req'));if(r.accountSetId!=='all'&&!profile.sets.some(s=>s.id===r.accountSetId)){r.accountSetId='';r.pendingSetup=[...new Set([...(r.pendingSetup||[]),'accountSetId'])];r.enabled=false;}return r;});await saveProfile({...profile,requirements:[...profile.requirements,...additions]});$('#template-dialog').close();renderRequirements();toast('Templates added. You can edit or delete any requirement.');}catch(e){fail(e);}};
function requirementFor(gap){return profile.requirements.find(r=>r.id===gap.requirementId||r.id+':outside-network'===gap.requirementId||r.id+':outside-apps'===gap.requirementId||r.id+':outside-device'===gap.requirementId);}
let coverageProgressTimer=null,coverageProgressStarted=0,coverageEtaState=null;
function coverageEtaUpdate(event,now=performance.now()){
 const counted=Number.isInteger(event.completed)&&Number.isInteger(event.total)&&event.total>0&&event.completed>=0&&event.completed<=event.total;
 if(!counted){coverageEtaState=null;return;}
 const key=[event.stage,event.message,event.unit||'accounts',event.total].join('|');
 if(!coverageEtaState||coverageEtaState.key!==key||event.completed<coverageEtaState.completed)coverageEtaState={key,points:[],started:now,completed:event.completed,total:event.total};
 const state=coverageEtaState;state.completed=event.completed;state.points.push({at:now,value:event.completed});
 while(state.points.length>2&&state.points[1].at<now-15000)state.points.shift();
}
function coverageEtaText(now=performance.now()){
 const state=coverageEtaState;if(!state)return 'Time remaining: estimating…';
 if(state.completed===state.total)return 'Finishing this stage…';
 const first=state.points[0],last=state.points.at(-1),elapsed=(now-first.at)/1000,advanced=state.completed-first.value;
 if(now-state.started<3000||state.points.length<3||advanced<=0||elapsed<=0)return 'Time remaining: estimating…';
 if(now-last.at>10000)return 'Time remaining: updating estimate…';
 const seconds=Math.max(5,Math.ceil((state.total-state.completed)/(advanced/elapsed)/5)*5);
 return 'About '+(seconds<60?seconds+' seconds':Math.ceil(seconds/60)+(Math.ceil(seconds/60)===1?' minute':' minutes'))+' left in this stage';
}
function coverageProgressStage(stage){
 const stages=['prepare','assess','results'],messages={prepare:'Preparing your requirements…',assess:'Checking your policies for missing protection…',results:'Building your coverage results…'};
 $('#coverage-progress-message').textContent=messages[stage];$('#coverage-progress-bar').setAttribute('aria-valuetext',messages[stage]);
 document.querySelectorAll('[data-coverage-stage]').forEach(item=>{const index=stages.indexOf(item.dataset.coverageStage),current=stages.indexOf(stage);item.classList.toggle('current',index===current);item.classList.toggle('complete',index<current);if(index===current)item.setAttribute('aria-current','step');else item.removeAttribute('aria-current');});
 $('#coverage-progress-bar').removeAttribute('value');
 $('#coverage-progress-bar').removeAttribute('data-determinate');
 for(const attribute of ['aria-valuemin','aria-valuemax','aria-valuenow'])$('#coverage-progress-bar').removeAttribute(attribute);
}
function coverageProgressUpdate(event){
 coverageEtaUpdate(event);
 coverageProgressStage(event.stage);
 let message=event.message;
 if(Number.isInteger(event.completed)&&Number.isInteger(event.total)&&event.total>0&&event.completed>=0&&event.completed<=event.total){
  const bar=$('#coverage-progress-bar');bar.setAttribute('data-determinate','true');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax',String(event.total));bar.setAttribute('aria-valuenow',String(event.completed));bar.style.setProperty('--coverage-progress',(100*event.completed/event.total)+'%');
  message+=' — '+event.completed.toLocaleString()+' of '+event.total.toLocaleString()+' '+(event.unit||'accounts');
 }
 const details=[];
 const req=profile.requirements.find(r=>r.id===event.requirementId||event.requirementId?.startsWith(r.id+':outside-'));
 if(event.requirementIndex>0&&event.requirementCount>0)details.push('Requirement '+event.requirementIndex+' of '+event.requirementCount+(req?' · '+req.name:''));
 if(event.regionOperations>0)details.push(event.regionOperations.toLocaleString()+' scenario checks');
 if(event.gapGroups>0)details.push(event.gapGroups.toLocaleString()+' potential gaps found');
 $('#coverage-progress-detail').textContent=details.join(' — ');
 $('#coverage-progress-eta').textContent=coverageEtaText();
 $('#coverage-progress-message').textContent=message;$('#coverage-progress-bar').setAttribute('aria-valuetext',message);
}
function startCoverageProgress(){
 const accountCount=source.records.length,requirementCount=profile.requirements.filter(r=>r.enabled!==false).length;
 coverageEtaState=null;$('#coverage-progress-eta').textContent=coverageEtaText();coverageProgressStarted=performance.now();$('#coverage-progress-elapsed').textContent='0 seconds';$('#coverage-progress-scope').textContent=accountCount.toLocaleString()+(accountCount===1?' account · ':' accounts · ')+requirementCount+(requirementCount===1?' requirement':' requirements');
 $('#coverage-progress-detail').textContent='';coverageProgressStage('prepare');$('#coverage-progress-dialog').showModal();document.querySelector('main').setAttribute('aria-busy','true');
 coverageProgressTimer=setInterval(()=>{const now=performance.now(),elapsed=(now-coverageProgressStarted)/1000,seconds=Math.floor(elapsed);$('#coverage-progress-eta').textContent=coverageEtaText(now);$('#coverage-progress-elapsed').textContent=seconds<60?elapsed.toFixed(1)+' seconds':Math.floor(seconds/60)+'m '+seconds%60+'s';},100);
}
function stopCoverageProgress(){clearInterval(coverageProgressTimer);coverageProgressTimer=null;$('#coverage-progress-dialog').close();document.querySelector('main').removeAttribute('aria-busy');}
function coveragePaint(){return new Promise(resolve=>{if(document.visibilityState==='hidden')setTimeout(resolve,0);else requestAnimationFrame(()=>requestAnimationFrame(resolve));});}
async function checkCoverage(){
 if(busy)return;
 try{
  clearError();if(!source?.records.length)throw Error('Load policies and accounts before checking coverage. A file with policies alone cannot tell us who is protected.');
  busy=true;document.querySelectorAll('.tabs button,#run,#rerun').forEach(b=>b.disabled=true);$('#run').textContent='Checking…';resetResults();assessmentModel=null;
  reviewPane='overview';$('#account-review-section').hidden=true;startCoverageProgress();await coveragePaint();
  const compiled=await CoverageProgress.compile(source,profile,coverageProgressUpdate);source=compiled.source;source.recordById=new Map(source.records.map(u=>[u.id,u]));
  coverageProgressUpdate({stage:'prepare',message:'Sending data to the local checker'});await coveragePaint();
  const issues=[...source.issues,...compiled.issues];
  result=source.kind==='snapshot'?await CoverageProgress.request('/api/assess',{snapshot:source.original,profile},sessionToken,coverageProgressUpdate):await CoverageProgress.request('/api/analyze',{model:compiled.model,coverageIssues:issues,sourceKey:source.key},sessionToken,coverageProgressUpdate);
  coverageProgressUpdate({stage:'results',message:'Loading your saved-check history'});await coveragePaint();
  if(result.sourceKey){try{result.savedRuns=await api('/api/history',{sourceKey:result.sourceKey});}catch{result.savedRuns={runs:[],unavailable:true};}}
  assessmentModel=compiled.model;result.sourceName=source.name;result.requirements=profile.requirements;result.assessmentNotes=source.notes||[];result.assessmentScope=source.assessmentScope||'';result.evidenceScope=source.kind==='snapshot'?'Minimum-protection assessment; offline findings. Session timing is outside scope.':'Finite mock or imported model; no real sign-ins.';
  selection=null;selectedGapKey=null;filter='open';$('#search').value='';$('#requirement-filter').innerHTML='<option value="all">All requirements</option>'+profile.requirements.filter(r=>r.enabled!==false).map(r=>'<option value="'+esc(r.id)+'">'+esc(r.name)+'</option>').join('');
  coverageProgressUpdate({stage:'results',message:'Drawing your coverage overview'});await coveragePaint();
  $('#result-empty').hidden=true;$('#result-body').hidden=false;$('#download-results').disabled=false;renderResults();
 }catch(e){resetResults();assessmentModel=null;fail(e);}
 finally{stopCoverageProgress();busy=false;document.querySelectorAll('.tabs button,#run,#rerun').forEach(b=>b.disabled=false);$('#run').textContent='Check coverage →';updateWorkflowFooter();if(result)showTab('results');}
}
$('#coverage-progress-dialog').addEventListener('cancel',e=>e.preventDefault());




function renderHistory(){
 const panel=$('#coverage-changes'),history=$('#coverage-history');panel.hidden=!result.changes;$('#coverage-changes-section').hidden=!result.changes;history.hidden=!result.savedRuns;
 if(!result.changes)return;
 const view=HistoryView.summary(result.changes),time=value=>RoleSchedules.instant(value)!==null?new Date(value).toLocaleString():'Time unavailable';
 panel.innerHTML=`<h2>${esc(view.title)}</h2>${view.details.map(text=>`<p>${esc(text)}</p>`).join('')}${result.changes.previousRunAtUtc?`<small>Compared with ${esc(time(result.changes.previousRunAtUtc))}</small>`:''}${view.examples.length?`<details><summary>Example accounts</summary><div class="chips">${view.examples.map(x=>`<span class="chip">${esc(accountName(x.accountId))} · ${x.kind==='new'?'New gaps':'Gaps closed'}</span>`).join('')}</div></details>`:''}`;
 const saved=result.savedRuns||{};
 $('#history-list').innerHTML=(saved.runs||[]).map(run=>`<div class="saved-run"><div><strong>${esc(time(run.runAtUtc))}</strong><small>${run.status!=='completeWithinModel'?'Incomplete check':`${run.score===null?'Not scored':esc(run.score)+'% coverage'} · ${esc(run.affected)} affected · ${esc(run.checked)} checked`}</small><small>Snapshot ${esc(time(run.snapshotCapturedAtUtc))}</small></div><button class="text-button" data-download-run="${esc(run.id)}">Export check</button></div>`).join('')+(saved.unavailable?'<p>Previous checks could not be loaded.</p>':saved.unreadable?'<p>Some previous checks could not be read.</p>':'')+(saved.runs?.length===saved.limit?`<p class="small">Latest ${saved.limit} checks shown.</p>`:'');
 document.querySelectorAll('[data-download-run]').forEach(button=>button.onclick=async()=>{try{await downloadServerReport('/api/history/export',{sourceKey:result.sourceKey,runId:button.dataset.downloadRun},'ca-check-'+button.dataset.downloadRun);}catch(e){fail(e);}});
}
function protectionLabel(r){const controls=r?.protections||[r?.outcome||'mfa'];return controls.map(p=>p==='compliant'?'a compliant device':p==='hybridJoined'?'a hybrid-joined device':label(p)).join(' and ');}
function findingUnverified(g){return g.assessmentStatus===undefined?!result.coverageSummary?.requirements.find(r=>r.id===requirementFor(g)?.id)?.complete:g.assessmentStatus!=='gapWithinModel';}
function issueLabel(g){if(g.unassessed)return 'Requirement not checked';const r=requirementFor(g);if(g.requirementId.endsWith(':outside-device'))return 'Access from other devices is not blocked';if(g.requirementId.endsWith(':outside-apps'))return 'Access to other apps is not blocked';if(g.requirementId.endsWith(':outside-network'))return 'Access outside allowed networks';const controls=r?.protections||[r?.outcome||'mfa'],missing=[];if(controls.includes('block'))return 'Access should be blocked';if(controls.includes('phishingResistant')&&g.witness.authentication!=='phishingResistant')missing.push('Phishing-resistant MFA missing');else if(controls.includes('mfa')&&g.witness.authentication==='password')missing.push('MFA missing');if(controls.includes('compliant')&&g.witness.compliant!=='true')missing.push('Compliant device missing');if(controls.includes('hybridJoined')&&g.witness.hybridJoined!=='true')missing.push('Hybrid-joined device missing');return missing.join(' / ')||'Requirement not met';}
function findingCaption(g){return findingUnverified(g)?'Cannot confirm: '+(requirementFor(g)?.name||'Requirement'):'Gap found: '+issueLabel(g);}
function scopeTags(g,compact=false){return ReviewPresentation.scope(g,source.model.dimensions,scenarioValue).filter(row=>!compact||['application','client','network','flow'].includes(row.axis)).map(row=>`<span class="scope-tag" title="${esc(label(row.axis)+': '+row.detail)}">${esc(label(row.axis))}: ${esc(row.text)}</span>`).join('');}
function issuesForFinding(g){const indices=g.coverageIssueIndices||[];const issues=indices.map(i=>result.coverageIssues?.[i]).filter(Boolean);return issues.length?issues:(result.coverageIssues||[]).filter(i=>!i.requirementId||requirementFor(g)?.id===i.requirementId||g.requirementId===i.requirementId);}
function reviewIssues(issues){return issues.map(i=>{const view=ReviewPresentation.issue(i,source.model);return `<li class="review-issue"><strong>${esc(view.title)}</strong><p>${esc(view.action)}</p><button class="text-button" data-review-pane="${esc(view.pane)}" data-review-requirement="${esc(i.requirementId||'')}">${view.pane==='requirements'?'Review requirement':view.pane==='sets'?'Review account definitions':'Review imported data'}</button>${view.details?'<details><summary>Technical details</summary><p>'+esc(view.details)+'</p></details>':''}</li>`;}).join('');}
function bindReviewActions(container){container.querySelectorAll('[data-review-pane]').forEach(b=>b.onclick=()=>{showTab(b.dataset.reviewPane);if(b.dataset.reviewPane==='requirements'){const r=requirementFor({requirementId:b.dataset.reviewRequirement});if(r)openRequirement(r.id);}if(b.dataset.reviewPane==='data'){$('#source-summary details').open=true;$('#source-summary').scrollIntoView({behavior:'smooth'});}});}
function acceptanceScope(g){const r=requirementFor(g);return `<p><strong>${esc(r?.name||g.requirementId)}</strong></p><div class="scope-tags">${scopeTags(g)}</div><p class="small">${g.identityIds.length} ${g.identityIds.length===1?'account':'accounts'} · Selected scenario only</p><div class="chips">${g.identityIds.slice(0,10).map(id=>'<span class="chip">'+esc(accountName(id))+'</span>').join('')}${g.identityIds.length>10?'<span class="chip">+'+(g.identityIds.length-10)+' more</span>':''}</div><details><summary>Full scenario conditions</summary>${visibleScenario(g.region,g.witness).map(([key,values])=>'<p class="small"><strong>'+esc(label(key))+'</strong>: '+values.map(v=>esc(scenarioValue(key,v))).join(', ')+'</p>').join('')}</details>`;}
function scenarioScope(g){
 if(g.unassessed)return requirementFor(g)?.name||'Requirement not checked';
 const dimensions=source.model.dimensions,rows=ReviewPresentation.scope(g,dimensions,scenarioValue),apps=g.region.application||[];
 const target=g.witness.accessTarget==='userAction'?label(g.witness.userAction):g.witness.accessTarget==='authenticationContext'?'Authentication-context request':apps.length===dimensions.application.length?'All apps':apps.length===1?appName(apps[0]):'Multiple apps';
 const detail=axis=>rows.find(row=>row.axis===axis)?.text;
 const client=(g.region.client||[]).length<dimensions.client?.length?detail('client'):null;
 return [target,detail('network'),client,detail('platform'),detail('flow'),detail('registrationContext')].filter(Boolean).join(' / ');
}
function renderCoverageCharts(summary){
 const colors={gap:'var(--danger)',unknown:'var(--amber)',met:'var(--success)',pending:'var(--muted)'};
 const remaining=Math.max(0,summary.checked-summary.affected);
 const slices=[{filter:'confirmed',label:'Confirmed gap',value:summary.confirmedAffected,color:colors.gap},{filter:'unknown',label:'Needs investigation',value:summary.unverifiedOnlyAffected,color:colors.unknown},{filter:summary.complete?'met':'unconfirmed',label:summary.complete?'Meet all requirements':'Not yet confirmed',value:remaining,color:summary.complete?colors.met:colors.pending}];
 const circumference=2*Math.PI*64;let offset=0;
 const rings=slices.filter(s=>s.value).map(s=>{const length=summary.checked?s.value/summary.checked*circumference:0;const ring=`<circle class="interactive-donut-segment" data-account-group="${s.filter}" role="button" tabindex="0" aria-label="${esc(s.label)}: ${s.value} accounts. Show accounts" cx="90" cy="90" r="64" fill="none" stroke="${s.color}" stroke-width="24" stroke-dasharray="${length} ${circumference-length}" stroke-dashoffset="${-offset}" transform="rotate(-90 90 90)"/>`;offset+=length;return ring;}).join('');
 const bars=[...summary.requirements].sort((a,b)=>b.confirmedAffected-a.confirmedAffected||b.unverifiedOnlyAffected-a.unverifiedOnlyAffected).map(row=>{
  const parts=[{label:'Confirmed gaps',value:row.confirmedAffected,color:colors.gap},{label:'Needs investigation',value:row.unverifiedOnlyAffected,color:colors.unknown},{label:row.complete?'Meet requirement':'Not yet confirmed',value:Math.max(0,row.checked-row.affected),color:row.complete?colors.met:colors.pending}];
  let start=0;const segments=parts.filter(p=>p.value).map(p=>{const width=row.checked?p.value/row.checked*100:0;const rect=`<rect x="${start}" y="0" width="${width}" height="12" fill="${p.color}"><title>${p.value} ${p.label.toLowerCase()}</title></rect>`;start+=width;return rect;}).join('');
  return `<button class="requirement-chart-row" data-requirement="${esc(row.id)}"><span class="row"><strong>${esc(row.name)}</strong><span>${row.confirmedAffected} with gaps / ${row.checked} in scope</span></span><svg class="requirement-bar" viewBox="0 0 100 12" preserveAspectRatio="none" role="img" aria-label="${esc(parts.map(p=>p.value+' '+p.label.toLowerCase()).join(', '))}"><rect width="100" height="12" fill="var(--raised)"/>${segments}</svg>${!row.checked?'<small>No accounts in scope</small>':row.unverifiedOnlyAffected?`<small>${row.unverifiedOnlyAffected} need investigation</small>`:''}</button>`;
 }).join('');
 $('#coverage-charts').innerHTML=`<article class="chart-card"><h2>Account protection</h2><p class="small">Each account appears once. Select a group to see its accounts.</p><div class="donut-layout"><svg viewBox="0 0 180 180" role="group" aria-label="${esc(slices.map(s=>s.value+' '+s.label.toLowerCase()).join(', '))}"><circle cx="90" cy="90" r="64" fill="none" stroke="var(--raised)" stroke-width="24"/>${rings}<g class="interactive-donut-centre" data-account-group="scope" role="button" tabindex="0" aria-label="Show all ${summary.checked} accounts in scope"><circle cx="90" cy="90" r="49" fill="transparent" pointer-events="all"/><text x="90" y="87" text-anchor="middle" class="donut-number">${summary.checked.toLocaleString()}</text><text x="90" y="108" text-anchor="middle" class="donut-caption">accounts in scope</text></g></svg><ul class="chart-legend">${slices.map(s=>`<li><button type="button" class="chart-filter-button" data-account-group="${s.filter}" aria-label="Show ${s.value} accounts: ${esc(s.label)}"><svg class="legend-dot" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="${s.color}"/></svg><span>${s.label}</span><strong>${s.value.toLocaleString()}</strong></button></li>`).join('')}</ul></div><p class="small">${summary.unchecked?summary.unchecked+' accounts are outside your requirements. ':''}${summary.acceptedOnly?summary.acceptedOnly+' accounts have accepted exceptions only. Their protection gaps remain in this chart.':'Green means every requirement in scope is met.'}</p></article><article class="chart-card"><h2>Coverage by requirement</h2><p class="small">Choose a requirement to see its accounts.</p><div class="chart-legend inline"><span><svg class="legend-dot" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="${colors.gap}"/></svg>Gap</span><span><svg class="legend-dot" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="${colors.unknown}"/></svg>Investigate</span><span><svg class="legend-dot" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="${colors.met}"/></svg>Meets requirement</span><span><svg class="legend-dot" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="${colors.pending}"/></svg>Not confirmed</span></div><div class="requirement-chart">${bars||'<p>No enabled requirements.</p>'}</div></article>`;
}
function renderAcceptedSummary(groups=coverageAccountGroups){
 const count=groups?.acceptedAny?.size||0,panel=$('#accepted-summary');panel.hidden=!count;
 panel.innerHTML=count?'<button type="button" class="text-button" data-account-group="acceptedAny">View accepted exceptions: '+count.toLocaleString()+' '+(count===1?'account':'accounts')+' →</button><span>Acceptance does not change the coverage result.</span>':'';
}
function renderResults(){
 const summary=CoverageSummary.build(result,assessmentModel,profile.requirements);result.coverageSummary=summary;coverageAccountGroups=ReviewPresentation.accountGroups(result,assessmentModel,summary);
 const unresolved=!summary.complete;reviewSetMemberships=ReviewPresentation.accountSetMemberships(profile.sets,resolvedSets());renderHistory();renderCoverageCharts(summary);renderAccountPicker();renderRequirementInvestigation();showReviewPane(reviewPane,false);
 $('#result-subtitle').textContent=source.name+' / '+(source.kind==='snapshot'?(RoleSchedules.instant(source.original?.capturedAtUtc)!==null?'Snapshot '+new Date(source.original.capturedAtUtc).toLocaleString():'Snapshot time not supplied or invalid'):'Checked '+new Date(result.runAtUtc).toLocaleString())+' / Compared with your saved requirements';
 $('#result-status').className='notice '+(unresolved||!summary.checked?'warning':summary.toReview?'danger':summary.affected?'warning':'success');
 $('#result-status').textContent=result.coverageIssues?.find(issue=>issue.code==='analysis-resource-limit')?.message||(unresolved?'Some requirements still need checking.':summary.toReview?`${summary.toReview} ${summary.toReview===1?'account needs':'accounts need'} attention.`:summary.affected?`${summary.affected} ${summary.affected===1?'account has':'accounts have'} accepted exceptions.`:summary.checked?'All checked accounts meet your requirements.':'No accounts are covered by these requirements.');
 $('#metrics').innerHTML=`<button type="button" class="score-card" data-account-group="met" ${summary.score===null?'disabled':''} title="Show accounts meeting all requirements"><span>Requirement coverage</span><strong>${summary.score===null?'Not scored':summary.score+'%'}</strong><progress max="100" value="${summary.score||0}" aria-label="Accounts meeting every requirement" ${summary.score===null?'hidden':''}></progress><small>${summary.complete?`${summary.passed} of ${summary.checked} checked accounts meet every requirement`:'Some checks cannot be confirmed yet'}</small></button><button type="button" data-account-group="attention" class="impact-card ${summary.toReview?'':'clear'}"><span>Accounts needing attention</span><strong>${summary.toReview}</strong><small>${summary.acceptedOnly?summary.acceptedOnly+' with only accepted exceptions (separate)':summary.unverifiedOnlyAffected?'Includes checks needing investigation':'Accounts with unaccepted gaps'}</small></button><button type="button" class="pass-card" data-account-group="met" ${summary.passed===null?'disabled':''} title="Show accounts meeting all requirements"><span>Meet all requirements</span><strong>${summary.passed===null?'--':summary.passed}</strong><small>${summary.complete?(summary.passed?'No gaps found for these accounts':'No accounts meet every requirement'):'Not confirmed while checks are incomplete'}</small></button><button type="button" data-account-group="scope" title="Show accounts in assessment scope"><span>${summary.unassessedAccounts?'Accounts in scope':'Accounts checked'}</span><strong>${summary.checked}</strong><small>${summary.unchecked?summary.unchecked+' outside the checked scope':'All '+summary.total+' imported accounts are in scope'}</small></button>`;
 $('#metrics .impact-card').classList.toggle('unknown',!summary.complete&&!summary.confirmedAffected&&summary.toReview>0);
 $('#metrics .impact-card').classList.toggle('unconfirmed-clear',!summary.complete&&!summary.toReview);
 $('#review-incomplete-checks').hidden=!unresolved||!profile.requirements.some(r=>r.enabled!==false);$('#coverage-issues').hidden=!result.coverageIssues?.length;$('#coverage-title').textContent=`${result.coverageIssues?.length||0} ${result.coverageIssues?.length===1?'check needs':'checks need'} review`;
 $('#coverage-list').innerHTML=reviewIssues(result.coverageIssues||[]);bindReviewActions($('#coverage-list'));
 $('#assessment-notes').hidden=!result.assessmentNotes?.length;$('#assessment-note-list').innerHTML=(result.assessmentNotes||[]).map(n=>`<li>${esc(n.message)}</li>`).join('');
 $('#analysis-detail-text').textContent=`${result.identityCount} imported accounts / ${result.identityProfileCount} distinct policy profiles / ${result.gaps.length} grouped scenarios / ${result.elapsedMilliseconds} ms engine time. Accepted exceptions remain included in the coverage score.`;
 renderAcceptedSummary();bindAccountGroupLinks();
 document.querySelectorAll('[data-requirement]').forEach(b=>b.onclick=()=>openRequirementReview(b.dataset.requirement));
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
 const query=$('#search').value.trim().toLowerCase(),requirementId=$('#requirement-filter').value;
 const checks=[...result.gaps,...summary.unassessedChecks.map(c=>({key:'unassessed:'+c.requirementId,requirementId:c.requirementId,identityIds:c.accountIds,messages:c.messages,unassessed:true,assessmentStatus:'needsInvestigation'}))];
 const visible=checks.filter(g=>{
  const r=requirementFor(g),template=r?.origin?.startsWith('template')&&!r?.origin?.includes(':customized');
  return (filter==='all'||(filter==='accepted'?!!g.acceptance:!g.acceptance))&&(requirementId==='all'||r?.id===requirementId)&&($('#origin-filter').value==='all'||($('#origin-filter').value==='template'?template:!template));
 });
 const accountMap=new Map();for(const gap of visible)for(const id of gap.identityIds){if(!accountMap.has(id))accountMap.set(id,[]);accountMap.get(id).push(gap);}
 const accounts=[...accountMap].filter(([id,gaps])=>{if(scenarioAccountId&&id!==scenarioAccountId)return false;const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));return !query||[id,accountName(id),u?.userPrincipalName,...gaps.map(g=>requirementFor(g)?.name),...gaps.map(issueLabel)].join(' ').toLowerCase().includes(query);}).sort(([a],[b])=>accountName(a).localeCompare(accountName(b))||a.localeCompare(b));
 const page=ReviewPresentation.page(accounts,scenarioPage);scenarioPage=page.index;if(!page.items.some(([id])=>id===selection))selection=page.items[0]?.[0];$('#scenario-page').textContent=page.label;$('#scenario-context').textContent=(selection?accountName(selection)+' · ':'')+(requirementId==='all'?'All requirements':profile.requirements.find(r=>r.id===requirementId)?.name||'Selected requirement');$('#scenario-previous').disabled=page.index===0;$('#scenario-next').disabled=page.index===page.pages-1;$('#clear-scenario-account').hidden=!scenarioAccountId;$('#clear-scenario-filters').hidden=!scenarioAccountId&&!query&&requirementId==='all'&&$('#origin-filter').value==='all'&&filter==='open';
 $('#accounts-title').textContent=filter==='accepted'?'Accounts with accepted exceptions':filter==='all'?'Accounts in these scenarios':'Accounts needing attention';
 $('#account-list-count').textContent=`${accounts.length} ${accounts.length===1?'account':'accounts'}`;
 $('#finding-list').innerHTML=accounts.length?page.items.map(([id,gaps])=>{const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));return `<button class="finding account-finding ${id===selection?'selected':''}" data-account="${esc(id)}" aria-pressed="${id===selection}"><div class="row"><span>${esc(u?.userType||'Account')}</span></div><strong>${esc(accountName(id))}</strong><p class="account-upn">${esc(u?.userPrincipalName||'')}</p><div class="issue-tags">${[...new Set(gaps.map(g=>findingCaption(g)))].map(t=>`<span>${esc(t)}</span>`).join('')}</div></button>`;}).join(''):'<div class="empty">'+(checks.length?'No accounts match these filters.':summary.complete?'Every checked account meets your requirements.':'Finish the incomplete checks to confirm coverage.')+'</div>';
 document.querySelectorAll('[data-account]').forEach(b=>b.onclick=()=>{selection=b.dataset.account;selectedGapKey=null;renderResults();});
 renderAccount(selection,accountMap.get(selection)||[]);
}
function renderAccount(id,gaps){
 gaps=[...gaps].sort((a,b)=>Number(findingUnverified(a))-Number(findingUnverified(b)));
 if(!id||!gaps.length){$('#finding-detail').innerHTML='<div class="empty">Select an account to inspect its checks.</div>';return;}
 const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));if(!gaps.some(g=>g.key===selectedGapKey))selectedGapKey=gaps[0].key;
 const choices=gaps.length>1?`<div class="finding-selector"><p class="small">Findings for this account (${gaps.length})</p><div class="scenario-picker">${gaps.map((g,index)=>`<button type="button" class="${g.key===selectedGapKey?'selected':''}" data-scenario="${esc(g.key)}" aria-pressed="${g.key===selectedGapKey}"><span class="finding-choice-number">${index+1}</span><span class="finding-choice-copy"><strong>Requirement: ${esc(requirementFor(g)?.name||g.requirementId)}</strong><small>${esc(g.unassessed?'Check not completed':scenarioScope(g))}</small></span><span class="review-status ${findingUnverified(g)?'unknown':'gap'}">${esc(ReviewPresentation.gapStatus(findingUnverified(g)).label)}${g.acceptance?' · Accepted':''}</span></button>`).join('')}</div></div>`:'';
 const memberships=reviewSetMemberships.get(id)||[];
 $('#finding-detail').innerHTML=`<header class="finding-account-header"><div><h2>${esc(accountName(id))}</h2><p class="account-upn">${esc(u?.userPrincipalName||id)}</p></div><button class="text-button" id="view-account-requirements">All requirements for this account →</button></header>${memberships.length?`<details class="finding-account-sets"><summary>Account sets (${memberships.length})</summary><div class="account-set-tags">${memberships.map(set=>'<span class="chip">'+esc(set.name)+'</span>').join('')}</div></details>`:''}${choices}<div id="scenario-detail"></div>`;
 $('#view-account-requirements').onclick=()=>{accountCheckId=id;$('#account-check-search').value='';$('#account-check-type').value='all';$('#account-check-protection').value='all';showReviewPane('accounts');renderAccountPicker(true);$('#account-check-section').open=true;$('#account-check-section').scrollIntoView({behavior:'smooth',block:'start'});};
 document.querySelectorAll('[data-scenario]').forEach(b=>b.onclick=()=>{selectedGapKey=b.dataset.scenario;renderAccount(id,gaps);});renderFinding(gaps.find(g=>g.key===selectedGapKey));
}
function renderUnassessedCheck(check){
 const req=requirementFor(check),issues=(result.coverageIssues||[]).filter(i=>i.requirementId===check.requirementId);
 $('#scenario-detail').innerHTML=`<section class="finding-conclusion"><div class="finding-result-heading"><h3>Requirement: ${esc(req?.name||check.requirementId)}</h3><span class="review-status unknown">Cannot confirm</span></div><p class="requirement-reminder">${esc(requirementDescription(req))}</p><ul class="review-issues">${reviewIssues(issues.length?issues:(check.messages||[]).map(message=>({code:'requirement-not-evaluated',requirementId:check.requirementId,message})))}</ul></section>`;
 bindReviewActions($('#scenario-detail'));
}
function policyTrace(p,witness){if(p.unverifiedLocations){const permits=p.guaranteedGrantAlternatives?.some(a=>Object.entries(a).every(([key,s])=>(!s.include?.length||s.include.includes(witness[key]))&&!s.exclude?.includes(witness[key])));return permits?'Its grants allow this example regardless of location.':'May apply; location matching is unverified. No protection credited.';}return p.unverifiedApplicationFilter?'May apply; app-filter matching and its grants are unverified.':'Applies; this sign-in satisfies its grants.';}
function exampleScenarioEntries(gap,req){return visibleScenario(gap.witness,gap.witness).filter(([key,value])=>['application','platform','client','network','authentication'].includes(key)||['compliant','hybridJoined'].includes(key)&&gap.region[key]?.length<source.model.dimensions[key]?.length||key==='flow'&&(req?.flows?.length||value!=='standard'||gap.region.flow?.length<source.model.dimensions.flow?.length)||['signInRisk','userRisk'].includes(key)&&((key==='signInRisk'?req?.signInRiskLevels:req?.userRiskLevels)?.length||gap.region[key]?.length<source.model.dimensions[key]?.length)||key==='directoryScopeEnforcement'&&value!=='ordinary'||key==='userAction'||key==='externalUserType'||key==='externalTenantId'||key==='registrationContext'&&value!=='unspecified'&&value!=='none'||key.startsWith('authenticationContext.')||key.startsWith('device.')||key.startsWith('roleActive.')||key.startsWith('groupMember.')||key.startsWith('resourceGroup.'));}
function exampleScenarioSentence(gap,req,outside,unverified){return ReviewPresentation.scenarioSentence(gap,{accountName:accountName(selection||gap.identityIds[0]),axes:exampleScenarioEntries(gap,req).map(([key])=>key),format:scenarioValue,axisName:label,authenticationContext:req?.authenticationContextId,outcome:outside?'block':req?.outcome,requiredProtection:protectionLabel(req),unverified});}
function renderFinding(gap){if(gap?.unassessed){renderUnassessedCheck(gap);return;}if(!gap){$('#scenario-detail').innerHTML='<p>Choose a finding to inspect its sign-in conditions.</p>';return;}const unverified=findingUnverified(gap),req=requirementFor(gap), outside=gap.requirementId===req?.id+':outside-network'||gap.requirementId===req?.id+':outside-apps'||gap.requirementId===req?.id+':outside-device', outcome=outside?'block':req?.outcome||'mfa';const actual=outcome==='block'?(gap.witness.authentication==='password'?'Single-factor sign-in':gap.witness.authentication==='mfa'?'MFA sign-in':'Phishing-resistant sign-in'):(req?.protections||[outcome]).includes('compliant')?label(gap.witness.authentication)+' / '+(gap.witness.compliant==='true'?'Compliant device':'Device not compliant'):label(gap.witness.authentication);const actualDetail=actual+((req?.protections||[outcome]).includes('hybridJoined')?' / '+(gap.witness.hybridJoined==='true'?'Hybrid-joined device':'Device not hybrid joined'):'');const matched=gap.applicablePolicyIds.map(id=>source.model.policies.find(p=>p.id===id)).filter(Boolean);const trace=matched.map(p=>`<div class="trace"><strong>${esc(policyName(p.id))}</strong><span>${policyTrace(p,gap.witness)}</span></div>`).join('');$('#scenario-detail').innerHTML=`<section class="finding-conclusion"><div class="finding-result-heading"><h3>Requirement: ${esc(req?.name||gap.requirementId)}</h3><span class="review-status ${unverified?'unknown':'gap'}">${unverified?'Cannot confirm':'Gap found'}</span></div><p class="requirement-reminder">${esc(requirementDescription(req))}</p>${unverified?'<ul class="review-issues">'+reviewIssues(issuesForFinding(gap))+'</ul>':''}<h4 class="finding-example-heading">${unverified?'Example needing verification':'Example sign-in'}</h4><p class="scenario-explanation">${esc(exampleScenarioSentence(gap,req,outside,unverified))}</p>${!unverified&&!matched.length?'<p class="finding-cause">No enabled policy applies to this example.</p>':''}<div class="finding-evidence"><details class="recommendation-section"><summary>Recommendations &amp; related policies</summary><div id="finding-policy-advice"></div></details><details><summary>Example sign-in details</summary><dl class="finding-comparison"><div><dt>Required protection</dt><dd>${esc(outside?'Blocked access':protectionLabel(req))}</dd></div><div><dt>${unverified?'Authentication to verify':'Policy coverage allows'}</dt><dd>${esc(actualDetail)}</dd></div></dl><div class="witness">${exampleScenarioEntries(gap,req).map(([key,value])=>`<div><span>${esc(label(key))}</span><strong>${esc(scenarioValue(key,value))}</strong></div>`).join('')}</div></details><details><summary>Policies applying to this example (${matched.length})</summary>${trace||(unverified?'<p>No policy is confirmed to protect this example.</p>':'<p>No enabled policy applies to this example sign-in.</p>')}</details><details><summary>Why other policies do not apply</summary>${source.model.policies.filter(p=>!gap.applicablePolicyIds.includes(p.id)).map(p=>`<div class="trace"><strong>${esc(policyName(p.id))}</strong><span>${esc(nonMatchReason(p,gap))}</span></div>`).join('')}</details><details><summary>Accounts in this scenario (${gap.identityIds.length.toLocaleString()})</summary><input type="search" id="scenario-member-search" aria-label="Find an account in this scenario" placeholder="Name, sign-in address or ID"><div id="scenario-members" class="scenario-members"></div><div class="account-picker-pages"><button type="button" id="scenario-member-previous" class="secondary">Previous</button><span id="scenario-member-page" class="small"></span><button type="button" id="scenario-member-next" class="secondary">Next</button></div></details><details><summary>Full scenario conditions</summary>${visibleScenario(gap.region,gap.witness).map(([key,values])=>`<p class="small"><strong>${esc(label(key))}</strong>: ${values.map(v=>esc(scenarioValue(key,v))).join(', ')}</p>`).join('')}</details></div>${gap.acceptance?`<div class="notice warning">Accepted exception: ${esc(gap.acceptance.reason)}. ${unverified?'This check still needs verification.':'Protection is still missing.'}</div>`:''}<footer class="finding-exception-actions"><span class="small">Accepting an exception does not add protection.</span><button class="secondary" id="accept-current">${gap.acceptance?'Reopen exception':'Accept this scenario for '+gap.identityIds.length.toLocaleString()+' '+(gap.identityIds.length===1?'account':'accounts')}</button></footer></section>`;renderGapPolicyAdvice(gap,req,unverified);renderScenarioMembers(gap);bindReviewActions($('#scenario-detail'));bindRequirementInfo($('#scenario-detail'));$('#accept-current').onclick=async()=>{if(gap.acceptance){try{const removedKeys=new Set([gap.key,...(gap.acceptance.recordKeys||[])]),shared=result.gaps.some(g=>g!==gap&&g.acceptance?.recordKeys?.some(k=>removedKeys.has(k)));await api('/api/accept',{key:gap.key,reopen:true});if(shared){await checkCoverage();}else{gap.acceptance=null;renderResults();}}catch(e){fail(e);}}else{pendingAcceptance=gap.key;$('#accept-scope').innerHTML=acceptanceScope(gap);$('#accept-reason').value='';$('#accept-dialog').showModal();}};}

function nonMatchReason(p,g){const id=g.identityIds[0];if(p.excludeUsers?.includes(id)||p.excludeUsers?.includes('*'))return 'Account explicitly excluded.';if(!p.includeUsers?.includes('*')&&!p.includeUsers?.includes(id))return 'Account not in this assignment.';const flowExclusion=source.flowResourceExclusions?.find(e=>e.policyId===(source.policyOrigins?.[p.id]||p.id)&&e.resourceId===g.witness.application);if(flowExclusion)return flowExclusion.message;for(const [key,s] of Object.entries(p.conditions||{})){const value=g.witness[key];if(s.exclude?.includes(value))return `${label(key)} excluded: ${scenarioValue(key,value)}.`;if(s.include?.length&&!s.include.includes(value))return `${label(key)} does not match: ${scenarioValue(key,value)}.`;}return 'Not applicable to this example.';}

async function startOAuth(e){

 e.preventDefault();if(busy)return;

 if(signinWindow&&!signinWindow.closed){signinWindow.focus();return;}

 clearError();const generation=beginSourceLoad();

 signinWindow=window.open('about:blank','ca-gap-sign-in','popup=yes,width=520,height=720');

 if(!signinWindow){fail(Error('Allow the sign-in popup and try again.'));return;}

 $('#connect-button').disabled=true;workflowCollecting=true;updateWorkflowFooter();

 try{

  if(generation!==authGeneration)return;

  const response=await api('/api/oauth/start',{tenantId:$('#tenant-id').value.trim(),clientId:$('#client-id').value.trim(),includePimGroups:$('#include-pim-groups').checked,includeApplicationAttributes:$('#include-application-attributes').checked});

  if(generation!==authGeneration)return;
  signinWindow.location.href=response.authorizeUrl;

  $('#connection-state').textContent='Signing in…';$('#disconnect').hidden=false;

  pollOAuth(generation);

 }catch(e){if(generation!==authGeneration)return;workflowCollecting=false;updateWorkflowFooter();signinWindow?.close();signinWindow=null;$('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;fail(e);}

}

window.addEventListener('message',event=>{

 if(event.origin!==location.origin||event.source!==signinWindow||event.data?.type!=='ca-oauth-complete')return;

 window.focus();$('#connection-state').textContent='Finishing sign-in…';

});

async function pollOAuth(generation){

 if(generation!==authGeneration)return;

 try{

  const state=await api('/api/oauth/status',{});

  if(generation!==authGeneration)return;

  if(state.status==='complete'){

   if(busy||document.querySelector('dialog[open]')){CollectionProgress.stop();$('#token-connection-state').textContent='Data collected. Finish the current edit or check to load it.';$('#connection-state').textContent='Snapshot ready. Finish the current edit or check to load it.';pollTimer=setTimeout(()=>pollOAuth(generation),1500);return;}

   if(signinWindow&&!signinWindow.closed){try{signinWindow.close();}catch{}}

   const normalized=SnapshotModel.normalize(state.snapshot);if(!await adopt(normalized,state.snapshot,{generation}))return;

   CollectionProgress.stop();$('#disconnect').hidden=false;$('#connection-state').textContent='Connected · Read-only snapshot collected.';$('#token-connection-state').textContent='Snapshot collected.';

   $('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#cancel-token').hidden=true;signinWindow=null;return;

  }

  if(state.status==='collecting')CollectionProgress.update(state.progress);
  if(state.status==='error')throw Error(state.message);

  if(state.status==='idle')throw Error('Sign-in is no longer active. Please try again.');

  if(state.status==='signingIn'&&signinWindow?.closed){await api('/api/oauth/disconnect',{});throw Error('Sign-in cancelled. Click Sign in with Microsoft to try again.');}

  workflowCollecting=true;updateWorkflowFooter();
  $('#connection-state').textContent=state.status==='collecting'?'Connected · Reading policies, accounts and memberships…':'Signing in…';

  pollTimer=setTimeout(()=>pollOAuth(generation),750);

 }catch(e){

  if(generation!==authGeneration)return;

  workflowCollecting=false;updateWorkflowFooter();
  if(signinWindow&&!signinWindow.closed)signinWindow.close();signinWindow=null;

  $('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;CollectionProgress.stop();fail(e);$('#connection-state').textContent='Connection needs attention.';$('#token-connection-state').textContent='Collection needs attention.';

 }

}

const fullExport=`./Export-TenantSnapshot.ps1 -TenantId (az account show --query tenantId --output tsv) -OutputPath ./ca-tenant-snapshot.json`;
const policyExport=`$ErrorActionPreference = 'Stop'
$graphToken = az account get-access-token --resource https://graph.microsoft.com/ --query accessToken --output tsv
if ($LASTEXITCODE -ne 0 -or !$graphToken) { throw 'The existing Azure CLI session could not get a Graph token.' }
$headers = @{ Authorization = "Bearer $graphToken" }
try {
    $policies = [System.Collections.Generic.List[object]]::new()
    $next = 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies'
    $visited = [System.Collections.Generic.HashSet[string]]::new()
    while ($next) {
        $target = [uri]$next
        if ($target.Scheme -ne 'https' -or $target.Host -ne 'graph.microsoft.com' -or $target.Port -ne 443 -or $target.UserInfo -or !$visited.Add($next)) { throw 'Invalid Graph pagination link.' }
        $page = Invoke-RestMethod -Method GET -Uri $next -Headers $headers
        if ($null -eq $page.value) { throw 'Graph did not return policies.' }
        foreach ($policy in $page.value) { $policies.Add($policy) }
        $next = $page.'@odata.nextLink'
    }
    ConvertTo-Json -InputObject @($policies.ToArray()) -Depth 100 | Set-Content ./ca-policies.json -Encoding utf8
} finally {
    $graphToken = $null
    $headers.Clear()
}`;
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));document.querySelectorAll('[data-next]').forEach(b=>b.onclick=()=>showTab(b.dataset.next));document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$('#'+b.dataset.close).close());

$('#edit-network-trust').onclick=()=>{
 if(busy)return;
 const raw=source.original,ranges=raw.legacyMfaTrustedIpRanges;
 $('#legacy-ip-setting').value=Array.isArray(ranges)?ranges.length?'configured':'none':'unknown';
 $('#legacy-ip-ranges').value=Array.isArray(ranges)?ranges.join('\n'):'';
 $('#legacy-ip-ranges-label').hidden=$('#legacy-ip-setting').value!=='configured';
 $('#legacy-federated-setting').value=typeof raw.legacyMfaFederatedIntranetEnabled==='boolean'?String(raw.legacyMfaFederatedIntranetEnabled):'unknown';
 $('#network-trust-error').hidden=true;$('#network-trust-dialog').showModal();
};
$('#legacy-ip-setting').onchange=()=>$('#legacy-ip-ranges-label').hidden=$('#legacy-ip-setting').value!=='configured';
$('#network-trust-form').onsubmit=async e=>{
 e.preventDefault();if(busy)return;
 try{
  const original=structuredClone(source.original),mode=$('#legacy-ip-setting').value,flag=$('#legacy-federated-setting').value;
  if(mode==='unknown')delete original.legacyMfaTrustedIpRanges;
  else{
   const ranges=mode==='none'?[]:$('#legacy-ip-ranges').value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);
   if(mode==='configured'&&!ranges.length)throw Error('Enter the trusted IPv4 ranges, or choose No trusted IP ranges.');
   LocationModel.parseLegacyTrustedRanges(ranges);original.legacyMfaTrustedIpRanges=ranges;
  }
  if(flag==='unknown')delete original.legacyMfaFederatedIntranetEnabled;else original.legacyMfaFederatedIntranetEnabled=flag==='true';
  const next=SnapshotModel.normalize(original);next.key=source.key;next.kind=source.kind;next.name=source.name;
  await adopt(next,original);$('#network-trust-dialog').close();toast('Local settings updated. Save the snapshot to keep them.');
 }catch(error){fail(error,'#network-trust-error');}
};
$('#choose-file').onclick=()=>$('#source-file').click();$('#source-file').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 const generation=beginSourceLoad(),previousSource=source;
 try{
  if(file.size>10485760)throw Error('Choose a JSON file smaller than 10 MB.');
  let input=parseImportedJson(await file.text());if(generation!==authGeneration)return;
  const evidence=input?.resourceGroupEvidenceVersion===1;
  if(evidence)input=ResourceGroups.merge(previousSource?.original,input);
  if(await adopt(SnapshotModel.normalize(input),input,{generation}))toast(evidence?'Extra app-group information added. Save the snapshot to keep it.':'File loaded. It replaces the previously loaded data.');
 }catch(e){if(generation===authGeneration)fail(e);}finally{e.target.value='';}
};

$('#load-demo').onclick=()=>loadDemo().catch(fail);$('#download-source').onclick=()=>source&&download(source.original,'ca-snapshot.json');$('#new-set').onclick=()=>openSet();$('#set-kind').onchange=toggleSetKind;$('#manual-search').oninput=()=>{manualPage=0;renderManual();};$('#add-clause').onclick=()=>{$('#clause-list').append(clauseRow());renderSetPreview();};$('#set-form').onsubmit=saveSet;$('#new-requirement').onclick=()=>openRequirement();$('#requirement-form').onsubmit=saveRequirement;$('#open-templates').onclick=openTemplates;$('#run').onclick=checkCoverage;$('#rerun').onclick=checkCoverage;$('#download-results').onclick=async()=>{if(!result)return;const button=$('#download-results');button.disabled=true;button.textContent='Exporting…';try{await downloadServerReport('/api/results/export',{sourceKey:result.sourceKey,modelHash:result.modelHash,coverageSummary:result.coverageSummary},'ca-coverage-results.json');}catch(e){fail(e);}finally{button.disabled=false;button.textContent='Export results';}};$('#export-profile').onclick=()=>profile&&download(profile,'ca-requirements.json');$('#import-profile').onclick=()=>$('#profile-file').click();$('#profile-file').onchange=async e=>{try{const file=e.target.files[0];if(!file)return;const next=parseImportedJson(await file.text());if(next.version!==1||!Array.isArray(next.requirements))throw Error('Choose an exported requirements configuration.');RequirementModel.resolve(next.sets,source.records);if(next.requirements.some(r=>r.enabled!==false))RequirementModel.compile(next,source);await saveProfile(next);renderSets();renderRequirements();toast('Configuration imported.');}catch(e){fail(e);}finally{e.target.value='';}};document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;scenarioPage=0;if(result)renderResults();});$('#search').oninput=()=>{scenarioPage=0;if(result)renderResults();};$('#origin-filter').onchange=()=>{scenarioPage=0;if(result)renderResults();};$('#accept-form').onsubmit=async e=>{e.preventDefault();try{const response=await api('/api/accept',{key:pendingAcceptance,reason:$('#accept-reason').value});result.gaps.find(g=>g.key===pendingAcceptance).acceptance=response.acceptance;$('#accept-dialog').close();renderResults();}catch(e){$('#accept-dialog').close();fail(e);}};$('#connect-form').onsubmit=startOAuth;$('#disconnect').onclick=async()=>{try{CollectionProgress.stop();workflowCollecting=false;updateWorkflowFooter();authGeneration++;clearTimeout(pollTimer);$('#collect-token').disabled=false;$('#cancel-token').hidden=true;if(signinWindow&&!signinWindow.closed)signinWindow.close();signinWindow=null;$('#connect-button').disabled=false;await api('/api/oauth/disconnect',{});$('#connection-state').textContent='Connection cleared. Loaded data remains available until you close or replace it.';$('#disconnect').hidden=true;}catch(e){fail(e);}};$('#full-export-code').textContent=fullExport;$('#policy-export-code').textContent=policyExport;$('#redirect-uri').textContent=location.origin+'/oauth/callback';$('#copy-redirect').onclick=()=>navigator.clipboard.writeText(location.origin+'/oauth/callback').then(()=>toast('Redirect URI copied.')).catch(fail);document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>navigator.clipboard.writeText($('#'+b.dataset.copy).textContent).then(()=>toast('Commands copied.')).catch(fail));

(async()=>{try{const session=await api('/api/session');sessionToken=session.token;if(session.connection){if(!$('#tenant-id').value)$('#tenant-id').value=session.connection.tenantId;if(!$('#client-id').value)$('#client-id').value=session.connection.clientId;if(!$('#token-tenant-id').value)$('#token-tenant-id').value=session.connection.tenantId;}const returning=new URL(location.href);if(returning.searchParams.get('signin')==='return'){selectImportMethod('direct');returning.searchParams.delete('signin');history.replaceState(null,'',returning.pathname+returning.search+returning.hash);$('#disconnect').hidden=false;$('#connect-button').disabled=true;pollOAuth(++authGeneration);}lab=await api('/api/lab');$('#demo-scenario').innerHTML='<option value="baseline">Clean baseline</option>'+lab.faults.map(f=>`<option value="${esc(f.id)}">${esc(f.name)}</option>`).join('');}catch(e){fail(e);}})();



for(const selector of ['#tenant-id','#client-id'])$(selector).addEventListener('change',()=>{const tenantId=$('#tenant-id').value.trim(),clientId=$('#client-id').value.trim();const guid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;if(sessionToken&&guid.test(tenantId)&&guid.test(clientId))api('/api/connection/save',{tenantId,clientId}).catch(fail);});



function toggleRequirementTarget(){updateRequirementPreview();}

$('#req-target').onchange=toggleRequirementTarget;$('#requirement-form').addEventListener('input',updateRequirementPreview);$('#requirement-form').addEventListener('change',updateRequirementPreview);$('#req-app-search').oninput=()=>{appChoicePage=0;renderEditorChoices('apps',selectableApps(),appName);};

function visibleScenario(object,witness){return Object.entries(object).filter(([key])=>key!=='accessTarget'&&!key.startsWith('groupActivation.')&&(witness.accessTarget==='application'||!witness.accessTarget?key!=='userAction'&&!key.startsWith('authenticationContext.'):witness.accessTarget==='userAction'?key!=='application'&&!key.startsWith('authenticationContext.'):key!=='application'&&key!=='userAction'));}


$('#requirement-filter').onchange=()=>{scenarioPage=0;if(result)renderResults();};


function selectImportMethod(mode){
 const choice=document.querySelector('[data-import-method="'+mode+'"]');
 $('#import-choices').hidden=true;$('#import-choice-title').hidden=true;$('#import-selection').hidden=false;
 $('#import-method-title').textContent=choice.querySelector('strong').textContent;
 $('#tenant-import').hidden=!['direct','token'].includes(mode);
 $('#cloudshell-import').hidden=mode!=='cloudshell';$('#file-import').hidden=mode!=='file';$('#demo-import').hidden=mode!=='demo';
 $('#connection-method').value=mode;
 $('#direct-connection').hidden=mode!=='direct';$('#token-connection').hidden=mode!=='token';
 // The same collection options apply to direct sign-in, token collection and Cloud Shell export.
 const options=$('#collection-options');
 if(mode==='cloudshell')$('#cloudshell-import').prepend(options);else $('#tenant-import').prepend(options);
 if(mode==='token'&&!$('#token-tenant-id').value)$('#token-tenant-id').value=$('#tenant-id').value;
 $('#import-method-title').focus();
}
$('#import-method-title').tabIndex=-1;
document.querySelectorAll('[data-import-method]').forEach(button=>button.onclick=()=>selectImportMethod(button.dataset.importMethod));
$('#change-import-method').onclick=()=>{
 const previous=$('#connection-method').value;
 $('#import-choices').hidden=false;$('#import-choice-title').hidden=false;$('#import-selection').hidden=true;
 for(const id of ['tenant-import','cloudshell-import','file-import','demo-import'])$('#'+id).hidden=true;
 document.querySelector('[data-import-method="'+previous+'"]').focus();
};
$('#cloudshell-choose-file').onclick=()=>$('#source-file').click();
$('#choose-evidence-file').onclick=()=>$('#source-file').click();
$('#file-export-help').onclick=()=>selectImportMethod('cloudshell');
$('#token-form').onsubmit=async e=>{
 e.preventDefault();if(busy)return;clearError();const accessToken=$('#existing-token').value.trim();$('#existing-token').value='';
 if(!accessToken){fail(Error('Paste a Microsoft Graph access token.'));return;}
 const generation=beginSourceLoad();
 $('#collect-token').disabled=true;$('#connect-button').disabled=true;$('#cancel-token').hidden=false;workflowCollecting=true;updateWorkflowFooter();
 try{
  if(generation!==authGeneration)return;
  await api('/api/token/collect',{tenantId:$('#token-tenant-id').value.trim(),accessToken,includePimGroups:$('#include-pim-groups').checked,includeApplicationAttributes:$('#include-application-attributes').checked});
  if(generation!==authGeneration)return;
  CollectionProgress.start();$('#token-connection-state').textContent='';pollOAuth(generation);
 }catch(e){if(generation!==authGeneration)return;workflowCollecting=false;updateWorkflowFooter();$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;fail(e);}
};

$('#cancel-token').onclick=()=>$('#disconnect').click();

let referenceLab=null;
$('#load-reference').onclick=async()=>{if(busy)return;const generation=beginSourceLoad();try{if(!referenceLab)referenceLab=await api('/api/reference-lab');if(generation!==authGeneration)return;const selected=referenceLab.scenarios.find(s=>s.id===$('#reference-scenario').value)||referenceLab.scenarios[0];const normalized=SnapshotModel.normalize(selected.snapshot);normalized.key='demo:reference';normalized.kind='reference';normalized.name='Reference lab / '+selected.name;if(!await adopt(normalized,selected.snapshot,{generation}))return;if(!profile.requirements.length){await saveProfile(structuredClone(referenceLab.requirements));renderSets();renderRequirements();}if(generation===authGeneration)toast('Reference data loaded. It replaces the previously loaded data.');}catch(e){if(generation===authGeneration)fail(e);}};
api('/api/reference-lab').then(pack=>{referenceLab=pack;$('#reference-scenario').innerHTML=pack.scenarios.map(s=>`<option value="${esc(s.id)}">${esc(s.name)} (${s.expectedAccounts.length} with bundled rules)</option>`).join('');}).catch(()=>{});

let referenceUndo=null;
$('#restore-reference').onclick=async()=>{try{if(source?.key!=='demo:reference'){toast('Load the reference tenant first.');return;}referenceUndo=structuredClone(profile);await saveProfile(structuredClone(referenceLab.requirements));$('#undo-reference').hidden=false;renderSets();renderRequirements();toast('Reference requirements restored. Undo is available below the reference loader.');}catch(e){fail(e);}};
$('#undo-reference').onclick=async()=>{if(!referenceUndo)return;try{await saveProfile(referenceUndo);referenceUndo=null;$('#undo-reference').hidden=true;renderSets();renderRequirements();toast('Previous reference requirements restored.');}catch(e){fail(e);}};

function updateExportOptions(){ $('#full-export-code').textContent=fullExport+($('#include-pim-groups').checked?' -IncludePimGroups':'')+($('#include-application-attributes').checked?' -IncludeApplicationAttributes':''); }
$('#include-pim-groups').onchange=updateExportOptions;$('#include-application-attributes').onchange=updateExportOptions;




let pendingSetImport=[];
$('#open-set-catalog').onclick=()=>{
 $('#set-catalog-list').innerHTML=AccountSetLibrary.catalog.map(t=>'<article class="catalog-set"><h3>'+esc(t.name)+'</h3><p>'+esc(t.description)+'</p><button class="secondary" data-set-template="'+esc(t.id)+'">Customise and add</button></article>').join('');
 document.querySelectorAll('[data-set-template]').forEach(b=>b.onclick=()=>{const t=AccountSetLibrary.catalog.find(t=>t.id===b.dataset.setTemplate);$('#set-catalog-dialog').close();const draft=structuredClone(t.set);openSet(draft.id&&!profile.sets.some(s=>s.id===draft.id)?draft.id:null,draft);});
 $('#set-catalog-dialog').showModal();
};
$('#export-sets').onclick=()=>{try{download(AccountSetLibrary.export(profile.sets),'ca-account-sets.json');}catch(e){fail(e);}};
$('#import-sets').onclick=()=>$('#sets-file').click();
$('#sets-file').onchange=async e=>{
 try{const file=e.target.files[0];if(!file)return;if(file.size>10485760)throw Error('Choose an account-set file smaller than 10 MB.');pendingSetImport=AccountSetLibrary.read(parseImportedJson(await file.text()));
  if(!pendingSetImport.length)throw Error('This file contains no account sets.');
  const resolved=RequirementModel.resolve(pendingSetImport,source.records).resolved;
  $('#set-import-list').innerHTML=pendingSetImport.map((s,i)=>{const status=AccountSetLibrary.status(profile.sets,s),preview=resolved.get(s.id);return '<label class="import-set-row"><input type="checkbox" data-import-set="'+i+'" '+(status==='existing'?'disabled':'checked')+'><span><strong>'+esc(s.name)+'</strong><small>'+esc(status==='existing'?'Already present — skipped':status==='copy'?'Add as a separate copy':'New account set')+'</small><small>'+preview.ids.length+' matching accounts'+(preview.unknown.length?' / '+preview.unknown.length+' cannot be confirmed':'')+'</small></span></label>';}).join('');
  const update=()=>$('#confirm-import-sets').disabled=!document.querySelector('[data-import-set]:checked');$('#set-import-list').onchange=update;update();$('#set-import-error').hidden=true;$('#set-import-dialog').showModal();
 }catch(e){fail(e);}finally{e.target.value='';}
};
$('#set-import-form').onsubmit=async e=>{
 e.preventDefault();try{const selected=[...document.querySelectorAll('[data-import-set]:checked')].map(b=>pendingSetImport[Number(b.dataset.importSet)]);if(!selected.length)throw Error('Choose an account set to add.');const merged=AccountSetLibrary.merge(profile.sets,selected,()=>uniqueId('set'));RequirementModel.resolve(merged.sets,source.records);await saveProfile({...profile,sets:merged.sets});$('#set-import-dialog').close();renderSets();renderRequirements();toast(merged.additions.length+' account sets added. Your existing requirements are unchanged.');}catch(e){fail(e,'#set-import-error');}
};

function renderAccountPicker(revealSelected=false){
 const query=$('#account-check-search').value.trim().toLowerCase(),terms=query.split(/\s+/).filter(Boolean),type=$('#account-check-type').value,protection=$('#account-check-protection').value,group=coverageAccountGroups?.[protection];
 const matches=source.records.filter(u=>(!group||group.has(u.id))&&(type==='all'||u.userType===type)&&terms.every(term=>[u.displayName,u.userPrincipalName,u.id].join(' ').toLowerCase().includes(term))).sort((a,b)=>accountName(a.id).localeCompare(accountName(b.id)));
 if(accountCheckId&&!matches.some(account=>account.id===accountCheckId))accountCheckId=null;
 $('#account-check-picker').dataset.matches=String(matches.length);
 if(revealSelected){const index=matches.findIndex(u=>u.id===accountCheckId);accountPickerPage=index<0?0:Math.floor(index/50);}
 const pages=Math.max(1,Math.ceil(matches.length/50));accountPickerPage=Math.min(Math.max(0,accountPickerPage),pages-1);const offset=accountPickerPage*50,shown=matches.slice(offset,offset+50);
 $('#account-check-picker').innerHTML=shown.map(u=>'<button type="button" class="account-picker-option" data-pick-account="'+esc(u.id)+'" aria-pressed="'+(u.id===accountCheckId)+'"><span class="account-picker-copy"><strong>'+esc(accountName(u.id))+'</strong><small title="'+esc(u.userPrincipalName||u.id)+'">'+esc(u.userPrincipalName||u.id)+'</small><span class="account-picker-type">'+esc(u.userType||'Account')+(u.pimEligible||u.eligibleRoleIds?.length?' · PIM eligible':'')+(u.accountEnabled===false?' · Disabled':'')+'</span></span><span class="account-picker-mark" aria-hidden="true">'+(u.id===accountCheckId?'✓':'')+'</span></button>').join('')||'<div class="account-picker-empty">'+(query||type!=='all'?'No accounts match these filters. Change your search or clear the filters.':protection==='accepted'&&coverageAccountGroups?.acceptedAny?.size?'Some accounts have accepted exceptions and other open checks. Choose With accepted exceptions to see them.':protection!=='all'?'No accounts in this coverage group.':'No accounts are available.')+'</div>';
 $('#account-check-picker').scrollTop=0;
 $('#account-check-count').textContent=matches.length.toLocaleString()+' '+(matches.length===1?'account':'accounts')+(query||type!=='all'||protection!=='all'?' found':' available');
 $('#account-check-protection-note').textContent=({attention:'Unaccepted gaps or checks that still need investigation.',confirmed:'Confirmed gaps, including any accepted exceptions.',unknown:'Uncertain checks, with no confirmed gap for these accounts.',met:'Every requirement in scope is met.',unconfirmed:'No reported gap, but the overall check is incomplete.',acceptedAny:'Accounts with at least one accepted exception. Other gaps may still need attention.',accepted:'Every reported gap has an accepted exception. Accounts with other open gaps are excluded.',scope:'Accounts included in at least one assessed requirement.',outside:'Accounts outside all assessed requirements.'})[protection]||'';
 $('#account-check-protection-note').hidden=protection==='all';
 $('#account-check-page').textContent=matches.length?(offset+1)+'–'+Math.min(offset+50,matches.length)+' of '+matches.length.toLocaleString():'0 accounts';$('#account-check-previous').disabled=accountPickerPage===0;$('#account-check-next').disabled=accountPickerPage>=pages-1;
 $('#account-check-clear').hidden=!query&&type==='all'&&protection==='all';
 const buttons=[...$('#account-check-picker').querySelectorAll('[data-pick-account]')];
 buttons.forEach((button,index)=>{button.onclick=()=>{accountCheckId=button.dataset.pickAccount;buttons.forEach(b=>{const selected=b===button;b.setAttribute('aria-pressed',String(selected));b.querySelector('.account-picker-mark').textContent=selected?'✓':'';});renderAccountRequirementCheck();};button.onkeydown=e=>{const target=e.key==='ArrowDown'?buttons[index+1]:e.key==='ArrowUp'?buttons[index-1]:e.key==='Home'?buttons[0]:e.key==='End'?buttons.at(-1):null;if(target){e.preventDefault();target.focus();}};});
 renderAccountRequirementCheck();
}
function renderAccountRequirementCheck(){
 if(!accountCheckId){$('#account-check-results').innerHTML=$('#account-check-picker').dataset.matches==='0'?'<div class="empty">No accounts match these filters. Change or clear the filters to choose an account.</div>':'<div class="empty">Choose an account to see which requirements it meets.</div>';return;}
 const resolved=resolvedSets(),summary=result.coverageSummary,rows=ReviewPresentation.accountRequirements(result,assessmentModel,profile.requirements,accountCheckId,summary,r=>RequirementModel.scope(r,resolved));
 $('#account-check-results').innerHTML='<div class="eyebrow">SELECTED ACCOUNT</div><h2>'+esc(accountName(accountCheckId))+'</h2><p class="account-upn">'+esc(source.recordById.get(accountCheckId)?.userPrincipalName||accountCheckId)+'</p><p class="small">All saved requirements are shown. “Not applicable” means the account is outside that requirement’s account selection.</p>'+rows.map(row=>'<div class="account-requirement-row"><div><strong>Requirement: '+esc(row.name)+'</strong> '+requirementInfoButton(row.id)+'<small>'+esc(row.detail)+'</small></div><span class="account-requirement-status '+row.kind+'"><span aria-hidden="true">'+({met:'✓',gap:'✕',unknown:'?',na:'—',disabled:'○'}[row.kind])+'</span> '+esc(row.label)+'</span>'+(row.kind==='unknown'?'<button type="button" class="text-button" data-check-explanation="'+esc(row.id)+'">Why can’t this be confirmed? →</button>':'')+(row.gapKeys.length?'<button class="text-button" data-check-requirement="'+esc(row.id)+'">View scenarios →</button>':'')+'</div>').join('')+(!rows.length?'<p>No requirements have been added.</p>':'');
 bindRequirementInfo($('#account-check-results'));bindCheckExplanations($('#account-check-results'),accountCheckId);
 document.querySelectorAll('[data-check-requirement]').forEach(button=>button.onclick=()=>openAccountScenarios(accountCheckId,button.dataset.checkRequirement));
}
$('#account-check-search').oninput=()=>{accountPickerPage=0;if(result)renderAccountPicker();};
$('#account-check-type').onchange=()=>{accountPickerPage=0;if(result)renderAccountPicker();};
$('#account-check-clear').onclick=()=>{$('#account-check-search').value='';$('#account-check-type').value='all';$('#account-check-protection').value='all';accountPickerPage=0;if(result)renderAccountPicker();$('#account-check-search').focus();};
$('#account-check-previous').onclick=()=>{accountPickerPage--;renderAccountPicker();};
$('#account-check-next').onclick=()=>{accountPickerPage++;renderAccountPicker();};
$('#account-check-search').onkeydown=e=>{if(!['Enter','ArrowDown'].includes(e.key))return;const first=$('#account-check-picker [data-pick-account]');if(first){e.preventDefault();if(e.key==='Enter')first.click();else first.focus();}};

setupReviewResizing();
let resettingApp=false;
$('#open-reset-app').onclick=()=>{if(busy)return;$('#settings-dialog').close();$('#reset-app-error').hidden=true;$('#export-before-reset').hidden=!profile;$('#reset-app-dialog').showModal();};
$('#cancel-reset-app').onclick=()=>{if(!resettingApp)$('#reset-app-dialog').close();};
$('#reset-app-dialog').addEventListener('cancel',e=>{if(resettingApp)e.preventDefault();});
$('#export-before-reset').onclick=()=>profile&&download(profile,'ca-requirements.json');
$('#confirm-reset-app').onclick=async()=>{
 if(busy||resettingApp)return;resettingApp=true;$('#reset-app-error').hidden=true;$('#confirm-reset-app').disabled=true;$('#cancel-reset-app').disabled=true;$('#reset-app-dialog .dialog-close').disabled=true;$('#confirm-reset-app').textContent='Resetting…';
 try{const response=await api('/api/app/reset',{confirmation:'reset-local-app-data'});authGeneration++;clearTimeout(pollTimer);if(signinWindow&&!signinWindow.closed)signinWindow.close();
  try{for(const key of ['ca-gap-appearance','ca-gap-appearance-settings'])localStorage.removeItem(key);}catch{}
  try{sessionStorage.setItem('ca-gap-reset-notice',JSON.stringify({backup:response.backup}));}catch{}
  location.reload();
 }catch(e){fail(e,'#reset-app-error');}finally{resettingApp=false;$('#confirm-reset-app').disabled=false;$('#cancel-reset-app').disabled=false;$('#reset-app-dialog .dialog-close').disabled=false;$('#confirm-reset-app').textContent='Reset app data';}
};
try{const resetNotice=sessionStorage.getItem('ca-gap-reset-notice');if(resetNotice){sessionStorage.removeItem('ca-gap-reset-notice');const value=JSON.parse(resetNotice);const note=document.createElement('div');note.className='notice';note.setAttribute('role','status');note.textContent='App data reset. Load your data to start again.'+(typeof value.backup==='string'?' A recovery copy is in '+value.backup+'.':'');document.querySelector('main').prepend(note);}}catch{}

document.querySelectorAll('[data-dialog-close]').forEach(button=>button.onclick=()=>{
 const id=button.dataset.dialogClose;
 if(id==='reset-app-dialog'){$('#cancel-reset-app').click();return;}
 if(id==='appearance-dialog'){$('#close-appearance').click();return;}
 $('#'+id).close();
});

function requirementDescription(definition){return RequirementBuilder.describe(definition,builderContext());}
function requirementInfoButton(id){return id?'<button type="button" class="requirement-info-button" data-requirement-info="'+esc(id)+'" aria-label="Explain this requirement" title="Requirement summary">i</button>':'';}
function bindRequirementInfo(container){container.querySelectorAll('[data-requirement-info]').forEach(button=>button.onclick=()=>{const definition=profile.requirements.find(r=>r.id===button.dataset.requirementInfo);if(!definition)return;$('#requirement-info-name').textContent=definition.name;$('#requirement-info-summary').textContent=requirementDescription(definition);$('#requirement-info-dialog').showModal();});}
function showReviewPane(name,hideInspector=true){
 reviewPane=name;const inspecting=!hideInspector&&!$('#account-review-section').hidden;document.querySelectorAll('#result-body > [data-review-pane]').forEach(p=>p.hidden=inspecting||p.dataset.reviewPane!==name);
 document.querySelectorAll('[data-review-mode]').forEach(button=>{const active=button.dataset.reviewMode===name;button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;});
 if(hideInspector)$('#account-review-section').hidden=true;
}
function openRequirementReview(id){selectedReviewRequirement=id;requirementAccountPage=0;$('#requirement-account-search').value='';$('#requirement-account-status').value='all';showReviewPane('requirements');renderRequirementInvestigation();$('#review-mode-requirements').focus();}
function openAccountScenarios(id,requirementId){scenarioAccountId=id;scenarioPage=0;$('#scenario-context').textContent=accountName(id)+' · '+(profile.requirements.find(r=>r.id===requirementId)?.name||'Selected requirement');$('#close-scenario-review').textContent=reviewPane==='requirements'?'← Back to requirement':'← Back to account';filter='all';$('#requirement-filter').value=requirementId;$('#origin-filter').value='all';$('#search').value='';selection=id;selectedGapKey=null;$('#account-review-section').hidden=false;$('#account-review-section').open=true;renderResults();$('#account-review-section').scrollIntoView({behavior:'smooth',block:'start'});}
function renderRequirementInvestigation(){
 const summary=result.coverageSummary,definitions=profile.requirements;
 if(!definitions.some(r=>r.id===selectedReviewRequirement))selectedReviewRequirement=summary.requirements.find(r=>r.affected)?.id||definitions[0]?.id||null;
 $('#requirement-coverage-rows').innerHTML=definitions.map(definition=>{const row=summary.requirements.find(r=>r.id===definition.id),status=definition.enabled===false?{label:definition.pendingSetup?.length?'Setup needed':'Disabled',kind:definition.pendingSetup?.length?'unknown':'disabled'}:row?ReviewPresentation.requirementStatus(row,definition):{label:'Cannot confirm',kind:'unknown'};return '<button type="button" class="requirement-result '+(definition.id===selectedReviewRequirement?'selected':'')+'" data-select-requirement="'+esc(definition.id)+'" aria-pressed="'+(definition.id===selectedReviewRequirement)+'"><span class="row"><strong>Requirement: '+esc(definition.name)+'</strong><span class="review-status '+status.kind+'">'+esc(status.label)+'</span></span><span class="requirement-reminder">'+esc(requirementDescription(definition))+'</span><small>'+(row?row.checked+' accounts in scope'+(row.affected?' · '+row.affected+' with gaps or incomplete checks':''):'Not included in this check')+'</small></button>';}).join('')||'<p>No requirements have been added.</p>';
 $('#requirement-coverage-rows').querySelectorAll('[data-select-requirement]').forEach(button=>button.onclick=()=>{selectedReviewRequirement=button.dataset.selectRequirement;requirementAccountPage=0;$('#requirement-account-search').value='';renderRequirementInvestigation();});
 renderRequirementAccounts();
}
function renderRequirementAccounts(){
 const definition=profile.requirements.find(r=>r.id===selectedReviewRequirement);if(!definition){$('#selected-requirement-heading').innerHTML='<h2>Choose a requirement</h2>';$('#clear-requirement-account-filters').hidden=true;$('#requirement-policy-content').innerHTML='';delete $('#requirement-policy-content').dataset.mappingKey;
 $('#requirement-account-rows').innerHTML='';$('#requirement-account-count').textContent='';$('#requirement-account-page').textContent='';$('#requirement-account-previous').disabled=true;$('#requirement-account-next').disabled=true;return;}
 $('#selected-requirement-heading').innerHTML='<h2>Requirement: '+esc(definition.name)+' '+requirementInfoButton(definition.id)+'</h2><p class="requirement-reminder">'+esc(requirementDescription(definition))+'</p>'+(!result.coverageSummary.requirements.find(r=>r.id===definition.id)?.complete&&definition.enabled!==false?'<button type="button" class="text-button" data-check-explanation="'+esc(definition.id)+'">Why can’t this be confirmed? →</button>':'');bindCheckExplanations($('#selected-requirement-heading'));
 let scope;try{scope=RequirementModel.scope(definition,resolvedSets());}catch{scope={include:[],unknown:[]};}
 const rows=ReviewPresentation.requirementAccounts(result,assessmentModel,definition,result.coverageSummary,scope,source.records),missing=scope.unknown.filter(id=>!source.recordById.has(id)).length;
 const query=$('#requirement-account-search').value.trim().toLowerCase(),status=$('#requirement-account-status').value;
 const visible=rows.filter(row=>(!query||[row.account.displayName,row.account.userPrincipalName,row.account.id].join(' ').toLowerCase().includes(query))&&(status==='all'||status==='attention'&&row.needsAttention||status==='met'&&row.status.kind==='met'||status==='acceptedAny'&&row.hasAccepted||status==='accepted'&&row.acceptedOnly)).sort((a,b)=>Number(b.needsAttention)-Number(a.needsAttention)||accountName(a.account.id).localeCompare(accountName(b.account.id)));
 const pages=Math.max(1,Math.ceil(visible.length/50));requirementAccountPage=Math.max(0,Math.min(requirementAccountPage,pages-1));const offset=requirementAccountPage*50;
 $('#requirement-account-count').textContent=rows.length.toLocaleString()+' in scope · '+rows.filter(r=>r.needsAttention).length.toLocaleString()+' need attention · '+rows.filter(r=>r.hasAccepted).length.toLocaleString()+' with accepted exceptions'+(missing?' · '+missing+' selected account IDs are missing from this export':'');
 $('#clear-requirement-account-filters').hidden=!query&&status==='all';
 $('#requirement-account-rows').innerHTML=visible.slice(offset,offset+50).map(row=>'<tr><td><strong>'+esc(accountName(row.account.id))+'</strong><small>'+esc(row.account.userPrincipalName||row.account.id)+'</small></td><td>'+esc(row.account.userType||'Account')+'</td><td><span class="review-status '+row.status.kind+'">'+esc(row.status.label)+'</span>'+(row.hasAccepted?'<small>'+esc(row.acceptedOnly?'All reported gaps accepted':'Has accepted exceptions; other checks still need attention')+'</small>':'')+'</td><td>'+(row.status.gapKeys.length?'<button class="text-button" data-requirement-account="'+esc(row.account.id)+'">View scenarios →</button>':'<button class="text-button" data-requirement-account-review="'+esc(row.account.id)+'">All requirements →</button>')+'</td></tr>').join('')||'<tr><td colspan="4">No accounts match this view.</td></tr>';
 $('#requirement-account-page').textContent=visible.length?(offset+1)+'–'+Math.min(offset+50,visible.length)+' of '+visible.length.toLocaleString():'0 accounts';$('#requirement-account-previous').disabled=requirementAccountPage===0;$('#requirement-account-next').disabled=requirementAccountPage>=pages-1;
 $('#requirement-account-rows').querySelectorAll('[data-requirement-account]').forEach(button=>button.onclick=()=>openAccountScenarios(button.dataset.requirementAccount,definition.id));
 $('#requirement-account-rows').querySelectorAll('[data-requirement-account-review]').forEach(button=>button.onclick=()=>{accountCheckId=button.dataset.requirementAccountReview;$('#account-check-search').value='';$('#account-check-type').value='all';showReviewPane('accounts');renderAccountPicker(true);});
 bindRequirementInfo($('#selected-requirement-heading'));bindCheckExplanations($('#selected-requirement-heading'));renderSelectedPolicyMapping();
}
document.querySelectorAll('[data-review-mode]').forEach((button,index,buttons)=>{button.onclick=()=>showReviewPane(button.dataset.reviewMode);button.onkeydown=e=>{const target=e.key==='ArrowRight'?buttons[(index+1)%buttons.length]:e.key==='ArrowLeft'?buttons[(index+buttons.length-1)%buttons.length]:null;if(target){e.preventDefault();target.focus();target.click();}};});
$('#requirement-account-search').oninput=()=>{requirementAccountPage=0;renderRequirementAccounts();};$('#requirement-account-status').onchange=()=>{requirementAccountPage=0;renderRequirementAccounts();};$('#requirement-account-previous').onclick=()=>{requirementAccountPage--;renderRequirementAccounts();};$('#requirement-account-next').onclick=()=>{requirementAccountPage++;renderRequirementAccounts();};

$('#open-settings').onclick=()=>{if(!busy)$('#settings-dialog').showModal();};
$('#settings-appearance').onclick=()=>{$('#settings-dialog').close();$('#open-appearance').click();};

function openAccountGroup(name){if(!result||!coverageAccountGroups?.[name])return;accountCheckId=null;accountPickerPage=0;$('#account-check-search').value='';$('#account-check-type').value='all';$('#account-check-protection').value=name;showReviewPane('accounts');$('#account-check-section').open=true;renderAccountPicker();$('#review-mode-accounts').focus();}
function bindAccountGroupLinks(){document.querySelectorAll('[data-account-group]').forEach(control=>{control.onclick=()=>openAccountGroup(control.dataset.accountGroup);if(['circle','g'].includes(control.tagName.toLowerCase()))control.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();openAccountGroup(control.dataset.accountGroup);}};});}
$('#account-check-protection').onchange=()=>{accountCheckId=null;accountPickerPage=0;if(result)renderAccountPicker();};

$('#source-label').onclick=()=>showTab('data');
$('#empty-check').onclick=()=>checkCoverage();
$('#manual-previous').onclick=()=>{manualPage--;renderManual();};$('#manual-next').onclick=()=>{manualPage++;renderManual();};
$('#scenario-previous').onclick=()=>{scenarioPage--;selection=null;renderResults();};$('#scenario-next').onclick=()=>{scenarioPage++;selection=null;renderResults();};
$('#clear-scenario-filters').onclick=()=>{filter='open';scenarioPage=0;scenarioAccountId=null;$('#search').value='';$('#requirement-filter').value='all';$('#origin-filter').value='all';renderResults();};
$('#close-scenario-review').onclick=()=>{showReviewPane(reviewPane);$('#review-pane-'+reviewPane).scrollIntoView({behavior:'smooth',block:'start'});};

function renderScenarioMembers(gap){
 let index=0;const render=()=>{const query=$('#scenario-member-search').value.trim().toLowerCase(),ids=gap.identityIds.filter(id=>[id,accountName(id),source.recordById.get(id)?.userPrincipalName].join(' ').toLowerCase().includes(query)),page=ReviewPresentation.page(ids,index);index=page.index;
 $('#scenario-members').innerHTML=page.items.map(id=>'<div class="scenario-member"><strong>'+esc(accountName(id))+'</strong><span>'+esc(source.recordById.get(id)?.userPrincipalName||id)+'</span></div>').join('')||'<p class="small">No accounts match.</p>';
 $('#scenario-member-page').textContent=page.label;$('#scenario-member-previous').disabled=page.index===0;$('#scenario-member-next').disabled=page.index===page.pages-1;};
 $('#scenario-member-search').oninput=()=>{index=0;render();};$('#scenario-member-previous').onclick=()=>{index--;render();};$('#scenario-member-next').onclick=()=>{index++;render();};render();
}

$('#clear-requirement-account-filters').onclick=()=>{$('#requirement-account-search').value='';$('#requirement-account-status').value='all';requirementAccountPage=0;renderRequirementInvestigation();};


$('#clear-scenario-account').onclick=()=>{scenarioAccountId=null;scenarioPage=0;renderResults();};

function bindCheckExplanations(container,accountId=null){container.querySelectorAll('[data-check-explanation]').forEach(button=>button.onclick=()=>openCheckExplanation(button.dataset.checkExplanation,accountId));}
function openCheckExplanation(requirementId,accountId=null){
 const definition=profile.requirements.find(r=>r.id===requirementId);if(!definition)return;
 $('#check-explanation-name').textContent=definition.name+(accountId?' · '+accountName(accountId):'');$('#check-explanation-reminder').textContent=requirementDescription(definition);
 let issues=ReviewPresentation.checkIssues(result,requirementId,accountId);
 if(!issues.length){
  let scope;try{scope=RequirementModel.scope(definition,resolvedSets());}catch{}
  issues=accountId&&(!scope||scope.unknown.includes(accountId))?[{requirementId,code:'account-classification',message:'Account-set membership could not be confirmed from the imported data.'}]:[{requirementId,code:'requirement-not-evaluated',message:'This check did not provide a complete answer for this requirement. Review its setup and run the check again.'}];
 }
 $('#check-explanation-reasons').innerHTML=reviewIssues(issues);bindReviewActions($('#check-explanation-reasons'));
 $('#check-explanation-reasons').querySelectorAll('[data-review-pane]').forEach(button=>{const action=button.onclick;button.onclick=()=>{$('#check-explanation-dialog').close();action();};});
 $('#check-explanation-dialog').showModal();
}

function setupReviewResizing(){
 const panels=[['#requirement-coverage-rows','Requirement list'],['.requirement-account-table-wrap','Requirement accounts'],['#account-check-picker','Account list'],['#finding-list','Scenario account list']];
 const bindings=[];
 function bind(handle,read,write,min,max){
  const update=()=>{const value=Math.max(min,Math.round(read()));handle.setAttribute('aria-valuenow',String(value));handle.setAttribute('aria-valuemin',String(min));handle.setAttribute('aria-valuemax',String(max()));handle.setAttribute('aria-valuetext',value+' pixels');};
  handle.addEventListener('pointerdown',event=>{event.preventDefault();const vertical=handle.getAttribute('aria-orientation')==='vertical',origin=vertical?event.clientX:event.clientY,initial=read();handle.setPointerCapture(event.pointerId);
   const move=e=>{write(Math.max(min,Math.min(max(),initial+(vertical?e.clientX:e.clientY)-origin)));update();};
   const stop=()=>{handle.removeEventListener('pointermove',move);handle.removeEventListener('pointerup',stop);handle.removeEventListener('pointercancel',stop);};handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',stop);handle.addEventListener('pointercancel',stop);
  });
  handle.addEventListener('focus',update);handle.addEventListener('keydown',event=>{const vertical=handle.getAttribute('aria-orientation')==='vertical',decrease=vertical?'ArrowLeft':'ArrowUp',increase=vertical?'ArrowRight':'ArrowDown';if(![decrease,increase,'Home','End'].includes(event.key))return;event.preventDefault();write(event.key==='Home'?min:event.key==='End'?max():Math.max(min,Math.min(max(),read()+(event.key===increase?40:-40))));update();});bindings.push(update);
 }
 for(const [selector,label]of panels){const panel=$(selector),handle=document.createElement('div');handle.className='panel-resize-handle';handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','horizontal');handle.setAttribute('aria-label','Resize '+label.toLowerCase()+' height');handle.title='Drag to resize, or use Up and Down arrow keys';panel.after(handle);bind(handle,()=>panel.getBoundingClientRect().height,value=>{panel.style.maxHeight='none';panel.style.height=value+'px';},120,()=>Math.max(600,window.innerHeight*2));}
 const grid=$('.requirement-investigation-grid'),handle=$('#requirement-width-handle');bind(handle,()=>$('#requirement-coverage').getBoundingClientRect().width,value=>grid.style.setProperty('--requirement-pane-width',value+'px'),300,()=>Math.max(300,grid.clientWidth-508));
 $('#reset-review-layout').onclick=()=>{for(const [selector]of panels){$(selector).style.removeProperty('height');$(selector).style.removeProperty('max-height');}grid.style.removeProperty('--requirement-pane-width');bindings.forEach(update=>update());toast('Panel sizes restored.');};
}

$('#review-incomplete-checks').onclick=()=>{if(result.coverageIssues?.length){showReviewPane('overview');$('#coverage-issues').open=true;$('#coverage-issues').scrollIntoView({behavior:'smooth',block:'start'});$('#coverage-issues > summary').focus();}else{const definition=profile.requirements.find(r=>r.enabled!==false&&!result.coverageSummary.requirements.find(row=>row.id===r.id)?.complete);if(definition)openCheckExplanation(definition.id);}};

function mappingPolicyName(id){return source.policyNames?.[id]||source.policies.find(p=>p.id===id)?.displayName||id;}
function mappingScopeText(conditions){
 return Object.entries(conditions||{}).map(([axis,selector])=>{const included=selector.include?.length?selector.include.map(v=>scenarioValue(axis,v)).join(', '):'Any',excluded=selector.exclude?.length?' · except '+selector.exclude.map(v=>scenarioValue(axis,v)).join(', '):'';return label(axis)+': '+included+excluded;}).join('; ')||'All sign-in conditions';
}
function renderSelectedPolicyMapping(){
 const definition=profile?.requirements.find(r=>r.id===selectedReviewRequirement),container=$('#requirement-policy-content');if(!definition||!result||!assessmentModel)return;
 const key=policyMappingGeneration+':'+definition.id;if(container.dataset.mappingKey===key)return;container.dataset.mappingKey=key;
 if(definition.enabled===false){container.innerHTML='<p class="small">This requirement was not included in the check.</p>';return;}
 container.innerHTML='<p class="small" role="status">Mapping policies to this requirement…</p>';
 const generation=policyMappingGeneration,assessment=result,id=definition.id;
 setTimeout(()=>{
  if(generation!==policyMappingGeneration||assessment!==result||selectedReviewRequirement!==id)return;
  let mapping=policyMappingCache.get(id);if(!mapping){mapping=PolicyMapping.build(assessmentModel,id,{origins:source.policyOrigins});policyMappingCache.set(id,mapping);}
  if(mapping.status!=='complete'){container.innerHTML='<p class="notice warning">'+esc(mapping.message||'No checked scenarios are available to map for this requirement.')+'</p>';return;}
  const coverage=result.coverageSummary.requirements.find(r=>r.id===id),agreement=!coverage?.complete||mapping.jointlyCovered===(coverage.affected===0),verified=!!coverage?.complete&&agreement;
  if(!agreement){container.innerHTML='<p class="notice warning">The policy mapping does not agree with this coverage result. No protection links are being credited. Export the check for investigation.</p>';return;}
  const linked=mapping.rows.filter(r=>r.accounts.length||r.matchingAccounts.length).sort((a,b)=>Number(b.full)-Number(a.full)||b.accounts.length-a.accounts.length||mappingPolicyName(a.id).localeCompare(mappingPolicyName(b.id)));
  const allPolicies=new Map(source.policies.map(p=>[p.id,p]));for(const row of mapping.rows)if(!allPolicies.has(row.id))allPolicies.set(row.id,{id:row.id,state:row.state});
  const linkedIds=new Set(linked.map(r=>r.id)),others=[...allPolicies.values()].filter(p=>!linkedIds.has(p.id));
  const title=!verified?'Some checks remain unconfirmed. Treat these as modelled policy links to review.':mapping.jointlyCovered?(linked.some(r=>r.accounts.length)?(linked.filter(r=>r.accounts.length).length===1?'This policy covers the requirement in the checked scenarios.':'Together, these policies cover the requirement in the checked scenarios.'):'The valid model scenarios already satisfy the requirement; no individual policy was credited.'):'These policies leave some of the required protection missing.';
  const renderRow=row=>{const originalState=source.policies.find(p=>p.id===row.id)?.state||row.state,notEnforced=originalState!=='enabled';const status=(notEnforced?'Not enforced':row.unverified?'Matching or protection unconfirmed':!verified?'Needs verification':row.full?(row.blocksOnly?'Covers by blocking access':'Covers this requirement'):row.accounts.length?(row.blocksOnly?'Blocks some matching access':'Protects some matching sign-ins'):'Applies without the required protection'),kind=notEnforced||row.unverified||!verified?'unknown':row.accounts.length?'met':'gap';
   return '<tr><td><details class="mapping-policy-details"><summary>'+esc(mappingPolicyName(row.id))+'</summary>'+row.conditions.map(c=>'<p class="small">'+esc(mappingScopeText(c))+'</p>').join('')+'<details><summary>Technical policy details</summary><pre>'+esc(JSON.stringify(source.policies.find(p=>p.id===row.id)||assessmentModel.policies.filter(p=>row.fragmentIds.includes(p.id)),null,2))+'</pre></details></details></td><td><span class="review-status '+kind+'">'+esc(status)+'</span></td><td>'+(verified?row.accounts.length:Math.max(row.accounts.length,row.matchingAccounts.length)).toLocaleString()+'</td></tr>';
  };
  container.innerHTML='<p class="mapping-intro">'+esc(title)+'</p><p class="small">Links are automatic. Counts overlap, and protection may cover only some sign-ins.</p>'+(linked.length?'<div class="mapping-table-wrap"><table class="mapping-table"><thead><tr><th>Policy · expand for scope</th><th>Contribution</th><th>'+(verified?'Accounts with protection':'Accounts linked')+'</th></tr></thead><tbody>'+linked.map(renderRow).join('')+'</tbody></table></div>':'<p class="small">No enforced policy contribution was identified.</p>')+(others.length?'<details class="mapping-other"><summary>Other policies ('+others.length+')</summary><p class="small">These were not credited with protection for this requirement. An inactive or unsupported policy is not automatically linked to a requirement.</p>'+others.map(p=>'<div class="mapping-other-row"><strong>'+esc(mappingPolicyName(p.id))+'</strong><span>'+esc(p.state==='enabledForReportingButNotEnforced'||p.state==='reportOnly'?'Report-only · not enforced':p.state==='disabled'?'Disabled':mapping.rows.some(r=>r.id===p.id)?'No protection contribution identified':'Could not evaluate its contribution')+'</span></div>').join('')+'</details>':'')+'<div class="button-actions mapping-actions"><button type="button" class="text-button" id="export-policy-mapping">Export mapping ↓</button>'+(coverage?.affected?'<button type="button" class="text-button" id="mapping-review-gaps">Review gap recommendations →</button>':'')+'</div>';
  $('#export-policy-mapping').onclick=()=>download({calensPolicyMappingVersion:1,requirement:{id,name:definition.name,description:requirementDescription(definition)},scope:'Exported finite model only',attributionVerified:verified,requirementMet:verified?mapping.jointlyCovered:null,coverageStatus:coverage?.complete?'complete':'unconfirmed',mapping,otherPolicies:others.map(p=>({id:p.id,name:mappingPolicyName(p.id),state:p.state}))},'calens-policy-mapping.json');
  const review=$('#mapping-review-gaps');if(review)review.onclick=()=>{$('#requirement-account-status').value='attention';$('#requirement-account-search').value='';requirementAccountPage=0;renderRequirementAccounts();$('.requirement-account-table-wrap').scrollIntoView({behavior:'smooth',block:'center'});};
 },0);
}
function renderGapPolicyAdvice(gap,definition,unverified){
 const container=$('#finding-policy-advice'),advice=PolicyMapping.explain(assessmentModel,gap,{accountId:selection||gap.identityIds[0],origins:source.policyOrigins,confirmed:!unverified});
 if(advice.status==='inconsistent'||advice.status==='unavailable'){container.innerHTML='<p class="notice warning">This example’s policy links need validation. No policy-change recommendations were generated.</p>';return;}
 const recommendationTitle=item=>{if(item.kind!=='scope'||!item.difference)return item.title;const difference=item.difference;if(difference.axis==='account')return difference.kind==='excluded'?'Review this account exclusion':'Review the account assignment';return difference.kind==='excluded'?'Review exclusion for '+scenarioValue(difference.axis,difference.value):'Review '+label(difference.axis).toLowerCase()+' coverage';};
 const reason=row=>row.reason==='unverified'?'Its matching or protection could not be verified.':row.reason==='notEnforced'?'It is not enforced.':row.reason==='allowsExample'?'It applies, but permits this example.':row.reason==='deniesExample'?'It would block this example; check the evidence.':row.failures.map(f=>f.axis==='account'?(f.kind==='excluded'?'This account is excluded by its assignment.':'This account is not included in its assignment.'):(label(f.axis)+(f.kind==='excluded'?' excludes ':' does not include ')+scenarioValue(f.axis,f.value)+'.')).join(' ');
 const ranked=advice.recommendations.map((item,index)=>({item,index})).sort((a,b)=>{
  const rank=item=>item.kind==='evidence'?0:item.kind==='grants'?1:item.kind==='reportOnly'?2:item.kind==='scope'?(item.difference?.axis==='application'?5:3):4;
  return rank(a.item)-rank(b.item)||a.index-b.index;
 }).map(row=>row.item);
 const firstPolicy=ranked.find(item=>item.policyId),firstOther=ranked.find(item=>!item.policyId);
 const visibleRecommendations=[firstPolicy,firstOther].filter(Boolean),remainingRecommendations=ranked.filter(item=>!visibleRecommendations.includes(item));
 const primary=firstPolicy?advice.rows.filter(row=>row.id===firstPolicy.policyId):[],other=advice.rows.filter(row=>!primary.includes(row));
 const policyRows=rows=>rows.map(row=>'<div class="mapping-related-row"><strong>Policy: '+esc(mappingPolicyName(row.id))+'</strong><p>'+esc(reason(row))+'</p></div>').join('');
 const impact=item=>item.kind==='newPolicy'?'A new policy combines with every other applicable policy; review its account and resource scope.':item.kind==='reportOnly'?'Enabling this policy enforces all its conditions and controls for every account it targets.':item.kind==='grants'?'Changing grants affects every matching sign-in, including any allowed OR route.':item.kind==='scope'?(item.difference?.axis==='application'?'Adding resources extends all of this policy’s controls to those resources.':'Widening this scope applies all of this policy’s controls to additional matching sign-ins.') :'';
 const recommendationCards=items=>items.map(item=>'<article><strong>'+esc(recommendationTitle(item))+'</strong>'+(item.policyId?'<p class="small">Policy: '+esc(mappingPolicyName(item.policyId))+'</p>':'')+'<p>'+esc(item.detail)+'</p>'+(impact(item)?'<p class="small">Potential impact: '+esc(impact(item))+'</p>':'')+(item.kind==='newPolicy'?'<p class="small">Scope to review: '+gap.identityIds.length.toLocaleString()+' accounts · '+esc(scenarioScope(gap))+'</p><p class="small">Required protection: '+esc(item.mustBlock?'Block access':protectionLabel(definition))+'</p>':'')+'</article>').join('');
 container.innerHTML='<p class="small">'+(unverified?'Resolve the unconfirmed checks before changing policies.':'These are review options. Their wider effects have not been simulated.')+'</p>'+(primary.length?'<h4>Why this gap remains</h4><div class="mapping-related">'+policyRows(primary)+'</div>':'<p class="small">'+(unverified?'The policy relationship needs more information.':'No evaluated policy provides the required protection for this example.')+'</p>')+'<h4>Recommendations</h4><div class="mapping-recommendations">'+recommendationCards(visibleRecommendations)+'</div>'+(remainingRecommendations.length?'<details><summary>Other review options ('+remainingRecommendations.length+')</summary><div class="mapping-recommendations">'+recommendationCards(remainingRecommendations)+'</div></details>':'')+(other.length?'<details><summary>Other related policies ('+other.length+')</summary><div class="mapping-related">'+policyRows(other)+'</div></details>':'')+(unverified?'<button type="button" class="text-button" data-check-explanation="'+esc(definition.id)+'">See what needs checking →</button>':'');
 bindCheckExplanations(container,selection||gap.identityIds[0]);
}

