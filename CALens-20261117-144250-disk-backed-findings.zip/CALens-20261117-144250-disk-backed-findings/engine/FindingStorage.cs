using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
namespace CaGapAnalyzer {
 // Mutable, disk-backed ordered finding records. Only a bounded page window is resident.
 public sealed class PagedFindingRecords : IList, IDisposable {
  const int PageSize=512,CachePages=3;
  sealed class Page { public List<IDictionary> Records=new();public long Used;public bool Dirty; }
  readonly Dictionary<int,Page> pages=new(); readonly HashSet<int> saved=new();readonly Dictionary<string,int> keys=new(StringComparer.Ordinal);
  readonly string directory;long clock;int count;bool disposed;
  public PagedFindingRecords(){directory=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"calens-findings-"+Guid.NewGuid().ToString("N")));Directory.CreateDirectory(directory);}
  public IDictionary Find(string key){foreach(var entry in pages)for(int i=0;i<entry.Value.Records.Count;i++)if(entry.Value.Records[i]["key"] is string k)keys.TryAdd(k,entry.Key*PageSize+i);return keys.TryGetValue(key,out var index)?(IDictionary)this[index]:null;}
  public string TemporaryPath=>directory;
  public int ResidentPages=>pages.Count;public int PageCapacity=>PageSize;public int SpilledPages=>saved.Count;
  string FileName(int page)=>Path.Combine(directory,page.ToString("D8")+".json.gz");
  Page Load(int index){
   if(disposed)throw new ObjectDisposedException(nameof(PagedFindingRecords));
   if(!pages.TryGetValue(index,out var page)){
    if(pages.Count>=CachePages){var victim=pages.OrderBy(e=>e.Value.Used).First();Save(victim.Key,victim.Value);pages.Remove(victim.Key);}
    page=new Page();if(saved.Contains(index)){
     using var file=File.OpenRead(FileName(index));using var gzip=new GZipStream(file,CompressionMode.Decompress);using var reader=new StreamReader(gzip);
     var root=(IDictionary)ReportCodec.Parse(reader.ReadToEnd());foreach(var record in (IEnumerable)root["gaps"])page.Records.Add((IDictionary)record);
    }pages.Add(index,page);
   }page.Used=++clock;return page;
  }
  void Save(int index,Page page){
   if(!page.Dirty&&saved.Contains(index))return;
   // Write then replace; disk errors abort the assessment rather than lose findings.
   for(int i=0;i<page.Records.Count;i++)if(page.Records[i]["key"] is string key)keys.TryAdd(key,index*PageSize+i);
   var path=FileName(index);using(var file=File.Create(path+".tmp"))using(var gzip=new GZipStream(file,CompressionLevel.Fastest)){
    ReportCodec.Write(new Hashtable{{"gaps",page.Records.ToArray()}},gzip,true);
   }File.Move(path+".tmp",path,true);saved.Add(index);page.Dirty=false;
  }
  public void Flush(){foreach(var entry in pages)Save(entry.Key,entry.Value);}
  public object this[int index]{get{if(index<0||index>=count)throw new ArgumentOutOfRangeException(nameof(index));var p=Load(index/PageSize);p.Dirty=true;return p.Records[index%PageSize];}set{if(index<0||index>=count)throw new ArgumentOutOfRangeException(nameof(index));var p=Load(index/PageSize);p.Dirty=true;p.Records[index%PageSize]=(IDictionary)value;}}
  public int Add(object value){if(value is not IDictionary record)throw new ArgumentException("A finding must be a map.");var index=count;var p=Load(index/PageSize);p.Dirty=true;p.Records.Add(record);if(record["key"] is string key)keys.TryAdd(key,index);count++;return index;}
  public int Count=>count;public bool IsFixedSize=>false;public bool IsReadOnly=>false;public bool IsSynchronized=>false;public object SyncRoot=>this;
  public IEnumerable ReadOnlyRecords(){for(int i=0;i<count;i++)yield return Load(i/PageSize).Records[i%PageSize];}
  public IEnumerator GetEnumerator(){for(int i=0;i<count;i++)yield return this[i];}
  public void CopyTo(Array array,int index){foreach(var value in this)array.SetValue(value,index++);}
  public int IndexOf(object value){for(int i=0;i<count;i++)if(ReferenceEquals(this[i],value))return i;return -1;}
  public bool Contains(object value)=>IndexOf(value)>=0;
  public void Clear()=>throw new NotSupportedException();public void Insert(int index,object value)=>throw new NotSupportedException();public void Remove(object value)=>throw new NotSupportedException();public void RemoveAt(int index)=>throw new NotSupportedException();
  public void Dispose(){if(disposed)return;disposed=true;pages.Clear();try{var temp=Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)+Path.DirectorySeparatorChar;if(directory.StartsWith(temp,StringComparison.OrdinalIgnoreCase)&&Path.GetFileName(directory).StartsWith("calens-findings-",StringComparison.Ordinal))Directory.Delete(directory,true);}catch{}GC.SuppressFinalize(this);}
  ~PagedFindingRecords(){Dispose();}
 }
}
