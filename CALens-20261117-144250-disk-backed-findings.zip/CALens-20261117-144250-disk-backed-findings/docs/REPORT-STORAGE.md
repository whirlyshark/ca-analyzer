# Assessment report storage

CALens keeps every finding. Disk-backed storage separates the amount of result
detail from the memory needed for one calculation. No tenant changes or tokens
are involved in this storage.

## Local lifecycle

Each assessment creates an isolated `calens-findings-<random id>` directory in
the current Windows user's temporary folder. Pages are compressed JSON, with
512 records per page and three pages cached. Page writes use a temporary file
and replacement. Save failures abort the operation instead of discarding data.
Mutable exception metadata is written when its page is evicted. Indexed finding
keys support selecting and accepting a finding without a full PowerShell scan.

A completed JSON report is saved atomically to the requested report location.
Its pages are self-contained; it does not depend on the temporary directory.
The store removes its temporary directory on disposal/garbage collection. A
crash can leave temporary pages, which may contain tenant identifiers and
findings. Treat reports and temporary pages as private tenant data.

## File and transport formats

Small reports keep normal `gaps` JSON. Medium reports may use the existing
`_calensDetailPool` version 1. Large reports contain `_calensFindingPages`:

```json
{"status":"completeWithinModel","_calensFindingPages":{"version":1,"count":437104,"pages":[{"gaps":["..."],"_calensDetailPool":{"version":1,"strings":[],"regions":[],"witnesses":[]}}]}}
```

The example is schematic. Every actual page contains complete pooled records;
there are no placeholder findings. List order and values are preserved. Read
with `ReportCodec.ReadFile`, which returns an ordinary report with a disk-backed,
indexable `gaps` collection. Use `.Count`, indexing or enumeration. The snapshot
JSON input size limit does not apply to this report-file reader.

Large streamed UI responses use `resultStart`, numbered `resultPage` events and
`resultEnd`. The browser requires a valid final count and every page in order.
An interrupted stream is an error, never a partial result shown as complete.
Exports use the paged JSON format above. The bundled browser decoder supports
both existing and paged report formats; third-party readers must support them.

Full scenario details are decoded lazily in the browser. Account counts,
requirement status and findings remain available without expanding every wide
app/network list. Selected scenarios, witnesses and policies are still complete.

## Accuracy boundary

Paging does not alter policy predicates, grant combination, scenario constraints,
account grouping or requirement evaluation. Exact fingerprints remain compatible.
Independent region/point tests and byte-exact roundtrips verify those boundaries.
Missing source facts remain explicit uncertainties; storage never invents facts
or declares unsupported checks successful.
