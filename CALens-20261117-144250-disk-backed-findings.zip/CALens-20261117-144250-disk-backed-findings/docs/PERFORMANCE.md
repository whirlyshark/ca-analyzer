# Performance measurements

Development measurement, 2026-11-16. Release acceptance is still pending.

The fresh-process offline command was measured against fictional exports containing 21 raw policies and seven requirements. Policies include overlapping Member/Guest groups, active and eligible roles, explicit exclusions and compensating protection, app-specific grants, legacy/flow blocks, IPv4/IPv6 networks, registration actions, authentication context, disabled and report-only policies. Six equivalent account profiles were found; this represents a patterned organisation, not every worst-case unique-identity policy set.

| Accounts | Case | Full CLI and JSON/HTML export | Engine | Peak process memory | Confirmed accounts needing attention |
|---|---|---:|---:|---:|---:|
| 1,000 | Covered | 3.90 seconds | 24 ms | 289 MiB | 0 |
| 1,000 | MFA AND compliance weakened to OR | 3.98 seconds | 28 ms | 294 MiB | 750 |
| 10,000 | Covered | 21.49 seconds | 135 ms | 704 MiB | 0 |
| 10,000 | MFA AND compliance weakened to OR | 23.64 seconds | 143 ms | 683 MiB | 7,500 |

Environment: Windows 10.0.26300 x64, 16 logical processors, PowerShell 7.6.9, .NET 10.0.14. Measurements ran while the separate validation suite was active, so these are observed results under concurrent local load, not a controlled performance guarantee. Input fixture generation is excluded; fresh PowerShell startup, input reading, V8 normalization/compilation, history evidence construction, .NET analysis, summaries and report export are included. History saving is disabled and the benchmark uses a new empty acceptance path. The child process has no Node/SDK on PATH and uses unusable external proxies; this is not an OS-enforced air gap.

A second frozen all-options run on PowerShell 7.4.22 / .NET 8.0.33 measured the same cases at 3.41 / 3.50 seconds for 1,000 accounts and 18.50 / 18.86 seconds for 10,000 accounts, retaining the exact independent results and input hashes. Peak memory was 283 / 294 / 651 / 680 MiB respectively. Evidence: `data/release-audit-20261116-213756.local/full-validation-02/release-journey-scale/results.json`. Use the final candidate's validation evidence for its exact measured timings rather than treating earlier observations as a service-level promise.

Independent expectations require the complete exact affected-account union and requirement, confirmed certainty, summary agreement, expected CLI exit status, HTML report and unchanged inputs. The changed policy permits MFA OR a compliant device, which leaves noncompliant requirements uncovered for six of the eight fictional account cohorts. Report findings retain four separate scenario regions; region count is not the affected-account count.

Reproduce from development source:

```powershell
pwsh -NoProfile -File tests/Measure-ReleaseJourney.ps1 -OutputDirectory ./data/new-release-measurement.local
```

Choose a new output folder. Evidence includes input hashes, logs, exported reports, environment and measurements. The all-options validation runner also includes this measurement. Initial evidence is under `data/release-audit-20261116-213756.local/release-journey-scale-01/results.json`.

Time depends on distinct account profiles, overlapping condition boundaries, policy alternatives and requirement complexity, not just account count. Region/time limits must result in an incomplete assessment; increasing them does not expand supported Entra semantics. Attribution has its own bounded limits and must withhold partial coverage claims when exceeded. Additional scale fixtures exercise PIM, unknown directory data, resource groups, risk, history and other partitions; their results belong to the specific validation run, not the table above.

Interactive snapshot/account-set file selection is capped at 10 MiB. The offline module accepts 100 MiB per snapshot/requirements input; full-snapshot UI requests have a 100 MiB combined-body limit, and other API requests have a 10 MiB limit. These input-upload limits do not cap the number of findings or the size of saved assessment reports.

## Disk-backed findings (17 November 2026)

Tenant assessments and normalized-model commands now write findings into local
compressed pages as the engine produces them. A page contains up to 512 records;
only three mutable pages are cached. Eviction persists changes before discarding
a page. Exact finding keys, full regions, witnesses, policy references and
acceptance metadata survive page reloads. Owned temporary pages are removed when
the store is disposed; a process crash can leave temporary files behind.

**There is no 100,000-finding cutoff.** `MaxRegions` bounds the live regions in a
single calculation, rather than the accumulated result. For disk-backed runs,
`TimeoutSeconds` applies to an individual account-profile/requirement work unit,
not the whole assessment. Defaults remain 100,000 regions / 60 seconds for tenant
checks and 20,000 / 30 seconds for normalized UI checks. Large assessments may run
longer than 60 seconds. The low-level compatibility `Engine.Analyze` expanded-JSON
API retains its original safeguards; user entrypoints use the paged path.

Managed-memory safeguards still protect active calculations. They are not total
process-memory caps: snapshot translation, comparison and rendering also use
memory. A genuine computation failure must not be labelled a completed check.
There is no sampling or omission of findings to manufacture completion.

Large saved reports use `_calensFindingPages` version 1, containing independently
pooled pages (`_calensDetailPool` version 1). Encoding is page by page, rather than
constructing a second expanded result. Small reports keep their prior layout.
To reopen any size of report in PowerShell:

```powershell
. ./engine/Assessment.ps1
$report = [CaGapAnalyzer.ReportCodec]::ReadFile('C:/reports/check.json')
$report.gaps.Count
```

The browser receives large results as numbered pages and validates their order
and final count before displaying a complete assessment. Wide scenario maps are
created only when inspected; all finding metadata remains available for account
and requirement investigation. Saved-check listings scan report headers without
expanding findings. Exporting a report preserves every finding. See
[report storage](REPORT-STORAGE.md) for the format and lifecycle.

A synthetic full-pipeline test used **3,214 accounts, 60 groups, 20 CA policies,
17 requirements and 2,000 inventoried apps**, deliberately preventing account
profile reuse. It completed all 3,214 profiles and saved **437,104 findings** with
`completeWithinModel`, all 3,214 accounts checked and a score of 0 (all accounts
have deliberately introduced gaps). CLI assessment and JSON/HTML output took
about 180 seconds with peak process working set around 1.04 GiB on this machine.
The full JSON was about 176.8 MB. Only three finding pages were resident.

An independent oracle checked all 54,638 account/requirement pairs: each has
exactly eight disjoint regions covering the expected 233,309,160 finite-model
points. It validated every domain, account membership, witness and policy
reference. Reopening and rewriting the report preserved its SHA-256 byte for
byte. Reopening/oracle/export validation peaked around 1.43 GiB; this is measured
process memory, not a promise for all machines or policy sets.

A second automated test produces **122,061 findings with a working-region budget
of only 64**. It verifies eviction, mutable exceptions, indexed lookup, full
report roundtrips, history headers and transport counts. A browser-stream test
checks all 122,061 finding keys and rejects missing, repeated or truncated pages.
The actual user's snapshot was not available; these are reproducible synthetic
scale and correctness tests, alongside the existing semantic regression suite.

Run the larger reproducible test with:

```powershell
./tests/Test-DiskScale.ps1 -OutputDirectory ./data/my-scale-test.local
```

The review dialog shows account/requirement activity, scenario operations,
finding preparation and opening counts, and separate summary/save phases. Its
ETA uses measured progress over the latest 15 seconds, resets between stages
and withdraws stale estimates; it estimates the current counted stage only.
