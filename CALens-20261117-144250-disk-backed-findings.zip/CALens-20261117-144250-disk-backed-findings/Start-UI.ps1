#Requires -Version 7.4
[CmdletBinding()]
param([ValidateRange(1024,65535)][int]$Port=8765,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'engine/GapEngine.cs')
. (Join-Path $PSScriptRoot 'collection/OAuth.ps1')
. (Join-Path $PSScriptRoot 'collection/DirectoryGroups.ps1')
. (Join-Path $PSScriptRoot 'engine/Assessment.ps1')
. (Join-Path $PSScriptRoot 'engine/Javascript.ps1')
. (Join-Path $PSScriptRoot 'engine/Acceptance.ps1')
. (Join-Path $PSScriptRoot 'engine/LocalState.ps1')
. (Join-Path $PSScriptRoot 'engine/Maintenance.ps1')
Import-Module (Join-Path $PSScriptRoot 'CA.GapAnalyzer.psd1') -Force
. (Join-Path $PSScriptRoot 'engine/Interactive.ps1')
. (Join-Path $PSScriptRoot 'engine/Progress.ps1')
$url="http://localhost:$Port/"
$token=[guid]::NewGuid().ToString('N')
$data=Join-Path $PSScriptRoot 'data'
$null=New-Item -ItemType Directory -Path $data -Force
$acceptPath=Join-Path $data 'acceptances.local.json'
$tagPath=Join-Path $data 'tag-rules.local.json'
$workspacePath=Join-Path $data 'workspaces.local.json'
$connectionPath=Join-Path $data 'connection.local.json'
function Read-Connection {
    foreach($path in @($connectionPath,(Join-Path $PSScriptRoot 'collection/reader-app.local.json'))){
        if(Test-Path -LiteralPath $path){
            $settings=Read-CaLocalState -Path $path
            return @{tenantId=([guid]$settings.tenantId).ToString();clientId=([guid]$settings.clientId).ToString()}
        }
    }
    return $null
}
function Save-Connection($tenantId,$clientId) {
    $null=Update-CaLocalState -Path $connectionPath -Update {param($current);return @{tenantId=([guid]$tenantId).ToString();clientId=([guid]$clientId).ToString()}}
}
$oauthPending=$null
$oauthState=@{status='idle'}
function New-SnapshotWorker([string]$TenantId,[string]$BearerToken,[bool]$IncludePimGroups=$false,[bool]$IncludeApplicationAttributes=$false){
    $worker=[powershell]::Create()
    try{
        $progress=[Collections.Concurrent.ConcurrentDictionary[string,object]]::new()
        $saved=Read-CaLocalState -Path $workspacePath
        $extraGroups=@($saved['tenant:'+$TenantId].sets|ForEach-Object {$_.clauses}|Where-Object {$_.field -in @('groupIds','eligibleGroupIds') -and [guid]::TryParse([string]$_.value,[ref]([guid]::Empty))}|ForEach-Object {$_.value}|Sort-Object -Unique)
        $null=$worker.AddScript({param($path,$bearer,$tenant,$pim,$attributes,$progress,$extra);. $path;Get-CaTenantSnapshot -TenantId $tenant -BearerToken $bearer -IncludePimGroups:$pim -IncludeApplicationAttributes:$attributes -ProgressState $progress -ReferencedGroupsOnly -AdditionalGroupIds $extra}).AddArgument((Join-Path $PSScriptRoot 'collection/TenantSnapshot.ps1')).AddArgument($BearerToken).AddArgument($TenantId).AddArgument($IncludePimGroups).AddArgument($IncludeApplicationAttributes).AddArgument($progress).AddArgument([string[]]$extraGroups)
        return @{status='collecting';worker=$worker;handle=$worker.BeginInvoke();progress=$progress;readerToken=$BearerToken}
    }catch{$worker.Dispose();throw}
}
function Read-Acceptances {
    Read-CaLocalState -Path $acceptPath
}
function Hash-Text([string]$text) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($text))).ToLowerInvariant() }
function Send($context,$value,[string]$type='application/json',[int]$status=200) {
    $bytes=[Text.Encoding]::UTF8.GetBytes($value)
    $context.Response.StatusCode=$status
    $context.Response.ContentType="$type; charset=utf-8"
    $context.Response.ContentEncoding=[Text.Encoding]::UTF8
    $context.Response.Headers['Cache-Control']='no-store'
    $context.Response.Headers['X-Content-Type-Options']='nosniff'
    $context.Response.Headers['Referrer-Policy']='no-referrer'
    $context.Response.Headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
    $context.Response.ContentLength64=$bytes.Length
    $context.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $context.Response.Close()
}
function Send-Report($context,$report){
    $response=$context.Response;$response.StatusCode=200;$response.ContentType='application/json; charset=utf-8';$response.SendChunked=$true
    $response.Headers['Cache-Control']='no-store';$response.Headers['X-Content-Type-Options']='nosniff'
    try{[CaGapAnalyzer.ReportCodec]::Write($report,$response.OutputStream)}finally{$response.Close()}
}
$listener=[Net.HttpListener]::new()
$listener.Prefixes.Add($url)
try {$listener.Start()} catch {
    $listener.Close()
    try {$existing=Invoke-RestMethod ($url+'api/session') -TimeoutSec 2} catch {$existing=$null}
    if($existing.application -eq 'CA-Gap-Analyzer') {
        Write-Host "CALens is already running at $url"
        if(-not $NoBrowser){Start-Process $url}
        return
    }
    throw "Cannot listen on port $Port. Close the program using it or use -Port with another port."
}
Write-Host "CALens is running at $url"
Write-Host 'Local only. No tenant connection. Press Ctrl+C to stop.'
if(-not $NoBrowser){Start-Process $url}
$lastResult=$null
try {
    while($listener.IsListening){
        $context=$listener.GetContext()
        try {
            $request=$context.Request
            if($request.Url.Authority -ne "localhost:$Port"){Send $context '{"error":"Invalid host"}' 'application/json' 403;continue}
            $route=$request.Url.AbsolutePath
            if($request.HttpMethod -eq 'GET'){
                switch($route){
                    '/' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/workspace.html') -Raw -Encoding utf8) 'text/html'}
                    '/workspace.css' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/workspace.css') -Raw -Encoding utf8) 'text/css'}
                    '/calens-mark.svg' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/calens-mark.svg') -Raw -Encoding utf8) 'image/svg+xml'}
                    '/calens-logo.svg' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/calens-logo.svg') -Raw -Encoding utf8) 'image/svg+xml'}
                    '/policy-mapping.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/policy-mapping.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/review-presentation.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/review-presentation.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/account-set-library.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/account-set-library.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/appearance.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/appearance.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/workspace.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/workspace.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/workflow-navigation.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/workflow-navigation.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/report-codec.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/report-codec.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/coverage-progress.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/coverage-progress.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/collection-progress.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/collection-progress.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/group-directory.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/group-directory.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/coverage-worker.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/coverage-worker.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/requirement-review.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/requirement-review.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/requirement-model.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/requirement-model.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/requirement-builder.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/requirement-builder.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/api/reference-lab' {Send $context (Get-Content (Join-Path $PSScriptRoot 'examples/reference-lab.json') -Raw -Encoding utf8)}
                    '/builtin-role-catalog.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/builtin-role-catalog.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/demo-snapshot.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/demo-snapshot.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/snapshot.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/snapshot.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/session-controls.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/session-controls.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/authentication-strengths.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/authentication-strengths.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/device-filter.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/device-filter.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/external-users.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/external-users.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/role-schedules.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/role-schedules.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/pim-groups.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/pim-groups.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/resource-groups.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/resource-groups.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/location-model.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/location-model.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/coverage-summary.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/coverage-summary.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/history-view.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/history-view.js') -Raw -Encoding utf8) 'text/javascript'}
                    '/oauth/complete' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/oauth-complete.html') -Raw) 'text/html'}
                    '/oauth-complete.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/oauth-complete.js') -Raw) 'text/javascript'}
                    '/export-snapshot.ps1' {
                        $export=Get-Content (Join-Path $PSScriptRoot 'collection/Export-TenantSnapshot.ps1') -Raw
                        $collector=Get-Content (Join-Path $PSScriptRoot 'collection/TenantSnapshot.ps1') -Raw
                        $collector=(Get-Content (Join-Path $PSScriptRoot 'engine/JsonData.ps1') -Raw)+"`n"+$collector
                        $export=$export.Replace("`$ErrorActionPreference='Stop'","`$ErrorActionPreference='Stop'`n$collector")
                        $context.Response.Headers['Content-Disposition']='attachment; filename="Export-TenantSnapshot.ps1"'
                        Send $context $export 'text/plain'
                    }
                    '/export-resource-groups.ps1' {
                        $export=Get-Content (Join-Path $PSScriptRoot 'Export-ResourceGroupEvidence.ps1') -Raw
                        $collector=Get-Content (Join-Path $PSScriptRoot 'collection/ResourceGroupEvidence.ps1') -Raw
                        $export=$export.Replace("`$ErrorActionPreference='Stop'","`$ErrorActionPreference='Stop'`n$collector")
                        $context.Response.Headers['Content-Disposition']='attachment; filename="Export-ResourceGroupEvidence.ps1"'
                        Send $context $export 'text/plain'
                    }
                    '/resource-groups-guide.txt' {Send $context (Get-Content (Join-Path $PSScriptRoot 'docs/RESOURCE-GROUPS.md') -Raw -Encoding utf8) 'text/plain'}
                    '/oauth/callback' {
                        if(-not (Test-CaOAuthCallback $oauthPending $request.QueryString['state'] $request.Cookies['ca_oauth_tx'].Value)){Send $context '<h1>Sign-in not accepted</h1><p>The sign-in expired or did not match this browser. Start again from the analyzer.</p>' 'text/html' 400;break}
                        $transaction=$oauthPending;$oauthPending=$null
                        $context.Response.Headers['Set-Cookie']='ca_oauth_tx=; Path=/oauth; Max-Age=0; HttpOnly; SameSite=Lax'
                        if($request.QueryString['error'] -or -not $request.QueryString['code']){
                            $oauthState=@{status='error';message='Microsoft sign-in was cancelled or denied.'}
                            $context.Response.Headers['Location']='/oauth/complete'
                            Send $context '' 'text/html' 303;break
                        }
                        try{
                            $worker=$null
                            $accessResponse=Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$($transaction.tenantId)/oauth2/v2.0/token" -Body @{client_id=$transaction.clientId;grant_type='authorization_code';code=$request.QueryString['code'];redirect_uri=$transaction.redirectUri;code_verifier=$transaction.verifier;scope=$transaction.scopes} -ContentType 'application/x-www-form-urlencoded' -TimeoutSec 30
                            if(-not $accessResponse.access_token){throw 'Token not returned.'}
                            $oauthState=New-SnapshotWorker -TenantId $transaction.tenantId -BearerToken $accessResponse.access_token -IncludePimGroups $transaction.includePimGroups -IncludeApplicationAttributes $transaction.includeApplicationAttributes
                            $accessResponse=$null;$transaction=$null
                            $context.Response.Headers['Location']='/oauth/complete'
                            Send $context '' 'text/html' 303
                        }catch{
                            if($worker){$worker.Dispose()}
                            $accessResponse=$null;$transaction=$null
                            $oauthState=@{status='error';message='Could not complete sign-in. Check the app platform, localhost redirect and delegated consent.'}
                            $context.Response.Headers['Location']='/oauth/complete'
                            Send $context '' 'text/html' 303
                        }
                    }
                    '/app.css' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/app.css') -Raw) 'text/css'}
                    '/app.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/app.js') -Raw) 'text/javascript'}
                    '/findings.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/findings.js') -Raw) 'text/javascript'}
                    '/lab.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/lab.js') -Raw) 'text/javascript'}
                    '/account-tags.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/account-tags.js') -Raw) 'text/javascript'}
                    '/accounts.js' {Send $context (Get-Content (Join-Path $PSScriptRoot 'ui/accounts.js') -Raw) 'text/javascript'}
                    '/api/tag-rules' {
                        $rules=Read-CaLocalState -Path $tagPath -DefaultValue @()
                        Send $context (@{rules=@($rules)}|ConvertTo-Json -Depth 10)
                    }
                    '/api/lab' {Send $context (Get-Content (Join-Path $PSScriptRoot 'examples/architecture-lab.json') -Raw)}
                    '/api/session' {Send $context (@{application='CA-Gap-Analyzer';token=$token;connection=(Read-Connection)}|ConvertTo-Json)}
                    '/api/example' {Send $context (Get-Content (Join-Path $PSScriptRoot 'examples/exclusion-gap.json') -Raw)}
                    default {Send $context '{"error":"Not found"}' 'application/json' 404}
                }
                continue
            }
            if($request.HttpMethod -ne 'POST' -or $request.Headers['X-Session-Token'] -ne $token -or ($request.Headers['Origin'] -and $request.Headers['Origin'] -ne $url.TrimEnd('/'))){Send $context '{"error":"Invalid session"}' 'application/json' 403;continue}
            $uploadLimit=if($route -eq '/api/assess'){100MB}else{10MB}
            if($request.ContentLength64 -lt 0 -or $request.ContentLength64 -gt $uploadLimit){Send $context (@{error="Maximum upload is $($uploadLimit/1MB) MB"}|ConvertTo-Json) 'application/json' 413;continue}
            $reader=[IO.StreamReader]::new($request.InputStream)
            $rawBody=$reader.ReadToEnd()
            if($route -in @('/api/assess','/api/analyze') -and $request.Headers['X-Coverage-Progress'] -eq '1'){
                $lastResult=Send-CaAssessmentStream $context $rawBody $PSScriptRoot ($route -eq '/api/assess');continue
            }
            $body=$rawBody|ConvertFrom-CaJson
            if($route -eq '/api/token/collect'){
                if($body.ContainsKey('includePimGroups') -and $body.includePimGroups -isnot [bool]){throw 'IncludePimGroups must be true or false.'}
                if($body.ContainsKey('includeApplicationAttributes') -and $body.includeApplicationAttributes -isnot [bool]){throw 'IncludeApplicationAttributes must be true or false.'}
                if($oauthState.status -eq 'collecting'){throw 'A collection is already running.'}
                $tenant=([guid]$body.tenantId).ToString()
                $providedToken=([string]$body.accessToken).Trim() -replace '^Bearer\s+',''
                $body.accessToken=$null
                if(!$providedToken -or $providedToken.Length -gt 65536){throw 'Enter a Microsoft Graph access token.'}
                try{
                    $oauthPending=$null
                    $oauthState=New-SnapshotWorker -TenantId $tenant -BearerToken $providedToken -IncludePimGroups ($body.includePimGroups -eq $true) -IncludeApplicationAttributes ($body.includeApplicationAttributes -eq $true)
                }finally{$providedToken=$null}
                Send $context '{"status":"collecting"}'
            }elseif($route -eq '/api/connection/save'){
                Save-Connection $body.tenantId $body.clientId
                Send $context '{"saved":true}'
            }elseif($route -eq '/api/oauth/start'){
                if($body.ContainsKey('includePimGroups') -and $body.includePimGroups -isnot [bool]){throw 'IncludePimGroups must be true or false.'}
                if($body.ContainsKey('includeApplicationAttributes') -and $body.includeApplicationAttributes -isnot [bool]){throw 'IncludeApplicationAttributes must be true or false.'}
                if($oauthState.status -eq 'collecting'){throw 'A collection is already running.'}
                $oauthPending=New-CaOAuthTransaction -TenantId ([guid]$body.tenantId) -ClientId ([guid]$body.clientId) -RedirectUri ($url+'oauth/callback') -IncludePimGroups:($body.includePimGroups -eq $true) -IncludeApplicationAttributes:($body.includeApplicationAttributes -eq $true)
                Save-Connection $body.tenantId $body.clientId
                $oauthState=@{status='signingIn'}
                $context.Response.Headers['Set-Cookie']="ca_oauth_tx=$($oauthPending.cookie); Path=/oauth; HttpOnly; SameSite=Lax"
                Send $context (@{authorizeUrl=$oauthPending.authorizeUrl}|ConvertTo-Json)
            }elseif($route -eq '/api/oauth/status'){
                if($oauthState.status -eq 'collecting' -and $oauthState.handle.IsCompleted){
                    $worker=$oauthState.worker
                    try{
                        $output=$worker.EndInvoke($oauthState.handle)
                        if($output.Count -ne 1 -or $output[0].caGapSnapshotVersion -ne 1){throw 'Collection failed.'}
                        $oauthState=@{status='complete';snapshot=$output[0];readerToken=$oauthState.readerToken}
                    }catch{$oauthState=@{status='error';message='Snapshot collection failed. Check reader permissions and tenant access.'}}
                    finally{$worker.Dispose()}
                }
                if($oauthState.status -eq 'signingIn' -and $oauthPending -and [DateTime]::UtcNow -gt $oauthPending.expires){$oauthPending=$null;$oauthState=@{status='error';message='Sign-in expired. Please start again.'}}
                if($oauthState.status -eq 'complete'){Send $context (@{status='complete';snapshot=$oauthState.snapshot}|ConvertTo-Json -Depth 100)}else{Send $context (@{status=$oauthState.status;message=$oauthState.message;progress=$(if($oauthState.progress){$oauthState.progress['latest']}else{$null})}|ConvertTo-Json -Depth 10)}
            }elseif($route -in @('/api/groups/search','/api/groups/read')){
                if($oauthState.status -ne 'complete' -or !$oauthState.readerToken -or ([guid]$body.tenantId).ToString() -ne $oauthState.snapshot.tenantId){throw 'Connect to this tenant first to search online. Groups already in your snapshot remain available offline.'}
                if($route -eq '/api/groups/search'){$groupResult=Find-CaDirectoryGroups -Query ([string]$body.query) -BearerToken $oauthState.readerToken}
                else{
                    if($body.ContainsKey('includePimGroups') -and $body.includePimGroups -isnot [bool]){throw 'Invalid group request.'}
                    $groupResult=Get-CaDirectoryGroupEvidence -GroupId ([guid]$body.groupId) -KnownUserIds ([string[]]@($oauthState.snapshot.users|ForEach-Object {$_.id})) -IncludePimGroups:($body.includePimGroups -eq $true) -BearerToken $oauthState.readerToken
                }
                Send $context ($groupResult|ConvertTo-Json -Depth 50)
            }elseif($route -eq '/api/oauth/disconnect'){
                if($oauthState.status -eq 'collecting'){$oauthState.worker.Stop();$oauthState.worker.Dispose()}
                $oauthPending=$null;$oauthState=@{status='idle'}
                Send $context '{"disconnected":true}'
            }elseif($route -eq '/api/app/reset'){
                if($body.confirmation -cne 'reset-local-app-data'){throw 'Confirm the local app-data reset first.'}
                if($oauthState.status -in @('collecting','signingIn')){throw 'Finish or clear the current connection before resetting app data.'}
                $reset=Reset-CaLocalAppData -Root $PSScriptRoot
                $oauthPending=$null;$oauthState=@{status='idle'};$lastResult=$null
                Send $context ($reset|ConvertTo-Json -Depth 5)
            }elseif($route -eq '/api/workspace/load'){
                $profiles=Read-CaLocalState -Path $workspacePath
                Send $context (@{profile=$profiles[[string]$body.key]}|ConvertTo-Json -Depth 100)
            }elseif($route -eq '/api/workspace/save'){
                if(-not $body.key -or ([string]$body.key).Length -gt 200 -or $body.profile.version -ne 1 -or $body.profile.sets -isnot [array] -or $body.profile.requirements -isnot [array]){throw 'Invalid workspace profile.'}
                $null=Update-CaLocalState -Path $workspacePath -Update {param($profiles);$profiles[[string]$body.key]=$body.profile;return ,$profiles}
                Send $context '{"saved":true}'
            }elseif($route -eq '/api/assess'){
                if($body.streamProgress -eq $true){$lastResult=Send-CaAssessmentStream $context $body $PSScriptRoot $true;continue}
                $result=Invoke-CaInteractiveAssessment $body.snapshot $body.profile
                $lastResult=$result
                Send-Report $context $result
            }elseif($route -eq '/api/results/export'){
                if(!$lastResult -or $lastResult.modelHash -cne $body.modelHash -or $lastResult.sourceKey -cne $body.sourceKey){throw 'Check coverage again before exporting this result.'}
                $export=[System.Management.Automation.OrderedHashtable]::new();foreach($key in $lastResult.Keys){$export[$key]=$lastResult[$key]}
                if($body.coverageSummary -and $body.coverageSummary.total -eq $lastResult.identityCount -and $body.coverageSummary.checked -eq $lastResult.coverageSummary.checked -and $body.coverageSummary.score -eq $lastResult.coverageSummary.score){$export.coverageSummary=$body.coverageSummary}
                $context.Response.Headers['Content-Disposition']='attachment; filename="ca-coverage-results.json"'
                Send-Report $context $export
            }elseif($route -eq '/api/history/export'){
                $export=Get-CaInteractiveHistory ([string]$body.sourceKey) ([string]$body.runId)
                $context.Response.Headers['Content-Disposition']='attachment; filename="ca-saved-check.json"'
                Send-Report $context $export
            }elseif($route -eq '/api/history'){
                Send-Report $context (Get-CaInteractiveHistory ([string]$body.sourceKey) ([string]$body.runId))
            }elseif($route -eq '/api/analyze'){
                if($body.streamProgress -eq $true){$lastResult=Send-CaAssessmentStream $context $body $PSScriptRoot $false;continue}
                $accepted=Read-Acceptances
                $result=Invoke-CaAssessmentCore -Model $body.model -CoverageIssues @($body.coverageIssues) -Acceptances $accepted -SourceKey ([string]$body.sourceKey) -AcceptanceEvidence $body.acceptanceEvidence
                $lastResult=$result
                Send-Report $context $result
            } elseif($route -eq '/api/tag-rules'){
                if($null -eq $body.rules -or $body.rules -isnot [array] -or $body.rules.Count -gt 50){throw 'Provide an array of at most 50 rules.'}
                foreach($rule in $body.rules){
                    if($rule.enabled -isnot [bool] -or $rule.tag -isnot [string] -or -not $rule.tag.Trim() -or $rule.tag.Length -gt 40 -or $rule.field -notin @('displayName','userPrincipalName','jobTitle','userType') -or $rule.operator -notin @('startsWith','equals','hasValue') -or $rule.value -isnot [string] -or $rule.value.Length -gt 200 -or ($rule.operator -ne 'hasValue' -and -not $rule.value.Trim())){throw 'Invalid tag rule.'}
                }
                $null=Update-CaLocalState -Path $tagPath -Update {param($current);return ,@($body.rules)} -DefaultValue @()
                Send $context '{"saved":true}'
            } elseif($route -eq '/api/accept'){
                if(-not $lastResult -or -not [CaGapAnalyzer.ReportCodec]::FindFinding($lastResult,[string]$body.key)){throw 'Run an assessment and select a current finding first.'}
                if($body.reopen){
                    if($lastResult['acceptanceMatching'] -and $lastResult.acceptanceMatching.status -in @('bounded','unavailable')){throw 'Exception scope could not be fully compared. Run the check again before reopening it.'}
                    $gap=[CaGapAnalyzer.ReportCodec]::FindFinding($lastResult,[string]$body.key)
                    $removeKeys=@($body.key)+@($gap.acceptance.recordKeys)
                }else{
                    $reason=([string]$body.reason).Trim()
                    if($reason.Length -lt 3 -or $reason.Length -gt 1000){throw 'Provide a reason between 3 and 1,000 characters.'}
                    $newAcceptance=@{reason=$reason;acceptedAtUtc=[DateTime]::UtcNow.ToString('o')}
                    $scope=New-CaSemanticAcceptanceScope $lastResult $body.key
                    if($scope){$newAcceptance.semanticScope=$scope}
                }
                $accepted=Update-CaLocalState -Path $acceptPath -Update {
                    param($current)
                    if($body.reopen){foreach($key in $removeKeys){if($key){$null=$current.Remove($key)}}}else{$current[$body.key]=$newAcceptance}
                    return ,$current
                }
                $gap=[CaGapAnalyzer.ReportCodec]::FindFinding($lastResult,[string]$body.key);$gap.acceptance=Get-CaAcceptanceSummary $accepted[$body.key] $body.key
                Send $context (@{acceptance=$gap.acceptance}|ConvertTo-Json -Depth 20)
            }else{Send $context '{"error":"Not found"}' 'application/json' 404}
        }catch{
            Send $context (@{error=$_.Exception.Message}|ConvertTo-Json) 'application/json' 400
        }
    }
}finally{
    if($oauthState.status -eq 'collecting'){$oauthState.worker.Stop();$oauthState.worker.Dispose()}
    $oauthPending=$null;$oauthState=$null
    $listener.Stop();$listener.Close()
}

