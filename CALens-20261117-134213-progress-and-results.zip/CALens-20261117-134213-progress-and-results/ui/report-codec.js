'use strict';
// Lossless storage/transport for repeated scenario axes. No findings are sampled.
const ReportCodec=(()=>{
 const marker='_calensDetailPool',own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
 function decode(value){
  if(!value||!own(value,marker))return value;
  const pool=value[marker];
  if(!pool||pool.version!==1||!Array.isArray(value.gaps)||!['strings','regions','witnesses'].every(k=>Array.isArray(pool[k])))throw Error('Unsupported shared coverage result.');
  if(value.gaps.length>1000000||['strings','regions','witnesses'].some(k=>pool[k].length>2000000))throw Error('Coverage result is too large.');
  if(pool.strings.some(a=>!Array.isArray(a)||a.some(s=>typeof s!=='string')))throw Error('Invalid shared coverage values.');
  const index=(v,rows)=>{if(!Number.isInteger(v)||v<0||v>=rows.length)throw Error('Invalid shared coverage reference.');return rows[v];};
  const caches={regions:new Map(),witnesses:new Map()};let cells=0;
  function details(ref,key,table){
   if(!ref||Object.keys(ref).length!==1||!own(ref,key))throw Error('Invalid shared coverage details.');
   const row=index(ref[key],pool[table]);let result=caches[table].get(ref[key]);
   if(!result){
    if(!Array.isArray(row)||!row.length)throw Error('Invalid shared coverage row.');
    const names=index(row[0],pool.strings),region=table==='regions';
    if(new Set(names).size!==names.length||(region?row.length!==names.length+1:row.length!==2))throw Error('Invalid shared coverage axes.');
    const values=region?null:index(row[1],pool.strings);if(values&&values.length!==names.length)throw Error('Invalid shared coverage witness.');
    result=Object.fromEntries(names.map((name,i)=>[name,region?index(row[i+1],pool.strings):values[i]]));caches[table].set(ref[key],result);
   }
   cells+=Object.keys(result).length;if(cells>12000000)throw Error('Shared coverage expansion limit exceeded.');return {...result};
  }
  const output={...value,gaps:value.gaps.map(g=>{
   const gap={...g,region:details(g.region,'$region','regions'),witness:details(g.witness,'$witness','witnesses')};
   for(const key of ['identityIds','applicablePolicyIds','nonApplicablePolicyIds'])if(own(g,key)){
    const ref=g[key];if(!ref||Object.keys(ref).length!==1||!own(ref,'$strings'))throw Error('Invalid shared coverage list.');gap[key]=index(ref.$strings,pool.strings);
   }return gap;
  })};delete output[marker];return output;
 }
 function encode(value,force=false){
  if(!value||!Array.isArray(value.gaps)||!value.gaps.length||own(value,marker))return value;
  if(!force&&value.gaps.length<256){let size=0;const widths=new WeakMap();for(const gap of value.gaps)for(const values of Object.values(gap.region||{})){if(!widths.has(values))widths.set(values,values.reduce((n,s)=>n+s.length+3,0));size+=widths.get(values);}if(size<1048576)return value;}
  const pool={version:1,strings:[],regions:[],witnesses:[]},tables={strings:new Map(),regions:new Map(),witnesses:new Map()},refs=new WeakMap();
  function add(table,row){const key=JSON.stringify(row),map=tables[table];if(!map.has(key)){map.set(key,pool[table].length);pool[table].push(row);}return map.get(key);}
  function strings(a){if(!Array.isArray(a)||a.some(s=>typeof s!=='string'))throw Error('Invalid coverage values.');if(refs.has(a))return refs.get(a);const id=add('strings',a);refs.set(a,id);return id;}
  return {...value,gaps:value.gaps.map(g=>{
   const names=Object.keys(g.region),wnames=Object.keys(g.witness);
   const copy={...g,region:{$region:add('regions',[strings(names),...names.map(n=>strings(g.region[n]))])},witness:{$witness:add('witnesses',[strings(wnames),strings(wnames.map(n=>g.witness[n]))])}};
   for(const key of ['identityIds','applicablePolicyIds','nonApplicablePolicyIds'])if(own(g,key))copy[key]={$strings:strings(g[key])};return copy;
  }),[marker]:pool};
 }
 return {encode,decode};
})();
if(typeof module!=='undefined')module.exports=ReportCodec;
