# Performance measurements

Development measurement, 2026-11-16. Release acceptance is still pending.

The fresh-process offline command was measured against fictional exports containing 21 raw policies and seven requirements. Policies include overlapping Member/Guest groups, active and eligible roles, explicit exclusions and compensating protection, app-specific grants, legacy/flow blocks, IPv4/IPv6 networks, registration actions, authentication context, disabled and report-only policies. Six equivalent account profiles were found; this represents a patterned organisation, not every worst-case unique-identity policy set.

| Accounts | Case | Full CLI and JSON/HTML export | Engine | Peak process memory | Confirmed accounts needing attention |
|---|---|---:|---:|---:|---:|
| 1,000 | Covered | 3.90 seconds | 24 ms | 289 MiB | 0 |
| 1,000 | MFA AND compliance weakened to OR | 3.98 seconds | 28 ms | 294 MiB | 750 |
| 10,000 | Covered | 21.49 seconds | 135 ms | 704 MiB | 0 |
| 10,000 | MFA AND compliance weakened to OR | 23.64 seconds | 143 ms | 683 MiB | 7,500 |

Environment: Windows 10.0.26300 x64, 16 logical processors, PowerShell 7.6.9, .NET 10.0.14. Measurements ran while the separate validation suite was active, so these are observed results under concurrent local load, not a controlled performance guarantee. Input fixture generation is excluded; fresh PowerShell startup, input reading, V8 normalization/compilation, history evidence construction, .NET analysis, summaries and report export are included. History saving is disabled and the benchmark uses a new empty acceptance path. The child process has no Node/SDK on PATH and uses unusable external proxies; this is not an OS-enforced air gap.

A second frozen all-options run on PowerShell 7.4.22 / .NET 8.0.33 measured the same cases at 3.41 / 3.50 seconds for 1,000 accounts and 18.50 / 18.86 seconds for 10,000 accounts, retaining the exact independent results and input hashes. Peak memory was 283 / 294 / 651 / 680 MiB respectively. Evidence: `data/release-audit-20261116-213756.local/full-validation-02/release-journey-scale/results.json`. Use the final candidate's validation evidence for its exact measured timings rather than treating earlier observations as a service-level promise.

Independent expectations require the complete exact affected-account union and requirement, confirmed certainty, summary agreement, expected CLI exit status, HTML report and unchanged inputs. The changed policy permits MFA OR a compliant device, which leaves noncompliant requirements uncovered for six of the eight fictional account cohorts. Report findings retain four separate scenario regions; region count is not the affected-account count.

Reproduce from development source:

```powershell
pwsh -NoProfile -File tests/Measure-ReleaseJourney.ps1 -OutputDirectory ./data/new-release-measurement.local
```

Choose a new output folder. Evidence includes input hashes, logs, exported reports, environment and measurements. The all-options validation runner also includes this measurement. Initial evidence is under `data/release-audit-20261116-213756.local/release-journey-scale-01/results.json`.

Time depends on distinct account profiles, overlapping condition boundaries, policy alternatives and requirement complexity, not just account count. Region/time limits must result in an incomplete assessment; increasing them does not expand supported Entra semantics. Attribution has its own bounded limits and must withhold partial coverage claims when exceeded. Additional scale fixtures exercise PIM, unknown directory data, resource groups, risk, history and other partitions; their results belong to the specific validation run, not the table above.

Interactive snapshot/account-set file selection is capped at 10 MiB. The offline module accepts 100 MiB per input file; full-snapshot UI assessment requests have a 100 MiB combined-body limit, and other API requests have a 10 MiB limit. Full snapshots use the same default 100,000-region / 60-second engine limits in the UI and CLI. Generic normalized-model UI checks use 20,000 / 30 seconds. Those engine timers do not cover the whole startup, translation or report-export pipeline. Attribution defaults to 20,000 regions and 750 ms and withholds coverage when bounded. These are explicit resource limits, not correctness shortcuts or promises of real sign-in feasibility.

## Memory use and large checks (November 2026)

Account count alone does not predict memory use. Region fragmentation, wide app
or external-identity domains, and repeated detailed findings can dominate a run.
The engine now shares immutable axis sets, applies account bounds before expanding
shared scenario constraints, and compares account profiles structurally rather
than serializing a large JSON key for every account. Source diagnostic evidence
still binds fingerprints in the assessment layer; the C# predicate evaluator no
longer retains a second unused JSON DOM for it. Finding fingerprint inputs are
unchanged, but their shared uncertainty JSON is serialized once per run.

The tenant assessment now keeps typed findings in memory and shares repeated axis
lists. Large JSON reports use a lossless `_calensDetailPool` (version 1): each
finding refers to shared account lists, policy lists, regions and witnesses.
CALens expands these references when opening results, saved checks and downloads.
Small reports retain their ordinary JSON layout. No finding or scenario value is
removed. External readers of large report JSON must understand this shared format;
PowerShell callers can use `ConvertFrom-CaJson` from `engine/Assessment.ps1`.

The typed tenant path uses a managed-heap growth guard up to 768 MiB above its
post-load baseline, scaled down for smaller runtime memory limits. The legacy
low-level `Engine.Analyze` JSON API retains its 256 MiB growth guard and 16 Mi
character expanded-detail budget. These are safeguards, not total process memory
caps: input parsing, PowerShell, JavaScript, report rendering and encoding also
use memory. Region/time/memory limits still return explicitly incomplete results;
they must never be interpreted as clean checks. Restart after changing builds to
load the updated C# engine.

The review dialog receives actual completed-account counts, the current
requirement, scenario subtraction counts and potential finding counts. It then
shows distinct activity for uncertainty checks, finding preparation, exception
matching, coverage totals, history comparison and saving. Finding preparation
has its own completed/total counter. There is no guessed whole-run percentage;
the progress bar belongs to the current counted stage. A rough ETA uses measured
progress over the latest 15 seconds, appears after sufficient observations, resets
between stages and withdraws stale estimates. It estimates the current stage,
not the whole remaining assessment.

Synthetic regression evidence (17 November 2026): a tenant fixture with 3,214
accounts, 60 groups, 33 exported policy shapes, 17 enabled starter requirements
and 2,000 inventoried apps completed all 113 identity profiles and returned
43,571 findings in about 135 seconds through CLI analysis and JSON/HTML export.
Its packed JSON was approximately 39.7 MB. Parse/expand/repack preserved every
field exactly. The finite engine completed; the final assessment remained
`unresolvedCoverage` because the fixture deliberately lacks some source facts.
This is not a measurement of the user's real snapshot, which was unavailable.
The same fixture previously stopped at the expanded result-detail limit.

A separate 3,214-account model with 20 coupled constraints verifies that fixed
account bounds are applied before shared-constraint expansion. Independent
small-model tests compare typed and legacy findings, exact fingerprints and
per-point decisions. Cumulative allocation figures are not peak working set.
