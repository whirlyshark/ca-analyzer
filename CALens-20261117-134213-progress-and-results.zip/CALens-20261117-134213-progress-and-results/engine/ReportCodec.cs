using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text;
using System.Security.Cryptography;

namespace CaGapAnalyzer
{
    // Lossless result transport only. No analysis predicates or scopes change.
    public static class ReportCodec
    {
        const string Marker="_calensDetailPool";
        static readonly Type MapType=Type.GetType("System.Management.Automation.OrderedHashtable, System.Management.Automation",true);
        static IDictionary Map()=> (IDictionary)Activator.CreateInstance(MapType);
        static readonly JsonSerializerOptions Options=CreateOptions();
        static object Unwrap(object value){while(value?.GetType().FullName=="System.Management.Automation.PSObject")value=value.GetType().GetProperty("BaseObject").GetValue(value);return value;}
        sealed class WrapperConverter:JsonConverterFactory{
            public override bool CanConvert(Type t)=>t.FullName=="System.Management.Automation.PSObject";
            public override JsonConverter CreateConverter(Type t,JsonSerializerOptions o)=>(JsonConverter)Activator.CreateInstance(typeof(Wrapper<>).MakeGenericType(t));
        }
        sealed class Wrapper<T>:JsonConverter<T>{
            public override T Read(ref Utf8JsonReader reader,Type type,JsonSerializerOptions options)=>throw new NotSupportedException();
            public override void Write(Utf8JsonWriter writer,T value,JsonSerializerOptions options)=>JsonSerializer.Serialize(writer,Unwrap(value),options);
        }
        static JsonSerializerOptions CreateOptions(){var o=new JsonSerializerOptions{WriteIndented=false,MaxDepth=100};o.Converters.Add(new WrapperConverter());return o;}
        static object[] ArrayOf(object value)=>value is IEnumerable sequence && value is not string && value is not IDictionary?sequence.Cast<object>().ToArray():throw new ArgumentException("Invalid shared result array.");
        static int Index(object value,int count){long n=value is int i?i:value is long l?l:-1;return n>=0&&n<count?(int)n:throw new ArgumentException("Invalid shared result reference.");}
        static string[] Strings(object value){var array=ArrayOf(value);if(array.Any(v=>v is not string))throw new ArgumentException("Invalid shared result strings.");return array.Cast<string>().ToArray();}
        static IDictionary Copy(IDictionary source){var target=Map();foreach(DictionaryEntry entry in source)target.Add(entry.Key,entry.Value);return target;}
        sealed class Pool
        {
            public List<string[]> Strings=new(); public List<int[]> Regions=new();public List<int[]> Witnesses=new();
            readonly Dictionary<object,int> references=new(ReferenceEqualityComparer.Instance);
            readonly Dictionary<string,int> strings=new(StringComparer.Ordinal),regions=new(StringComparer.Ordinal),witnesses=new(StringComparer.Ordinal);
            public int StringId(object value){
                if(references.TryGetValue(value,out int id))return id;
                var array=value as string[]??ReportCodec.Strings(value);var key=JsonSerializer.Serialize(array,Options);
                if(!strings.TryGetValue(key,out id)){id=Strings.Count;Strings.Add(array);strings.Add(key,id);}
                references.Add(value,id);return id;
            }
            public int Region(IDictionary region){
                var names=region.Keys.Cast<string>().ToArray();var values=new int[names.Length+1];values[0]=StringId(names);
                for(int i=0;i<names.Length;i++)values[i+1]=StringId(region[names[i]]);
                var key=string.Join(",",values);if(!regions.TryGetValue(key,out int id)){id=Regions.Count;Regions.Add(values);regions.Add(key,id);}return id;
            }
            public int Witness(IDictionary witness){
                var names=witness.Keys.Cast<string>().ToArray();var values=names.Select(n=>(string)witness[n]).ToArray();var descriptor=new[]{StringId(names),StringId(values)};
                var key=string.Join(",",descriptor);if(!witnesses.TryGetValue(key,out int id)){id=Witnesses.Count;Witnesses.Add(descriptor);witnesses.Add(key,id);}return id;
            }
        }
        static IDictionary Reference(string key,int id){var map=Map();map.Add(key,id);return map;}
        public static object Pack(object value,bool force=false)
        {
            value=Unwrap(value);
            if(value is not IDictionary report||!report.Contains("gaps")||report.Contains(Marker))return value;
            var gaps=ArrayOf(report["gaps"]);if(gaps.Length==0)return value;
            if(!force&&gaps.Length<256){
                long detail=0;var widths=new Dictionary<object,long>(ReferenceEqualityComparer.Instance);
                foreach(var item in gaps){if(item is not IDictionary g||g["region"] is not IDictionary r)continue;foreach(var axis in r.Values){if(!widths.TryGetValue(axis,out var width)){width=Strings(axis).Sum(s=>(long)s.Length+3);widths.Add(axis,width);}detail+=width;}}
                if(detail<1048576)return value;
            }
            var pool=new Pool();var packed=Copy(report);var output=new object[gaps.Length];
            for(int i=0;i<gaps.Length;i++){
                if(gaps[i] is not IDictionary gap||gap["region"] is not IDictionary region||gap["witness"] is not IDictionary witness)throw new ArgumentException("Invalid finding details.");
                var copy=Copy(gap);copy["region"]=Reference("$region",pool.Region(region));copy["witness"]=Reference("$witness",pool.Witness(witness));
                foreach(var field in new[]{"identityIds","applicablePolicyIds","nonApplicablePolicyIds"})if(gap.Contains(field))copy[field]=Reference("$strings",pool.StringId(gap[field]));
                output[i]=copy;
            }
            var metadata=Map();metadata.Add("version",1);metadata.Add("strings",pool.Strings.ToArray());metadata.Add("regions",pool.Regions.ToArray());metadata.Add("witnesses",pool.Witnesses.ToArray());
            packed["gaps"]=output;packed.Add(Marker,metadata);return packed;
        }
        public static string Serialize(object value,bool force=false)=>JsonSerializer.Serialize(Pack(value,force),Options);
        public static object Expand(object value)
        {
            value=Unwrap(value);
            if(value is not IDictionary report||!report.Contains(Marker))return value;
            if(report[Marker] is not IDictionary metadata||Index(metadata["version"],2)!=1||!report.Contains("gaps"))throw new ArgumentException("Unsupported shared result format.");
            var strings=ArrayOf(metadata["strings"]).Select(Strings).ToArray();
            var regions=ArrayOf(metadata["regions"]);var witnesses=ArrayOf(metadata["witnesses"]);var gaps=ArrayOf(report["gaps"]);
            if(strings.Length>2000000||regions.Length>2000000||witnesses.Length>2000000||gaps.Length>1000000)throw new ArgumentException("Shared result limit exceeded.");
            var regionCache=new IDictionary[regions.Length];var witnessCache=new IDictionary[witnesses.Length];long cells=0;
            IDictionary Details(object reference,string key,bool isRegion){
                if(reference is not IDictionary map||map.Count!=1||!map.Contains(key))throw new ArgumentException("Invalid shared result details.");
                var cache=isRegion?regionCache:witnessCache;var rows=isRegion?regions:witnesses;int index=Index(map[key],rows.Length);
                if(cache[index]!=null){cells+=cache[index].Count;if(cells>12000000)throw new ArgumentException("Shared result expansion limit exceeded.");return Copy(cache[index]);}
                var row=ArrayOf(rows[index]);if(row.Length<1)throw new ArgumentException("Invalid shared result row.");var names=strings[Index(row[0],strings.Length)];
                if((isRegion?row.Length!=names.Length+1:row.Length!=2)||names.Distinct(StringComparer.Ordinal).Count()!=names.Length)throw new ArgumentException("Invalid shared result axes.");
                cells+=names.Length;if(cells>12000000)throw new ArgumentException("Shared result expansion limit exceeded.");
                var target=Map();var values=isRegion?null:strings[Index(row[1],strings.Length)];if(values!=null&&values.Length!=names.Length)throw new ArgumentException("Invalid shared witness.");
                for(int n=0;n<names.Length;n++)target.Add(names[n],isRegion?(object)strings[Index(row[n+1],strings.Length)]:values[n]);
                cache[index]=target;return Copy(target);
            }
            foreach(var item in gaps){
                if(item is not IDictionary gap)throw new ArgumentException("Invalid shared finding.");
                gap["region"]=Details(gap["region"],"$region",true);gap["witness"]=Details(gap["witness"],"$witness",false);
                foreach(var field in new[]{"identityIds","applicablePolicyIds","nonApplicablePolicyIds"})if(gap.Contains(field)){
                    if(gap[field] is not IDictionary r||r.Count!=1||!r.Contains("$strings"))throw new ArgumentException("Invalid shared account or policy list.");gap[field]=strings[Index(r["$strings"],strings.Length)];
                }
            }
            report.Remove(Marker);return report;
        }
        public sealed class FindingFingerprints {
            readonly byte[] prefix;
            readonly Dictionary<string,string> text=new(StringComparer.Ordinal);
            readonly Dictionary<object,string> sequences=new(ReferenceEqualityComparer.Instance);
            public FindingFingerprints(string prefix){this.prefix=Encoding.UTF8.GetBytes(prefix);}
            string Quote(string value){
                if(text.TryGetValue(value,out var known))return known;
                var b=new StringBuilder("\"");foreach(char c in value){switch(c){
                    case '"':b.Append("\\\"");break;case '\\':b.Append("\\\\");break;
                    case '\b':b.Append("\\b");break;case '\f':b.Append("\\f");break;case '\n':b.Append("\\n");break;case '\r':b.Append("\\r");break;case '\t':b.Append("\\t");break;
                    default:if(c<32||c=='\u0085'||c=='\u2028'||c=='\u2029')b.Append("\\u").Append(((int)c).ToString("x4"));else b.Append(c);break;
                }}b.Append('"');known=b.ToString();text.Add(value,known);return known;
            }
            string Json(object value){
                value=Unwrap(value);if(value==null)return "null";if(value is string s)return Quote(s);
                if(value is IDictionary map)return "{"+string.Join(",",map.Keys.Cast<string>().Select(k=>Quote(k)+":"+Json(map[k])))+"}";
                if(value is IEnumerable list){if(sequences.TryGetValue(value,out var known))return known;known="["+string.Join(",",list.Cast<object>().Select(Json))+"]";sequences.Add(value,known);return known;}
                return JsonSerializer.Serialize(value,Options);
            }
            public string JsonGap(IDictionary gap)=>Json(gap);
            public string Hash(IDictionary gap){using var hash=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);hash.AppendData(prefix);hash.AppendData(Encoding.UTF8.GetBytes(Json(gap)));return Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();}
        }
        public static object Parse(string json)
        {
            var intern=new Dictionary<string,string>(StringComparer.Ordinal);
            string Text(string s){if(intern.TryGetValue(s,out var known))return known;intern.Add(s,s);return s;}
            object Read(JsonElement node){
                switch(node.ValueKind){
                    case JsonValueKind.Object:var map=Map();foreach(var property in node.EnumerateObject()){var key=Text(property.Name);if(map.Contains(key))throw new ArgumentException("Duplicate JSON property.");map.Add(key,Read(property.Value));}return map;
                    case JsonValueKind.Array:return node.EnumerateArray().Select(Read).ToArray();
                    case JsonValueKind.String:return Text(node.GetString());
                    case JsonValueKind.Number:if(node.TryGetInt64(out long n))return n;if(node.TryGetDecimal(out decimal d))return d;var number=node.GetDouble();if(!double.IsFinite(number))throw new ArgumentException("Invalid JSON number.");return number;
                    case JsonValueKind.True:return true;case JsonValueKind.False:return false;case JsonValueKind.Null:return null;
                    default:throw new ArgumentException("Invalid JSON value.");
                }
            }
            using var document=JsonDocument.Parse(json,new JsonDocumentOptions{MaxDepth=100});return Expand(Read(document.RootElement));
        }
    }
}
