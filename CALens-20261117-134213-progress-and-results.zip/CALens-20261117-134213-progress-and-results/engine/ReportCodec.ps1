if(-not ('CaGapAnalyzer.ReportCodec' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'ReportCodec.cs')}
function ConvertTo-CaReportJson {param([AllowNull()]$Report);[CaGapAnalyzer.ReportCodec]::Serialize($Report)}
function ConvertTo-CaPackedReport {param([AllowNull()]$Report);return ,([CaGapAnalyzer.ReportCodec]::Pack($Report))}
