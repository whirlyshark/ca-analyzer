function New-CaSemanticAcceptanceScope($Result,[string]$Key){
    $js=New-CaJavascriptEngine
    try{
        $js.Script.SetProperty('acceptanceReportJson',[string](ConvertTo-CaReportJson $Result));$js.Script.SetProperty('acceptanceGapKey',$Key)
        $js.Evaluate('JSON.stringify((()=>{const r=ReportCodec.decode(JSON.parse(acceptanceReportJson)),g=r.gaps.find(g=>g.key===acceptanceGapKey);return g?AcceptanceModel.capture(r,g):null;})())')|ConvertFrom-CaJson
    }finally{$js.Dispose()}
}
function Resolve-CaSemanticAcceptances($Result,$Acceptances,$JavascriptEngine){
    if($Result.status -cne 'completeWithinModel' -or $Result.coverageIssues.Count -or !$Result['sourceKey'] -or !$Result['historyEvidence']){
        $Result.acceptanceMatching=@{version=1;status='notEligible';comparisons=0;candidates=0;milliseconds=0};return
    }
    if(!@($Acceptances.Values|Where-Object {$_['semanticScope'] -and $_['semanticScope']['sourceKey'] -ceq $Result.sourceKey}).Count){
        $Result.acceptanceMatching=@{version=1;status='complete';comparisons=0;candidates=0;milliseconds=0};return
    }
    $JavascriptEngine.Script.SetProperty('acceptanceReportJson',[string](ConvertTo-CaReportJson $Result));$JavascriptEngine.Script.SetProperty('acceptanceRecordsJson',[string](ConvertTo-Json -InputObject $Acceptances -Depth 100 -Compress))
    $matching=$JavascriptEngine.Evaluate('JSON.stringify(AcceptanceModel.resolve(ReportCodec.decode(JSON.parse(acceptanceReportJson)),JSON.parse(acceptanceRecordsJson)))')|ConvertFrom-CaJson
    $byKey=@{};foreach($match in $matching.matches){$byKey[$match.key]=$match.recordKeys}
    foreach($gap in $Result.gaps){
        if(!$byKey.ContainsKey($gap.key)){continue}
        $keys=@($byKey[$gap.key]);if($gap.acceptance){$keys+=@($gap.acceptance.recordKeys)}
        $keys=@($keys|Sort-Object -Unique)
        if(!$gap.acceptance){$gap.acceptance=Get-CaAcceptanceSummary $Acceptances[$keys[0]] $keys[0];$gap.acceptance.matchedSemantically=$true}
        $gap.acceptance.recordKeys=$keys
        $gap.acceptance.exceptionCount=$keys.Count
        $gap.acceptance.reasons=@($keys|ForEach-Object {$Acceptances[$_].reason}|Sort-Object -Unique)
        if($keys.Count -gt 1){$gap.acceptance.reason='Accepted under '+$keys.Count+' exceptions: '+($gap.acceptance.reasons -join '; ')}
    }
    $matching.Remove('matches');$Result.acceptanceMatching=$matching
}
