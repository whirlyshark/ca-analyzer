#Requires -Version 7.4
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'engine/Assessment.ps1')
. (Join-Path $PSScriptRoot 'engine/LocalState.ps1')
. (Join-Path $PSScriptRoot 'engine/Javascript.ps1')
. (Join-Path $PSScriptRoot 'engine/Acceptance.ps1')
. (Join-Path $PSScriptRoot 'engine/Reporting.ps1')
function Invoke-CaTenantAssessment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SnapshotPath,
        [Parameter(Mandatory)][string]$RequirementsPath,
        [string]$OutputPath,
        [string]$StateDirectory=(Join-Path $PSScriptRoot 'data/assessments'),
        [string]$AcceptancePath=(Join-Path $PSScriptRoot 'data/acceptances.local.json'),
        [ValidateLength(1,100)][string]$AssessmentName='default',
        [switch]$NoHistory,
        [ValidateRange(1,10000000)][int]$MaxRegions=100000,
        [ValidateRange(1,3600)][int]$TimeoutSeconds=60,
        [scriptblock]$Progress
    )
    $ErrorActionPreference='Stop'
    foreach($path in @($SnapshotPath,$RequirementsPath)){if((Get-Item -LiteralPath $path).Length -gt 100MB){throw 'Input exceeds the 100 MB file limit.'}}
    if($OutputPath){
        $destination=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
        if([IO.Path]::GetExtension($destination) -ne '.json'){throw 'OutputPath must end in .json; the HTML report is created beside it.'}
        foreach($inputPath in @($SnapshotPath,$RequirementsPath,$AcceptancePath)){
            $resolvedInput=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($inputPath)
            if($destination -eq $resolvedInput -or [IO.Path]::ChangeExtension($destination,'.html') -eq $resolvedInput){throw 'A report must not overwrite a snapshot, requirements file or acceptance store.'}
        }
    }
    if($Progress){$null=& $Progress @{stage='prepare';message='Reading accounts and requirements'}}
    $snapshotBytes=[IO.File]::ReadAllBytes($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($SnapshotPath));$profileBytes=[IO.File]::ReadAllBytes($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RequirementsPath))
    $js=New-CaJavascriptEngine;$runLock=$null
    try{
        $js.Script.SetProperty('snapshotJson',[Text.Encoding]::UTF8.GetString($snapshotBytes).TrimStart([char]0xFEFF))
        $js.Script.SetProperty('profileJson',[Text.Encoding]::UTF8.GetString($profileBytes).TrimStart([char]0xFEFF))
        if($Progress){$null=& $Progress @{stage='prepare';message='Preparing policy conditions and account sets'}}
        $js.Execute('var caPreparation={snapshot:JSON.parse(snapshotJson),profile:JSON.parse(profileJson)};caPreparation.initial=SnapshotModel.normalize(caPreparation.snapshot);')
        if($Progress){$null=& $Progress @{stage='prepare';message='Matching account sets and requirements'}}
        $js.Execute('caPreparation.compiled=RequirementModel.compile(caPreparation.profile,caPreparation.initial);caPreparation.source=caPreparation.compiled.source;')
        if($Progress){$null=& $Progress @{stage='prepare';message='Preparing evidence for saved comparisons'}}
        $js.Execute('caPreparation.historyEvidence=HistoryModel.capture(caPreparation.source,caPreparation.compiled.model,caPreparation.profile.requirements);')
        $prepared=$js.Evaluate(@'
JSON.stringify((()=>{const {snapshot,profile,compiled,source,historyEvidence}=caPreparation;return {historyEvidence,model:compiled.model,coverageIssues:[...source.issues,...compiled.issues],sourceKey:source.key,sourceName:source.name,capturedAtUtc:snapshot.capturedAtUtc||null,records:source.records,requirements:profile.requirements,assessmentNotes:source.notes||[],assessmentScope:source.assessmentScope||'Finite normalized model; no real sign-in reachability is established.',policyNames:source.policyNames||{},appNames:source.appNames||{},networkNames:source.networkNames||{},deviceValueNames:source.deviceValueNames||{},roleNames:source.roleNames||{},groupNames:source.groupNames||{},registrationContextNames:source.registrationContextNames||{},externalValueNames:source.externalValueNames||{}};})())
'@)|ConvertFrom-CaJson
        $js.Execute('caPreparation=null;snapshotJson=null;')
        $accepted=Read-CaLocalState -Path $AcceptancePath
        if($Progress){$null=& $Progress @{stage='assess';message='Checking policies against your requirements'}}
        $result=Invoke-CaAssessmentCore -Model $prepared.model -CoverageIssues @($prepared.coverageIssues) -Acceptances $accepted -MaxRegions $MaxRegions -TimeoutSeconds $TimeoutSeconds -SourceKey $prepared.sourceKey -AcceptanceEvidence $prepared.historyEvidence -Progress $Progress
        $result.sourceKey=$prepared.sourceKey;$result.historyEvidence=$prepared.historyEvidence
        if($Progress){$null=& $Progress @{stage='results';message='Matching accepted exceptions'}}
        Resolve-CaSemanticAcceptances $result $accepted $js
        if($Progress){$null=& $Progress @{stage='results';message='Counting account and requirement coverage'}}
        $js.Script.SetProperty('resultJson',[string](ConvertTo-CaReportJson $result))
        $js.Script.SetProperty('modelJson',[string]($prepared.model|ConvertTo-Json -Depth 100 -Compress))
        $result.coverageSummary=$js.Evaluate('JSON.stringify(CoverageSummary.build(ReportCodec.decode(JSON.parse(resultJson)),JSON.parse(modelJson),JSON.parse(profileJson).requirements))')|ConvertFrom-CaJson
        $scope=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($prepared.sourceKey+'|'+$AssessmentName))).ToLowerInvariant().Substring(0,24)
        $folder=Join-Path $StateDirectory $scope;$latest=Join-Path $folder 'latest.local.json'
        if(!$NoHistory){
            $null=New-Item -ItemType Directory -Path $folder -Force
            try{$runLock=[IO.File]::Open((Join-Path $folder 'assessment.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{throw 'Another assessment is updating this named tenant history. Retry after it finishes.'}
        }
        $previous=if(!$NoHistory -and (Test-Path -LiteralPath $latest)){Get-Content -LiteralPath $latest -Raw|ConvertFrom-CaJson}else{$null}
        $result.assessmentVersion=1;$result.sourceName=$prepared.sourceName;$result.sourceKey=$prepared.sourceKey;$result.snapshotCapturedAtUtc=$prepared.capturedAtUtc;$result.assessmentName=$AssessmentName
        $result.requirements=$prepared.requirements;$result.policyNames=$prepared.policyNames;$result.appNames=$prepared.appNames;$result.networkNames=$prepared.networkNames;$result.deviceValueNames=$prepared.deviceValueNames;$result.roleNames=$prepared.roleNames;$result.groupNames=$prepared.groupNames;$result.registrationContextNames=$prepared.registrationContextNames;$result.externalValueNames=$prepared.externalValueNames
        $result.assessmentNotes=$prepared.assessmentNotes;$result.assessmentScope=$prepared.assessmentScope
        $result.accountNames=@{};foreach($record in $prepared.records){$result.accountNames[$record.id]=if($record['displayName']){$record['displayName']}else{$record.id}}
        $result.inputs=@{snapshotSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($snapshotBytes)).ToLowerInvariant();requirementsSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($profileBytes)).ToLowerInvariant()}
        $result.historyEvidence=$prepared.historyEvidence
        if($Progress){$null=& $Progress @{stage='results';message='Comparing with your previous check'}}
        $result.changes=Get-CaAssessmentChanges $result $previous $js
        if(!$OutputPath -and !$NoHistory){$OutputPath=Join-Path $folder (([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)+'.local.json')}
        if($Progress){$null=& $Progress @{stage='results';message='Saving results and building reports'}}
        if($OutputPath){
            $OutputPath=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
            $null=New-Item -ItemType Directory -Path (Split-Path $OutputPath) -Force
            $result.reportPath=$OutputPath;$result.htmlReportPath=[IO.Path]::ChangeExtension($OutputPath,'.html')
            ConvertTo-CaReportJson $result|Set-Content -LiteralPath $OutputPath -Encoding utf8
            ConvertTo-CaAssessmentHtml $result $prepared|Set-Content -LiteralPath $result.htmlReportPath -Encoding utf8
        }
        if(!$NoHistory){$null=New-Item -ItemType Directory -Path $folder -Force;ConvertTo-CaReportJson $result|Set-Content -LiteralPath ($latest+'.tmp') -Encoding utf8;Move-Item -LiteralPath ($latest+'.tmp') -Destination $latest -Force}
        return $result
    }finally{if($runLock){$runLock.Dispose()};$js.Dispose()}
}
function Invoke-CaGapAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ModelPath,
        [string]$OutputPath,
        [ValidateRange(1,10000000)][int]$MaxRegions=100000,
        [ValidateRange(1,3600)][int]$TimeoutSeconds=60
    )
    if (-not ('CaGapAnalyzer.Engine' -as [type])) {
        Add-Type -Path (Join-Path $PSScriptRoot 'engine/GapEngine.cs') -ErrorAction Stop
    }
    $json=Get-Content -LiteralPath $ModelPath -Raw -ErrorAction Stop
    $result=[CaGapAnalyzer.Engine]::Analyze($json,$MaxRegions,$TimeoutSeconds)
    if ($OutputPath) { $result | Set-Content -LiteralPath $OutputPath -Encoding utf8 -ErrorAction Stop }
    $result | ConvertFrom-Json -Depth 100
}
Export-ModuleMember -Function Invoke-CaGapAnalysis,Invoke-CaTenantAssessment

