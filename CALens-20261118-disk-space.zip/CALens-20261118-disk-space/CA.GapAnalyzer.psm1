#Requires -Version 7.4
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'engine/Assessment.ps1')
. (Join-Path $PSScriptRoot 'engine/LocalState.ps1')
. (Join-Path $PSScriptRoot 'engine/Javascript.ps1')
. (Join-Path $PSScriptRoot 'engine/Acceptance.ps1')
. (Join-Path $PSScriptRoot 'engine/Reporting.ps1')
function Invoke-CaTenantAssessment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SnapshotPath,
        [Parameter(Mandatory)][string]$RequirementsPath,
        [string]$OutputPath,
        [string]$StateDirectory=(Join-Path $PSScriptRoot 'data/assessments'),
        [string]$AcceptancePath=(Join-Path $PSScriptRoot 'data/acceptances.local.json'),
        [ValidateLength(1,100)][string]$AssessmentName='default',
        [switch]$NoHistory,
        [ValidateRange(1,10000000)][int]$MaxRegions=100000,
        [ValidateRange(0,3600)][int]$TimeoutSeconds=0,
        [scriptblock]$Progress
    )
    $ErrorActionPreference='Stop'
    if($OutputPath){
        $destination=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
        if([IO.Path]::GetExtension($destination) -ne '.json'){throw 'OutputPath must end in .json; the HTML report is created beside it.'}
        foreach($inputPath in @($SnapshotPath,$RequirementsPath,$AcceptancePath)){
            $resolvedInput=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($inputPath)
            if($destination -eq $resolvedInput -or [IO.Path]::ChangeExtension($destination,'.html') -eq $resolvedInput){throw 'A report must not overwrite a snapshot, requirements file or acceptance store.'}
        }
    }
    if($Progress){$null=& $Progress @{stage='prepare';message='Reading accounts and requirements'}}
    $snapshotBytes=[IO.File]::ReadAllBytes($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($SnapshotPath));$profileBytes=[IO.File]::ReadAllBytes($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RequirementsPath))
    $js=New-CaJavascriptEngine;$runLock=$null;$previous=$null;$result=$null;$finished=$false
    try{
        $js.Script.SetProperty('snapshotJson',[Text.Encoding]::UTF8.GetString($snapshotBytes).TrimStart([char]0xFEFF))
        $js.Script.SetProperty('profileJson',[Text.Encoding]::UTF8.GetString($profileBytes).TrimStart([char]0xFEFF))
        if($Progress){$null=& $Progress @{stage='prepare';message='Preparing policy conditions and account sets'}}
        $js.Execute('var caPreparation={snapshot:JSON.parse(snapshotJson),profile:JSON.parse(profileJson)};caPreparation.initial=SnapshotModel.normalize(caPreparation.snapshot);')
        if($Progress){$null=& $Progress @{stage='prepare';message='Matching account sets and requirements'}}
        $js.Execute('caPreparation.compiled=RequirementModel.compile(caPreparation.profile,caPreparation.initial);caPreparation.source=caPreparation.compiled.source;')
        if($Progress){$null=& $Progress @{stage='prepare';message='Preparing evidence for saved comparisons'}}
        $js.Execute('caPreparation.historyEvidence=HistoryModel.capture(caPreparation.source,caPreparation.compiled.model,caPreparation.profile.requirements);')
        $prepared=$js.Evaluate(@'
JSON.stringify((()=>{const {snapshot,profile,compiled,source,historyEvidence}=caPreparation;return {reviewContext:{version:1,source,profile,model:compiled.model},historyEvidence,model:compiled.model,coverageIssues:[...source.issues,...compiled.issues],sourceKey:source.key,sourceName:source.name,capturedAtUtc:snapshot.capturedAtUtc||null,records:source.records,requirements:profile.requirements,assessmentNotes:source.notes||[],assessmentScope:source.assessmentScope||'Finite normalized model; no real sign-in reachability is established.',policyNames:source.policyNames||{},appNames:source.appNames||{},networkNames:source.networkNames||{},deviceValueNames:source.deviceValueNames||{},roleNames:source.roleNames||{},groupNames:source.groupNames||{},registrationContextNames:source.registrationContextNames||{},externalValueNames:source.externalValueNames||{}};})())
'@)|ConvertFrom-CaJson
        $js.Execute('caPreparation=null;snapshotJson=null;')
        $accepted=Read-CaLocalState -Path $AcceptancePath
        $scope=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($prepared.sourceKey+'|'+$AssessmentName))).ToLowerInvariant().Substring(0,24)
        $folder=Join-Path $StateDirectory $scope;$latest=Join-Path $folder 'latest.local.json'
        if(!$NoHistory){
            $null=New-Item -ItemType Directory -Path $folder -Force
            try{$runLock=[IO.File]::Open((Join-Path $folder 'assessment.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{throw 'Another assessment is updating this named tenant history. Retry after it finishes.'}
        }
        $previous=if(!$NoHistory -and (Test-Path -LiteralPath $latest)){[CaGapAnalyzer.ReportCodec]::ReadFile($latest)}else{$null}
        if($previous -and $previous.status -in @('incomplete:timeout','incomplete:regionLimit','incomplete:memoryLimit','incomplete:resultSizeLimit')){if($previous.gaps -is [IDisposable]){$previous.gaps.Dispose()};$previous=$null}
        # Reuse only a completed, exact input/model/evidence match under identical analyzer code.
        $codeFiles=@(Get-ChildItem (Join-Path $PSScriptRoot 'engine'),(Join-Path $PSScriptRoot 'ui') -File|Where-Object {$_.Extension -in @('.cs','.ps1','.js')}|Sort-Object FullName)
        $codeHash=(@($codeFiles|ForEach-Object {(Get-FileHash -LiteralPath $_.FullName).Hash})+@((Get-FileHash -LiteralPath $PSCommandPath).Hash)) -join ':'
        $reuseEvidence=[ordered]@{prepared=$prepared;code=$codeHash;snapshot=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($snapshotBytes));profile=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($profileBytes))}
        $reuseKey=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes(($reuseEvidence|ConvertTo-Json -Depth 100 -Compress))))
        $canReuse=$previous -and $previous['reuseKey'] -ceq $reuseKey -and $previous.status -ceq 'completeWithinModel' -and !$previous.coverageIssues.Count -and $previous.gapRefinement.refinedGroups -eq $previous.gapRefinement.originalGroups
        if($canReuse){
            if($Progress){$null=& $Progress @{stage='assess';message='Reusing verified results for unchanged inputs'}}
            $result=[ordered]@{};foreach($key in $previous.Keys){$result[$key]=$previous[$key]}
            foreach($gap in $result.gaps){$gap.acceptance=if($accepted.ContainsKey($gap.key)){Get-CaAcceptanceSummary $accepted[$gap.key] $gap.key}else{$null}}
            $result.runAtUtc=[DateTime]::UtcNow.ToString('o');$result.elapsedMilliseconds=0;$result.analysisMilliseconds=0;$result.contextResolutionMilliseconds=0
        }else{
        if($Progress){$null=& $Progress @{stage='assess';message='Checking policies against your requirements'}}
        $result=Invoke-CaAssessmentCore -Model $prepared.model -CoverageIssues @($prepared.coverageIssues) -Acceptances $accepted -MaxRegions $MaxRegions -TimeoutSeconds $TimeoutSeconds -SourceKey $prepared.sourceKey -AcceptanceEvidence $prepared.historyEvidence -Progress $Progress
        }
        $result.reusedAnalysis=[bool]$canReuse;$result.reuseKey=$reuseKey
        $result.sourceKey=$prepared.sourceKey;$result.historyEvidence=$prepared.historyEvidence
        if($Progress){$null=& $Progress @{stage='results';message='Matching accepted exceptions'}}
        Resolve-CaSemanticAcceptances $result $accepted $js
        if($Progress){$null=& $Progress @{stage='results';message='Counting account and requirement coverage'}}
        $js.Script.SetProperty('resultJson',[string]([CaGapAnalyzer.ReportCodec]::SerializeSummary($result)))
        $js.Script.SetProperty('modelJson',[string]($prepared.model|ConvertTo-Json -Depth 100 -Compress))
        $result.coverageSummary=$js.Evaluate('JSON.stringify(CoverageSummary.build(ReportCodec.decode(JSON.parse(resultJson)),JSON.parse(modelJson),JSON.parse(profileJson).requirements))')|ConvertFrom-CaJson
        $result.assessmentVersion=1;$result.sourceName=$prepared.sourceName;$result.sourceKey=$prepared.sourceKey;$result.snapshotCapturedAtUtc=$prepared.capturedAtUtc;$result.assessmentName=$AssessmentName
        $result.requirements=$prepared.requirements;$result.policyNames=$prepared.policyNames;$result.appNames=$prepared.appNames;$result.networkNames=$prepared.networkNames;$result.deviceValueNames=$prepared.deviceValueNames;$result.roleNames=$prepared.roleNames;$result.groupNames=$prepared.groupNames;$result.registrationContextNames=$prepared.registrationContextNames;$result.externalValueNames=$prepared.externalValueNames
        $result.assessmentNotes=$prepared.assessmentNotes;$result.assessmentScope=$prepared.assessmentScope
        $result.accountNames=@{};foreach($record in $prepared.records){$result.accountNames[$record.id]=if($record['displayName']){$record['displayName']}else{$record.id}}
        $result.inputs=@{snapshotSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($snapshotBytes)).ToLowerInvariant();requirementsSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($profileBytes)).ToLowerInvariant()}
        $result.historyEvidence=$prepared.historyEvidence
        if(!$NoHistory){$result.reviewContext=$prepared.reviewContext;$result.reviewContextVersion=1}
        if($Progress){$null=& $Progress @{stage='results';message='Comparing with your previous check'}}
        $result.changes=Get-CaAssessmentChanges $result $previous $js
        $autoSaved=!$OutputPath -and !$NoHistory;$indexed=$false
        if($autoSaved){$OutputPath=Join-Path $folder (([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)+'.local.json')}
        if($Progress){$null=& $Progress @{stage='results';message='Saving results and building reports'}}
        if($OutputPath){
            $OutputPath=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
            $null=New-Item -ItemType Directory -Path (Split-Path $OutputPath) -Force
            $result.reportPath=$OutputPath;$result.htmlReportPath=[IO.Path]::ChangeExtension($OutputPath,'.html')
            Write-CaReportFile $result $OutputPath
            $header=[ordered]@{};foreach($field in @('sourceKey','sourceName','assessmentVersion','reviewContextVersion','coverageSummary','runAtUtc','snapshotCapturedAtUtc','status','modelHash')){$header[$field]=$result[$field]}
            [CaGapAnalyzer.ReservedFile]::WriteText(($OutputPath+'.header.json'),($header|ConvertTo-Json -Depth 30 -Compress))
            if(!$NoHistory){try{[CaGapAnalyzer.ReportCodec]::SaveReviewIndex($result,$OutputPath);$indexed=$true}catch{Write-Warning ("The full report was saved, but its fast-opening index could not be created. "+$_.Exception.GetBaseException().Message)}}
            [CaGapAnalyzer.ReservedFile]::WriteText($result.htmlReportPath,(ConvertTo-CaAssessmentHtml $result $prepared))
        }
        if(!$NoHistory){$null=New-Item -ItemType Directory -Path $folder -Force;if($OutputPath){try{[CaGapAnalyzer.ReservedFile]::CopyFile($OutputPath,($latest+'.tmp'))}catch{[IO.File]::Delete($latest+'.tmp');throw}}else{Write-CaReportFile $result ($latest+'.tmp')};Move-Item -LiteralPath ($latest+'.tmp') -Destination $latest -Force}
        if($autoSaved -and $indexed -and $result.gaps -is [CaGapAnalyzer.PagedFindingRecords]){
            $working=$result.gaps
            $result.gaps=[CaGapAnalyzer.PagedFindingRecords]::new(($OutputPath+'.review'),$working.Count)
            $working.Dispose()
        }
        $finished=$true;return $result
    }finally{
        if($previous -and $previous.gaps -is [IDisposable] -and (!$finished -or ![object]::ReferenceEquals($previous.gaps,$result.gaps))){$previous.gaps.Dispose()}
        if(!$finished -and $result -and $result.gaps -is [IDisposable]){$result.gaps.Dispose()}
        if($runLock){$runLock.Dispose()};$js.Dispose()}
}
function Invoke-CaGapAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ModelPath,
        [string]$OutputPath,
        [ValidateRange(1,10000000)][int]$MaxRegions=100000,
        [ValidateRange(0,3600)][int]$TimeoutSeconds=0
    )
    if (-not ('CaGapAnalyzer.Engine' -as [type])) {
        Add-Type -Path (Join-Path $PSScriptRoot 'engine/GapEngine.cs') -ErrorAction Stop
    }
    $json=Get-Content -LiteralPath $ModelPath -Raw -ErrorAction Stop
    $result=Invoke-CaStoredCalculation $json $MaxRegions $TimeoutSeconds $null $null
    if ($OutputPath) {Write-CaReportFile $result $OutputPath}
    return $result
}
Export-ModuleMember -Function Invoke-CaGapAnalysis,Invoke-CaTenantAssessment


