#Requires -Version 7.4
[CmdletBinding()]
param(
 [Parameter(Mandatory)][string]$SnapshotPath,
 [Parameter(Mandatory)][string]$RequirementsPath,
 [string]$RequirementId,
 [string]$OutputPath
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'engine/Assessment.ps1')
. (Join-Path $PSScriptRoot 'engine/Javascript.ps1')
if($OutputPath){$destination=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath);if([IO.Path]::GetExtension($destination) -ne '.json'){throw 'OutputPath must end in .json.'};if(Test-Path -LiteralPath $destination){throw 'Choose a new output filename. Existing files are never overwritten.'}}
$js=New-CaJavascriptEngine
try{
 $js.Execute((Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ui/policy-mapping.js') -Raw -Encoding utf8))
 $js.Script.SetProperty('snapshotJson',(Get-Content -LiteralPath $SnapshotPath -Raw -Encoding utf8).TrimStart([char]0xFEFF))
 $js.Script.SetProperty('profileJson',(Get-Content -LiteralPath $RequirementsPath -Raw -Encoding utf8).TrimStart([char]0xFEFF))
 $js.Script.SetProperty('selectedRequirementId',$RequirementId)
 $preparedJson=$js.Evaluate(@'
JSON.stringify((()=>{const profile=JSON.parse(profileJson),initial=SnapshotModel.normalize(JSON.parse(snapshotJson)),compiled=RequirementModel.compile(profile,initial);globalThis.mappingPrepared={profile,...compiled};return {model:compiled.model,issues:[...compiled.source.issues,...compiled.issues]};})())
'@)
 $prepared=$preparedJson|ConvertFrom-CaJson
 $assessment=Invoke-CaAssessmentCore -Model $prepared.model -CoverageIssues @($prepared.issues)
 $js.Script.SetProperty('mappingAssessmentJson',([CaGapAnalyzer.ReportCodec]::SerializeSummary($assessment)))
 $json=$js.Evaluate(@'
JSON.stringify((()=>{
 const {profile,source,model}=mappingPrepared,result=JSON.parse(mappingAssessmentJson),summary=CoverageSummary.build(result,model,profile.requirements),definitions=profile.requirements.filter(r=>r.enabled!==false&&(!selectedRequirementId||r.id===selectedRequirementId));
 if(selectedRequirementId&&!definitions.length)throw Error('The requested requirement was not found or is disabled.');
 return {calensPolicyMappingVersion:1,scope:'Exported finite model only; no tenant or policy changes',sourceName:source.name,policyNames:source.policyNames||{},requirements:definitions.map(definition=>{const mapping=PolicyMapping.build(model,definition.id,{origins:source.policyOrigins}),coverage=summary.requirements.find(r=>r.id===definition.id),agreement=!coverage?.complete||mapping.jointlyCovered===(coverage.affected===0);return {id:definition.id,name:definition.name,attributionVerified:mapping.status==='complete'&&!!coverage?.complete&&agreement,requirementMet:mapping.status==='complete'&&!!coverage?.complete&&agreement?mapping.jointlyCovered:null,agreement,mapping};})};
})(),null,2)
'@)
 if($OutputPath){$null=New-Item -ItemType Directory -Path (Split-Path $destination) -Force;$stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$bytes=[Text.Encoding]::UTF8.GetBytes($json);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}
 $json
}finally{$js.Dispose()}
