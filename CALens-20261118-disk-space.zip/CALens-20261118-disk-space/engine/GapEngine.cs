using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;

namespace CaGapAnalyzer
{
    // A finite, explicit model. This is not a Microsoft Graph policy parser.
    public sealed class Model
    {
        public int SchemaVersion { get; set; }
        public Dictionary<string, string[]> Dimensions { get; set; } = new();
        public Identity[] Identities { get; set; } = Array.Empty<Identity>();
        public Policy[] Policies { get; set; } = Array.Empty<Policy>();
        public Requirement[] Requirements { get; set; } = Array.Empty<Requirement>();
        // Supplemental unresolved source facts bind exception fingerprints.
        // They are never interpreted as grants or applicability predicates.
        [System.Text.Json.Serialization.JsonIgnore]
        public JsonElement DiagnosticEvidence { get; set; }
        // AND of groups; each group is an OR of valid scenario rectangles.
        // This preserves relationships between claims rather than independently
        // combining impossible device, authentication or activation states.
        public Dictionary<string, Selector>[][] ScenarioConstraints { get; set; } = Array.Empty<Dictionary<string, Selector>[]>();
    }
    public sealed class Identity
    {
        public string Id { get; set; } = "";
        public bool Privileged { get; set; }
        public bool PimEligible { get; set; }
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // Per-person AND groups of OR rectangles, for coupled eligibility and
        // activation facts that cannot be represented by independent axes.
        public Dictionary<string, Selector>[][] ScenarioConstraints { get; set; } = Array.Empty<Dictionary<string, Selector>[]>();
    }
    public sealed class Selector
    {
        public string[] Include { get; set; } = Array.Empty<string>();
        public string[] Exclude { get; set; } = Array.Empty<string>();
    }
    public sealed class Policy
    {
        public string Id { get; set; } = "";
        public string State { get; set; } = "enabled";
        public string[] IncludeUsers { get; set; } = new[] { "*" };
        public string[] ExcludeUsers { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // OR of alternatives; dimensions within each alternative are ANDed.
        // [] = block; [{}] = no additional grant restriction.
        public Dictionary<string, Selector>[] GrantAlternatives { get; set; } = Array.Empty<Dictionary<string, Selector>>();
        public bool UnverifiedApplicationFilter { get; set; }
        public bool UnverifiedLocations { get; set; }
        // Null is legacy/unknown evidence, not proof of passive IP matching.
        public bool? LocationMatchingOnly { get; set; }
        // The app grants remain valid for app access. Registration without a
        // resource needs a separate applicability upper bound, never a grant.
        public bool RegistrationResourceContext { get; set; }
        // Proof of permitted grants only; never used to credit protection.
        // Absent/empty means no request is proved immune to a possible denial.
        public Dictionary<string, Selector>[] GuaranteedGrantAlternatives { get; set; }
        public Dictionary<string, Selector>[] GuaranteedRegistrationGrantAlternatives { get; set; }
    }
    public sealed class Requirement
    {
        public string Id { get; set; } = "";
        public string Scope { get; set; } = "all";
        public string[] IncludeUsers { get; set; } = new[] { "*" };
        public string[] ExcludeUsers { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // OR clauses, intersected with Conditions. Null means no extra bound;
        // an empty array deliberately means an empty scenario scope.
        public Dictionary<string, Selector>[] ConditionAlternatives { get; set; }
        public string[] AllowedAuthentication { get; set; } = Array.Empty<string>();
        public bool MustBlock { get; set; }
        public bool MustPermit { get; set; }
        public bool InventoryCheck { get; set; }
        public Dictionary<string, Selector>[] RequiredAlternatives { get; set; }
    }
    public sealed class Gap
    {
        public string RequirementId { get; set; } = "";
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public Dictionary<string, string[]> Region { get; set; } = new();
        public Dictionary<string, string> Witness { get; set; } = new();
        public string[] ApplicablePolicyIds { get; set; } = Array.Empty<string>();
        public string[] NonApplicablePolicyIds { get; set; } = Array.Empty<string>();
    }
    public sealed class Analysis
    {
        internal string SplitAxis;
        public string EngineVersion { get; set; } = "0.3.0-rc.1";
        public string Status { get; set; } = "completeWithinModel";
        public string Limitation { get; set; } = "Exhaustive only over the supplied finite normalized model; no claim of complete Entra semantics or real sign-in reachability.";
        public int IdentityCount { get; set; }
        public int IdentityProfileCount { get; set; }
        public bool ProfileGroupingEnabled { get; set; }
        public long RegionSubtractionCount { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public IList<Gap> Gaps { get; set; } = new List<Gap>();
        public string[] EmptyRequirementIds { get; set; } = Array.Empty<string>();
        public string[] UnverifiedApplicationFilterPolicyIds { get; set; } = Array.Empty<string>();
        public string[] UnverifiedLocationPolicyIds { get; set; } = Array.Empty<string>();
        public string[] RegistrationResourcePolicyIds { get; set; } = Array.Empty<string>();
    }
    public sealed class AnalysisProgress
    {
        public string Phase { get; set; }
        public string RequirementId { get; set; }
        public int RequirementIndex { get; set; }
        public int RequirementCount { get; set; }
        public int CompletedAccounts { get; set; }
        public int TotalAccounts { get; set; }
        public int ProfileIndex { get; set; }
        public int ProfileCount { get; set; }
        public long RegionOperations { get; set; }
        public int GapGroups { get; set; }
    }
    internal sealed class Region
    {
        public HashSet<string>[] Axes;
        public Region(HashSet<string>[] axes) { Axes = axes; }
        // Axis sets are immutable after construction. Copies own their axis
        // array and share unchanged sets; mutation must create a new set.
        public Region Copy() => new Region((HashSet<string>[])Axes.Clone());
    }
    internal sealed class ContextPolicyScope
    {
        public HashSet<string> People;
        public Region Condition;
        public Region[] Grants;
    }
    public sealed class PolicyContextQuery
    {
        public string RequirementId { get; set; } = "";
        public string[] PolicyIds { get; set; } = Array.Empty<string>();
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public string[] RelaxedAxes { get; set; } = Array.Empty<string>();
        public string MatchMode { get; set; } = "denied";
        public Dictionary<string, string[]> PolicyIdentityBindings { get; set; }
    }
    public sealed class GapRefinementCut
    {
        public string RequirementId { get; set; } = "";
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
    }
    public sealed class GapRefinementResult
    {
        public string Status { get; set; } = "complete";
        public int OriginalGroups { get; set; }
        public IList<Gap> Gaps { get; set; } = Array.Empty<Gap>();
        public int[] ParentGapIndices { get; set; } = Array.Empty<int>();
    }
    public static class Engine
    {
        private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            UnmappedMemberHandling = System.Text.Json.Serialization.JsonUnmappedMemberHandling.Disallow
        };
        // Could an uncertain policy change any remaining permitted violation?
        // Only PIM membership/role coordinates may be relaxed. Other request
        // conditions and grant alternatives remain exact. The applicable mode
        // checks downstream session effects without relaxing any coordinates.
        // Null means unproved.
        public static string RelevantPolicyContexts(string modelJson, string gapsJson, string queriesJson, int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => RelevantPolicyContextsCore(modelJson, gapsJson, queriesJson, maxRegions, timeoutMilliseconds, false);
        // Same proof, preserving the individual gap answers. A row is published
        // only after every policy has been checked; invalid/bounded rows stay null.
        public static string RelevantPolicyContextsByGap(string modelJson, string gapsJson, string queriesJson, int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => RelevantPolicyContextsCore(modelJson, gapsJson, queriesJson, maxRegions, timeoutMilliseconds, true);
        public static string RelevantPolicyContextsTyped(string modelJson, IList<Gap> gaps, string queriesJson, int maxRegions=20000,int timeoutMilliseconds=5000,bool byGap=false)
            => RelevantPolicyContextsCore(modelJson,null,queriesJson,maxRegions,timeoutMilliseconds,byGap,gaps);
        private static string RelevantPolicyContextsCore(string modelJson, string gapsJson, string queriesJson, int maxRegions, int timeoutMilliseconds, bool byGap, IList<Gap> suppliedGaps=null)
        {
            if (maxRegions < 1 || timeoutMilliseconds < 0) throw new ArgumentException("Limits must be positive.");
            var model = JsonSerializer.Deserialize<Model>(modelJson, JsonOptions) ?? throw new ArgumentException("Missing model.");
            Validate(model);
            var gaps = suppliedGaps ?? JsonSerializer.Deserialize<Gap[]>(gapsJson, JsonOptions) ?? throw new ArgumentException("Missing gaps.");
            var queries = JsonSerializer.Deserialize<PolicyContextQuery[]>(queriesJson, JsonOptions) ?? throw new ArgumentException("Missing queries.");
            if (byGap && (long)queries.Length * gaps.Count > maxRegions) throw new ArgumentException("Per-gap context matrix exceeds the configured limit.");
            var results = new bool?[queries.Length];
            var matrix = byGap ? queries.Select(_ => new bool?[gaps.Count]).ToArray() : null;
            var clock = Stopwatch.StartNew();
            var names = model.Dimensions.Keys.OrderBy(x => x, StringComparer.Ordinal).ToArray();
            var universe = new Region(names.Select(n => new HashSet<string>(model.Dimensions[n], StringComparer.Ordinal)).ToArray());
            var identities = model.Identities.Select(u => u.Id).ToHashSet(StringComparer.Ordinal);
            // Retain sparse bounds. Copying every app/network domain for every
            // person would undo the analyzer's identity-profile grouping.
            var identityBounds = model.Identities.ToDictionary(u => u.Id, u => u.Conditions, StringComparer.Ordinal);
            var policies = model.Policies.ToDictionary(p => p.Id, StringComparer.Ordinal);
            var requirements = model.Requirements.Select(r => r.Id).ToHashSet(StringComparer.Ordinal);
            void Check(int count = 0) { if (count > maxRegions || (timeoutMilliseconds > 0 && clock.ElapsedMilliseconds >= timeoutMilliseconds)) throw new BudgetException("contextLimit"); }
            var axisCache=new Dictionary<string[],HashSet<string>>(ReferenceEqualityComparer.Instance);
            Region GapRegion(int index){var g=gaps[index];
                if (g == null || !requirements.Contains(g.RequirementId) || g.Region == null || g.Region.Count != names.Length || g.IdentityIds == null || g.IdentityIds.Length == 0 || g.IdentityIds.Any(id => !identities.Contains(id))) throw new ArgumentException("Invalid gap evidence.");
                return new Region(names.Select((n,i) => {
                    if(!g.Region.TryGetValue(n,out var values)||values==null||values.Length==0)throw new ArgumentException("Invalid gap domain.");
                    if(axisCache.TryGetValue(values,out var known))return known;
                    if(values.Any(v=>!universe.Axes[i].Contains(v)))throw new ArgumentException("Invalid gap domain.");
                    if(axisCache.Count>4096)axisCache.Clear();var set=values.ToHashSet(StringComparer.Ordinal);axisCache.Add(values,set);return set;
                }).ToArray());
            }
            var candidatesByRequirement=new Dictionary<string,List<int>>(StringComparer.Ordinal);
            for(int i=0;i<gaps.Count;i++){Check();GapRegion(i);var id=gaps[i].RequirementId;if(!candidatesByRequirement.TryGetValue(id,out var candidates)){candidates=new();candidatesByRequirement.Add(id,candidates);}candidates.Add(i);}
            var candidateCache=new Dictionary<string,int[]>(StringComparer.Ordinal);
            for (int q = 0; q < queries.Length; q++)
            {
                try
                {
                    Check();
                    var query = queries[q];
                    if (!ValidPolicyContext(query, model, policies, requirements, identities, out var people)) continue;
                    if(!candidateCache.TryGetValue(query.RequirementId,out var candidateIndices)){
                        candidateIndices=new[]{query.RequirementId,query.RequirementId+":outside-network",query.RequirementId+":outside-apps",query.RequirementId+":outside-device"}
                            .SelectMany(id=>candidatesByRequirement.TryGetValue(id,out var rows)?rows:Enumerable.Empty<int>()).OrderBy(i=>i).ToArray();
                        candidateCache.Add(query.RequirementId,candidateIndices);
                    }
                    bool relevant = false;
                    var gapAnswers = byGap ? new bool[gaps.Count] : null;
                    foreach (var policyId in query.PolicyIds.Distinct(StringComparer.Ordinal))
                    {
                        Check();
                        var scope = GetContextPolicyScope(query, policies[policyId], people, identityBounds, universe, names, Check);
                        if (scope == null) continue;
                        foreach (int i in candidateIndices)
                        {
                            Check(); var gap = gaps[i];
                            if (byGap && gapAnswers[i]) continue;
                            bool sameRequirement = gap.RequirementId == query.RequirementId || new[] { ":outside-network", ":outside-apps", ":outside-device" }.Any(s => gap.RequirementId == query.RequirementId + s);
                            if (!sameRequirement || !gap.IdentityIds.Any(scope.People.Contains)) continue;
                            var overlap = Intersect(GapRegion(i), scope.Condition);
                            if (overlap == null) continue;
                            if (query.MatchMode == "applicable") { relevant = true; if (byGap) { gapAnswers[i] = true; continue; } break; }
                            // One witness establishes relevance. Walk remaining pieces depth-first
                            // instead of materializing every fragment across all grants at once.
                            var pending=new Stack<(Region Piece,int Grant)>();pending.Push((overlap,0));
                            bool uncovered=false;
                            while(pending.Count>0){
                                Check();var item=pending.Pop();
                                if(item.Grant==scope.Grants.Length){uncovered=true;break;}
                                foreach(var piece in Subtract(item.Piece,scope.Grants[item.Grant]))pending.Push((piece,item.Grant+1));
                                if(suppliedGaps==null)Check(pending.Count);
                            }
                            if (uncovered) { relevant = true; if (byGap) { gapAnswers[i] = true; continue; } break; }
                        }
                        if (relevant && !byGap) break;
                    }
                    results[q] = relevant;
                    if (byGap) matrix[q] = gapAnswers.Select(value => (bool?)value).ToArray();
                }
                catch (BudgetException) when(suppliedGaps==null) { break; }
            }
            return byGap ? JsonSerializer.Serialize(matrix) : JsonSerializer.Serialize(results);
        }
        private static bool SameRequirement(string gap, string query) => gap == query || new[] { ":outside-network", ":outside-apps", ":outside-device" }.Any(s => gap == query + s);
        private static ContextPolicyScope GetContextPolicyScope(PolicyContextQuery query, Policy policy, HashSet<string> people, Dictionary<string, Dictionary<string, Selector>> identityBounds, Region universe, string[] names, Action<int> check)
        {
            check(0);
            var original = Select(universe, names, policy.Conditions);
            if (policy.State != "enabled" || original == null) return null;
            var relaxed = query.RelaxedAxes.ToHashSet(StringComparer.Ordinal);
            if (query.MatchMode == "registrationResource") relaxed.UnionWith(names.Where(n => n == "application" || n == "accessTarget" || n == "registrationContext" || n == "directoryScopeEnforcement" || n.StartsWith("resourceGroup.", StringComparison.Ordinal)));
            var condition = Select(universe, names, policy.Conditions.Where(e => !relaxed.Contains(e.Key)).ToDictionary(e => e.Key,e => e.Value));
            if (query.MatchMode == "registrationResource") condition = Select(condition, names, new Dictionary<string,Selector> { ["accessTarget"] = new Selector { Include = new[] { "userAction" } }, ["registrationContext"] = new Selector { Include = new[] { "unspecified" } } });
            var targets = new TargetSet(policy.IncludeUsers, policy.ExcludeUsers);
            var coordinates = policy.Conditions.Keys.Where(n => relaxed.Contains(n) && query.MatchMode != "registrationResource").Select(n => (Name:n,Index:Array.IndexOf(names,n))).ToArray();
            var selectedPeople = query.PolicyIdentityBindings == null ? people : query.PolicyIdentityBindings[policy.Id].ToHashSet(StringComparer.Ordinal);
            // Confirmed per-person bounds still constrain relaxed PIM axes.
            var affected = selectedPeople.Where(id => {
                check(0);
                return targets.Contains(id) && coordinates.All(c => !identityBounds[id].TryGetValue(c.Name,out var bound) || original.Axes[c.Index].Any(v => (bound.Include.Length == 0 || bound.Include.Contains(v,StringComparer.Ordinal)) && !bound.Exclude.Contains(v,StringComparer.Ordinal)));
            }).ToHashSet(StringComparer.Ordinal);
            if (affected.Count == 0) return null;
            var grantAlternatives = query.MatchMode == "registrationResource" ? (policy.LocationMatchingOnly == true ? policy.GuaranteedRegistrationGrantAlternatives : null) ?? Array.Empty<Dictionary<string,Selector>>() : query.MatchMode == "potentiallyDenied" ? (policy.LocationMatchingOnly == true ? policy.GuaranteedGrantAlternatives : null) ?? Array.Empty<Dictionary<string,Selector>>() : policy.GrantAlternatives;
            var grants = query.MatchMode == "applicable" ? Array.Empty<Region>() : grantAlternatives.Where(a => a.Where(e => relaxed.Contains(e.Key)).All(e => {
                var selected = Select(universe,names,new Dictionary<string,Selector> { [e.Key]=e.Value });
                return selected != null && selected.Axes[Array.IndexOf(names,e.Key)].SetEquals(universe.Axes[Array.IndexOf(names,e.Key)]);
            })).Select(a => Select(universe,names,a.Where(e => !relaxed.Contains(e.Key)).ToDictionary(e => e.Key,e => e.Value))).Where(r => r != null).ToArray();
            return new ContextPolicyScope { People=affected, Condition=condition, Grants=grants };
        }
        private static bool ValidPolicyContext(PolicyContextQuery query, Model model, Dictionary<string, Policy> policies, HashSet<string> requirements, HashSet<string> identities, out HashSet<string> people)
        {
            people = null;
            if (query == null || !(query.MatchMode == "denied" || query.MatchMode == "applicable" || query.MatchMode == "potentiallyDenied" || query.MatchMode == "registrationResource") || !requirements.Contains(query.RequirementId) || query.PolicyIds == null || query.PolicyIds.Length == 0 || query.PolicyIds.Any(id => id == null || !policies.ContainsKey(id)) || query.IdentityIds == null || query.IdentityIds.Length == 0 || query.IdentityIds.Any(id => !identities.Contains(id)) || query.RelaxedAxes == null || (query.MatchMode == "denied" ? query.RelaxedAxes.Length == 0 : query.RelaxedAxes.Length != 0) || query.RelaxedAxes.Any(n => n == null || !model.Dimensions.ContainsKey(n) || !(n.StartsWith("groupMember.", StringComparison.Ordinal) || n.StartsWith("roleActive.", StringComparison.Ordinal)))) return false;
            if (query.MatchMode == "registrationResource" && query.PolicyIds.Any(id => !policies[id].RegistrationResourceContext)) return false;
            if (query.MatchMode == "potentiallyDenied" && query.PolicyIds.Any(id => !policies[id].UnverifiedLocations)) return false;
            people = query.IdentityIds.ToHashSet(StringComparer.Ordinal);
            var knownPeople = people;
            return query.PolicyIdentityBindings == null || !(query.PolicyIdentityBindings.Keys.Any(id => !query.PolicyIds.Contains(id, StringComparer.Ordinal)) || query.PolicyIds.Any(id => !query.PolicyIdentityBindings.TryGetValue(id, out var bound) || bound == null || bound.Length == 0 || bound.Any(user => !knownPeople.Contains(user))));
        }
        // Refine presentation groups only. The represented account/request set
        // must remain exactly equal; neither a grant nor a diagnosis is inferred.
        // Publish atomically, reverting to the original groups on any limit.
        public static string RefinePolicyContextGaps(string modelJson, string gapsJson, string queriesJson, string cutsJson = "[]", int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => JsonSerializer.Serialize(RefinePolicyContextGapsData(modelJson,gapsJson,queriesJson,cutsJson,maxRegions,timeoutMilliseconds),JsonOptions);
        // The PowerShell adapter consumes typed strings/arrays directly so a
        // repeated identity list is not decoded once per refined request cell.
        public static GapRefinementResult RefinePolicyContextGapsData(string modelJson, string gapsJson, string queriesJson, string cutsJson = "[]", int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => RefinePolicyContextGapsCore(modelJson,gapsJson,queriesJson,cutsJson,maxRegions,timeoutMilliseconds,null);
        public static GapRefinementResult RefinePolicyContextGapsTypedData(string modelJson, IList<Gap> gaps, string queriesJson, string cutsJson="[]", int maxRegions=20000,int timeoutMilliseconds=5000)
            => RefinePolicyContextGapsCore(modelJson,null,queriesJson,cutsJson,maxRegions,timeoutMilliseconds,gaps);
        private static GapRefinementResult RefinePolicyContextGapsCore(string modelJson,string gapsJson,string queriesJson,string cutsJson,int maxRegions,int timeoutMilliseconds,IList<Gap> suppliedGaps)
        {
            if (maxRegions < 1 || timeoutMilliseconds < 0) throw new ArgumentException("Limits must be positive.");
            var clock = Stopwatch.StartNew();
            var model = JsonSerializer.Deserialize<Model>(modelJson, JsonOptions) ?? throw new ArgumentException("Missing model."); Validate(model);
            var gaps = suppliedGaps ?? JsonSerializer.Deserialize<Gap[]>(gapsJson, JsonOptions) ?? throw new ArgumentException("Missing gaps.");
            var queries = JsonSerializer.Deserialize<PolicyContextQuery[]>(queriesJson, JsonOptions) ?? throw new ArgumentException("Missing queries.");
            var cuts = JsonSerializer.Deserialize<GapRefinementCut[]>(cutsJson, JsonOptions) ?? throw new ArgumentException("Missing cuts.");
            var result = new GapRefinementResult { OriginalGroups = gaps.Count, Gaps = gaps, ParentGapIndices = Enumerable.Range(0,gaps.Count).ToArray() };
            var names = model.Dimensions.Keys.OrderBy(n => n, StringComparer.Ordinal).ToArray();
            var universe = new Region(names.Select(n => model.Dimensions[n].ToHashSet(StringComparer.Ordinal)).ToArray());
            var identities = model.Identities.Select(u => u.Id).ToHashSet(StringComparer.Ordinal);
            var policies = model.Policies.ToDictionary(p => p.Id, StringComparer.Ordinal);
            var requirements = model.Requirements.Select(r => r.Id).ToHashSet(StringComparer.Ordinal);
            if(gaps.Count>maxRegions){result.Status="bounded:regionLimit";return result;}
            var cells = gaps.Select((g,parent) => {
                if (g == null || !requirements.Contains(g.RequirementId) || g.Region == null || g.Region.Count != names.Length || g.IdentityIds == null || g.IdentityIds.Length == 0 || g.IdentityIds.Distinct(StringComparer.Ordinal).Count() != g.IdentityIds.Length || g.IdentityIds.Any(id => !identities.Contains(id))) throw new ArgumentException("Invalid gap evidence.");
                var region = new Region(names.Select((n,i) => {
                    if (!g.Region.TryGetValue(n, out var values) || values == null || values.Length == 0 || values.Any(v => !universe.Axes[i].Contains(v))) throw new ArgumentException("Invalid gap domain.");
                    return values.ToHashSet(StringComparer.Ordinal);
                }).ToArray());
                return (RequirementId: g.RequirementId, People: g.IdentityIds, Region: region, Parent: parent);
            }).ToList();
            // Keep identity-profile grouping useful while refining many request
            // cells. Bound the expanded report as well as its rectangle count.
            long identityLimit = Math.Max(cells.Sum(cell => (long)cell.People.Length), (long)maxRegions * 64);
            var uncertain = new List<(string RequirementId, string[] People, Region Region, int Parent)>();
            long uncertainIdentities = 0;
            var identityBounds = model.Identities.ToDictionary(u => u.Id,u => u.Conditions,StringComparer.Ordinal);
            void Check(int count) { if (count > maxRegions) throw new BudgetException("regionLimit"); if (timeoutMilliseconds > 0 && clock.ElapsedMilliseconds >= timeoutMilliseconds) throw new BudgetException("timeout"); }
            void Split(string requirement, HashSet<string> people, Region cut)
            {
                if (cut == null || people.Count == 0 || cells.Count == 0) return;
                var next = new List<(string RequirementId, string[] People, Region Region, int Parent)>();
                var partitions = new Dictionary<string[], (string[] Selected, string[] Other)>();
                long nextIdentities = uncertainIdentities;
                void Add((string RequirementId, string[] People, Region Region, int Parent) cell, bool matched = false) {
                    nextIdentities += cell.People.Length;
                    if (nextIdentities > identityLimit) throw new BudgetException("identityReferenceLimit");
                    if (matched) { uncertain.Add(cell); uncertainIdentities += cell.People.Length; }
                    else next.Add(cell);
                    Check(next.Count + uncertain.Count);
                }
                foreach (var cell in cells)
                {
                    Check(next.Count + uncertain.Count);
                    var overlap = SameRequirement(cell.RequirementId, requirement) ? Intersect(cell.Region, cut) : null;
                    if (overlap == null) { Add(cell); continue; }
                    if (!partitions.TryGetValue(cell.People, out var partition)) {
                        var selectedPeople = cell.People.Where(people.Contains).ToArray();
                        partition = selectedPeople.Length == cell.People.Length ? (cell.People, Array.Empty<string>()) : (selectedPeople, cell.People.Where(id => !people.Contains(id)).ToArray());
                        partitions[cell.People] = partition;
                    }
                    var selected = partition.Selected;
                    if (selected.Length == 0) { Add(cell); continue; }
                    if (partition.Other.Length > 0) Add((cell.RequirementId, partition.Other, cell.Region, cell.Parent));
                    foreach (var outside in Subtract(cell.Region, cut)) Add((cell.RequirementId, selected, outside, cell.Parent));
                    // A point reached by any unresolved scope is already in the
                    // union. Do not split it again at every overlapping policy.
                    Add((cell.RequirementId, selected, overlap, cell.Parent), true);
                }
                Check(next.Count + uncertain.Count); cells = next;
            }
            try
            {
                Check(cells.Count);
                foreach (var query in queries)
                {
                    Check(cells.Count + uncertain.Count);
                    if (!ValidPolicyContext(query, model, policies, requirements, identities, out var people)) continue;
                    foreach (var policyId in query.PolicyIds.Distinct(StringComparer.Ordinal).OrderBy(id => id, StringComparer.Ordinal))
                    {
                        if (cells.Count == 0) break;
                        var scope = GetContextPolicyScope(query,policies[policyId],people,identityBounds,universe,names,Check);
                        if (scope == null) continue;
                        var regions = new List<Region> { scope.Condition };
                        foreach (var grant in scope.Grants) {
                            var next = new List<Region>();
                            foreach (var region in regions) { next.AddRange(Subtract(region,grant)); Check(next.Count); }
                            regions = next;
                            if (regions.Count == 0) break;
                        }
                        foreach (var region in regions) Split(query.RequirementId,scope.People,region);
                    }
                }
                foreach (var cut in cuts)
                {
                    Check(cells.Count + uncertain.Count);
                    if (cut == null || !requirements.Contains(cut.RequirementId) || cut.IdentityIds == null || cut.IdentityIds.Length == 0 || cut.IdentityIds.Any(id => !identities.Contains(id)) || cut.Conditions == null || cut.Conditions.Any(e => !model.Dimensions.ContainsKey(e.Key) || e.Value == null || e.Value.Include == null || e.Value.Exclude == null || e.Value.Include.Concat(e.Value.Exclude).Any(v => !model.Dimensions[e.Key].Contains(v)))) continue;
                    Split(cut.RequirementId, cut.IdentityIds.ToHashSet(StringComparer.Ordinal), Select(universe, names, cut.Conditions));
                }
                cells = uncertain.Concat(cells).ToList();
                Check(cells.Count);
                if (cells.Count != gaps.Count)
                {
                    var enabled = model.Policies.Where(p => p.State == "enabled").ToArray();
                    var bounds = enabled.ToDictionary(p => p.Id, p => Select(universe, names, p.Conditions));
                    var targets = enabled.ToDictionary(p => p.Id, p => new TargetSet(p.IncludeUsers, p.ExcludeUsers));
                    result.Gaps = cells.Select(cell => {
                        Check(cells.Count);
                        var witness = names.Select((n,i) => (Name:n, Value:cell.Region.Axes[i].OrderBy(v => v, StringComparer.Ordinal).First())).ToDictionary(e => e.Name,e => e.Value);
                        var applied = enabled.Where(p => targets[p.Id].Contains(cell.People[0]) && Contains(bounds[p.Id], names, witness)).Select(p => p.Id).ToArray();
                        return new Gap { RequirementId=cell.RequirementId, IdentityIds=cell.People.OrderBy(id => id, StringComparer.Ordinal).ToArray(), Region=names.Select((n,i) => (Name:n,Values:cell.Region.Axes[i].OrderBy(v => v,StringComparer.Ordinal).ToArray())).ToDictionary(e => e.Name,e => e.Values), Witness=witness, ApplicablePolicyIds=applied, NonApplicablePolicyIds=enabled.Select(p=>p.Id).Except(applied).ToArray() };
                    }).ToArray();
                    result.ParentGapIndices = cells.Select(cell => cell.Parent).ToArray();
                }
            }
            catch (BudgetException e) { result.Status = "bounded:" + e.Message; result.Gaps = gaps; result.ParentGapIndices = Enumerable.Range(0,gaps.Count).ToArray(); }
            return result;
        }
        public static string Analyze(string json, int maxRegions = 100000, int timeoutSeconds = 60, bool groupIdentities = true, Action<int,int> progress = null)
            => JsonSerializer.Serialize(AnalyzeCore(json,maxRegions,timeoutSeconds,groupIdentities,progress,null,false),JsonOptions);
        // The app consumes shared typed data and a compact lossless wire format.
        // It need not materialize the expanded legacy JSON string at all.
        public static Analysis AnalyzeData(string json, int maxRegions = 100000, int timeoutSeconds = 60, bool groupIdentities = true, Action<AnalysisProgress> progress = null)
            => AnalyzeCore(json,maxRegions,timeoutSeconds,groupIdentities,null,progress,true);
        public static IDictionary AnalyzeReportData(string json, int maxRegions=100000, int timeoutSeconds=0, Action<AnalysisProgress> progress=null, IList records=null)
        {
            var analysis=AnalyzeCore(json,maxRegions,timeoutSeconds,true,null,progress,true,records);return ReportFields(analysis,records);
        }
        private static IDictionary ReportFields(Analysis analysis,IList records){var report=new Dictionary<string,object>(StringComparer.Ordinal);
            foreach(var property in typeof(Analysis).GetProperties()){
                var key=char.ToLowerInvariant(property.Name[0])+property.Name.Substring(1);
                report.Add(key,property.Name=="Gaps"?(object)(records??analysis.Gaps.Select(GapRecord).ToArray()):property.GetValue(analysis));
            }
            return report;
        }
        // Retry an interrupted disk-backed calculation over disjoint portions of the same
        // finite model. Commit a portion only after all its requirements have finished.
        public static IDictionary AnalyzePartitionedReport(string json,int maxRegions,int timeoutSeconds,
            Action<AnalysisProgress> progress,IList destination)
        {
            var model=JsonSerializer.Deserialize<Model>(json,JsonOptions);
            Validate(model);
            var names=model.Dimensions.Keys.OrderBy(n=>n,StringComparer.Ordinal).ToArray();
            var root=new Region(names.Select(n=>model.Dimensions[n].ToHashSet(StringComparer.Ordinal)).ToArray());
            var selectors=new List<Dictionary<string,Selector>>();
            selectors.AddRange(model.ScenarioConstraints.SelectMany(g=>g));
            foreach(var u in model.Identities){selectors.Add(u.Conditions);selectors.AddRange(u.ScenarioConstraints.SelectMany(g=>g));}
            foreach(var p in model.Policies.Where(p=>p.State=="enabled")){selectors.Add(p.Conditions);selectors.AddRange(p.GrantAlternatives);}
            foreach(var r in model.Requirements){selectors.Add(r.Conditions);if(r.ConditionAlternatives!=null)selectors.AddRange(r.ConditionAlternatives);if(r.RequiredAlternatives!=null)selectors.AddRange(r.RequiredAlternatives);else if(r.AllowedAuthentication.Length>0)selectors.Add(new(){{"authentication",new Selector{Include=r.AllowedAuthentication}}});}
            var axes=selectors.SelectMany(c=>c.Keys).Distinct().Select(n=>Array.IndexOf(names,n)).OrderBy(i=>root.Axes[i].Count).ToArray();
            var remaining=new Stack<Region>();remaining.Push(root);
            var empty=model.Requirements.Select(r=>r.Id).ToHashSet(StringComparer.Ordinal);
            var feasible=new HashSet<string>(StringComparer.Ordinal);
            Analysis last=null;long operations=0;var elapsed=Stopwatch.StartNew();
            while(remaining.Count>0){
                var domain=remaining.Pop();
                var staging=(IList)Activator.CreateInstance(destination.GetType(),new object[]{false});
                try{
                    last=AnalyzeCore(json,maxRegions,timeoutSeconds,true,null,progress,true,staging,domain,model,feasible);
                    operations+=last.RegionSubtractionCount;
                    if(last.Status=="incomplete:regionLimit"||last.Status=="incomplete:memoryLimit"){
                        int axis=last.SplitAxis==null?-1:Array.IndexOf(names,last.SplitAxis);
                        if(axis<0||domain.Axes[axis].Count<2)axis=axes.FirstOrDefault(i=>domain.Axes[i].Count>1,-1);
                        if(axis<0)return ReportFields(last,destination);
                        var values=domain.Axes[axis].OrderBy(v=>v,StringComparer.Ordinal).ToArray();
                        var left=domain.Copy();var right=domain.Copy();int middle=values.Length/2;
                        left.Axes[axis]=values.Take(middle).ToHashSet(StringComparer.Ordinal);
                        right.Axes[axis]=values.Skip(middle).ToHashSet(StringComparer.Ordinal);
                        remaining.Push(right);remaining.Push(left);continue;
                    }
                    if(last.Status!="completeWithinModel"&&last.Status!="incomplete:emptyRequirementScope")return ReportFields(last,destination);
                    empty.IntersectWith(last.EmptyRequirementIds);
                    foreach(var row in staging)destination.Add(row);
                }finally{(staging as IDisposable)?.Dispose();}
            }
            if(feasible.Count!=model.Identities.Length)throw new ArgumentException("Identity conditions leave no valid scenarios for one or more accounts.");
            last.Status=empty.Count==0?"completeWithinModel":"incomplete:emptyRequirementScope";
            last.EmptyRequirementIds=model.Requirements.Where(r=>empty.Contains(r.Id)).Select(r=>r.Id).ToArray();
            last.ElapsedMilliseconds=elapsed.ElapsedMilliseconds;last.RegionSubtractionCount=operations;
            return ReportFields(last,destination);
        }
        sealed class StoredGaps : IList<Gap> {
            readonly IList records;readonly Func<int,object> read;public StoredGaps(IList records){this.records=records;read=records.GetType().GetMethod("Read",new[]{typeof(int)})?.CreateDelegate<Func<int,object>>(records)??(i=>records[i]);}
            public Gap this[int i]{get=>ReadRecord((IDictionary)read(i));set=>records[i]=GapRecord(value);}
            public int Count=>records.Count;public bool IsReadOnly=>false;public void Add(Gap gap)=>records.Add(GapRecord(gap));
            public IEnumerator<Gap> GetEnumerator(){for(int i=0;i<Count;i++)yield return this[i];}IEnumerator IEnumerable.GetEnumerator()=>GetEnumerator();
            public void CopyTo(Gap[] array,int index){foreach(var gap in this)array[index++]=gap;}public void Clear()=>records.Clear();public int IndexOf(Gap gap)=>throw new NotSupportedException();public bool Contains(Gap gap)=>throw new NotSupportedException();public void Insert(int i,Gap gap)=>throw new NotSupportedException();public bool Remove(Gap gap)=>throw new NotSupportedException();public void RemoveAt(int i)=>throw new NotSupportedException();
        }
        static Gap ReadRecord(IDictionary record){
            string[] Texts(object v)=>v is string[] values?values:((IEnumerable)v).Cast<object>().Select(x=>(string)x).ToArray();
            var region=record["region"] as Dictionary<string,string[]>;
            if(region==null){region=new(StringComparer.Ordinal);foreach(DictionaryEntry e in (IDictionary)record["region"])region.Add((string)e.Key,Texts(e.Value));}
            var witness=record["witness"] as Dictionary<string,string>;
            if(witness==null){witness=new(StringComparer.Ordinal);foreach(DictionaryEntry e in (IDictionary)record["witness"])witness.Add((string)e.Key,(string)e.Value);}
            return new Gap{RequirementId=(string)record["requirementId"],IdentityIds=Texts(record["identityIds"]),Region=region,Witness=witness,ApplicablePolicyIds=Texts(record["applicablePolicyIds"]),NonApplicablePolicyIds=Texts(record["nonApplicablePolicyIds"])};
        }
        public static IDictionary GapRecord(Gap gap){
            // PowerShell's ordered map retains normal key/property projection.
            var map=(IDictionary)Activator.CreateInstance(Type.GetType("System.Management.Automation.OrderedHashtable, System.Management.Automation",true));
            map.Add("requirementId",gap.RequirementId);map.Add("identityIds",gap.IdentityIds);map.Add("region",gap.Region);map.Add("witness",gap.Witness);map.Add("applicablePolicyIds",gap.ApplicablePolicyIds);map.Add("nonApplicablePolicyIds",gap.NonApplicablePolicyIds);return map;
        }
        public static IList<Gap> ReadReportGapList(IEnumerable records)=>records is IList list?new StoredGaps(list):ReadReportGaps(records);
        public static Gap[] ReadReportGaps(IEnumerable records)
        {
            string[] Texts(object value)=>value is string[] typed?typed:value is IEnumerable list?list.Cast<object>().Select(v=>v as string??throw new ArgumentException("Invalid gap strings.")).ToArray():throw new ArgumentException("Invalid gap list.");
            var output=new List<Gap>();
            foreach(var item in records){
                if(item is not IDictionary record)throw new ArgumentException("Invalid gap record.");
                var region=record["region"] as Dictionary<string,string[]>;
                if(region==null){region=new(StringComparer.Ordinal);foreach(DictionaryEntry e in (IDictionary)record["region"])region.Add((string)e.Key,Texts(e.Value));}
                var witness=record["witness"] as Dictionary<string,string>;
                if(witness==null){witness=new(StringComparer.Ordinal);foreach(DictionaryEntry e in (IDictionary)record["witness"])witness.Add((string)e.Key,(string)e.Value);}
                output.Add(new Gap{RequirementId=(string)record["requirementId"],IdentityIds=Texts(record["identityIds"]),Region=region,Witness=witness,ApplicablePolicyIds=Texts(record["applicablePolicyIds"]),NonApplicablePolicyIds=Texts(record["nonApplicablePolicyIds"])});
            }
            return output.ToArray();
        }
        private static Analysis AnalyzeCore(string json, int maxRegions, int timeoutSeconds, bool groupIdentities, Action<int,int> progress, Action<AnalysisProgress> detailProgress, bool sharedOutput, IList records=null, Region domain=null,Model parsed=null,HashSet<string> feasible=null)
        {
            if (maxRegions < 1 || timeoutSeconds < 0) throw new ArgumentException("The region limit must be positive and the timeout cannot be negative.");
            var model = parsed ?? JsonSerializer.Deserialize<Model>(json, JsonOptions) ?? throw new ArgumentException("Missing model.");
            if(parsed==null)Validate(model);
            var clock = Stopwatch.StartNew();var workClock=Stopwatch.StartNew();
            var initialHeap = GC.GetTotalMemory(false);
            long memoryAllowance = Math.Min((sharedOutput?768L:256L) * 1024 * 1024, Math.Max(16L * 1024 * 1024, GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 8));
            long checks = 0, resultCharacters = 0;
            var progressClock = Stopwatch.StartNew();
            var live = new AnalysisProgress { Phase="Preparing scenario rules",TotalAccounts=model.Identities.Length,RequirementCount=model.Requirements.Length };
            void Report(bool force=false) { if(detailProgress!=null && (force || progressClock.ElapsedMilliseconds>=200)) { detailProgress(live);progressClock.Restart(); } }
            var axisValues = new AxisValuePool();
            var names = model.Dimensions.Keys.OrderBy(x => x, StringComparer.Ordinal).ToArray();
            var universe = domain ?? new Region(names.Select(n => new HashSet<string>(model.Dimensions[n], StringComparer.Ordinal)).ToArray());
            var result = new Analysis { Gaps=records!=null?new StoredGaps(records):new List<Gap>(), IdentityCount = model.Identities.Length, ProfileGroupingEnabled = groupIdentities,
                UnverifiedApplicationFilterPolicyIds = model.Policies.Where(p => p.State == "enabled" && p.UnverifiedApplicationFilter).Select(p => p.Id).ToArray(),
                UnverifiedLocationPolicyIds = model.Policies.Where(p => p.State == "enabled" && p.UnverifiedLocations).Select(p => p.Id).ToArray(),
                RegistrationResourcePolicyIds = model.Policies.Where(p => p.State == "enabled" && p.RegistrationResourceContext).Select(p => p.Id).ToArray() };
            void Check(int regions)
            {
                if (regions > maxRegions) throw new BudgetException("regionLimit");
                if (timeoutSeconds > 0 && (records!=null?workClock:clock).Elapsed.TotalSeconds > timeoutSeconds) throw new BudgetException("timeout");
                if ((++checks & 127) == 0 && GC.GetTotalMemory(false) - initialHeap > memoryAllowance) {
                    Report(true);GC.Collect();
                    if(GC.GetTotalMemory(false)-initialHeap>memoryAllowance)throw new BudgetException("memoryLimit");
                }
                if ((checks & 127) == 0) { live.RegionOperations=result.RegionSubtractionCount;live.GapGroups=result.Gaps.Count;Report(); }
            }
            void CheckList(List<Region> regions){
                if(regions.Count>maxRegions){
                    var first=regions[0];
                    for(int i=0;i<names.Length;i++)if(regions.Any(r=>!r.Axes[i].SetEquals(first.Axes[i]))){
                        result.SplitAxis=names[i];break;
                    }
                }
                Check(regions.Count);
            }
            List<Region> SubtractAll(List<Region> source, Region cut)
            {
                var output = new List<Region>();
                foreach (var region in source)
                {
                    result.RegionSubtractionCount++;
                    output.AddRange(Subtract(region, cut));
                    CheckList(output);
                }
                return output;
            }
            List<Region> IntersectAll(List<Region> source, List<Region> allowed)
            {
                var output = new List<Region>();
                foreach (var region in source) foreach (var bound in allowed)
                {
                    var overlap = Intersect(region, bound);
                    if (overlap != null) output.Add(overlap);
                    CheckList(output);
                }
                return output;
            }
            List<Region> DisjointUnion(IEnumerable<Dictionary<string, Selector>> clauses, Region domain = null)
            {
                var union = new List<Region>();
                foreach (var clause in clauses)
                {
                    var rectangle = Select(domain ?? universe, names, clause);
                    if (rectangle == null) continue;
                    var pieces = new List<Region> { rectangle };
                    foreach (var existing in union) pieces = SubtractAll(pieces, existing);
                    union.AddRange(pieces); CheckList(union);
                }
                return union;
            }
            List<Region> ApplyConstraints(List<Region> regions, IEnumerable<Dictionary<string, Selector>[]> groups)
            {
                foreach (var group in groups)
                {
                    var next = new List<Region>();
                    foreach (var region in regions)
                    {
                        // Bound clauses before splitting. Expanding every shared
                        // membership combination first can be exponential even
                        // when each actual account has only one feasible state.
                        next.AddRange(DisjointUnion(group, region)); CheckList(next);
                    }
                    regions = next;
                }
                return regions;
            }
            var enabled = model.Policies.Where(p => p.State == "enabled").ToArray();
            var policyTargets = enabled.ToDictionary(p => p.Id, p => new TargetSet(p.IncludeUsers, p.ExcludeUsers));
            var requirementTargets = model.Requirements.ToDictionary(r => r.Id, r => new TargetSet(r.IncludeUsers, r.ExcludeUsers));
            bool AppliesIndexed(Requirement r, Identity u) => requirementTargets[r.Id].Contains(u.Id) && (r.Scope == "all" || u.Privileged || u.PimEligible);
            // Exact equivalence under all identity-dependent predicates in this model.
            var profiles = model.Identities.GroupBy(u => u, new IdentityProfileComparer(enabled, model.Requirements, policyTargets, requirementTargets, groupIdentities)).ToArray();
            result.IdentityProfileCount = profiles.Length;
            live.ProfileCount=profiles.Length;Report(true);
            int completedAccounts = 0;
            progress?.Invoke(0, model.Identities.Length);
            try
            {
                var requirementRegions = model.Requirements.ToDictionary(r => r.Id, r => {
                    var bound = Select(universe, names, r.Conditions);
                    if (bound == null) return new List<Region>();
                    var regions = new List<Region> { bound };
                    return r.ConditionAlternatives == null ? regions : IntersectAll(regions, DisjointUnion(r.ConditionAlternatives));
                });
                var satisfyingRegions = model.Requirements.ToDictionary(r=>r.Id,r=>r.MustBlock?new List<Region>():
                    (r.RequiredAlternatives ?? new[]{new Dictionary<string,Selector>{{"authentication",new Selector{Include=r.AllowedAuthentication}}}})
                    .Select(a=>Select(universe,names,a)).Where(a=>a!=null).ToList());
                var calculationKeys=model.Requirements.ToDictionary(r=>r.Id,r=>JsonSerializer.Serialize(new{r.Conditions,r.ConditionAlternatives,r.MustBlock,r.MustPermit,r.InventoryCheck,r.RequiredAlternatives,r.AllowedAuthentication},JsonOptions));
                var nonemptyRequirements = new HashSet<string>(StringComparer.Ordinal);
                var conditionRegions = enabled.ToDictionary(p => p.Id, p => Select(universe, names, p.Conditions));
                var forbidden = new Dictionary<string, List<Region>>();
                foreach (var policy in enabled)
                {
                    Check(0);
                    var match = conditionRegions[policy.Id];
                    var denied = match == null ? new List<Region>() : new List<Region> { match };
                    foreach (var alternative in policy.GrantAlternatives)
                    {
                        var allowed = Select(universe, names, alternative);
                        if (allowed != null) denied = SubtractAll(denied, allowed);
                    }
                    forbidden[policy.Id] = denied;
                }
                foreach (var profile in profiles)
                {
                    live.ProfileIndex++;live.RequirementIndex=0;live.RequirementId=null;
                    Check(0);
                    var representative = profile.First();
                    var profileIds=profile.Select(u=>u.Id).OrderBy(x=>x,StringComparer.Ordinal).ToArray();
                    var identityRegion = Select(universe, names, representative.Conditions);
                    var validProfile = identityRegion == null ? new List<Region>() : new List<Region> { identityRegion };
                    validProfile = ApplyConstraints(validProfile, model.ScenarioConstraints.Concat(representative.ScenarioConstraints));
                    if(domain!=null && validProfile.Count==0)continue;
                    if(feasible!=null)feasible.UnionWith(profileIds);
                    if (validProfile.Count == 0) throw new ArgumentException("Identity conditions leave no valid scenarios: " + representative.Id);
                    var policies = enabled.Where(p => policyTargets[p.Id].Contains(representative.Id)).ToArray();
                    var calculated=new Dictionary<string,List<Region>>(StringComparer.Ordinal);int cachedRegions=0;
                    foreach (var requirement in model.Requirements.Where(r => AppliesIndexed(r, representative)))
                    {
                        if(records!=null)workClock.Restart();live.Phase="Checking requirements";live.RequirementIndex=Array.IndexOf(model.Requirements,requirement)+1;live.RequirementId=requirement.Id;Report();
                        var calculationKey=calculationKeys[requirement.Id];
                        if(!calculated.TryGetValue(calculationKey,out var gaps)){
                        gaps = IntersectAll(requirementRegions[requirement.Id], validProfile);
                        if (gaps.Count == 0) continue;

                        var permitScope = requirement.MustPermit ? gaps : null;
                        if (!requirement.MustBlock && !requirement.MustPermit)
                        {
                            foreach(var satisfies in satisfyingRegions[requirement.Id]) gaps=SubtractAll(gaps,satisfies);
                        }
                        if (!requirement.InventoryCheck)
                        foreach (var policy in policies)
                            foreach (var cut in forbidden[policy.Id]) gaps = SubtractAll(gaps, cut);
                        if (permitScope != null)
                        {
                            var denied = permitScope;
                            foreach (var reachable in gaps) denied = SubtractAll(denied, reachable);
                            gaps = denied;
                        }
                        // Cache only within this identity profile; retain subtraction and output ordering.
                        if(calculated.Count<64 && cachedRegions+gaps.Count<=maxRegions){calculated[calculationKey]=gaps;cachedRegions+=gaps.Count;}
                        }
                        nonemptyRequirements.Add(requirement.Id);
                        foreach (var gap in gaps)
                        {
                            Check(sharedOutput?0:result.Gaps.Count + 1);
                            if (!sharedOutput) {
                                resultCharacters += names.Select((n,i) => n.Length + 8L + gap.Axes[i].Sum(v => (long)v.Length + 3)).Sum()
                                    + profile.Sum(u => (long)u.Id.Length + 3) + enabled.Sum(p => (long)p.Id.Length + 3) + names.Sum(n => (long)n.Length + 32) + 256;
                                if(resultCharacters>16L*1024*1024)throw new BudgetException("resultSizeLimit");
                            }
                            var witness = names.Select((n, i) => new { Name = n, Value = axisValues.Get(gap.Axes[i])[0] })
                                .ToDictionary(x => x.Name, x => x.Value);
                            var applied = requirement.InventoryCheck ? Array.Empty<string>() : policies.Where(p => Contains(conditionRegions[p.Id], names, witness)).Select(p => p.Id).ToArray();
                            result.Gaps.Add(new Gap {
                                RequirementId = requirement.Id,
                                IdentityIds = profileIds,
                                Region = names.Select((n,i) => new { Name=n, Values=axisValues.Get(gap.Axes[i]) }).ToDictionary(x => x.Name,x => x.Values),
                                Witness = witness,
                                ApplicablePolicyIds = applied,
                                NonApplicablePolicyIds = enabled.Select(p => p.Id).Except(applied).ToArray()
                            });
                        }
                    }
                    completedAccounts += profile.Count();
                    live.CompletedAccounts=completedAccounts;live.RegionOperations=result.RegionSubtractionCount;live.GapGroups=result.Gaps.Count;Report(true);
                    progress?.Invoke(completedAccounts, model.Identities.Length);
                }
                result.EmptyRequirementIds = model.Requirements.Where(r => !nonemptyRequirements.Contains(r.Id)).Select(r => r.Id).ToArray();
                if (result.EmptyRequirementIds.Length > 0) result.Status = "incomplete:emptyRequirementScope";
            }
            catch (BudgetException e) { result.Status = "incomplete:" + e.Message;
                result.Limitation = string.IsNullOrEmpty(live.RequirementId) ? "while preparing scenario rules" : $"while checking requirement {live.RequirementId} (account profile {live.ProfileIndex} of {live.ProfileCount})";
            }
            result.ElapsedMilliseconds = clock.ElapsedMilliseconds;
            return result;
        }
        private sealed class AxisValuePool
        {
            private sealed class Box { public string[] Values; public Box(string[] values){Values=values;} }
            private readonly Dictionary<HashSet<string>,string[]> byValue = new(HashSet<string>.CreateSetComparer());
            private readonly System.Runtime.CompilerServices.ConditionalWeakTable<HashSet<string>,Box> byReference = new();
            public string[] Get(HashSet<string> values) {
                if(byReference.TryGetValue(values,out var known))return known.Values;
                if(!byValue.TryGetValue(values,out var array)){array=values.OrderBy(v=>v,StringComparer.Ordinal).ToArray();if(byValue.Count>=4096)byValue.Clear();byValue.Add(values,array);}
                byReference.Add(values,new Box(array));return array;
            }
        }
        private sealed class IdentityProfileComparer : IEqualityComparer<Identity>
        {
            private readonly Policy[] policies;
            private readonly Requirement[] requirements;
            private readonly Dictionary<string, TargetSet> policyTargets, requirementTargets;
            private readonly bool grouped;
            public IdentityProfileComparer(Policy[] policies, Requirement[] requirements, Dictionary<string,TargetSet> policyTargets, Dictionary<string,TargetSet> requirementTargets, bool grouped)
            { this.policies=policies; this.requirements=requirements; this.policyTargets=policyTargets; this.requirementTargets=requirementTargets; this.grouped=grouped; }
            private bool Applies(Requirement r, Identity u) => requirementTargets[r.Id].Contains(u.Id) && (r.Scope == "all" || u.Privileged || u.PimEligible);
            private static bool ValuesEqual(string[] a, string[] b) => a.Length == b.Length && (a.Length == 0 || (a.Length == 1 ? a[0] == b[0] : a.OrderBy(v=>v,StringComparer.Ordinal).SequenceEqual(b.OrderBy(v=>v,StringComparer.Ordinal))));
            private static bool ConditionsEqual(Dictionary<string,Selector> a, Dictionary<string,Selector> b) => a.Count == b.Count && a.All(e => b.TryGetValue(e.Key,out var v) && ValuesEqual(e.Value.Include,v.Include) && ValuesEqual(e.Value.Exclude,v.Exclude));
            private static int ValuesHash(string[] values) { unchecked { int h=values.Length; foreach(var v in values) h+=StringComparer.Ordinal.GetHashCode(v)*31; return h; } }
            private static int ConditionsHash(Dictionary<string,Selector> conditions) { unchecked { int h=conditions.Count; foreach(var e in conditions) h+=StringComparer.Ordinal.GetHashCode(e.Key) ^ (ValuesHash(e.Value.Include)*397) ^ ValuesHash(e.Value.Exclude); return h; } }
            public bool Equals(Identity a, Identity b)
            {
                if (ReferenceEquals(a,b)) return true;
                if (a == null || b == null || (!grouped && a.Id != b.Id) || !ConditionsEqual(a.Conditions,b.Conditions) || a.ScenarioConstraints.Length != b.ScenarioConstraints.Length) return false;
                foreach(var p in policies) if(policyTargets[p.Id].Contains(a.Id) != policyTargets[p.Id].Contains(b.Id)) return false;
                foreach(var r in requirements) if(Applies(r,a) != Applies(r,b)) return false;
                for(int i=0;i<a.ScenarioConstraints.Length;i++) {
                    var x=a.ScenarioConstraints[i]; var y=b.ScenarioConstraints[i]; if(x.Length != y.Length) return false;
                    // Preserve legacy profile boundaries for saved exception
                    // scopes: constraint JSON previously retained clause key
                    // and selector-value order, unlike identity Conditions.
                    for(int j=0;j<x.Length;j++) if(x[j].Count != y[j].Count || !x[j].Zip(y[j]).All(pair => pair.First.Key == pair.Second.Key && pair.First.Value.Include.SequenceEqual(pair.Second.Value.Include) && pair.First.Value.Exclude.SequenceEqual(pair.Second.Value.Exclude))) return false;
                }
                return true;
            }
            public int GetHashCode(Identity u)
            {
                unchecked {
                    int h=grouped?17:StringComparer.Ordinal.GetHashCode(u.Id);
                    foreach(var p in policies) h=h*31+(policyTargets[p.Id].Contains(u.Id)?1:0);
                    foreach(var r in requirements) h=h*31+(Applies(r,u)?1:0);
                    h=h*31+ConditionsHash(u.Conditions);
                    foreach(var group in u.ScenarioConstraints) { h=h*31+group.Length; foreach(var clause in group) h=h*31+ConditionsHash(clause); }
                    return h;
                }
            }
        }
        private sealed class TargetSet
        {
            private readonly HashSet<string> include, exclude;
            private readonly bool includeAll, excludeAll;
            public TargetSet(string[] included, string[] excluded)
            {
                include = new HashSet<string>(included, StringComparer.Ordinal);
                exclude = new HashSet<string>(excluded, StringComparer.Ordinal);
                includeAll = include.Contains("*"); excludeAll = exclude.Contains("*");
            }
            public bool Contains(string id) => (includeAll || include.Contains(id)) && !excludeAll && !exclude.Contains(id);
        }
        private static bool Contains(Region region, string[] names, Dictionary<string,string> point) => region != null && names.Select((n,i) => region.Axes[i].Contains(point[n])).All(x => x);
        private static Region Select(Region universe, string[] names, Dictionary<string,Selector> conditions)
        {
            var result = universe.Copy();
            foreach (var entry in conditions)
            {
                var index = Array.IndexOf(names, entry.Key);
                var axis = result.Axes[index];
                if (entry.Value.Include.Length > 0) axis = IntersectAxis(axis, new HashSet<string>(entry.Value.Include, StringComparer.Ordinal));
                if (entry.Value.Exclude.Any(axis.Contains)) { axis = new HashSet<string>(axis, StringComparer.Ordinal); axis.ExceptWith(entry.Value.Exclude); }
                if (axis.Count == 0) return null;
                result.Axes[index] = axis;
            }
            return result;
        }
        private static List<Region> Subtract(Region source, Region cut)
        {
            var intersection = Intersect(source, cut);
            if (intersection == null) return new List<Region> { source };
            // Peel disjoint slabs off the overlap, one dimension at a time.
            var remainder = source.Copy();
            var output = new List<Region>();
            for (int i=0; i<source.Axes.Length; i++)
            {
                if (ReferenceEquals(remainder.Axes[i], intersection.Axes[i])) continue;
                var outside = new HashSet<string>(remainder.Axes[i], StringComparer.Ordinal);
                outside.ExceptWith(intersection.Axes[i]);
                if (outside.Count > 0) { var slab = remainder.Copy(); slab.Axes[i] = outside; output.Add(slab); }
                remainder.Axes[i] = intersection.Axes[i];
            }
            return output;
        }
        private static Region Intersect(Region source, Region bound)
        {
            var result = source.Copy();
            for (int i=0; i<result.Axes.Length; i++)
            {
                result.Axes[i] = IntersectAxis(source.Axes[i], bound.Axes[i]);
                if (result.Axes[i].Count == 0) return null;
            }
            return result;
        }
        private static HashSet<string> IntersectAxis(HashSet<string> left, HashSet<string> right)
        {
            if (ReferenceEquals(left, right)) return left;
            if (left.Count > right.Count) { var swap = left; left = right; right = swap; }
            var result = new HashSet<string>(left, StringComparer.Ordinal);
            result.IntersectWith(right);
            if (result.Count == left.Count) return left;
            if (result.Count == right.Count) return right;
            return result;
        }
        private static void Validate(Model m)
        {
            if (m.SchemaVersion != 1) throw new ArgumentException("Only schemaVersion 1 is supported.");
            if (!m.Dimensions.ContainsKey("authentication")) throw new ArgumentException("Missing authentication dimension.");
            foreach (var d in m.Dimensions)
                if (string.IsNullOrWhiteSpace(d.Key) || d.Value == null || d.Value.Length == 0 || d.Value.Any(string.IsNullOrWhiteSpace) || d.Value.Distinct().Count() != d.Value.Length)
                    throw new ArgumentException("Dimension values must be nonempty and unique.");
            if (m.Identities.Any(u => string.IsNullOrWhiteSpace(u.Id)) || m.Identities.Select(u=>u.Id).Distinct().Count() != m.Identities.Length) throw new ArgumentException("Identity IDs must be nonempty and unique.");
            var identityIds = new HashSet<string>(m.Identities.Select(u => u.Id), StringComparer.Ordinal);
            void Conditions(Dictionary<string,Selector> conditions)
            {
                foreach (var entry in conditions)
                {
                    if (!m.Dimensions.ContainsKey(entry.Key)) throw new ArgumentException("Unknown dimension: " + entry.Key);
                    if (entry.Value == null || entry.Value.Include == null || entry.Value.Exclude == null) throw new ArgumentException("Null selector.");
                    if (entry.Value.Include.Concat(entry.Value.Exclude).Any(v => !m.Dimensions[entry.Key].Contains(v))) throw new ArgumentException("Unknown dimension value: " + entry.Key);
                }
            }
            void Users(string[] include, string[] exclude)
            {
                if (include == null || exclude == null || include.Concat(exclude).Any(x => x != "*" && !identityIds.Contains(x))) throw new ArgumentException("Unknown identity reference.");
            }
            void Constraints(Dictionary<string,Selector>[][] groups)
            {
                if (groups == null || groups.Any(g=>g == null || g.Length == 0)) throw new ArgumentException("Scenario constraint groups cannot be empty or null.");
                foreach (var group in groups) foreach (var clause in group) { if (clause == null) throw new ArgumentException("Null scenario clause."); Conditions(clause); }
            }
            Constraints(m.ScenarioConstraints);
            foreach (var identity in m.Identities) { if (identity.Conditions == null) throw new ArgumentException("Null identity conditions."); Conditions(identity.Conditions); Constraints(identity.ScenarioConstraints); }
            if (m.Policies.Select(p=>p.Id).Distinct().Count() != m.Policies.Length || m.Requirements.Select(r=>r.Id).Distinct().Count() != m.Requirements.Length) throw new ArgumentException("Duplicate policy or requirement ID.");
            foreach (var p in m.Policies)
            {
                if (string.IsNullOrWhiteSpace(p.Id) || !new[]{"enabled","disabled","reportOnly"}.Contains(p.State)) throw new ArgumentException("Invalid policy ID or state.");
                if (p.LocationMatchingOnly == false && (!p.UnverifiedLocations || (p.GuaranteedGrantAlternatives?.Length ?? 0) != 0 || (p.GuaranteedRegistrationGrantAlternatives?.Length ?? 0) != 0)) throw new ArgumentException("Location acquisition uncertainty cannot carry permission proofs or verified location protection.");
                if (p.RegistrationResourceContext && (!p.Conditions.TryGetValue("accessTarget", out var appTarget) || appTarget.Include.Length != 1 || appTarget.Include[0] != "application" || appTarget.Exclude.Length != 0 || !m.Dimensions.TryGetValue("accessTarget", out var targetValues) || !targetValues.Contains("userAction", StringComparer.Ordinal) || !m.Dimensions.TryGetValue("registrationContext", out var contextValues) || !contextValues.Contains("unspecified", StringComparer.Ordinal))) throw new ArgumentException("Registration resource context requires an app-only policy and unspecified registration domain.");
                if (p.UnverifiedApplicationFilter && (p.GrantAlternatives == null || p.GrantAlternatives.Length != 1 || p.GrantAlternatives[0] == null || p.GrantAlternatives[0].Count != 0))
                    throw new ArgumentException("Unverified application-filter policies cannot carry protection grants.");
                if (p.UnverifiedLocations && (p.GrantAlternatives == null || p.GrantAlternatives.Length != 1 || p.GrantAlternatives[0] == null || p.GrantAlternatives[0].Count != 0))
                    throw new ArgumentException("Unverified location policies cannot carry protection grants.");
                if (p.GuaranteedGrantAlternatives != null)
                {
                    if (!p.UnverifiedLocations) throw new ArgumentException("Guaranteed grant bounds require unverified location scope.");
                    foreach (var bound in p.GuaranteedGrantAlternatives)
                    {
                        if (bound == null || bound.Keys.Any(n => n != "authentication" && n != "compliant" && n != "hybridJoined")) throw new ArgumentException("Invalid guaranteed grant bound.");
                        Conditions(bound);
                    }
                }
                Users(p.IncludeUsers,p.ExcludeUsers); Conditions(p.Conditions);
                foreach (var alt in p.GrantAlternatives) Conditions(alt);
                if (p.GuaranteedRegistrationGrantAlternatives != null)
                {
                    if (!p.RegistrationResourceContext) throw new ArgumentException("Registration grant bounds require registration resource context.");
                    foreach (var bound in p.GuaranteedRegistrationGrantAlternatives)
                    {
                        if (bound == null || bound.Keys.Any(n => n != "authentication" && n != "compliant" && n != "hybridJoined")) throw new ArgumentException("Invalid guaranteed registration grant bound.");
                        Conditions(bound);
                        bool Allows(Selector selector, string value) => selector == null || ((selector.Include.Length == 0 || selector.Include.Contains(value, StringComparer.Ordinal)) && !selector.Exclude.Contains(value, StringComparer.Ordinal));
                        // Each asserted permission must satisfy at least one
                        // complete necessary grant route. Mere overlap cannot
                        // turn a stronger AND grant into a permission proof.
                        if (!p.GrantAlternatives.Any(alt => alt.All(entry => m.Dimensions[entry.Key].Where(v => Allows(bound.GetValueOrDefault(entry.Key),v)).All(v => Allows(entry.Value,v)))))
                            throw new ArgumentException("Registration permission does not satisfy a necessary grant route.");
                    }
                }
            }
            foreach (var r in m.Requirements)
            {
                if (string.IsNullOrWhiteSpace(r.Id) || !new[]{"all","privileged"}.Contains(r.Scope)) throw new ArgumentException("Invalid requirement ID or scope.");
                Users(r.IncludeUsers,r.ExcludeUsers); Conditions(r.Conditions);
                if (r.ConditionAlternatives != null) foreach (var clause in r.ConditionAlternatives) { if (clause == null) throw new ArgumentException("Null requirement condition clause."); Conditions(clause); }
                if (!r.MustBlock && r.RequiredAlternatives == null && (r.AllowedAuthentication.Length == 0 || r.AllowedAuthentication.Any(x=>!m.Dimensions["authentication"].Contains(x)))) throw new ArgumentException("Invalid allowed authentication.");
                if (r.RequiredAlternatives != null)
                {
                    if (r.RequiredAlternatives.Length == 0) throw new ArgumentException("A control requirement needs an alternative; use MustBlock for denied access.");
                    foreach (var alternative in r.RequiredAlternatives) Conditions(alternative);
                }
            }
        }
        private sealed class BudgetException : Exception { public BudgetException(string reason) : base(reason) {} }
    }
}
