# Local UI adapter over the same assessment/history pipeline used by PowerShell.
function Get-CaInteractiveHistoryFolder([string]$SourceKey){
    if(!$SourceKey -or $SourceKey.Length -gt 1000){throw 'Choose a loaded snapshot first.'}
    $scope=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($SourceKey+'|default'))).ToLowerInvariant().Substring(0,24)
    Join-Path $PSScriptRoot "../data/assessments/$scope"
}
function Invoke-CaInteractiveAssessment($Snapshot,$Profile,[scriptblock]$Progress){
    if($Snapshot.caGapSnapshotVersion -ne 1 -or $Profile.version -ne 1){throw 'A full tenant snapshot and requirements configuration are required.'}
    $scratch=if($env:CALENS_TEMP_DIRECTORY){$env:CALENS_TEMP_DIRECTORY}else{[IO.Path]::GetTempPath()}
    $folder=Join-Path $scratch ('ca-ui-assessment-'+[guid]::NewGuid().ToString('N'))
    $null=New-Item -ItemType Directory -Path $folder
    $snapshotPath=Join-Path $folder 'snapshot.json';$profilePath=Join-Path $folder 'requirements.json'
    try{
        $json=ConvertTo-Json -InputObject $Snapshot -Depth 100 -Compress
        [CaGapAnalyzer.ReservedFile]::WriteText($snapshotPath,$json)
        $json=ConvertTo-Json -InputObject $Profile -Depth 100 -Compress
        [CaGapAnalyzer.ReservedFile]::WriteText($profilePath,$json)
        Invoke-CaTenantAssessment -SnapshotPath $snapshotPath -RequirementsPath $profilePath -Progress $Progress
    }finally{
        foreach($path in @($snapshotPath,$profilePath)){if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}}
        Remove-Item -LiteralPath $folder -Force
    }
}
function Read-CaSavedAssessmentHeader([string]$Path){
    $headerPath=$Path+'.header.json'
    if((Test-Path -LiteralPath $headerPath) -and (Get-Item -LiteralPath $headerPath).LastWriteTimeUtc -ge (Get-Item -LiteralPath $Path).LastWriteTimeUtc){
        try{
            $header=Get-Content -LiteralPath $headerPath -Raw|ConvertFrom-CaJson
            if($header['assessmentVersion'] -eq 1 -and $header['coverageSummary']){return $header}
        }catch{}
    }
    return ([CaGapAnalyzer.ReportHeaders]::Read($Path)|ConvertFrom-CaJson)
}
function Get-CaInteractiveHistory([string]$SourceKey,[string]$RunId){
    $folder=Get-CaInteractiveHistoryFolder $SourceKey
    if($RunId){
        if($RunId -notmatch '^\d{8}T\d{13}Z-[a-f0-9]{8}\.local\.json$'){throw 'Choose a saved check from the list.'}
        $path=Join-Path $folder $RunId
        $report=[CaGapAnalyzer.ReportCodec]::ReadFile($path)
        if($report.sourceKey -cne $SourceKey){throw 'Saved check belongs to a different source.'}
        return $report
    }
    $runs=[Collections.Generic.List[object]]::new();$unreadable=0
    if(Test-Path -LiteralPath $folder){
        foreach($file in @(Get-ChildItem -LiteralPath $folder -File -Filter '*.local.json'|Where-Object Name -ne 'latest.local.json'|Sort-Object Name -Descending|Select-Object -First 20)){
            try{
                $r=Read-CaSavedAssessmentHeader $file.FullName
                if($r.sourceKey -cne $SourceKey -or $r.assessmentVersion -ne 1 -or !$r.coverageSummary){throw 'Saved check is invalid.'}
                $runs.Add(@{id=$file.Name;runAtUtc=$r.runAtUtc;snapshotCapturedAtUtc=$r.snapshotCapturedAtUtc;status=$r.status;score=$r.coverageSummary.score;affected=$r.coverageSummary.affected;checked=$r.coverageSummary.checked})
            }catch{$unreadable++}
        }
    }
    @{runs=$runs.ToArray();unreadable=$unreadable;limit=20}
}

function Get-CaSavedAssessments {
    $root=Join-Path $PSScriptRoot '../data/assessments';$runs=[Collections.Generic.List[object]]::new();$unreadable=0
    if(Test-Path -LiteralPath $root){foreach($folder in Get-ChildItem -LiteralPath $root -Directory){
        if($folder.Name -notmatch '^[a-f0-9]{24}$'){continue}
        foreach($file in Get-ChildItem -LiteralPath $folder.FullName -File -Filter '*.local.json'){
            if($file.Name -notmatch '^\d{8}T\d{13}Z-[a-f0-9]{8}\.local\.json$'){continue}
            try{
                $r=Read-CaSavedAssessmentHeader $file.FullName
                if($r['assessmentVersion'] -ne 1 -or !$r['coverageSummary']){continue}
                $runs.Add(@{scope=$folder.Name;id=$file.Name;sourceKey=$r.sourceKey;sourceName=$r['sourceName'];runAtUtc=$r.runAtUtc;status=$r.status;score=$r.coverageSummary.score;checked=$r.coverageSummary.checked;affected=$r.coverageSummary.affected;fullContext=$r['reviewContextVersion'] -eq 1})
            }catch{$unreadable++}
        }
    }}
    return @{runs=@($runs.ToArray()|Sort-Object runAtUtc -Descending);unreadable=$unreadable}
}
function Open-CaSavedAssessment([string]$Scope,[string]$RunId){
    if($Scope -notmatch '^[a-f0-9]{24}$' -or $RunId -notmatch '^\d{8}T\d{13}Z-[a-f0-9]{8}\.local\.json$'){throw 'Choose a saved assessment from the list.'}
    $path=Join-Path $PSScriptRoot "../data/assessments/$Scope/$RunId"
    $r=[CaGapAnalyzer.ReportCodec]::ReadReviewFile($path)
    if($r.assessmentVersion -ne 1 -or !$r['historyEvidence'] -or !$r['coverageSummary']){throw 'This file does not contain a saved tenant assessment.'}
    $r.openedSavedAssessment=$true
    return $r
}
