using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
namespace CaGapAnalyzer {
 public static class ReportHeaders {
  // Keep the original metadata bytes and expand only one finding page at a time.
  // Offsets use UTF-8 byte positions so escaped strings and multibyte names survive.
  internal static object ReadPagedFile(string path){
   using var scan=File.OpenRead(path);using var source=File.OpenRead(path);
   var buffer=new byte[65536];int held=0;long position=0;
   if(scan.ReadByte()==0xef && scan.ReadByte()==0xbb && scan.ReadByte()==0xbf)position=3;
   scan.Position=position;var state=new JsonReaderState(new JsonReaderOptions{MaxDepth=100});
   long arrayStart=-1,arrayEnd=-1,pageStart=-1;bool marker=false,envelope=false,pages=false;
   PagedFindingRecords findings=null;
   try{
    while(true){
     int read=scan.Read(buffer,held,buffer.Length-held),length=held+read;bool final=read==0;
     var reader=new Utf8JsonReader(buffer.AsSpan(0,length),final,state);
     while(reader.Read()){
      var t=reader.TokenType;int depth=reader.CurrentDepth;
      if(t==JsonTokenType.PropertyName && depth==1){marker=reader.ValueTextEquals("_calensFindingPages");continue;}
      if(depth==1 && t==JsonTokenType.StartObject){envelope=marker;marker=false;}
      if(depth==1 && t==JsonTokenType.EndObject)envelope=false;
      if(!envelope)continue;
      if(depth==2 && t==JsonTokenType.PropertyName){pages=reader.ValueTextEquals("pages");continue;}
      if(depth==2 && t==JsonTokenType.StartArray && pages){
       if(arrayStart>=0)throw new JsonException("Duplicate finding pages.");
       arrayStart=position+reader.BytesConsumed;findings=new PagedFindingRecords();pages=false;
      }
      if(arrayStart<0||arrayEnd>=0)continue;
      if(depth==3 && t==JsonTokenType.StartObject)pageStart=position+reader.TokenStartIndex;
      else if(depth==3 && t==JsonTokenType.EndObject){
       if(pageStart<0)throw new JsonException("Invalid finding page.");
       source.Position=pageStart;
       byte[] bytes=new byte[checked((int)(position+reader.BytesConsumed-pageStart))];source.ReadExactly(bytes);
       var page=(System.Collections.IDictionary)ReportCodec.Parse(Encoding.UTF8.GetString(bytes));
       if(page["gaps"] is not System.Collections.IEnumerable rows || page["gaps"] is PagedFindingRecords)throw new JsonException("Invalid finding page.");
       foreach(var row in rows)findings.Add(row);
       pageStart=-1;
      }else if(depth==3 && pageStart<0)throw new JsonException("Invalid finding page.");
      if(depth==2 && t==JsonTokenType.EndArray)arrayEnd=position+reader.TokenStartIndex;
     }
     int consumed=(int)reader.BytesConsumed;position+=consumed;state=reader.CurrentState;held=length-consumed;
     if(final){if(held!=0)throw new JsonException("Incomplete report JSON.");break;}
     if(held>0)Buffer.BlockCopy(buffer,consumed,buffer,0,held);
     if(held==buffer.Length)Array.Resize(ref buffer,checked((int)Math.Min((long)Array.MaxLength,2L*buffer.Length)));
    }
    if(findings==null)return ReportCodec.Parse(File.ReadAllText(path));
    if(arrayEnd<arrayStart)throw new JsonException("Incomplete finding pages.");
    byte[] metadata=new byte[checked((int)(arrayStart+source.Length-arrayEnd))];
    source.Position=0;source.ReadExactly(metadata.AsSpan(0,(int)arrayStart));
    source.Position=arrayEnd;source.ReadExactly(metadata.AsSpan((int)arrayStart));
    return ReportCodec.Parse(Encoding.UTF8.GetString(metadata).TrimStart('\uFEFF'),findings);
   }catch{findings?.Dispose();throw;}
  }
  // Scan tokens without expanding or retaining the finding pages.
  public static string Read(string path){
   var wanted=new HashSet<string>(new[]{"sourceName","reviewContextVersion","sourceKey","assessmentVersion","coverageSummary","runAtUtc","snapshotCapturedAtUtc","status","modelHash"},StringComparer.Ordinal);
   using var file=File.OpenRead(path);using var output=new MemoryStream();using var writer=new Utf8JsonWriter(output);writer.WriteStartObject();
   byte[] buffer=new byte[65536];int held=0;var state=new JsonReaderState(new JsonReaderOptions{MaxDepth=100});bool capture=false;
   while(true){int read=file.Read(buffer,held,buffer.Length-held);bool final=read==0;int length=held+read;var reader=new Utf8JsonReader(buffer.AsSpan(0,length),final,state);
    while(reader.Read()){
     var token=reader.TokenType;int depth=reader.CurrentDepth;
     if(token==JsonTokenType.PropertyName&&depth==1){capture=wanted.Contains(reader.GetString());if(capture)writer.WritePropertyName(reader.GetString());continue;}
     if(!capture)continue;
     switch(token){
      case JsonTokenType.StartObject:writer.WriteStartObject();break;case JsonTokenType.EndObject:writer.WriteEndObject();break;
      case JsonTokenType.StartArray:writer.WriteStartArray();break;case JsonTokenType.EndArray:writer.WriteEndArray();break;
      case JsonTokenType.PropertyName:writer.WritePropertyName(reader.GetString());break;case JsonTokenType.String:writer.WriteStringValue(reader.GetString());break;
      case JsonTokenType.Number:writer.WriteRawValue(reader.ValueSpan,true);break;case JsonTokenType.True:writer.WriteBooleanValue(true);break;case JsonTokenType.False:writer.WriteBooleanValue(false);break;case JsonTokenType.Null:writer.WriteNullValue();break;
     }
     if(depth==1&&token!=JsonTokenType.StartObject&&token!=JsonTokenType.StartArray)capture=false;
    }
    int consumed=(int)reader.BytesConsumed;state=reader.CurrentState;held=length-consumed;if(held>0)Buffer.BlockCopy(buffer,consumed,buffer,0,held);
    if(final){if(held!=0)throw new JsonException("Incomplete report JSON.");break;}
    if(held==buffer.Length){if(buffer.Length>=16*1024*1024)throw new JsonException("Oversized report token.");Array.Resize(ref buffer,buffer.Length*2);}
   }
   writer.WriteEndObject();writer.Flush();return Encoding.UTF8.GetString(output.ToArray());
  }
 }
}
