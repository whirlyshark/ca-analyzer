using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
namespace CaGapAnalyzer {
 // Check the destination throughout large writes, including the final report.
 public sealed class ReservedFile : FileStream {
  const long Interval=1024*1024;
  long remaining;
  public static long ReserveBytes(){
   var setting=Environment.GetEnvironmentVariable("CALENS_MIN_FREE_GIB");
   if(string.IsNullOrEmpty(setting))return 5L<<30;
   if(!int.TryParse(setting,out var gib)||gib<1)throw new ArgumentException("CALENS_MIN_FREE_GIB must be a positive whole number.");
   return (long)gib<<30;
  }
  [System.Runtime.InteropServices.DllImport("kernel32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode,SetLastError=true)]
  static extern bool GetDiskFreeSpaceEx(string path,out ulong available,out ulong total,out ulong free);
  public static void Check(string path,long needed){
   var dir=Path.GetDirectoryName(Path.GetFullPath(path));
   long available;
   if(OperatingSystem.IsWindows()){
    var native=dir.StartsWith(@"\\?\")?dir:dir.StartsWith(@"\\")?@"\\?\UNC\"+dir.Substring(2):@"\\?\"+dir;
    if(!GetDiskFreeSpaceEx(native,out var bytes,out _,out _))throw new IOException("CALens could not check available disk space at "+dir);
    available=(long)bytes;
   }else available=new DriveInfo(Path.GetPathRoot(dir)).AvailableFreeSpace;
   var reserve=ReserveBytes();
   if(available-reserve<needed)throw new IOException($"CALens stopped writing to {dir} to keep {reserve>>30} GiB free. Free space or use a larger drive and run the assessment again.");
  }
  public static void CopyFile(string source,string target){
   Check(target,new FileInfo(source).Length);
   using var input=File.OpenRead(source);using var output=new ReservedFile(target);input.CopyTo(output);
  }
  public static void WriteText(string path,string text){
   var temp=path+".tmp-"+Guid.NewGuid().ToString("N");
   try{using(var file=new ReservedFile(temp))using(var writer=new StreamWriter(file,new System.Text.UTF8Encoding(false)))writer.Write(text);File.Move(temp,path,true);}
   finally{File.Delete(temp);}
  }
  public ReservedFile(string path):base(path,FileMode.Create,FileAccess.Write,FileShare.None){}
  void Before(int count){if(count>remaining){Check(Name,Math.Max(Interval,count));remaining=Math.Max(Interval,count);}remaining-=count;}
  public override void Write(byte[] buffer,int offset,int count){Before(count);base.Write(buffer,offset,count);}
  public override void Write(ReadOnlySpan<byte> buffer){Before(buffer.Length);base.Write(buffer);}
  public override void WriteByte(byte value){Before(1);base.WriteByte(value);}
 }
 // Mutable, disk-backed ordered finding records. Only a bounded page window is resident.
 public sealed class PagedFindingRecords : IList, IDisposable {
  const int PageSize=512,CachePages=3;
  sealed class Page { public List<IDictionary> Records=new();public long Used;public bool Dirty; }
  readonly Dictionary<int,Page> pages=new(); readonly HashSet<int> saved=new();readonly Dictionary<string,int> keys=new(StringComparer.Ordinal);
  bool scopeIndexValid;
  readonly Dictionary<string,HashSet<string>> scopePeople=new(StringComparer.Ordinal);
  readonly HashSet<string> registrationScopes=new(StringComparer.Ordinal);
  void IndexScope(IDictionary record){
   if(!scopeIndexValid)return;
   if(record["requirementId"] is not string id || record["identityIds"] is not IEnumerable people){scopeIndexValid=false;return;}
   var baseId=id;foreach(var suffix in new[]{":outside-network",":outside-apps",":outside-device"})if(id.EndsWith(suffix,StringComparison.Ordinal))baseId=id.Substring(0,id.Length-suffix.Length);
   bool action=record["region"] is IDictionary region && region.Contains("accessTarget") && ((IEnumerable)region["accessTarget"]).Cast<object>().Any(v=>(string)v=="userAction");
   foreach(var key in id==baseId?new[]{id}:new[]{id,baseId}){if(!scopePeople.TryGetValue(key,out var ids)){ids=new(StringComparer.Ordinal);scopePeople.Add(key,ids);}foreach(string person in people)ids.Add(person);if(action)registrationScopes.Add(key);}
  }
  public IDictionary RequirementIndex(){
   if(!scopeIndexValid)return null;
   var result=new Hashtable(StringComparer.Ordinal);foreach(var entry in scopePeople)result.Add(entry.Key,new Hashtable{{"ids",entry.Value.OrderBy(x=>x,StringComparer.Ordinal).ToArray()},{"hasRegistration",registrationScopes.Contains(entry.Key)}});return result;
  }
  readonly string backingDirectory;
  readonly string directory;long clock;int count;bool disposed;
  const string Prefix="calens-findings-v2-";
  const string Marker="calens-spill-v2.owner";
  static readonly System.Collections.Concurrent.ConcurrentDictionary<string,FileStream> owned=new();
  static readonly HashSet<string> scannedRoots=new(StringComparer.OrdinalIgnoreCase);
  static PagedFindingRecords(){AppDomain.CurrentDomain.ProcessExit+=(_,__)=>{foreach(var path in owned.Keys)RemoveOwned(path);};}
  static void CleanDirectory(string path,FileStream lease){
   using(lease){
    var dir=new DirectoryInfo(path);
    if(!dir.Exists||(dir.Attributes&FileAttributes.ReparsePoint)!=0)return;
    foreach(var file in dir.EnumerateFiles()){
     if(System.Text.RegularExpressions.Regex.IsMatch(file.Name,@"^\d{8,10}\.json\.gz(?:\.overview\.gz)?(?:\.tmp)?$"))file.Delete();
    }
    File.Delete(Path.Combine(path,Marker));
   }
   Directory.Delete(path,false);
  }
  static void RemoveOwned(string path){
   if(path==null||!owned.TryRemove(path,out var lease))return;
   try{CleanDirectory(path,lease);}catch(IOException){}catch(UnauthorizedAccessException){}
  }
  static void CleanAbandoned(string root){
   lock(scannedRoots){
    if(!scannedRoots.Add(root))return;
    foreach(var dir in new DirectoryInfo(root).EnumerateDirectories(Prefix+"*")){
     if(!Guid.TryParseExact(dir.Name.Substring(Prefix.Length),"N",out _)||(dir.Attributes&FileAttributes.ReparsePoint)!=0)continue;
     var marker=Path.Combine(dir.FullName,Marker);
     try{
      if(!File.Exists(marker)||(File.GetAttributes(marker)&FileAttributes.ReparsePoint)!=0)continue;
      // A live process holds this marker open without read sharing.
      var lease=new FileStream(marker,FileMode.Open,FileAccess.ReadWrite,FileShare.Delete);
      CleanDirectory(dir.FullName,lease);
     }catch(IOException){}catch(UnauthorizedAccessException){}
    }
   }
  }
  public PagedFindingRecords(bool indexScopes=false){
   scopeIndexValid=indexScopes;
   var root=Environment.GetEnvironmentVariable("CALENS_TEMP_DIRECTORY");
   directory=Path.GetFullPath(Path.Combine(string.IsNullOrWhiteSpace(root)?Path.GetTempPath():root,Prefix+Guid.NewGuid().ToString("N")));
  }
  void OpenScratch(){
   if(owned.ContainsKey(directory))return;
   var root=Path.GetDirectoryName(directory);Directory.CreateDirectory(root);CleanAbandoned(root);
   Directory.CreateDirectory(directory);
   var lease=new FileStream(Path.Combine(directory,Marker),FileMode.CreateNew,FileAccess.ReadWrite,FileShare.Delete);
   owned[directory]=lease;
  }
  public PagedFindingRecords(string backing,int total):this(){backingDirectory=Path.GetFullPath(backing);count=total;for(int i=0;i<(count+PageSize-1)/PageSize;i++)saved.Add(i);}
  string ReadName(int page){var own=FileName(page);return File.Exists(own)||backingDirectory==null?own:Path.Combine(backingDirectory,page.ToString("D8")+".json.gz");}
  public void Persist(string target){
   Flush();Directory.CreateDirectory(target);
   for(int i=0;i<(count+PageSize-1)/PageSize;i++){
    var name=ReadName(i);var copy=Path.Combine(target,Path.GetFileName(name));
    ReservedFile.CopyFile(name,copy);
    if(File.Exists(name+".overview.gz")){
     ReservedFile.CopyFile(name+".overview.gz",copy+".overview.gz");
    }else{
     using var file=new ReservedFile(copy+".overview.gz");using var gzip=new GZipStream(file,CompressionLevel.Optimal);
     ReportCodec.Write(Load(i).Records.Select(Overview).ToArray(),gzip);
    }
   }
  }
  public IDictionary Find(string key){if(backingDirectory!=null&&keys.Count<count){int position=0;foreach(IDictionary row in OverviewRecords()){keys.TryAdd((string)row["key"],position++);}}foreach(var entry in pages)for(int i=0;i<entry.Value.Records.Count;i++)if(entry.Value.Records[i]["key"] is string k)keys.TryAdd(k,entry.Key*PageSize+i);return keys.TryGetValue(key,out var index)?(IDictionary)this[index]:null;}
  public string TemporaryPath=>directory;
  public int ResidentPages=>pages.Count;public int PageCapacity=>PageSize;public int SpilledPages=>saved.Count;
  public object Read(int index){if(index<0||index>=count)throw new ArgumentOutOfRangeException(nameof(index));return Load(index/PageSize).Records[index%PageSize];}
  string FileName(int page)=>Path.Combine(directory,page.ToString("D8")+".json.gz");
  Page Load(int index){
   if(disposed)throw new ObjectDisposedException(nameof(PagedFindingRecords));
   if(!pages.TryGetValue(index,out var page)){
    if(pages.Count>=CachePages){var victim=pages.OrderBy(e=>e.Value.Used).First();Save(victim.Key,victim.Value);pages.Remove(victim.Key);}
    page=new Page();if(saved.Contains(index)){
     using var file=File.OpenRead(ReadName(index));using var gzip=new GZipStream(file,CompressionMode.Decompress);using var reader=new StreamReader(gzip);
     var root=(IDictionary)ReportCodec.Parse(reader.ReadToEnd());foreach(var record in (IEnumerable)root["gaps"])page.Records.Add((IDictionary)record);
    }pages.Add(index,page);
   }page.Used=++clock;return page;
  }
  static IDictionary Overview(IDictionary record){
   var map=new System.Management.Automation.OrderedHashtable();
   foreach(var field in new[]{"key","requirementId","identityIds","assessmentStatus","coverageIssueIndices","acceptance","applicablePolicyIds"})if(record.Contains(field))map.Add(field,record[field]);
   if(record["witness"] is IDictionary witness){var preview=new System.Management.Automation.OrderedHashtable();foreach(var field in new[]{"authentication","compliant","hybridJoined"})if(witness.Contains(field))preview.Add(field,witness[field]);map.Add("witness",preview);}
   return map;
  }
  public IEnumerable OverviewRecords(){
   for(int index=0;index<(count+PageSize-1)/PageSize;index++){
    if(pages.TryGetValue(index,out var resident)){foreach(var row in resident.Records)yield return Overview(row);}
    else if(!File.Exists(ReadName(index)+".overview.gz")){foreach(var row in Load(index).Records)yield return Overview(row);}
    else{using var file=File.OpenRead(ReadName(index)+".overview.gz");using var gzip=new GZipStream(file,CompressionMode.Decompress);using var reader=new StreamReader(gzip);var root=(IEnumerable)ReportCodec.Parse(reader.ReadToEnd());foreach(var row in root)yield return row;}
   }
  }
  public IEnumerable<string> PackedPages(){
   Flush();for(int index=0;index<(count+PageSize-1)/PageSize;index++){
    using var file=File.OpenRead(ReadName(index));using var gzip=new GZipStream(file,CompressionMode.Decompress);using var reader=new StreamReader(gzip);yield return reader.ReadToEnd();
   }
  }
  void Save(int index,Page page){
   if(!page.Dirty&&saved.Contains(index))return;
   // Write then replace; disk errors abort the assessment rather than lose findings.
   for(int i=0;i<page.Records.Count;i++)if(page.Records[i]["key"] is string key)keys.TryAdd(key,index*PageSize+i);
   OpenScratch();var path=FileName(index);using(var file=new ReservedFile(path+".tmp"))using(var gzip=new GZipStream(file,CompressionLevel.Optimal)){
    ReportCodec.Write(new Hashtable{{"gaps",page.Records.ToArray()}},gzip,true);
   }File.Move(path+".tmp",path,true);
   saved.Add(index);page.Dirty=false;
  }
  int discardedPages;
  // Only used when an exclusive, temporary source is being replaced in order.
  public void DiscardConsumedPages(int rows){
   if(backingDirectory!=null||rows<0||rows>count)throw new InvalidOperationException("Invalid temporary page release.");
   while(discardedPages<rows/PageSize){
    int index=discardedPages++;pages.Remove(index);saved.Remove(index);
    if(owned.ContainsKey(directory))File.Delete(FileName(index));
   }
  }
  public void Flush(){foreach(var entry in pages)Save(entry.Key,entry.Value);}
  public object this[int index]{get{if(index<0||index>=count)throw new ArgumentOutOfRangeException(nameof(index));scopeIndexValid=false;var p=Load(index/PageSize);p.Dirty=true;return p.Records[index%PageSize];}set{if(index<0||index>=count)throw new ArgumentOutOfRangeException(nameof(index));scopeIndexValid=false;var p=Load(index/PageSize);p.Dirty=true;p.Records[index%PageSize]=(IDictionary)value;}}
  public int Add(object value){if(value is not IDictionary record)throw new ArgumentException("A finding must be a map.");IndexScope(record);var index=count;var p=Load(index/PageSize);p.Dirty=true;p.Records.Add(record);if(record["key"] is string key)keys.TryAdd(key,index);count++;return index;}
  public int Count=>count;public bool IsFixedSize=>false;public bool IsReadOnly=>false;public bool IsSynchronized=>false;public object SyncRoot=>this;
  public IEnumerable ReadOnlyRecords(){for(int i=0;i<count;i++)yield return Load(i/PageSize).Records[i%PageSize];}
  public IEnumerator GetEnumerator(){for(int i=0;i<count;i++)yield return this[i];}
  public void CopyTo(Array array,int index){foreach(var value in this)array.SetValue(value,index++);}
  public int IndexOf(object value){for(int i=0;i<count;i++)if(ReferenceEquals(this[i],value))return i;return -1;}
  public bool Contains(object value)=>IndexOf(value)>=0;
  public void Clear()=>throw new NotSupportedException();public void Insert(int index,object value)=>throw new NotSupportedException();public void Remove(object value)=>throw new NotSupportedException();public void RemoveAt(int index)=>throw new NotSupportedException();
  public void Dispose(){if(disposed)return;disposed=true;pages.Clear();RemoveOwned(directory);GC.SuppressFinalize(this);}
  ~PagedFindingRecords(){Dispose();}
 }
}

