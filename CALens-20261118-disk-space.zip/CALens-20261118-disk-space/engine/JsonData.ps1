# Literal-preserving JSON for local configuration and request bodies. PowerShell's
# default date conversion can otherwise change user-defined filter values.
function Read-CaJsonValue([System.Text.Json.JsonElement]$Node){
    switch($Node.ValueKind.ToString()){
        'Object' {$map=[System.Management.Automation.OrderedHashtable]::new();foreach($property in $Node.EnumerateObject()){if($map.ContainsKey($property.Name)){throw 'Duplicate JSON property.'};$map.Add($property.Name,(Read-CaJsonValue $property.Value))};return ,$map}
        'Array' {$items=[Collections.Generic.List[object]]::new();foreach($item in $Node.EnumerateArray()){$items.Add((Read-CaJsonValue $item))};return ,$items.ToArray()}
        'String' {return $Node.GetString()}
        'Number' {$integer=0L;if($Node.TryGetInt64([ref]$integer)){return $integer};$decimal=[decimal]0;if($Node.TryGetDecimal([ref]$decimal)){return $decimal};$number=$Node.GetDouble();if(![double]::IsFinite($number)){throw 'Unsupported JSON number.'};return $number}
        'True' {return $true}
        'False' {return $false}
        'Null' {return $null}
        default {throw 'Unsupported JSON value.'}
    }
}
function ConvertFrom-CaJson {
    [CmdletBinding()]
    param([Parameter(Mandatory,ValueFromPipeline)][AllowEmptyString()][string]$Json)
    process{
        if('CaGapAnalyzer.ReportCodec' -as [type]){
            try{return ,([CaGapAnalyzer.ReportCodec]::Parse($Json.TrimStart([char]0xFEFF)))}catch{throw 'Could not read unambiguous valid JSON.'}
        }
        $document=$null
        try{$options=[System.Text.Json.JsonDocumentOptions]::new();$options.MaxDepth=100;$document=[System.Text.Json.JsonDocument]::Parse($Json.TrimStart([char]0xFEFF),$options);Read-CaJsonValue $document.RootElement}
        catch{throw 'Could not read unambiguous valid JSON.'}
        finally{if($document){$document.Dispose()}}
    }
}
