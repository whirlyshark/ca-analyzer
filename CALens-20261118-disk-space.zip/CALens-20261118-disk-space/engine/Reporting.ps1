function Get-CaAssessmentChanges($Current,$Previous,$JavascriptEngine){
    if(!$Previous){return @{hasPrevious=$false;modelChanged=$false;comparisonStatus='firstRun';newFindings=0;resolvedFindings=0}}
    $common=@{hasPrevious=$true;modelChanged=$Current.modelHash -cne $Previous.modelHash;previousRunAtUtc=$Previous.runAtUtc;completenessChanged=$Current.status -cne $Previous.status}
    if($Current.sourceKey -cne $Previous.sourceKey){return $common+@{comparisonStatus='differentSource';newFindings=$null;resolvedFindings=$null;message='The saved assessments belong to different sources.'}}
    if($Current.status -cne 'completeWithinModel' -or $Previous.status -cne 'completeWithinModel' -or $Current.coverageIssues.Count -or $Previous.coverageIssues.Count){return $common+@{comparisonStatus='incompleteEvidence';newFindings=$null;resolvedFindings=$null;message='One of the compared assessments is incomplete.'}}
    if($Current.gaps.Count -eq $Previous.gaps.Count -and $Current['historyEvidence'] -and $Previous['historyEvidence'] -and [CaGapAnalyzer.ReportCodec]::SameFindingDetails($Current,$Previous)){
        return $common+@{comparisonStatus='complete';newFindings=0;resolvedFindings=0;newScopesWithGaps=0;retiredScopesWithGaps=0;addedAccountScopes=0;removedAccountScopes=0;reconfiguredRequirements=@();comparedAccountScopes=(@($Current.historyEvidence.requirements|ForEach-Object {$_.accountIds.Count})|Measure-Object -Sum).Sum;addedExamples=@();removedExamples=@();accountsWithNewGaps=0;accountsWithReducedGaps=0}
    }
    $created=$false
    if(!$JavascriptEngine){$JavascriptEngine=New-CaJavascriptEngine;$created=$true}
    try{
        foreach($pair in @(@('currentHistoryJson',$Current),@('previousHistoryJson',$Previous))){
            $inputReport=$pair[1];$evidence=@{}
            foreach($key in @('sourceKey','modelHash','runAtUtc','status','coverageIssues','historyEvidence','gaps')){$evidence[$key]=$inputReport[$key]}
            $JavascriptEngine.Script.SetProperty($pair[0],[string](ConvertTo-CaReportJson $evidence))
        }
        return $JavascriptEngine.Evaluate('JSON.stringify(HistoryModel.compare(ReportCodec.decode(JSON.parse(currentHistoryJson)),ReportCodec.decode(JSON.parse(previousHistoryJson))))')|ConvertFrom-CaJson
    }catch{return $common+@{comparisonStatus='comparisonUnavailable';newFindings=$null;resolvedFindings=$null;message='The assessment completed, but changes from the previous check could not be compared.'}}finally{if($created){$JavascriptEngine.Dispose()}}
}
function ConvertTo-CaAssessmentHtml($Result,$Prepared){
    function E($Value){[Net.WebUtility]::HtmlEncode([string]$Value)}
    function DisplayTime($Value){
        if($Value -is [DateTimeOffset]){$time=$Value}elseif($Value -is [DateTime] -and $Value.Kind -ne [DateTimeKind]::Unspecified){$time=[DateTimeOffset]$Value}else{if($Value -isnot [string] -or $Value -notmatch '^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,7})?(?:Z|[+-]\d\d:\d\d)$'){return 'not supplied or invalid'};$time=[DateTimeOffset]::MinValue;if(![DateTimeOffset]::TryParse($Value,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$time)){return 'not supplied or invalid'}}
        return $time.UtcDateTime.ToString('dd MMM yyyy HH:mm:ss "UTC"',[Globalization.CultureInfo]::InvariantCulture)
    }
    $summary=$Result.coverageSummary
    $statusText=if($Result.status -ne 'completeWithinModel'){'Check incomplete'}elseif($summary.toReview){'Gaps need review'}elseif($summary.affected){'Accepted exceptions remain'}else{'All checked accounts meet your requirements'}
    $score=if($null -eq $summary.score){'Not scored'}else{"$($summary.score)%"}
    $impactTitle=if($summary.unverifiedOnlyAffected){'Accounts flagged'}else{'Accounts affected'}
    $impactDetail=if($summary.unverifiedOnlyAffected){"$($summary.confirmedAffected) confirmed / $($summary.unverifiedOnlyAffected) to investigate"}else{"$($summary.toReview) to review"}
    if($summary.acceptedOnly){$impactDetail+=" / $($summary.acceptedOnly) with accepted exceptions"}
    $records=@{};foreach($record in $Prepared.records){$records[$record.id]=$record}
    $requirements=@{};foreach($r in $Prepared.requirements){$requirements[$r.id]=$r.name;$requirements[$r.id+':outside-network']=$r.name;$requirements[$r.id+':outside-apps']=$r.name;$requirements[$r.id+':outside-device']=$r.name}
    $rows=@(foreach($gap in @($Result.gaps|Select-Object -First 250)){
        $accounts=@($gap.identityIds|Select-Object -First 25|ForEach-Object {if($records.ContainsKey($_) -and $records[$_]['displayName']){$records[$_]['displayName']}else{$_}}) -join ', '
        if($gap.identityIds.Count -gt 25){$accounts+=' and '+($gap.identityIds.Count-25)+' others'}
        $witness=$gap.witness;$conditions=@()
        foreach($dimension in $witness.Keys){
            if($dimension -in @('accessTarget','authentication','compliant','hybridJoined')){continue}
            if($dimension -like 'groupActivation.*'){continue}
            if($dimension -eq 'userAction' -and $witness[$dimension] -eq 'none'){continue}
            if($dimension -like 'authenticationContext.*' -and $witness[$dimension] -eq 'false'){continue}
            if($dimension -eq 'application' -and $witness['accessTarget'] -eq 'userAction'){continue}
            $value=$witness[$dimension]
            if($dimension -eq 'directoryScopeEnforcement'){
                if($value -eq 'ordinary'){continue}
                $dimension='Directory scope enforcement';$value=if($value -eq 'legacyBaseline'){'Low-privilege scopes: legacy enforcement (unverified)'}else{'Low-privilege scopes: current enforcement'}
            }
            if($dimension -eq 'application' -and $Prepared.appNames.ContainsKey($value)){$value=$Prepared.appNames[$value]}
            if($dimension -eq 'network' -and $Prepared.networkNames.ContainsKey($value)){$value=$Prepared.networkNames[$value]}
            if($dimension -eq 'registrationContext' -and $Prepared.registrationContextNames -and $Prepared.registrationContextNames.ContainsKey($value)){$value=$Prepared.registrationContextNames[$value]}
            if($Prepared.externalValueNames -and $Prepared.externalValueNames.ContainsKey($dimension) -and $Prepared.externalValueNames[$dimension].ContainsKey($value)){$value=$Prepared.externalValueNames[$dimension][$value]}
            if($dimension -like 'device.*' -and $Prepared.deviceValueNames -and $Prepared.deviceValueNames.ContainsKey($dimension)){$value=$Prepared.deviceValueNames[$dimension][$value]}
            if($dimension -like 'roleActive.*' -and $Prepared.roleNames){$role=$dimension.Substring(11);if($Prepared.roleNames.ContainsKey($role)){$dimension='Role active: '+$Prepared.roleNames[$role]}}
            if($dimension -like 'groupMember.*'){$group=$dimension.Substring(12);$dimension='Group: '+$(if($Prepared.groupNames -and $Prepared.groupNames.ContainsKey($group)){$Prepared.groupNames[$group]}else{$group});$value=if($value -eq 'true'){'Member'}else{'Not a member'}}
            if($dimension -like 'resourceGroup.*'){$group=$dimension.Substring(14);$dimension='Resource group: '+$(if($Prepared.appNames.ContainsKey($group)){$Prepared.appNames[$group]}else{$group});$value=if($value -eq 'true'){'Included'}else{'Not included'}}
            if($dimension -eq 'externalUserType'){$dimension='External-user category'}elseif($dimension -eq 'externalTenantId'){$dimension='External home tenant'}
            $conditions+=((E $dimension)+': '+(E $value))
        }
        $state=if($gap.acceptance){'Accepted: '+$gap.acceptance.reason}elseif($gap.assessmentStatus -ceq 'gapWithinModel'){'Gap found'}else{'Needs investigation'}
        '<tr><td>'+(E $accounts)+'</td><td>'+(E $requirements[$gap.requirementId])+'</td><td>'+($conditions -join '<br>')+'</td><td>'+(E $state)+'</td></tr>'
    }) -join "`n"
    foreach($check in @($summary['unassessedChecks']|Where-Object {$_})){
        if(!$check.accountIds.Count){continue}
        $names=@($check.accountIds|Select-Object -First 25|ForEach-Object {if($records.ContainsKey($_) -and $records[$_]['displayName']){$records[$_]['displayName']}else{$_}}) -join ', '
        if($check.accountIds.Count -gt 25){$names+=' and '+($check.accountIds.Count-25)+' others'}
        $rows+='<tr><td>'+(E $names)+'</td><td>'+(E $requirements[$check.requirementId])+'</td><td>'+(E ($check.messages -join ' '))+'</td><td>Requirement not checked</td></tr>'
    }
    if(!$rows){$rows='<tr><td colspan="4">'+$(if($Result.status -eq 'completeWithinModel'){'No gaps found in the checked scope.'}else{'Resolve incomplete checks before confirming coverage.'})+'</td></tr>'}
    $issues=@($Result.coverageIssues|ForEach-Object {$names=@($_['accountIds']|Select-Object -First 5|ForEach-Object {if($records.ContainsKey($_) -and $records[$_]['displayName']){$records[$_]['displayName']}else{$_}});'<li>'+(E $_.message)+$(if($names.Count){' '+(E ($names -join ', '))}else{''})+'</li>'}) -join ''
    $warning=if($issues){'<section class="warning"><h2>Checks needing attention</h2><ul>'+$issues+'</ul></section>'}else{''}
    $notes=if($Result.assessmentNotes.Count){'<details><summary>Assessment notes</summary><ul>'+(@($Result.assessmentNotes|ForEach-Object {'<li>'+(E $_.message)+'</li>'}) -join '')+'</ul></details>'}else{''}
    $requirementRows=@(foreach($requirement in $summary.requirements){
        $state=if(!$requirement.affected){if($requirement.complete){'All meet requirement'}else{'Not fully checked'}}elseif($requirement.complete){"$($requirement.affected) affected"}elseif($requirement.confirmedAffected -and $requirement.unverifiedOnlyAffected){"$($requirement.confirmedAffected) affected / $($requirement.unverifiedOnlyAffected) to investigate"}elseif($requirement.confirmedAffected){"$($requirement.affected) affected / Check incomplete"}else{"$($requirement.affected) to investigate"}
        '<tr><td>'+(E $requirement.name)+'</td><td>'+(E $requirement.checked)+'</td><td>'+(E $state)+'</td></tr>'
    }) -join ''
    $accountHeading=if($summary.unassessedAccounts){'Accounts in scope'}else{'Accounts checked'}
    $requirementSection=if($requirementRows){'<section><h2>Requirements</h2><table><thead><tr><th>Requirement</th><th>'+$accountHeading+'</th><th>Result</th></tr></thead><tbody>'+$requirementRows+'</tbody></table></section>'}else{''}
    $changes=if(!$Result.changes.hasPrevious){'<p>First saved assessment for this scope.</p>'}elseif($Result.changes.comparisonStatus -notin @('complete','scopeChanged')){'<p>Coverage changes were not confirmed. '+(E $Result.changes.message)+'</p>'}else{
        $gaining=[int]$Result.changes.accountsWithNewGaps;$reducing=[int]$Result.changes.accountsWithReducedGaps
        $text='<p>Since the previous run: '+$gaining+$(if($gaining -eq 1){' account has'}else{' accounts have'})+' new gaps; '+$reducing+$(if($reducing -eq 1){' account had'}else{' accounts had'})+' some gaps closed.</p>'
        if($Result.changes.comparisonStatus -eq 'scopeChanged'){$text+='<p>Scope changed: '+$Result.changes.addedAccountScopes+' checks added, '+$Result.changes.removedAccountScopes+' removed; '+$Result.changes.reconfiguredRequirements.Count+' requirements edited. Removed checks are not counted as fixes; edited requirements need a new comparison baseline.</p>'}
        $text
    }
    return @"
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'"><title>CA coverage assessment</title>
<style>body{font:15px/1.55 system-ui,sans-serif;margin:35px auto;padding:0 24px;max-width:1200px;color:#18382f;background:#f5f8f6}h1{font-size:27px}h2{font-size:18px}.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:15px}.metrics div,section{background:white;border:1px solid #d7e3db;border-radius:9px;padding:20px}.metrics strong{display:block;font-size:32px}small,p{color:#4e655b}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;padding:12px;border-bottom:1px solid #d7e3db;vertical-align:top;overflow-wrap:anywhere}section{margin:22px 0}.warning{background:#fff5df}footer{font-size:12px}</style>
<header><small>CONDITIONAL ACCESS COVERAGE</small><h1>$(E $Prepared.sourceName)</h1><p>Snapshot: $(E (DisplayTime $Result.snapshotCapturedAtUtc)) · Checked: $(E (DisplayTime $Result.runAtUtc))</p><p><strong>$(E $statusText)</strong></p></header>
<div class="metrics"><div>Requirement coverage<strong>$(E $score)</strong><small>Accounts meeting every requirement</small></div><div>$(E $impactTitle)<strong>$($summary.affected)</strong><small>$(E $impactDetail)</small></div><div>$(E $accountHeading)<strong>$($summary.checked)</strong><small>$($summary.unchecked) outside scope</small></div></div>
$changes $warning $notes $requirementSection
<section><h2>Findings</h2><table><thead><tr><th>Accounts</th><th>Requirement</th><th>Example conditions</th><th>Review status</th></tr></thead><tbody>$rows</tbody></table><p>Up to 250 finding groups and 25 account names per group shown. The JSON report contains all findings, account IDs and complete regions.</p></section>
<footer>Offline assessment of your exported configuration and declared requirements. Accepted exceptions do not improve the coverage score. Incomplete checks are not scored. This report does not prove live authentication, prompt timing or token issuance.</footer></html>
"@
}

