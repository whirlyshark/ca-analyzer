using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace CaGapAnalyzer
{
    // Lossless result transport only. No analysis predicates or scopes change.
    public static class ReportCodec
    {
        const string Marker="_calensDetailPool";
        static readonly Type MapType=Type.GetType("System.Management.Automation.OrderedHashtable, System.Management.Automation",true);
        static IDictionary Map()=> (IDictionary)Activator.CreateInstance(MapType);
        static readonly JsonSerializerOptions Options=CreateOptions();
        static object Unwrap(object value){while(value?.GetType().FullName=="System.Management.Automation.PSObject")value=value.GetType().GetProperty("BaseObject").GetValue(value);return value;}
        sealed class WrapperConverter:JsonConverterFactory{
            public override bool CanConvert(Type t)=>t.FullName=="System.Management.Automation.PSObject";
            public override JsonConverter CreateConverter(Type t,JsonSerializerOptions o)=>(JsonConverter)Activator.CreateInstance(typeof(Wrapper<>).MakeGenericType(t));
        }
        sealed class Wrapper<T>:JsonConverter<T>{
            public override T Read(ref Utf8JsonReader reader,Type type,JsonSerializerOptions options)=>throw new NotSupportedException();
            public override void Write(Utf8JsonWriter writer,T value,JsonSerializerOptions options)=>JsonSerializer.Serialize(writer,Unwrap(value),options);
        }
        static JsonSerializerOptions CreateOptions(){var o=new JsonSerializerOptions{WriteIndented=false,MaxDepth=100};o.Converters.Add(new WrapperConverter());return o;}
        static object[] ArrayOf(object value)=>value is IEnumerable sequence && value is not string && value is not IDictionary?sequence.Cast<object>().ToArray():throw new ArgumentException("Invalid shared result array.");
        static int Index(object value,int count){long n=value is int i?i:value is long l?l:-1;return n>=0&&n<count?(int)n:throw new ArgumentException("Invalid shared result reference.");}
        static string[] Strings(object value){var array=ArrayOf(value);if(array.Any(v=>v is not string))throw new ArgumentException("Invalid shared result strings.");return array.Cast<string>().ToArray();}
        static IDictionary Copy(IDictionary source){var target=Map();foreach(DictionaryEntry entry in source)target.Add(entry.Key,entry.Value);return target;}
        sealed class Pool
        {
            public List<string[]> Strings=new(); public List<int[]> Regions=new();public List<int[]> Witnesses=new();
            readonly Dictionary<object,int> references=new(ReferenceEqualityComparer.Instance);
            readonly Dictionary<string,int> strings=new(StringComparer.Ordinal),regions=new(StringComparer.Ordinal),witnesses=new(StringComparer.Ordinal);
            public int StringId(object value){
                if(references.TryGetValue(value,out int id))return id;
                var array=value as string[]??ReportCodec.Strings(value);var key=JsonSerializer.Serialize(array,Options);
                if(!strings.TryGetValue(key,out id)){id=Strings.Count;Strings.Add(array);strings.Add(key,id);}
                references.Add(value,id);return id;
            }
            public int Region(IDictionary region){
                var names=region.Keys.Cast<string>().ToArray();var values=new int[names.Length+1];values[0]=StringId(names);
                for(int i=0;i<names.Length;i++)values[i+1]=StringId(region[names[i]]);
                var key=string.Join(",",values);if(!regions.TryGetValue(key,out int id)){id=Regions.Count;Regions.Add(values);regions.Add(key,id);}return id;
            }
            public int Witness(IDictionary witness){
                var names=witness.Keys.Cast<string>().ToArray();var values=names.Select(n=>(string)witness[n]).ToArray();var descriptor=new[]{StringId(names),StringId(values)};
                var key=string.Join(",",descriptor);if(!witnesses.TryGetValue(key,out int id)){id=Witnesses.Count;Witnesses.Add(descriptor);witnesses.Add(key,id);}return id;
            }
        }
        static IDictionary Reference(string key,int id){var map=Map();map.Add(key,id);return map;}
        public static object Pack(object value,bool force=false)
        {
            value=Unwrap(value);
            if(value is not IDictionary report||!report.Contains("gaps")||report.Contains(Marker))return value;
            var gaps=ArrayOf(report["gaps"]);if(gaps.Length==0)return value;
            if(!force&&gaps.Length<256){
                long detail=0;var widths=new Dictionary<object,long>(ReferenceEqualityComparer.Instance);
                foreach(var item in gaps){if(item is not IDictionary g||g["region"] is not IDictionary r)continue;foreach(var axis in r.Values){if(!widths.TryGetValue(axis,out var width)){width=Strings(axis).Sum(s=>(long)s.Length+3);widths.Add(axis,width);}detail+=width;}}
                if(detail<1048576)return value;
            }
            var pool=new Pool();var packed=Copy(report);var output=new object[gaps.Length];
            for(int i=0;i<gaps.Length;i++){
                if(gaps[i] is not IDictionary gap||gap["region"] is not IDictionary region||gap["witness"] is not IDictionary witness)throw new ArgumentException("Invalid finding details.");
                var copy=Copy(gap);copy["region"]=Reference("$region",pool.Region(region));copy["witness"]=Reference("$witness",pool.Witness(witness));
                foreach(var field in new[]{"identityIds","applicablePolicyIds","nonApplicablePolicyIds"})if(gap.Contains(field))copy[field]=Reference("$strings",pool.StringId(gap[field]));
                output[i]=copy;
            }
            var metadata=Map();metadata.Add("version",1);metadata.Add("strings",pool.Strings.ToArray());metadata.Add("regions",pool.Regions.ToArray());metadata.Add("witnesses",pool.Witnesses.ToArray());
            packed["gaps"]=output;packed.Add(Marker,metadata);return packed;
        }
        public static void Write(object value,Stream stream,bool force=false,bool summary=false){
            value=Unwrap(value);
            using var writer=new Utf8JsonWriter(stream,new JsonWriterOptions{MaxDepth=100,SkipValidation=false});
            if(value is not IDictionary report||!report.Contains("gaps")){JsonSerializer.Serialize(writer,value,Options);return;}
            var records=(report["gaps"] is PagedFindingRecords paged?(summary?paged.OverviewRecords():paged.ReadOnlyRecords()):report["gaps"] as IEnumerable)??throw new ArgumentException("Missing findings.");
            int count=report["gaps"] is ICollection collection?collection.Count:records.Cast<object>().Count();
            if(!summary && ((report["gaps"] is PagedFindingRecords&&count>=256)||count>4096)){
                writer.WriteStartObject();foreach(DictionaryEntry e in report)if((string)e.Key!="gaps"){writer.WritePropertyName((string)e.Key);JsonSerializer.Serialize(writer,e.Value,Options);}
                writer.WritePropertyName("_calensFindingPages");writer.WriteStartObject();writer.WriteNumber("version",1);writer.WriteNumber("count",count);writer.WritePropertyName("pages");writer.WriteStartArray();
                if(report["gaps"] is PagedFindingRecords stored){foreach(var page in stored.PackedPages())writer.WriteRawValue(page);}else{
                var batch=new List<object>(512);foreach(var record in records){batch.Add(record);if(batch.Count==512){JsonSerializer.Serialize(writer,Pack(new Hashtable{{"gaps",batch.ToArray()}},true),Options);batch.Clear();writer.Flush();}}
                if(batch.Count>0)JsonSerializer.Serialize(writer,Pack(new Hashtable{{"gaps",batch.ToArray()}},true),Options);
                }
                writer.WriteEndArray();writer.WriteEndObject();writer.WriteEndObject();writer.Flush();return;
            }
            if(summary){
                writer.WriteStartObject();foreach(DictionaryEntry e in report){writer.WritePropertyName((string)e.Key);if((string)e.Key!="gaps"){JsonSerializer.Serialize(writer,e.Value,Options);continue;}
                    writer.WriteStartArray();foreach(IDictionary record in records){writer.WriteStartObject();foreach(var key in new[]{"requirementId","identityIds","acceptance","assessmentStatus"})if(record.Contains(key)){writer.WritePropertyName(key);JsonSerializer.Serialize(writer,record[key],Options);}writer.WriteEndObject();}writer.WriteEndArray();
                }writer.WriteEndObject();return;
            }
            JsonSerializer.Serialize(writer,Pack(value,force),Options);
        }
        public static string Serialize(object value,bool force=false){using var stream=new MemoryStream();Write(value,stream,force);return Encoding.UTF8.GetString(stream.GetBuffer(),0,checked((int)stream.Length));}
        public static string SerializeRun(object value){
            var run=(IDictionary)Unwrap(value);using var stream=new MemoryStream();stream.Write(Encoding.UTF8.GetBytes("{\"snapshotPath\":"));JsonSerializer.Serialize(stream,run["snapshotPath"],Options);stream.Write(Encoding.UTF8.GetBytes(",\"assessment\":"));Write(run["assessment"],stream);stream.WriteByte((byte)'}');return Encoding.UTF8.GetString(stream.GetBuffer(),0,checked((int)stream.Length));
        }
        public static string SerializeSummary(object value){
            var report=(IDictionary)Unwrap(value);var view=Copy(report);
            var groups=new Dictionary<(string,bool,string,bool),HashSet<string>>();
            var records=report["gaps"] is PagedFindingRecords p?p.OverviewRecords():(IEnumerable)report["gaps"];
            foreach(IDictionary g in records){var accepted=g["acceptance"]!=null && !Equals(g["acceptance"],false);var key=((string)g["requirementId"],g.Contains("assessmentStatus"),(string)g["assessmentStatus"],accepted);
                if(!groups.TryGetValue(key,out var ids)){ids=new(StringComparer.Ordinal);groups.Add(key,ids);}foreach(string id in (IEnumerable)g["identityIds"])ids.Add(id);
            }
            view["gaps"]=groups.Select(pair=>{var g=Map();g.Add("requirementId",pair.Key.Item1);g.Add("identityIds",pair.Value.ToArray());g.Add("acceptance",pair.Key.Item4?(object)true:null);if(pair.Key.Item2)g.Add("assessmentStatus",pair.Key.Item3);return g;}).ToArray();
            using var stream=new MemoryStream();Write(view,stream,false,true);return Encoding.UTF8.GetString(stream.GetBuffer(),0,checked((int)stream.Length));
        }
        public static bool SameFindingDetails(object left,object right){
            var a=(IDictionary)Unwrap(left);var b=(IDictionary)Unwrap(right);
            if(Serialize(a["historyEvidence"])!=Serialize(b["historyEvidence"]))return false;
            if(a["gaps"] is PagedFindingRecords leftPages && b["gaps"] is PagedFindingRecords rightPages){
                if(leftPages.Count!=rightPages.Count)return false;
                using var lp=leftPages.PackedPages().GetEnumerator();using var rp=rightPages.PackedPages().GetEnumerator();
                while(lp.MoveNext()){
                    if(!rp.MoveNext())return false;
                    if(lp.Current==rp.Current)continue;
                    // Only changed pages need expansion; compare the same exact evidence fields.
                    var l=(IDictionary)Parse(lp.Current);var r=(IDictionary)Parse(rp.Current);
                    l["historyEvidence"]=null;r["historyEvidence"]=null;
                    if(!SameFindingDetails(l,r))return false;
                }
                return !rp.MoveNext();
            }
            IEnumerable Rows(object r)=>r is PagedFindingRecords p?p.ReadOnlyRecords():(IEnumerable)r;
            var x=Rows(a["gaps"]).GetEnumerator();var y=Rows(b["gaps"]).GetEnumerator();
            var cache=new Dictionary<(object,object),bool>();
            bool StringsEqual(object first,object second){if(ReferenceEquals(first,second))return true;var pair=(first,second);if(cache.TryGetValue(pair,out var known))return known;known=((IEnumerable)first).Cast<string>().SequenceEqual(((IEnumerable)second).Cast<string>(),StringComparer.Ordinal);if(cache.Count>4096)cache.Clear();cache.Add(pair,known);return known;}
            try{while(x.MoveNext()){
                if(!y.MoveNext())return false;var l=(IDictionary)x.Current;var r=(IDictionary)y.Current;
                if((string)l["requirementId"]!=(string)r["requirementId"])return false;
                foreach(var field in new[]{"identityIds","applicablePolicyIds","nonApplicablePolicyIds"})if(!StringsEqual(l[field],r[field]))return false;
                var lr=(IDictionary)l["region"];var rr=(IDictionary)r["region"];if(lr.Count!=rr.Count)return false;foreach(DictionaryEntry axis in lr)if(!rr.Contains(axis.Key)||!StringsEqual(axis.Value,rr[axis.Key]))return false;
                var lw=(IDictionary)l["witness"];var rw=(IDictionary)r["witness"];if(lw.Count!=rw.Count)return false;foreach(DictionaryEntry axis in lw)if(!rw.Contains(axis.Key)||(string)axis.Value!=(string)rw[axis.Key])return false;
            }return !y.MoveNext();}finally{(x as IDisposable)?.Dispose();(y as IDisposable)?.Dispose();}
        }
        public static IDictionary FindFinding(object value,string key){var report=(IDictionary)Unwrap(value);if(report["gaps"] is PagedFindingRecords pages)return pages.Find(key);return ((IEnumerable)report["gaps"]).Cast<IDictionary>().FirstOrDefault(g=>(string)g["key"]==key);}
        public static IDictionary CaptureReport(object value,string key){var report=(IDictionary)Unwrap(value);var copy=Copy(report);var gap=FindFinding(report,key);copy["gaps"]=gap==null?Array.Empty<object>():new object[]{gap};return copy;}
        public static IDictionary CandidateReport(object value,object accepted){
            var report=(IDictionary)Unwrap(value);var records=(IDictionary)Unwrap(accepted);var byRequirement=new Dictionary<string,HashSet<string>>(StringComparer.Ordinal);
            foreach(var item in records.Values){if(Unwrap(item) is not IDictionary record||record["semanticScope"] is not IDictionary scope||(string)scope["sourceKey"]!=(string)report["sourceKey"]||scope["gaps"] is not IEnumerable oldGaps||scope["identityIds"] is not IEnumerable people)continue;
                foreach(var old in oldGaps){if(old is not IDictionary gap||gap["requirementId"] is not string id)continue;if(!byRequirement.TryGetValue(id,out var ids)){ids=new(StringComparer.Ordinal);byRequirement.Add(id,ids);}foreach(var person in people)if(person is string p)ids.Add(p);}
            }
            var candidates=new List<object>();var findings=report["gaps"] is PagedFindingRecords pages?pages.ReadOnlyRecords():(IEnumerable)report["gaps"];
            foreach(IDictionary gap in findings)if(byRequirement.TryGetValue((string)gap["requirementId"],out var ids)&&((IEnumerable)gap["identityIds"]).Cast<string>().Any(ids.Contains))candidates.Add(gap);
            var copy=Copy(report);copy["gaps"]=candidates.ToArray();return copy;
        }
        public static IDictionary IndexRequirements(object source){
            if(source is PagedFindingRecords indexed && indexed.RequirementIndex() is IDictionary ready)return ready;
            var records=source is PagedFindingRecords pages?pages.ReadOnlyRecords():(IEnumerable)source;
            var people=new Dictionary<string,HashSet<string>>(StringComparer.Ordinal);var registration=new HashSet<string>(StringComparer.Ordinal);
            foreach(IDictionary record in records){
                var id=(string)record["requirementId"];var baseId=id;foreach(var suffix in new[]{":outside-network",":outside-apps",":outside-device"})if(id.EndsWith(suffix,StringComparison.Ordinal))baseId=id.Substring(0,id.Length-suffix.Length);
                var keys=id==baseId?new[]{id}:new[]{id,baseId};bool action=false;
                if(record["region"] is IDictionary region&&region.Contains("accessTarget"))action=((IEnumerable)region["accessTarget"]).Cast<object>().Any(v=>(string)v=="userAction");
                foreach(var key in keys){if(!people.TryGetValue(key,out var ids)){ids=new(StringComparer.Ordinal);people.Add(key,ids);}foreach(string person in (IEnumerable)record["identityIds"])ids.Add(person);if(action)registration.Add(key);}
            }
            var result=Map();foreach(var entry in people){var item=Map();item.Add("ids",entry.Value.OrderBy(s=>s,StringComparer.Ordinal).ToArray());item.Add("hasRegistration",registration.Contains(entry.Key));result.Add(entry.Key,item);}return result;
        }
        public static void FinalizePlainBatch(IList records,int start,int end,FindingFingerprints fingerprints){
            for(int i=start;i<end;i++){
                var gap=(IDictionary)records[i];gap["key"]=fingerprints.Hash(gap);gap["acceptance"]=null;
                gap["assessmentStatus"]="gapWithinModel";gap["coverageIssueIndices"]=Array.Empty<int>();
            }
        }
        // Exact unions answer existence questions only; no scenario correlations are discarded from findings.
        public static IDictionary IndexDiagnosticAxes(object source){
            var result=Map();var rows=source is PagedFindingRecords p?p.ReadOnlyRecords():(IEnumerable)source;
            var seen=new HashSet<(string,string,object)>();
            foreach(IDictionary gap in rows){
                string id=(string)gap["requirementId"];foreach(var suffix in new[]{":outside-network",":outside-apps",":outside-device"})if(id.EndsWith(suffix,StringComparison.Ordinal)){id=id.Substring(0,id.Length-suffix.Length);break;}
                if(!result.Contains(id))result[id]=new Dictionary<string,HashSet<string>>(StringComparer.Ordinal);
                var axes=(Dictionary<string,HashSet<string>>)result[id];var region=(IDictionary)gap["region"];
                foreach(var axis in new[]{"application","network","directoryScopeEnforcement"}){
                    if(!region.Contains(axis))continue;
                    if(!axes.TryGetValue(axis,out var values)){values=new(StringComparer.Ordinal);axes.Add(axis,values);}
                    if(seen.Count>4096)seen.Clear();
                    if(seen.Add((id,axis,region[axis])))foreach(string value in (IEnumerable)region[axis])values.Add(value);
                }
            }
            return result;
        }
        public static string[] RequirementIds(object source){
            var records=source is PagedFindingRecords pages?pages.ReadOnlyRecords():(IEnumerable)source;
            var ids=new HashSet<string>(StringComparer.Ordinal);foreach(IDictionary record in records){var id=(string)record["requirementId"];ids.Add(id);foreach(var suffix in new[]{":outside-network",":outside-apps",":outside-device"})if(id.EndsWith(suffix,StringComparison.Ordinal))ids.Add(id.Substring(0,id.Length-suffix.Length));}return ids.ToArray();
        }
        public static void SaveReviewIndex(IDictionary report,string path){
            var target=path+".review";var staging=target+"-"+Guid.NewGuid().ToString("N");Directory.CreateDirectory(staging);
            PagedFindingRecords temporary=null;
            try{
                var pages=report["gaps"] as PagedFindingRecords;
                if(pages==null){temporary=pages=new PagedFindingRecords();foreach(var row in (IEnumerable)report["gaps"])pages.Add(row);}
                pages.Persist(staging);var header=Copy(report);header.Remove("gaps");
                var hashes=new Hashtable();foreach(var entry in Directory.GetFiles(staging,"*.gz")){using var input=File.OpenRead(entry);hashes[Path.GetFileName(entry)]=Convert.ToHexString(SHA256.HashData(input));}
                var file=new FileInfo(path);var envelope=new Hashtable{{"hashes",hashes},{"version",2},{"length",file.Length},{"written",file.LastWriteTimeUtc.Ticks},{"count",pages.Count},{"header",header}};
                WriteFile(envelope,Path.Combine(staging,"index.json"));File.WriteAllText(Path.Combine(staging,"index.sha256"),Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(staging,"index.json")))));
                if(Directory.Exists(target))Directory.Delete(target,true);Directory.Move(staging,target);
            }finally{temporary?.Dispose();if(Directory.Exists(staging))Directory.Delete(staging,true);}
        }
        public static object ReadReviewFile(string path){
            var target=path+".review";var index=Path.Combine(target,"index.json");
            if(File.Exists(index))try{
                if(File.ReadAllText(Path.Combine(target,"index.sha256"))!=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(index))))throw new IOException("Invalid index checksum");
                var meta=(IDictionary)ReadFile(index);var file=new FileInfo(path);
                if(Convert.ToInt32(meta["version"])==2&&Convert.ToInt64(meta["length"])==file.Length&&Convert.ToInt64(meta["written"])==file.LastWriteTimeUtc.Ticks){
                    var count=Convert.ToInt32(meta["count"]);if(count<0)throw new IOException("Invalid finding count");
                    for(int i=0;i<(count+511)/512;i++)if(!File.Exists(Path.Combine(target,i.ToString("D8")+".json.gz"))||!File.Exists(Path.Combine(target,i.ToString("D8")+".json.gz.overview.gz")))throw new IOException("Missing finding page");
                    var hashes=(IDictionary)meta["hashes"];for(int i=0;i<(count+511)/512;i++)foreach(var suffix in new[]{".json.gz",".json.gz.overview.gz"}){var name=i.ToString("D8")+suffix;using var stream=File.OpenRead(Path.Combine(target,name));if((string)hashes[name]!=Convert.ToHexString(SHA256.HashData(stream)))throw new IOException("Invalid page checksum");}
                    var report=(IDictionary)meta["header"];report["gaps"]=new PagedFindingRecords(target,count);return report;
                }
            }catch{}
            var loaded=(IDictionary)ReadFile(path);try{SaveReviewIndex(loaded,path);}catch{}return loaded;
        }
        public static object ReadFile(string path)=>new FileInfo(path).Length<8*1024*1024?Parse(File.ReadAllText(path)):ReportHeaders.ReadPagedFile(path);
        public static void WriteFile(object value,string path){
            path=Path.GetFullPath(path);var temp=path+".tmp-"+Guid.NewGuid().ToString("N");
            try{using(var file=new ReservedFile(temp)){Write(value,file);file.Flush(true);}File.Move(temp,path,true);}catch{try{File.Delete(temp);}catch{}throw;}
        }
        public static void WriteEvent(object value,Stream stream){
            if(Unwrap(value) is IDictionary report&&report["gaps"] is ICollection records&&records.Count>=256){
                void Event(object e){JsonSerializer.Serialize(stream,e,Options);stream.WriteByte(10);stream.Flush();}
                var header=Copy(report);header.Remove("gaps");Event(new Hashtable{{"type","resultStart"},{"result",header},{"findingCount",records.Count}});
                var batch=new List<object>(512);int index=0;foreach(var item in report["gaps"] is PagedFindingRecords paged?paged.ReadOnlyRecords():records){batch.Add(item);if(batch.Count==512){Event(new Hashtable{{"type","resultPage"},{"index",index++},{"page",Pack(new Hashtable{{"gaps",batch.ToArray()}},true)}});batch.Clear();}}
                if(batch.Count>0)Event(new Hashtable{{"type","resultPage"},{"index",index++},{"page",Pack(new Hashtable{{"gaps",batch.ToArray()}},true)}});
                Event(new Hashtable{{"type","resultEnd"},{"findingCount",records.Count},{"pages",index}});return;
            }
            var prefix=Encoding.UTF8.GetBytes("{\"type\":\"result\",\"result\":");stream.Write(prefix);Write(value,stream);stream.Write(Encoding.UTF8.GetBytes("}\n"));stream.Flush();
        }
        public static void WriteReviewEvent(object value,Stream stream){
            var report=(IDictionary)Unwrap(value);var header=Copy(report);header.Remove("gaps");header["detailMode"]="onDemand";
            var records=report["gaps"] is PagedFindingRecords p?p.OverviewRecords():(IEnumerable)report["gaps"];
            int count=((ICollection)report["gaps"]).Count,index=0;
            void Event(object e){JsonSerializer.Serialize(stream,e,Options);stream.WriteByte(10);stream.Flush();}
            Event(new Hashtable{{"type","resultStart"},{"result",header},{"findingCount",count}});
            var rows=new List<object>();var strings=new List<string>();var ids=new Dictionary<string,int>(StringComparer.Ordinal);
            int Id(string s){if(s==null)return -1;if(!ids.TryGetValue(s,out var id)){id=strings.Count;strings.Add(s);ids.Add(s,id);}return id;}
            void Page(){Event(new Hashtable{{"type","resultPage"},{"index",index++},{"page",new Hashtable{{"_calensReviewRows",1},{"strings",strings.ToArray()},{"rows",rows.ToArray()}}}});rows.Clear();strings.Clear();ids.Clear();}
            foreach(IDictionary g in records){var w=g["witness"] as IDictionary;
                rows.Add(new object[]{g["key"],Id((string)g["requirementId"]),((IEnumerable)g["identityIds"]).Cast<string>().Select(Id).ToArray(),g.Contains("assessmentStatus")?Id((string)g["assessmentStatus"]):-2,g["coverageIssueIndices"],g["acceptance"],Id((string)w?["authentication"]),Id((string)w?["compliant"]),Id((string)w?["hybridJoined"]),((IEnumerable)(g["applicablePolicyIds"]??Array.Empty<string>())).Cast<string>().Select(Id).ToArray()});
                if(rows.Count==512)Page();
            }
            if(rows.Count>0)Page();Event(new Hashtable{{"type","resultEnd"},{"findingCount",count},{"pages",index}});
        }
        public static object Expand(object value)
        {
            value=Unwrap(value);
            if(value is not IDictionary report||!report.Contains(Marker))return value;
            if(report[Marker] is not IDictionary metadata||Index(metadata["version"],2)!=1||!report.Contains("gaps"))throw new ArgumentException("Unsupported shared result format.");
            var strings=ArrayOf(metadata["strings"]).Select(Strings).ToArray();
            var regions=ArrayOf(metadata["regions"]);var witnesses=ArrayOf(metadata["witnesses"]);var gaps=ArrayOf(report["gaps"]);
            if(strings.Length>2000000||regions.Length>2000000||witnesses.Length>2000000||gaps.Length>1000000)throw new ArgumentException("Shared result limit exceeded.");
            var regionCache=new IDictionary[regions.Length];var witnessCache=new IDictionary[witnesses.Length];long cells=0;
            IDictionary Details(object reference,string key,bool isRegion){
                if(reference is not IDictionary map||map.Count!=1||!map.Contains(key))throw new ArgumentException("Invalid shared result details.");
                var cache=isRegion?regionCache:witnessCache;var rows=isRegion?regions:witnesses;int index=Index(map[key],rows.Length);
                if(cache[index]!=null){cells+=cache[index].Count;if(cells>12000000)throw new ArgumentException("Shared result expansion limit exceeded.");return Copy(cache[index]);}
                var row=ArrayOf(rows[index]);if(row.Length<1)throw new ArgumentException("Invalid shared result row.");var names=strings[Index(row[0],strings.Length)];
                if((isRegion?row.Length!=names.Length+1:row.Length!=2)||names.Distinct(StringComparer.Ordinal).Count()!=names.Length)throw new ArgumentException("Invalid shared result axes.");
                cells+=names.Length;if(cells>12000000)throw new ArgumentException("Shared result expansion limit exceeded.");
                var target=Map();var values=isRegion?null:strings[Index(row[1],strings.Length)];if(values!=null&&values.Length!=names.Length)throw new ArgumentException("Invalid shared witness.");
                for(int n=0;n<names.Length;n++)target.Add(names[n],isRegion?(object)strings[Index(row[n+1],strings.Length)]:values[n]);
                cache[index]=target;return Copy(target);
            }
            foreach(var item in gaps){
                if(item is not IDictionary gap)throw new ArgumentException("Invalid shared finding.");
                gap["region"]=Details(gap["region"],"$region",true);gap["witness"]=Details(gap["witness"],"$witness",false);
                foreach(var field in new[]{"identityIds","applicablePolicyIds","nonApplicablePolicyIds"})if(gap.Contains(field)){
                    if(gap[field] is not IDictionary r||r.Count!=1||!r.Contains("$strings"))throw new ArgumentException("Invalid shared account or policy list.");gap[field]=strings[Index(r["$strings"],strings.Length)];
                }
            }
            report.Remove(Marker);return report;
        }
        public sealed class FindingFingerprints {
            readonly byte[] prefix;
            readonly Dictionary<string,string> text=new(StringComparer.Ordinal);
            readonly Dictionary<object,string> sequences=new(ReferenceEqualityComparer.Instance);
            public FindingFingerprints(string prefix){this.prefix=Encoding.UTF8.GetBytes(prefix);}
            string Quote(string value){
                if(text.TryGetValue(value,out var known))return known;
                var b=new StringBuilder("\"");foreach(char c in value){switch(c){
                    case '"':b.Append("\\\"");break;case '\\':b.Append("\\\\");break;
                    case '\b':b.Append("\\b");break;case '\f':b.Append("\\f");break;case '\n':b.Append("\\n");break;case '\r':b.Append("\\r");break;case '\t':b.Append("\\t");break;
                    default:if(c<32||c=='\u0085'||c=='\u2028'||c=='\u2029')b.Append("\\u").Append(((int)c).ToString("x4"));else b.Append(c);break;
                }}b.Append('"');known=b.ToString();text.Add(value,known);return known;
            }
            string Json(object value){
                value=Unwrap(value);if(value==null)return "null";if(value is string s)return Quote(s);
                if(value is IDictionary map)return "{"+string.Join(",",map.Keys.Cast<string>().Select(k=>Quote(k)+":"+Json(map[k])))+"}";
                if(value is IEnumerable list){if(sequences.TryGetValue(value,out var known))return known;known="["+string.Join(",",list.Cast<object>().Select(Json))+"]";if(sequences.Count>=4096)sequences.Clear();sequences.Add(value,known);return known;}
                return JsonSerializer.Serialize(value,Options);
            }
            public string JsonGap(IDictionary gap)=>Json(gap);
            public string Hash(IDictionary gap){using var hash=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);hash.AppendData(prefix);hash.AppendData(Encoding.UTF8.GetBytes(Json(gap)));return Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();}
        }
        public static object Parse(string json)=>Parse(json,null);
        internal static object Parse(string json,PagedFindingRecords streamed)
        {
            var intern=new Dictionary<string,string>(StringComparer.Ordinal);
            string Text(string s){if(intern.TryGetValue(s,out var known))return known;intern.Add(s,s);return s;}
            object Read(JsonElement node){
                switch(node.ValueKind){
                    case JsonValueKind.Object:var map=Map();foreach(var property in node.EnumerateObject()){var key=Text(property.Name);if(map.Contains(key))throw new ArgumentException("Duplicate JSON property.");map.Add(key,Read(property.Value));}return map;
                    case JsonValueKind.Array:return node.EnumerateArray().Select(Read).ToArray();
                    case JsonValueKind.String:return Text(node.GetString());
                    case JsonValueKind.Number:if(node.TryGetInt64(out long n))return n;if(node.TryGetDecimal(out decimal d))return d;var number=node.GetDouble();if(!double.IsFinite(number))throw new ArgumentException("Invalid JSON number.");return number;
                    case JsonValueKind.True:return true;case JsonValueKind.False:return false;case JsonValueKind.Null:return null;
                    default:throw new ArgumentException("Invalid JSON value.");
                }
            }
            using var document=JsonDocument.Parse(json,new JsonDocumentOptions{MaxDepth=100});
            if(document.RootElement.ValueKind==JsonValueKind.Object&&document.RootElement.TryGetProperty("_calensFindingPages",out var pageInfo)){
                if(pageInfo.EnumerateObject().Select(p=>p.Name).Distinct(StringComparer.Ordinal).Count()!=pageInfo.EnumerateObject().Count()||pageInfo.GetProperty("version").GetInt32()!=1)throw new ArgumentException("Unsupported finding pages.");
                var root=Map();var rootKeys=new HashSet<string>(StringComparer.Ordinal);foreach(var property in document.RootElement.EnumerateObject()){if(!rootKeys.Add(property.Name))throw new ArgumentException("Duplicate report property.");if(property.Name!="_calensFindingPages")root.Add(property.Name,Read(property.Value));}
                if(root.Contains("gaps"))throw new ArgumentException("Conflicting finding storage.");
                var records=streamed??new PagedFindingRecords();try{
                    foreach(var page in pageInfo.GetProperty("pages").EnumerateArray()){
                        var expanded=(IDictionary)Expand(Read(page));foreach(IDictionary record in (IEnumerable)expanded["gaps"])records.Add(record);
                    }
                    if(records.Count!=pageInfo.GetProperty("count").GetInt32())throw new ArgumentException("Incomplete finding pages.");root.Add("gaps",records);return root;
                }catch{records.Dispose();throw;}
            }
            return Expand(Read(document.RootElement));
        }
    }
}
