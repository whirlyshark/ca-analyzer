'use strict';
// Accepted exceptions describe a requirement violation, not a frozen policy file.
// Only complete evidence can be carried across changed model encodings.
const AcceptanceModel={
 version:1,
 history(){return typeof module!=='undefined'&&module.exports?require('./history-model.js'):HistoryModel;},
 ids(ids){if(!Array.isArray(ids)||!ids.length||ids.some(x=>typeof x!=='string'||!x)||new Set(ids).size!==ids.length)throw Error('Invalid exception accounts.');return [...ids].sort();},
 capture(result,gap){
  const H=this.history(),e=result.historyEvidence;
  if(result.status!=='completeWithinModel'||result.coverageIssues?.length||!result.sourceKey||!e||e.version!==H.version||e.semantics!==H.semantics)return null;
  const requirement=e.requirements.find(r=>r.id===gap.requirementId);if(!requirement)return null;
  const identityIds=this.ids(gap.identityIds),accounts=new Set(requirement.accountIds);if(identityIds.some(id=>!accounts.has(id)))return null;
  return {version:this.version,identityIds,sourceKey:result.sourceKey,status:'completeWithinModel',coverageIssues:[],historyEvidence:{...e,requirements:[{id:requirement.id,definition:requirement.definition,accountIds:['accepted-scope']}]},gaps:[{requirementId:gap.requirementId,identityIds:['accepted-scope'],region:gap.region}]};
 },
 resolve(result,records,{timeoutMs=Infinity,maxRegions=Infinity,maxComparisons=Infinity,maxDomains=Infinity}={}){
  const start=Date.now(),H=this.history(),matches=new Map(),groups=new Map();let comparisons=0,candidates=0;
  const answer=(status,message)=>({version:this.version,status,comparisons,candidates,milliseconds:Date.now()-start,matches:status==='complete'?[...matches].map(([key,keys])=>({key,recordKeys:[...keys].sort()})):[],...(message?{message}:{})});
  if(result.status!=='completeWithinModel'||result.coverageIssues?.length||!result.sourceKey||!result.historyEvidence)return answer('notEligible');
  const entries=Object.entries(records||{}).filter(([,record])=>record?.semanticScope?.sourceKey===result.sourceKey);
  if(!entries.length)return answer('complete');
  const check=()=>{if(Date.now()-start>=timeoutMs||comparisons>=maxComparisons)throw Error('Exception comparison exceeded its budget.');};
  try{
   for(const gap of result.gaps||[]){check();const scope=this.capture(result,gap);if(!scope)throw Error('Current exception evidence is unavailable.');const key=H.key([gap.requirementId,scope.identityIds]);const group=groups.get(key)||{current:[],old:[]};group.current.push({gap,scope});groups.set(key,group);}
   for(const [recordKey,record] of entries){
    check();const before=record?.semanticScope;
    if(!before||before.version!==this.version||before.sourceKey!==result.sourceKey||before.status!=='completeWithinModel'||before.coverageIssues?.length||before.gaps?.length!==1||before.historyEvidence?.requirements?.length!==1)continue;
    if(typeof record.reason!=='string'||record.reason.trim().length<3||record.reason.length>1000)continue;
    const oldGap=before.gaps[0],key=H.key([oldGap.requirementId,this.ids(before.identityIds)]),group=groups.get(key);if(!group)continue;candidates++;
    if(before.historyEvidence.requirements[0].id!==oldGap.requirementId||H.key(before.historyEvidence.requirements[0].definition)!==H.key(group.current[0].scope.historyEvidence.requirements[0].definition))continue;
    if(before.historyEvidence.semantics!==H.semantics||before.historyEvidence.version!==H.version)continue;
    group.old.push({recordKey,scope:before});
   }
   for(const group of groups.values()){
    if(!group.old.length)continue;check();
    const sides=[group.current[0].scope.historyEvidence,...group.old.map(x=>x.scope.historyEvidence)];
    if(sides.length>maxDomains)throw Error('Exception comparison exceeded its domain budget.');
    const {regions,lift}=H.prepareDomains(sides,{maxRegions,deadline:start+timeoutMs});
    const old=group.old.map((item,i)=>({...item,pieces:lift(item.scope.gaps[0].region,i+1)})),fresh=group.current.map(item=>({...item,pieces:lift(item.gap.region,0)}));
    const nodes=[...old,...fresh],edges=nodes.map(()=>[]);
    for(let i=0;i<old.length;i++)for(let j=0;j<fresh.length;j++){
     check();comparisons++;
     if(old[i].pieces.some(a=>fresh[j].pieces.some(b=>regions.intersect(a,b)))){edges[i].push(old.length+j);edges[old.length+j].push(i);}
    }
    const seen=new Set(),difference=(a,b)=>{let pieces=a;for(const cut of b){check();pieces=regions.minus(pieces,cut);}return pieces;};
    for(let root=0;root<nodes.length;root++){
     if(seen.has(root)||!edges[root].length)continue;
     const component=[],pending=[root];seen.add(root);
     while(pending.length){check();const i=pending.pop();component.push(i);for(const j of edges[i])if(!seen.has(j)){seen.add(j);pending.push(j);}}
     const oldNodes=component.filter(i=>i<old.length).map(i=>old[i]),newNodes=component.filter(i=>i>=old.length).map(i=>fresh[i-old.length]);
     const left=oldNodes.flatMap(x=>x.pieces),right=newNodes.flatMap(x=>x.pieces);
     // Connected unions handle both split and merged findings, including
     // exceptions captured under different physical-domain refinements.
     if(difference(left,right).length||difference(right,left).length)continue;
     const keys=oldNodes.map(x=>x.recordKey);
     for(const item of newNodes){const accepted=matches.get(item.gap.key)||new Set();keys.forEach(k=>accepted.add(k));matches.set(item.gap.key,accepted);}
    }
   }
   return answer('complete');
  }catch(error){return answer(/budget|bounded/.test(error.message)?'bounded':'unavailable',error.message);}
 }
};
if(typeof module!=='undefined')module.exports=AcceptanceModel;
