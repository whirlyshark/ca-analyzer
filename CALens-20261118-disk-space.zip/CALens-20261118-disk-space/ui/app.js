'use strict';
const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {authentication:'Authentication', application:'Application', network:'Network', client:'Client', compliant:'Compliant device', platform:'Platform', risk:'Risk', flow:'Authentication flow', password:'Single-factor authentication', mfa:'MFA', phishingResistant:'Phishing-resistant MFA', browser:'Browser', desktop:'Desktop client', trusted:'Trusted network', untrusted:'Untrusted network', true:'Yes', false:'No'};
Object.assign(labels, {office:'Office network', vpn:'Corporate VPN', internet:'Public internet', azure:'Azure management', finance:'Finance app', hr:'HR app', crm:'CRM app', 'vpn-app':'VPN app', 'new-app':'New app', teams:'Teams', hybridJoined:'Hybrid joined', signInRisk:'Sign-in risk', userRisk:'User risk', sharepoint:'SharePoint', exchange:'Exchange Online'});
const label = v => labels[v] || v;
let labPack=null, activeLab=false, selectedFault=null;
let token, model, result, editorRules, sourceName='Exclusion & authentication gaps', isExample=true, filter='open', selectedKey=null, busy=false, pendingKey;
async function api(path, body) {
  const response = await fetch(path, body === undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':token},body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'The request failed.');
  return data;
}
function error(e) { $('#error').textContent=e.message || String(e); $('#error').hidden=false; window.scrollTo({top:0,behavior:'smooth'}); }
function clearError() { $('#error').hidden=true; }
function toast(message) {$('#toast').textContent=message;$('#toast').hidden=false;setTimeout(()=>$('#toast').hidden=true,3500);}
function view(name) {
  if(busy)return;
  document.querySelectorAll('.view').forEach(el=>el.hidden=el.id!==name);
  document.querySelectorAll('.nav').forEach(el=>el.classList.toggle('active',el.dataset.view===name));
  $('#breadcrumb').textContent={assessment:'Assessment',requirements:'Requirements',about:'Coverage & help',tags:'Account tags'}[name];
  if(name==='requirements') renderEditor();
  if(name==='tags')renderTags();
  window.scrollTo({top:0,behavior:'smooth'});
}
function counts() {
  $('#source-name').textContent=sourceName;
  $('#source-badge').textContent=isExample?'DEMO':'LOCAL MODEL';
  $('#mode-badge').textContent=isExample?'DEMO':'LOCAL MODEL';
  $('#scope-message').textContent=isExample?'Fictional accounts and policies. Nothing is connected to your tenant.':'Local model only. Live tenant import is not available yet.';
  $('#source-description').textContent=activeLab?`${model.identities.length.toLocaleString()} fictional accounts · Members and Guests · explicit policy groups`:isExample?'Member A · Member B · Member (PIM eligible)':'Imported from your computer. This is a normalized model, not a verified tenant snapshot.';
  $('#empty-start h3').textContent=`${model.identities.length.toLocaleString()} accounts. Are they all protected?`;
  $('#model-counts').innerHTML=`<span><strong>${model.identities.length}</strong> accounts</span><span><strong>${model.policies.length}</strong> policies</span>`;
  $('#rule-summary').innerHTML=model.requirements.length?model.requirements.map(r=>`<div class="rule-item"><span class="rule-icon">◎</span><div><strong>${esc(requirementName(r))}</strong><small>${r.scope==='privileged'?'Privileged & PIM-eligible accounts':'All selected accounts'}${Object.keys(r.conditions||{}).length?' · Selected conditions':''}</small></div></div>`).join(''):'<p>No requirements defined. Add a requirement before assessing.</p>';
}
function resetResult() {result=null;selectedKey=null;filter='open';$('#search').value='';document.querySelectorAll('[data-filter]').forEach(el=>el.classList.toggle('selected',el.dataset.filter==='open'));$('#result-content').hidden=true;$('#empty-start').hidden=false;$('#download').disabled=true;$('#run-meta').textContent='Check whether these accounts meet your requirements.';}
function validateShape(data) {
  if(data.schemaVersion!==1 || !data.dimensions || !Array.isArray(data.identities) || !Array.isArray(data.policies) || !Array.isArray(data.requirements) || !Array.isArray(data.dimensions.authentication)) throw new Error('This file is not a supported analyzer model. Use the example as a template. Raw Graph policy exports are not supported yet.');
}
async function example() {if(busy)return;activeLab=false;selectedFault=null;$('#scenario').value='small';$('#lab-catalog').hidden=true;$('#lab-size-label').hidden=true;$('#lab-change').hidden=true;clearError();model=await api('/api/example');sourceName='Exclusion & authentication gaps';isExample=true;counts();resetResult();}
async function run() {
  if(busy)return;
  clearError();
  if(!model.requirements.length){error(new Error('Define at least one requirement before running.'));return;}
  busy=true;$('#scenario').disabled=true;$('#lab-size').disabled=true;$('#run').disabled=true;$('#run-empty').disabled=true;$('#run').textContent='Evaluating policies…';
  try {let comparison=null;if(activeLab){const before=scaledBaseline();before.requirements=structuredClone(model.requirements);const baseResult=await api('/api/analyze',{model:before});comparison={baselineGapRegions:baseResult.gaps.length,baselineStatus:baseResult.status,baselineAnalysisMilliseconds:baseResult.analysisMilliseconds};}result=await api('/api/analyze',{model});if(comparison)result.comparison=comparison;selectedKey=null;$('#empty-start').hidden=true;$('#result-content').hidden=false;$('#download').disabled=false;renderResults();$('#results').scrollIntoView({behavior:'smooth',block:'start'});}
  catch(e){error(e);}
  finally{busy=false;$('#scenario').disabled=false;$('#lab-size').disabled=false;$('#run').disabled=false;$('#run-empty').disabled=false;$('#run').innerHTML='Check again <span>→</span>';}
}
function renderEditor(rules=model.requirements) {
  editorRules=structuredClone(rules);
  $('#rules-editor').innerHTML=editorRules.map((r,i)=>`<div class="rule-editor" data-index="${i}"><div class="rule-fields"><label>Requirement name<input type="text" class="rule-name" value="${esc(r.id)}" required></label><label>Account scope<select class="rule-scope"><option value="all" ${r.scope!=='privileged'?'selected':''}>All selected accounts</option><option value="privileged" ${r.scope==='privileged'?'selected':''}>Privileged + PIM</option></select></label></div><div class="detail-label">Acceptable authentication</div><div class="auth-options">${model.dimensions.authentication.map(a=>`<label><input type="checkbox" value="${esc(a)}" ${(r.allowedAuthentication||[]).includes(a)?'checked':''}>${esc(label(a))}</label>`).join('')}</div>${(Object.keys(r.conditions||{}).length||(r.includeUsers&&!r.includeUsers.includes('*'))||r.excludeUsers?.length)?'<p class="hint">Existing account selections, exclusions, and conditions are preserved.</p>':''}<button class="remove-rule" data-remove="${i}">Remove requirement</button></div>`).join('');
  document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>b.closest('.rule-editor').remove());
}
function readEditor(allowEmpty=false) {
  const rules=[...document.querySelectorAll('.rule-editor')].map(el=>{
    const original=editorRules[Number(el.dataset.index)]||{};
    const id=el.querySelector('.rule-name').value.trim();
    const auth=[...el.querySelectorAll('input[type=checkbox]:checked')].map(e=>e.value);
    if(!id||!auth.length)throw new Error('Every requirement needs a name and at least one acceptable authentication state.');
    return {...original,id,scope:el.querySelector('.rule-scope').value,allowedAuthentication:auth};
  });
  if(!rules.length&&!allowEmpty)throw new Error('Add at least one authentication requirement.');
  if(new Set(rules.map(r=>r.id)).size!==rules.length)throw new Error('Requirement names must be unique.');
  return rules;
}
function download(value,name) {const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>view(b.dataset.view));
$('#edit-rules').onclick=()=>view('requirements');$('#format-help').onclick=()=>view('about');
$('#run').onclick=run;$('#run-empty').onclick=run;
$('#example').onclick=()=>example().catch(error);
$('#upload').onclick=()=>$('#file').click();
$('#file').onchange=async e=>{const file=e.target.files[0];if(!file||busy)return;try{clearError();const data=JSON.parse(await file.text());validateShape(data);if(busy)return;activeLab=false;selectedFault=null;$('#scenario').value='small';$('#lab-catalog').hidden=true;$('#lab-change').hidden=true;$('#lab-size-label').hidden=true;model=data;sourceName=file.name;isExample=false;counts();resetResult();toast('Model loaded. Review requirements, then run an assessment.');}catch(e){error(e);}finally{$('#file').value='';}};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(el=>el.classList.toggle('selected',el===b));renderResults();});
$('#search').oninput=()=>{if(result)renderResults();};
$('#download').onclick=()=>download({...result,sourceName},'ca-gap-assessment.json');
$('#sample-download').onclick=async()=>{try{download(await api('/api/example'),'ca-gap-example.json');}catch(e){error(e);}};
$('#cancel-accept').onclick=()=>$('#accept-dialog').close();
$('#accept-form').onsubmit=async e=>{e.preventDefault();const button=e.submitter;button.disabled=true;try{const response=await api('/api/accept',{key:pendingKey,reason:$('#reason').value});const gap=result.gaps.find(g=>g.key===pendingKey);gap.acceptance=response.acceptance;$('#accept-dialog').close();renderResults();toast('Finding accepted. Your reason is saved locally.');}catch(e){$('#accept-dialog').close();error(e);}finally{button.disabled=false;}};
$('#save-rules').onclick=()=>{try{clearError();model.requirements=readEditor();counts();resetResult();view('assessment');toast('Requirements applied. Run an assessment to see the impact.');}catch(e){error(e);}};
$('#download-model').onclick=()=>{try{download({...model,requirements:readEditor()},'ca-gap-model.json');}catch(e){error(e);}};
$('#add-rule').onclick=()=>{
  try{const rules=readEditor(true);let n=rules.length+1;while(rules.some(r=>r.id===`requirement-${n}`))n++;renderEditor([...rules,{id:`requirement-${n}`,scope:'all',allowedAuthentication:model.dimensions.authentication.filter(a=>a!=='password')}]);}catch(e){error(e);}
};
(async()=>{try{token=(await api('/api/session')).token;await initLab();await initTags();}catch(e){error(e);$('#run').disabled=true;}})();
