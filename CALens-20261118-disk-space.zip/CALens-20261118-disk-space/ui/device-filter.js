'use strict';
// Device filter rules are parsed as data. No eval, Function constructor or
// executable input is used. String predicates are partitioned by an exact DFA
// product, including overlaps; literal sampling cannot establish coverage.
const DeviceFilter={
 properties:{deviceId:'id',displayName:'string',deviceOwnership:'ownership',enrollmentProfileName:'string',isCompliant:'boolean',manufacturer:'string',mdmAppId:'id',model:'string',operatingSystem:'string',operatingSystemVersion:'string',physicalIds:'collection',profileType:'profile',systemLabels:'collection',trustType:'trust'},
 requirementRule(filter){
  if(!filter||!['when','must'].includes(filter.mode)||!['all','any'].includes(filter.match)||!Array.isArray(filter.clauses)||!filter.clauses.length)throw Error('Choose device conditions and whether all or any must match.');
  for(const key of Object.keys(filter))if(!['mode','match','clauses'].includes(key))throw Error('Unsupported device requirement setting: '+key);
  const rules=filter.clauses.map(c=>{
   for(const key of Object.keys(c))if(!['property','operator','value'].includes(key))throw Error('Unsupported device condition setting: '+key);
   if(!(Object.hasOwn(this.properties,c.property)||/^extensionAttribute(?:[1-9]|1[0-5])$/.test(c.property))||!['eq','ne','startswith','notstartswith','endswith','notendswith','contains','notcontains'].includes(c.operator)||typeof c.value!=='string'||!c.value.trim())throw Error('Choose a device attribute, comparison and value.');
   return '(device.'+c.property+' -'+c.operator+' '+JSON.stringify(c.value)+')';
  });
  const rule=rules.join(filter.match==='all'?' -and ':' -or ');this.parse(rule);return rule;
 },
 parse(text){
  if(typeof text!=='string'||!text.trim()||text.length>3072)throw Error('Device filter must contain 1–3072 characters.');
  const tokens=[];let position=0;
  while(position<text.length){
   if(/\s/.test(text[position])){position++;continue;}
   const ch=text[position];if('()[],'.includes(ch)){tokens.push({type:ch,value:ch});position++;continue;}
   if(ch==='"'||ch==="'"){
    const quote=ch;let value='',closed=false;position++;
    while(position<text.length){let c=text[position++];if(c===quote){closed=true;break;}if(c==='\\'){if(position>=text.length)throw Error('Unterminated filter escape.');c=text[position++];const escapes={'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','\\':'\\','"':'"',"'":"'"};if(c==='u'){const hex=text.slice(position,position+4);if(!/^[a-f0-9]{4}$/i.test(hex))throw Error('Invalid Unicode escape.');value+=String.fromCharCode(parseInt(hex,16));position+=4;}else if(Object.hasOwn(escapes,c))value+=escapes[c];else throw Error('Unsupported filter escape.');}else value+=c;}
    if(!closed)throw Error('Unterminated device filter string.');tokens.push({type:'value',value,quoted:true});continue;
   }
   const word=/^(?:device\.[a-z][a-z0-9]*|-[a-z]+|true\b|false\b|null\b)/i.exec(text.slice(position));
   if(!word)throw Error('Unsupported device filter syntax at character '+position+'.');position+=word[0].length;
   const value=word[0];tokens.push({type:value.startsWith('-')?'operator':value.toLowerCase().startsWith('device.')?'property':'value',value});
  }
  let index=0;const peek=()=>tokens[index],take=type=>{const token=tokens[index++];if(!token||token.type!==type)throw Error('Expected '+type+' in device filter.');return token.value;};
  const literal=()=>{const token=peek(),value=take('value');if(!token.quoted&&String(value).toLowerCase()==='null')throw Error('Null literals in device filters require separate semantics validation. Use a documented negative operator to include unregistered devices.');return String(value).toLowerCase();};
  const unary=()=>{
   if(peek()?.value.toLowerCase()==='-not'){index++;return {kind:'not',child:unary()};}
   if(peek()?.type==='('){index++;const node=or();take(')');return node;}
   const raw=take('property').slice(7),property=Object.keys(this.properties).find(p=>p.toLowerCase()===raw.toLowerCase())||(/^extensionattribute(?:[1-9]|1[0-5])$/i.test(raw)?'extensionAttribute'+raw.match(/\d+$/)[0]:null);
   if(!property)throw Error('Unsupported device property: '+raw);
   const kind=this.properties[property]||'string',operator=take('operator').slice(1).toLowerCase();
   const allowed=kind==='collection'?['contains','notcontains']:['boolean','ownership','profile','trust'].includes(kind)?['eq','ne']:kind==='id'?['eq','ne','in','notin']:['eq','ne','startswith','notstartswith','endswith','notendswith','contains','notcontains','in','notin'];
   if(!allowed.includes(operator))throw Error('Unsupported operator '+operator+' for '+property+'.');
   let values=[];
   if(['in','notin'].includes(operator)){take('[');if(peek()?.type!==']'){values.push(literal());while(peek()?.type===','){index++;values.push(literal());}}take(']');if(!values.length)throw Error('A device filter list cannot be empty.');}else values=[literal()];
   if(kind==='boolean'&&values.some(v=>!['true','false'].includes(v)))throw Error('Compliance filters require True or False.');
   if(kind==='id'&&values.some(v=>!this.guid(v)))throw Error('Device and MDM IDs must be GUIDs.');
   const negative=operator==='ne'||operator.startsWith('not'),positive=operator==='ne'?'eq':operator.startsWith('not')?operator.slice(3):operator;
   const nodes=values.map(value=>({kind:'atom',property,operator:positive==='in'?'eq':positive,value}));
   const node=nodes.reduce((a,b)=>({kind:'or',left:a,right:b}));return negative?{kind:'not',child:node}:node;
  };
  const and=()=>{let node=unary();while(peek()?.value.toLowerCase()==='-and'){index++;node={kind:'and',left:node,right:unary()};}return node;};
  const or=()=>{let node=and();while(peek()?.value.toLowerCase()==='-or'){index++;node={kind:'or',left:node,right:and()};}return node;};
  const ast=or();if(index!==tokens.length)throw Error('Unexpected device filter tokens.');return ast;
 },
 guid(value){return /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value);},
 atomKey(atom){return JSON.stringify([atom.property,atom.operator,atom.value]);},
 matches(value,atom){if(value===null)return false;const s=String(value).toLowerCase();return atom.operator==='eq'?s===atom.value:atom.operator==='startswith'?s.startsWith(atom.value):atom.operator==='endswith'?s.endsWith(atom.value):s.includes(atom.value);},
 stringCells(atoms,{maxStates=Infinity,deadline=Infinity}={}){
  const alphabet=[...new Set(atoms.flatMap(a=>a.value.split('')))];let other='~';while(alphabet.includes(other))other=String.fromCharCode(other.charCodeAt(0)+1);alphabet.push(other);
  const start=atoms.map(()=>0),key=state=>state.join(','),queue=[{state:start,witness:''}],seen=new Set([key(start)]),signatures=new Map();
  const advance=(k,c,atom)=>{
   const p=atom.value;if(atom.operator==='eq')return k<0||k>=p.length||p[k]!==c?-1:k+1;
   if(atom.operator==='startswith')return k<0?-1:k===p.length?k:p[k]===c?k+1:-1;
   if(atom.operator==='contains'&&k===p.length)return k;
   const tail=p.slice(0,k)+c;for(let n=Math.min(p.length,tail.length);n>=0;n--)if(tail.endsWith(p.slice(0,n)))return n;
  };
  for(let i=0;i<queue.length;i++){
   if(i%128===0&&Date.now()>deadline)throw Error('Device string predicate partition exceeded its time budget.');
   const {state,witness}=queue[i];queue[i]=null;const truth=state.map((n,j)=>n===atoms[j].value.length),signature=truth.map(Boolean).map(Number).join('');
   if(!signatures.has(signature))signatures.set(signature,{value:witness,truth});
   for(const c of alphabet){const next=state.map((n,j)=>advance(n,c,atoms[j])),id=key(next);if(!seen.has(id)){if(seen.size>=maxStates)throw Error('Device string predicate partition exceeded its state budget.');seen.add(id);queue.push({state:next,witness:witness+c});}}
  }
  return [...signatures.values()];
 },
 prepare(rules,options={}){
  options={deadline:Infinity,...options};
  const parsed=new Map(),errors=new Map(),atomsByProperty=new Map();
  const add=atom=>{const list=atomsByProperty.get(atom.property)||[];if(!list.some(a=>this.atomKey(a)===this.atomKey(atom)))list.push(atom);atomsByProperty.set(atom.property,list);};
  const visit=node=>{if(node.kind==='atom')add(node);else if(node.kind==='not')visit(node.child);else{visit(node.left);visit(node.right);}};
  for(const {id,mode,rule} of rules){try{if(!['include','exclude'].includes(mode))throw Error('Device filter mode must be include or exclude.');const ast=this.parse(rule);visit(ast);parsed.set(id,{ast,mode});}catch(e){errors.set(id,e.message);}}
  if(!parsed.size)return {dimensions:{},scenarioConstraints:[],parsed,errors,properties:new Map(),atomSelectors:new Map(),valueNames:{}};
  const extensionProperties=[...atomsByProperty.keys()].filter(p=>p.startsWith('extensionAttribute'));
  const intuneId='0000000a-0000-0000-c000-000000000000';
  if(extensionProperties.length)add({kind:'atom',property:'mdmAppId',operator:'eq',value:intuneId});
  const dimensions={'device.registered':['false','true']},properties=new Map(),atomSelectors=new Map(),valueNames={},nullConditions={'device.registered':{include:['false']},compliant:{include:['false']},hybridJoined:{include:['false']}},scenarioConstraints=[];
  for(const [property,atoms] of atomsByProperty){
   const type=this.properties[property]||'string',axis='device.'+property;
   if(type==='collection'){
    const axes=[];atoms.forEach((atom,i)=>{const a=axis+'.has.'+i;dimensions[a]=['false','true'];valueNames[a]={false:'Does not contain '+atom.value,true:'Contains '+atom.value};atomSelectors.set(this.atomKey(atom),{[a]:{include:['true']}});nullConditions[a]={include:['false']};axes.push(a);});properties.set(property,{axes,type,atoms});continue;
   }
   let cells;
   if(['boolean','ownership','profile','trust','id'].includes(type)){
    const values=type==='boolean'?['false','true']:type==='ownership'?['personal','company']:type==='profile'?['registereddevice','securevm','printer','shared','iot']:type==='trust'?['azuread','serverad','workplace']:[...new Set(atoms.map(a=>a.value))];
    if(type==='id'){let n=0,other;do{other='ffffffff-ffff-4fff-8fff-'+(n++).toString(16).padStart(12,'0');}while(values.includes(other));values.push(other);}
    cells=values.map(value=>({value,truth:atoms.map(a=>this.matches(value,a))}));
   }else cells=this.stringCells(atoms,options);
   cells.push({value:null,truth:atoms.map(()=>false)});cells.forEach((cell,i)=>cell.id='v'+i);dimensions[axis]=cells.map(c=>c.id);valueNames[axis]=Object.fromEntries(cells.map(c=>[c.id,c.value===null?'No device attribute':c.value||'(empty string)']));
   atoms.forEach((atom,i)=>atomSelectors.set(this.atomKey(atom),{[axis]:{include:cells.filter(c=>c.truth[i]).map(c=>c.id)}}));
   // The documented null branch and an observed ROPC false compliance claim
   // are both feasible without a registered device. Do not collapse them.
   const nullId=cells.at(-1).id;nullConditions[axis]={include:cells.filter(c=>c.value===null||(property==='isCompliant'&&c.value==='false')).map(c=>c.id)};properties.set(property,{axis,type,atoms,cells,nullId});
   if(property==='isCompliant'||property==='trustType'){
    const claim=property==='isCompliant'?'compliant':'hybridJoined',positive=property==='isCompliant'?'true':'serverad';
    scenarioConstraints.push([{[axis]:{include:cells.filter(c=>c.value===positive).map(c=>c.id)},[claim]:{include:['true']}},{[axis]:{include:cells.filter(c=>c.value!==positive).map(c=>c.id)},[claim]:{include:['false']}}]);
   }
  }
  const registeredConditions={'device.registered':{include:['true']}};
  if(properties.has('deviceId')){const property=properties.get('deviceId');registeredConditions[property.axis]={include:property.cells.filter(c=>c.value!==null).map(c=>c.id)};}
  scenarioConstraints.unshift([nullConditions,registeredConditions]);
  if(extensionProperties.length){
   const mdm=properties.get('mdmAppId'),intuneCells=mdm.cells.filter(c=>c.value===intuneId).map(c=>c.id),empty=Object.fromEntries(extensionProperties.map(p=>{const x=properties.get(p);return [x.axis,{include:[x.nullId]}];}));
   scenarioConstraints.push([{[mdm.axis]:{include:intuneCells}},{compliant:{include:['true']}},{hybridJoined:{include:['true']}},empty]);
  }
  return {dimensions,scenarioConstraints,parsed,errors,properties,atomSelectors,valueNames};
 },
 compile(prepared,id,{maxRegions=Infinity}={}){
  if(prepared.errors.has(id))throw Error(prepared.errors.get(id));const entry=prepared.parsed.get(id);if(!entry)throw Error('Device filter was not prepared.');
  const domains=prepared.dimensions,axes=Object.keys(domains),limit=regions=>{if(regions.length>maxRegions)throw Error('Device filter exceeded its region budget.');return regions;};
  const values=(region,axis)=>region[axis]?.include||domains[axis],compact=sets=>Object.fromEntries(Object.entries(sets).filter(([axis,list])=>list.length!==domains[axis].length).map(([axis,list])=>[axis,{include:list}]));
  const intersect=(a,b)=>{const sets={};for(const axis of axes){const right=new Set(values(b,axis)),overlap=values(a,axis).filter(v=>right.has(v));if(!overlap.length)return null;sets[axis]=overlap;}return compact(sets);};
  const subtract=(a,b)=>{const overlap=intersect(a,b);if(!overlap)return [a];const remainder=Object.fromEntries(axes.map(axis=>[axis,[...values(a,axis)]])),out=[];for(const axis of axes){const inside=new Set(values(overlap,axis)),outside=remainder[axis].filter(v=>!inside.has(v));if(outside.length)out.push(compact({...remainder,[axis]:outside}));remainder[axis]=[...inside];}return out;};
  const minus=(regions,cut)=>{const out=[];for(const region of regions){out.push(...subtract(region,cut));limit(out);}return out;};
  const run=node=>{
   if(node.kind==='atom'){const selector=prepared.atomSelectors.get(this.atomKey(node));return Object.values(selector).some(s=>!s.include.length)?[]:[selector];}
   if(node.kind==='not'){let pieces=[{}];for(const cut of run(node.child))pieces=minus(pieces,cut);return pieces;}
   const left=run(node.left),right=run(node.right);
   if(node.kind==='and'){const out=[];for(const a of left)for(const b of right){const overlap=intersect(a,b);if(overlap)out.push(overlap);limit(out);}return out;}
   let pieces=right;for(const cut of left)pieces=minus(pieces,cut);return limit([...left,...pieces]);
  };
  return run(entry.mode==='exclude'?{kind:'not',child:entry.ast}:entry.ast);
 },
 classify(prepared,device,{registered=!!device?.deviceId,unregisteredCompliance='null'}={}){
  if(!['null','false'].includes(unregisteredCompliance))throw Error('Choose a documented null or observed false unregistered compliance claim.');
  const data=registered?{...device,deviceOwnership:device.deviceOwnership??device.ownership}:{};
  if(!registered&&unregisteredCompliance==='false')data.isCompliant=false;
  const compliant=registered&&data.isCompliant===true,hybrid=registered&&String(data.trustType||'').toLowerCase()==='serverad';
  if(![true,false].includes(registered))throw Error('Specify whether a registered device identity is present.');
  if(!(String(data.mdmAppId||'').toLowerCase()==='0000000a-0000-0000-c000-000000000000'||compliant||hybrid))for(const key of Object.keys(data))if(/^extensionAttribute\d+$/.test(key))data[key]=null;
  const point={'device.registered':String(registered),compliant:String(compliant),hybridJoined:String(hybrid)};
  for(const [property,info] of prepared.properties){
   let value=data[property]??null;if(typeof value==='boolean')value=String(value);
   if(info.type==='collection'){const members=new Set(Array.isArray(value)?value.map(v=>String(v).toLowerCase()):[]);info.atoms.forEach((a,i)=>point[info.axes[i]]=String(members.has(a.value)));}
   else {const truth=info.atoms.map(a=>this.matches(value,a)),cell=value===null?info.cells.find(c=>c.value===null):info.cells.find(c=>c.value!==null&&c.truth.every((v,i)=>v===truth[i]));if(!cell)throw Error('Device attribute is outside the modeled domain: '+property);point[info.axis]=cell.id;}
  }
  return point;
 }
};
if(typeof module!=='undefined')module.exports=DeviceFilter;
