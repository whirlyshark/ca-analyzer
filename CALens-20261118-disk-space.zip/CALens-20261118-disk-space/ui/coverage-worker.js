'use strict';
importScripts('/requirement-model.js','/location-model.js','/device-filter.js','/external-users.js','/role-schedules.js','/pim-groups.js','/resource-groups.js','/session-controls.js','/authentication-strengths.js','/snapshot.js','/requirement-review.js');
self.onmessage=({data})=>{
 try{
  if(data.action==='mapping'){try{importScripts('/policy-mapping.js');self.postMessage({mapping:PolicyMapping.build(data.model,data.id,{origins:data.origins})});}catch(error){self.postMessage({error:error.message});}return;}
  self.postMessage({type:'progress',stage:'prepare',message:'Preparing accounts and policy conditions'});
  const source={...SnapshotModel.normalize(data.input),key:data.key,name:data.name,kind:data.kind,isDemo:data.isDemo};
  if(data.action==='review'){self.postMessage({type:'reviewed',result:RequirementReview.check(data.profile,source)});return;}
  self.postMessage({type:'progress',stage:'prepare',message:'Matching your account sets and requirements'});
  const compiled=RequirementModel.compile(data.profile,source);
  self.postMessage({type:'compiled',compiled});
 }catch(error){self.postMessage({type:'error',message:error.message||String(error)});}
};
