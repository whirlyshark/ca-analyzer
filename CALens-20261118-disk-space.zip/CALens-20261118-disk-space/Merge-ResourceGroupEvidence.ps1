#Requires -Version 7.4
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SnapshotPath,[Parameter(Mandatory)][string]$EvidencePath,[Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'engine/Javascript.ps1')
$destination=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
foreach($inputPath in @($SnapshotPath,$EvidencePath)){
 $resolved=(Resolve-Path -LiteralPath $inputPath).ProviderPath
 if($destination -eq $resolved){throw 'Output must not overwrite a snapshot or evidence input.'}
}
if(Test-Path -LiteralPath $destination){throw 'Choose a new output file. Existing files are never overwritten.'}
$js=New-CaJavascriptEngine
try{
 $js.Script.SetProperty('snapshotJson',[IO.File]::ReadAllText((Resolve-Path -LiteralPath $SnapshotPath).ProviderPath).TrimStart([char]0xFEFF))
 $js.Script.SetProperty('evidenceJson',[IO.File]::ReadAllText((Resolve-Path -LiteralPath $EvidencePath).ProviderPath).TrimStart([char]0xFEFF))
 $json=$js.Evaluate('JSON.stringify(ResourceGroups.merge(JSON.parse(snapshotJson),JSON.parse(evidenceJson)),null,2)')
 $null=New-Item -ItemType Directory -Path (Split-Path $destination) -Force
 $stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$bytes=[Text.Encoding]::UTF8.GetBytes($json+"`n");$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 Write-Host 'Resource-group evidence merged into a new snapshot. Analysis can now run offline.'
}finally{$js.Dispose()}
