#Requires -Version 7.4
[CmdletBinding()]
param(
    [string]$ModelPath=(Join-Path $PSScriptRoot 'examples/exclusion-gap.json'),
    [string]$OutputPath,
    [int]$MaxRegions=100000,
    [int]$TimeoutSeconds=0
)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'CA.GapAnalyzer.psd1') -Force
$result=Invoke-CaGapAnalysis -ModelPath $ModelPath -OutputPath $OutputPath -MaxRegions $MaxRegions -TimeoutSeconds $TimeoutSeconds
[CaGapAnalyzer.ReportCodec]::Serialize($result)
if ($result.status -ne 'completeWithinModel') { exit 2 }
if ($result.gaps.Count -gt 0) { exit 1 }
