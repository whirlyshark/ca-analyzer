. (Join-Path $PSScriptRoot 'ReaderAuthentication.ps1')
. (Join-Path $PSScriptRoot 'TenantSnapshot.ps1')
. (Join-Path $PSScriptRoot '../engine/JsonData.ps1')
function Invoke-CaFreshAssessment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][guid]$TenantId,
        [Parameter(Mandatory)][guid]$ClientId,
        [Parameter(Mandatory)][Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,
        [Parameter(Mandatory)][string]$RequirementsPath,
        [string]$SnapshotDirectory=(Join-Path $PSScriptRoot '../data/snapshots'),
        [string]$StateDirectory=(Join-Path $PSScriptRoot '../data/assessments'),
        [string]$AcceptancePath=(Join-Path $PSScriptRoot '../data/acceptances.local.json'),
        [string]$AssessmentName='default',
        [switch]$IncludePimGroups,
        [switch]$IncludeApplicationAttributes
    )
    $ErrorActionPreference='Stop'
    $requirements=Get-Item -LiteralPath $RequirementsPath
    $profile=Get-Content -LiteralPath $requirements.FullName -Raw|ConvertFrom-CaJson
    if($profile.version -ne 1 -or $profile.sets -isnot [array] -or $profile.requirements -isnot [array] -or !$profile.requirements.Count){throw 'Export an accounts and requirements configuration from the UI first.'}
    # An explicitly supplied reader is required; never select an existing app or
    # recovery credential implicitly. Prevent accidental use of this lab's known
    # recovery application when its local metadata is present.
    $recoveryPath=Join-Path $PSScriptRoot '../recovery/recovery.local.json'
    if(Test-Path -LiteralPath $recoveryPath){$recovery=Get-Content -LiteralPath $recoveryPath -Raw|ConvertFrom-CaJson;if($recovery.clientId -and [guid]$recovery.clientId -eq $ClientId){throw 'The recovery application cannot be used for scheduled collection. Configure a separate read-only reader.'}}
    $null=New-Item -ItemType Directory -Path $StateDirectory -Force
    $lock=$null
    try{
        try{$lock=[IO.File]::Open((Join-Path $StateDirectory ('collection-'+$TenantId.ToString()+'.lock')),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{throw 'Another fresh collection for this tenant is running. Retry after it finishes.'}
        $started=[DateTime]::UtcNow.ToString('o')
        $request=New-CaCertificateGraphRequest -TenantId $TenantId -ClientId $ClientId -Certificate $Certificate
        $snapshot=Get-CaTenantSnapshot -TenantId $TenantId.ToString() -Request $request -IncludePimGroups:$IncludePimGroups -IncludeApplicationAttributes:$IncludeApplicationAttributes
        $snapshot.collection=@{mode='certificateReader';clientId=$ClientId.ToString();startedAtUtc=$started;completedAtUtc=[DateTime]::UtcNow.ToString('o')}
        $tenantFolder=Join-Path $SnapshotDirectory $TenantId.ToString();$null=New-Item -ItemType Directory -Path $tenantFolder -Force
        $snapshotPath=Join-Path $tenantFolder ([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)+'.local.json')
        $temporary=$snapshotPath+'.tmp'
        try{$snapshot|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $temporary -Encoding utf8;Move-Item -LiteralPath $temporary -Destination $snapshotPath -ErrorAction Stop}
        finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
        $result=Invoke-CaTenantAssessment -SnapshotPath $snapshotPath -RequirementsPath $requirements.FullName -StateDirectory $StateDirectory -AcceptancePath $AcceptancePath -AssessmentName $AssessmentName
        @{snapshotPath=$snapshotPath;assessment=$result}
    }finally{if($lock){$lock.Dispose()};$request=$null}
}
