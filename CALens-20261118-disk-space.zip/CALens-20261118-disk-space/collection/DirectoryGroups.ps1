# Read-only, tenant-pinned routes use these helpers. Credentials never enter results.
function Read-CaGroupData {
    param([string]$Path,[string]$BearerToken,[scriptblock]$Request,[switch]$AllPages)
    $next='https://graph.microsoft.com/v1.0/'+$Path;$expected=([uri]$next).AbsolutePath
    $rows=[Collections.Generic.List[object]]::new();$seen=[Collections.Generic.HashSet[string]]::new()
    while($next){
        $uri=[uri]$next
        if($uri.Scheme -ne 'https' -or $uri.Host -ne 'graph.microsoft.com' -or $uri.Port -ne 443 -or $uri.UserInfo -or $uri.Fragment -or $uri.AbsolutePath -ne $expected -or !$seen.Add($next)){throw 'Unexpected group pagination. No group was added.'}
        try{
            $page=if($Request){& $Request $next}else{(Invoke-WebRequest -Uri $next -Method Get -Headers @{Authorization="Bearer $BearerToken";ConsistencyLevel='eventual'} -MaximumRedirection 0 -TimeoutSec 60 -ErrorAction Stop).Content|ConvertFrom-Json -AsHashtable -Depth 100}
        }catch{throw 'Could not read groups. Check that the connection is current and has directory read permission. Reconnect to this tenant if needed.'}
        if($page -isnot [Collections.IDictionary]){throw 'Unexpected group response. No group was added.'}
        if(!$page.Contains('value')){return $page}
        if($page.value -isnot [array]){throw 'Unexpected group list. No group was added.'}
        foreach($row in $page.value){$rows.Add($row)}
        if(!$AllPages){return @{value=@($rows.ToArray());hasMore=[bool]$page['@odata.nextLink']}}
        $next=$page['@odata.nextLink']
    }
    return ,$rows.ToArray()
}
function Find-CaDirectoryGroups {
    param([string]$Query,[string]$BearerToken,[scriptblock]$Request)
    $Query=$Query.Trim()
    if($Query.Length -lt 2 -or $Query.Length -gt 120){throw 'Enter at least two characters of the group name, or a group ID.'}
    $id=[guid]::Empty
    $filter=if([guid]::TryParse($Query,[ref]$id)){"id eq '$($id.ToString())'"}else{"startswith(displayName,'"+$Query.Replace("'","''")+"')"}
    $result=Read-CaGroupData -Path ('groups?$select=id,displayName,visibility,isAssignableToRole&$top=50&$filter='+[uri]::EscapeDataString($filter)) -BearerToken $BearerToken -Request $Request
    return @{groups=@($result.value|ForEach-Object {@{id=$_.id;displayName=$_.displayName}});hasMore=$result.hasMore}
}
function Get-CaDirectoryGroupEvidence {
    param([guid]$GroupId,[string]$BearerToken,[scriptblock]$Request,[switch]$IncludePimGroups,[string[]]$KnownUserIds=@())
    $requestOptions=@{BearerToken=$BearerToken;Request=$Request}
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $people=[Collections.Generic.HashSet[string]]::new($KnownUserIds,[StringComparer]::OrdinalIgnoreCase)
    $evidence=[Collections.Generic.List[object]]::new()
    $pending=[Collections.Generic.Queue[string]]::new()
    function Read-GroupEvidence([string]$Id){
        if(!$seen.Add($Id)){return}
        $group=Read-CaGroupData -Path ('groups/'+$Id+'?$select=id,displayName,visibility,isAssignableToRole') @requestOptions
        if($group.id -ne $Id){throw 'The requested group could not be verified. No group was added.'}
        $members=Read-CaGroupData -Path ('groups/'+$Id+'/transitiveMembers/microsoft.graph.user?$select=id&$count=true') -AllPages @requestOptions
        if(@($members|Where-Object {!$_.id}).Count){throw 'The group membership read was incomplete. No group was added.'}
        $item=@{group=$group;members=@($members|ForEach-Object {$_.id});includePimGroups=[bool]$IncludePimGroups}
        $evidence.Add($item)
        if($IncludePimGroups){
            $filter=[uri]::EscapeDataString("groupId eq '$Id'")
            $item.eligibility=Read-CaGroupData -Path ('identityGovernance/privilegedAccess/group/eligibilityScheduleInstances?$filter='+$filter) -AllPages @requestOptions
            $item.assignments=Read-CaGroupData -Path ('identityGovernance/privilegedAccess/group/assignmentScheduleInstances?$filter='+$filter) -AllPages @requestOptions
            $direct=Read-CaGroupData -Path ('groups/'+$Id+'/members?$select=id') -AllPages @requestOptions
            $item.directMembers=@($direct|ForEach-Object {$_.id})
            $dependencies=@(@($direct|Where-Object {$_.'@odata.type' -ne '#microsoft.graph.servicePrincipal'}|ForEach-Object {$_.id})+@($item.eligibility|ForEach-Object {$_.principalId})+@($item.assignments|ForEach-Object {$_.principalId})|Where-Object {$_ -and !$people.Contains($_)}|Sort-Object -Unique)
            foreach($dependency in $dependencies){
                if(![guid]::TryParse($dependency,[ref]([guid]::Empty))){throw 'A related membership could not be resolved. No group was added.'}
                if(!$seen.Contains($dependency)){$pending.Enqueue($dependency)}
            }
        }
    }
    $pending.Enqueue($GroupId.ToString())
    while($pending.Count){Read-GroupEvidence $pending.Dequeue()}
    $result=$evidence[0];$result.relatedGroups=@($evidence.ToArray()|Select-Object -Skip 1)
    return $result
}
