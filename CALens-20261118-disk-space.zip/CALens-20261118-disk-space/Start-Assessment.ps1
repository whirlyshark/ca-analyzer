#Requires -Version 7.4
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SnapshotPath,[Parameter(Mandatory)][string]$RequirementsPath,[string]$OutputPath,[string]$StateDirectory=(Join-Path $PSScriptRoot 'data/assessments'),[string]$AcceptancePath=(Join-Path $PSScriptRoot 'data/acceptances.local.json'),[string]$AssessmentName='default',[switch]$NoHistory)
$ErrorActionPreference='Stop';$result=$null
try{
    Import-Module (Join-Path $PSScriptRoot 'CA.GapAnalyzer.psd1') -Force
    $result=Invoke-CaTenantAssessment @PSBoundParameters
    [CaGapAnalyzer.ReportCodec]::Serialize($result)
    if($result.status -ne 'completeWithinModel'){exit 2}
    if($result.coverageSummary.toReview -gt 0){exit 1}
    exit 0
}catch{Write-Error $_ -ErrorAction Continue;exit 3}

finally{if($result -and $result.gaps -is [IDisposable]){$result.gaps.Dispose()}}
