#Requires -Version 7.4
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId,[string]$RedirectUri='http://localhost:8765/oauth/callback')
$ErrorActionPreference='Stop'
$account=az account show -o json | ConvertFrom-Json
if($LASTEXITCODE -ne 0 -or $account.tenantId -ne $TenantId.ToString()){throw 'Sign Azure CLI into the intended tenant first.'}
$credential=az account get-access-token --resource https://graph.microsoft.com --tenant $TenantId.ToString() -o json | ConvertFrom-Json
if($LASTEXITCODE -ne 0 -or !$credential.accessToken){throw 'Could not obtain a Graph token.'}
$headers=@{Authorization="Bearer $($credential.accessToken)"}
function Graph([string]$Method,[string]$Path,$Body=$null){
    $request=@{Method=$Method;Uri=('https://graph.microsoft.com/v1.0/'+$Path);Headers=$headers}
    if($null -ne $Body){$request.Body=$Body|ConvertTo-Json -Depth 20;$request.ContentType='application/json'}
    Invoke-RestMethod @request
}
try{
    $name='CA Gap Analyzer Reader'
    $permissionNames=@('Policy.Read.All','Directory.Read.All','RoleManagement.Read.Directory')
    $graphApps=(Graph GET 'servicePrincipals?$filter=appId%20eq%20%2700000003-0000-0000-c000-000000000000%27').value
    if(@($graphApps).Count -ne 1){throw 'Cannot uniquely resolve Microsoft Graph.'}
    $graphSp=$graphApps[0]
    $permissions=@(foreach($permission in $permissionNames){
        $scope=@($graphSp.oauth2PermissionScopes|Where-Object {$_.value -eq $permission -and $_.isEnabled})
        if($scope.Count -ne 1){throw "Cannot resolve delegated scope $permission"}
        @{id=$scope[0].id;type='Scope'}
    })
    $found=@((Graph GET 'applications?$filter=displayName%20eq%20%27CA%20Gap%20Analyzer%20Reader%27').value)
    $statePath=Join-Path $PSScriptRoot 'reader-app.local.json'
    if($found.Count){
        if($found.Count -ne 1 -or !(Test-Path -LiteralPath $statePath)){throw 'An app with this name exists without an unambiguous local provisioning record. Inspect before reuse.'}
        $saved=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json
        if($saved.applicationObjectId -ne $found[0].id){throw 'Existing app differs from local record.'}
        $app=$found[0]
    }else{
        $app=Graph POST applications @{
            displayName=$name;signInAudience='AzureADMyOrg'
            publicClient=@{redirectUris=@($RedirectUri)}
            requiredResourceAccess=@(@{resourceAppId=$graphSp.appId;resourceAccess=$permissions})
        }
        @{tenantId=$TenantId.ToString();clientId=$app.appId;applicationObjectId=$app.id;redirectUri=$RedirectUri;permissions=$permissionNames;consentVerified=$false}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $statePath
    }
    $sp=@((Graph GET ("servicePrincipals?`$filter=appId%20eq%20%27$($app.appId)%27")).value)
    if(!$sp.Count){$sp=@(Graph POST servicePrincipals @{appId=$app.appId})}
    if($sp.Count -ne 1){throw 'Cannot uniquely resolve reader service principal.'}
    $grants=@((Graph GET ("oauth2PermissionGrants?`$filter=clientId%20eq%20%27$($sp[0].id)%27")).value|Where-Object {$_.resourceId -eq $graphSp.id -and $_.consentType -eq 'AllPrincipals'})
    if(!$grants.Count){
        $null=Graph POST oauth2PermissionGrants @{clientId=$sp[0].id;resourceId=$graphSp.id;consentType='AllPrincipals';scope=($permissionNames -join ' ')}
    }elseif($grants.Count -ne 1 -or @($permissionNames|Where-Object {$_ -notin ($grants[0].scope -split ' ')}).Count){throw 'Existing consent differs from the expected read-only grant. Inspect before changing.'}
    $verified=Graph GET ("applications/$($app.id)?`$select=id,appId,signInAudience,publicClient,requiredResourceAccess,passwordCredentials,keyCredentials")
    if($verified.signInAudience -ne 'AzureADMyOrg' -or $RedirectUri -notin $verified.publicClient.redirectUris -or $verified.passwordCredentials.Count -or $verified.keyCredentials.Count){throw 'Reader app verification failed.'}
    $requested=@($verified.requiredResourceAccess.resourceAccess)
    if($requested.Count -ne 3 -or @($requested|Where-Object {$_.type -ne 'Scope' -or $_.id -notin $permissions.id}).Count){throw 'Reader app permissions verification failed.'}
    $confirmed=@((Graph GET ("oauth2PermissionGrants?`$filter=clientId%20eq%20%27$($sp[0].id)%27")).value|Where-Object {$_.resourceId -eq $graphSp.id -and $_.consentType -eq 'AllPrincipals'})
    if($confirmed.Count -ne 1 -or @($confirmed[0].scope -split ' '|Where-Object {$_ -notin $permissionNames}).Count -or @($permissionNames|Where-Object {$_ -notin ($confirmed[0].scope -split ' ')}).Count){throw 'Delegated consent verification failed.'}
    $appRoles=(Graph GET ("servicePrincipals/$($sp[0].id)/appRoleAssignments")).value
    if(@($appRoles).Count){throw 'Reader has unexpected application permission assignments.'}
    $result=[ordered]@{tenantId=$TenantId.ToString();clientId=$app.appId;applicationObjectId=$app.id;servicePrincipalId=$sp[0].id;redirectUri=$RedirectUri;permissions=$permissionNames;consentVerified=$true}
    $result|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $statePath
    $result|ConvertTo-Json -Depth 10
}finally{$headers.Clear();$credential=$null}
