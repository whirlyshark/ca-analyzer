# Local UI adapter over the same assessment/history pipeline used by PowerShell.
function Get-CaInteractiveHistoryFolder([string]$SourceKey){
    if(!$SourceKey -or $SourceKey.Length -gt 1000){throw 'Choose a loaded snapshot first.'}
    $scope=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($SourceKey+'|default'))).ToLowerInvariant().Substring(0,24)
    Join-Path $PSScriptRoot "../data/assessments/$scope"
}
function Invoke-CaInteractiveAssessment($Snapshot,$Profile){
    if($Snapshot.caGapSnapshotVersion -ne 1 -or $Profile.version -ne 1){throw 'A full tenant snapshot and requirements configuration are required.'}
    $folder=Join-Path ([IO.Path]::GetTempPath()) ('ca-ui-assessment-'+[guid]::NewGuid().ToString('N'))
    $null=New-Item -ItemType Directory -Path $folder
    $snapshotPath=Join-Path $folder 'snapshot.json';$profilePath=Join-Path $folder 'requirements.json'
    try{
        ConvertTo-Json -InputObject $Snapshot -Depth 100 -Compress|Set-Content -LiteralPath $snapshotPath -Encoding utf8
        ConvertTo-Json -InputObject $Profile -Depth 100 -Compress|Set-Content -LiteralPath $profilePath -Encoding utf8
        Invoke-CaTenantAssessment -SnapshotPath $snapshotPath -RequirementsPath $profilePath
    }finally{
        foreach($path in @($snapshotPath,$profilePath)){if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}}
        Remove-Item -LiteralPath $folder -Force
    }
}
function Get-CaInteractiveHistory([string]$SourceKey,[string]$RunId){
    $folder=Get-CaInteractiveHistoryFolder $SourceKey
    if($RunId){
        if($RunId -notmatch '^\d{8}T\d{13}Z-[a-f0-9]{8}\.local\.json$'){throw 'Choose a saved check from the list.'}
        $path=Join-Path $folder $RunId
        if((Get-Item -LiteralPath $path).Length -gt 100MB){throw 'Saved check exceeds the 100 MB limit.'}
        $report=Get-Content -LiteralPath $path -Raw|ConvertFrom-CaJson
        if($report.sourceKey -cne $SourceKey){throw 'Saved check belongs to a different source.'}
        return $report
    }
    $runs=[Collections.Generic.List[object]]::new();$unreadable=0
    if(Test-Path -LiteralPath $folder){
        foreach($file in @(Get-ChildItem -LiteralPath $folder -File -Filter '*.local.json'|Where-Object Name -ne 'latest.local.json'|Sort-Object Name -Descending|Select-Object -First 20)){
            try{
                if($file.Length -gt 100MB){throw 'Saved check too large.'}
                $r=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-CaJson
                if($r.sourceKey -cne $SourceKey -or $r.assessmentVersion -ne 1 -or !$r.coverageSummary){throw 'Saved check is invalid.'}
                $runs.Add(@{id=$file.Name;runAtUtc=$r.runAtUtc;snapshotCapturedAtUtc=$r.snapshotCapturedAtUtc;status=$r.status;score=$r.coverageSummary.score;affected=$r.coverageSummary.affected;checked=$r.coverageSummary.checked})
            }catch{$unreadable++}
        }
    }
    @{runs=$runs.ToArray();unreadable=$unreadable;limit=20}
}
