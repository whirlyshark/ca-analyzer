# Shared assessment finalization for UI and unattended runs.
. (Join-Path $PSScriptRoot 'JsonData.ps1')
function Get-CaAcceptanceSummary($Record,[string]$Key){
    if($Record -isnot [Collections.IDictionary] -or $Record['reason'] -isnot [string] -or $Record['reason'].Trim().Length -lt 3 -or $Record['reason'].Length -gt 1000){return $null}
    $summary=@{};foreach($field in $Record.Keys){if($field -notin @('semanticScope','recordKey','recordKeys','matchedSemantically')){$summary[$field]=$Record[$field]}}
    $summary.recordKey=$Key;$summary.recordKeys=@($Key);$summary.exceptionCount=1;$summary.reasons=@($Record['reason']);return $summary
}
function Invoke-CaAssessmentCore {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Model,[object[]]$CoverageIssues=@(),[hashtable]$Acceptances=@{},[int]$MaxRegions=20000,[int]$TimeoutSeconds=30,[string]$SourceKey='',$AcceptanceEvidence=$null)
    if(-not ('CaGapAnalyzer.Engine' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'GapEngine.cs')}
    $modelJson=$Model|ConvertTo-Json -Depth 100 -Compress
    function Hash([string]$Text){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Text))).ToLowerInvariant()}
    $modelHash=Hash $modelJson
    $exceptionContext=if($SourceKey){ConvertTo-Json -InputObject @('tenant-exception-v1',$SourceKey,(Hash (ConvertTo-Json -InputObject $AcceptanceEvidence -Depth 100 -Compress))) -Compress}else{''}
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $result=[CaGapAnalyzer.Engine]::Analyze($modelJson,$MaxRegions,$TimeoutSeconds)|ConvertFrom-CaJson
    $result.analysisMilliseconds=$timer.ElapsedMilliseconds
    $requirementIds=@($Model.requirements|ForEach-Object {$_.id});$gapRequirementIds=@($result.gaps|ForEach-Object {$_.requirementId; $_.requirementId -replace ':(outside-network|outside-apps|outside-device)$',''})
    $contextClock=[Diagnostics.Stopwatch]::StartNew()
    function Test-CaDiagnosticDomain($Issue,[string]$Field,[string]$Axis){
        if(!$Model.dimensions.Contains($Axis)){return $false}
        $values=@($Issue[$Field]);if(!$values.Count){return $false}
        foreach($value in $values){if($value -isnot [string] -or $value -cnotin $Model.dimensions[$Axis]){return $false}}
        return $true
    }
    $knownIdentityIds=[Collections.Generic.HashSet[string]]::new([string[]]@($Model.identities|ForEach-Object id),[StringComparer]::Ordinal)
    $unassessedRequirementIds=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach($issue in $CoverageIssues){
        if(!$issue -or $issue['code'] -cne 'requirement-not-evaluated' -or $issue['requirementId'] -isnot [string] -or !$issue['requirementId'].Trim() -or $issue['requirementId'] -cin $requirementIds -or $issue['accountIds'] -isnot [array] -or $issue['message'] -isnot [string] -or !$issue['message'].Trim()){continue}
        $valid=$true;foreach($id in $issue['accountIds']){if($id -isnot [string] -or !$knownIdentityIds.Contains($id)){$valid=$false;break}}
        if($valid){$null=$unassessedRequirementIds.Add($issue['requirementId'])}
    }
    function Test-CaClassificationScope($Issue){
        if($Issue['code'] -cne 'account-classification' -or $Issue['accountIds'] -isnot [array] -or !$Issue['accountIds'].Count){return $false}
        foreach($id in $Issue['accountIds']){if($id -isnot [string] -or !$knownIdentityIds.Contains($id)){return $false}}
        return $true
    }
    $issues=[object[]]@()
    if($CoverageIssues.Count){$issues=ConvertTo-Json -InputObject @($CoverageIssues) -Depth 100|ConvertFrom-CaJson}
    if($result.unverifiedApplicationFilterPolicyIds.Count){
        # Bind this diagnostic to the engine's typed policy flags. A caller must
        # not omit it, swap in a denial-mode query, or narrow its policy/person set.
        $issues=@($issues|Where-Object {$_ -and $_['code'] -ne 'application-filter-context'})
        $bases=@($requirementIds|ForEach-Object {$base=$_ -replace ':(outside-network|outside-apps|outside-device)$','';if($base -cin $requirementIds){$base}else{$_}}|Sort-Object -Unique -CaseSensitive)
        foreach($base in $bases){
            $ids=@($result.gaps|Where-Object {($_.requirementId -replace ':(outside-network|outside-apps|outside-device)$','') -ceq $base -or $_.requirementId -ceq $base}|ForEach-Object identityIds|Sort-Object -Unique -CaseSensitive)
            $issues+=[ordered]@{requirementId=$base;code='application-filter-context';resolveWhenProtected=$true;policyContext=[ordered]@{requirementId=$base;policyIds=@($result.unverifiedApplicationFilterPolicyIds);identityIds=$ids;relaxedAxes=@();matchMode='applicable'};message='Application-filter matching is not verified. No protection is credited from those policies. Remaining possible access in this account/request scope needs filter and attribute evidence.'}
        }
    }
    if($result.unverifiedLocationPolicyIds.Count){
        # Derive location diagnostics from typed model flags, not caller-supplied
        # policy IDs or denial-mode queries that could conceal the uncertainty.
        $issues=@($issues|Where-Object {$_ -and $_['code'] -ne 'location-enforcement-context'})
        $bases=@($requirementIds|ForEach-Object {$base=$_ -replace ':(outside-network|outside-apps|outside-device)$','';if($base -cin $requirementIds){$base}else{$_}}|Sort-Object -Unique -CaseSensitive)
        foreach($base in $bases){
            $ids=@($result.gaps|Where-Object {($_.requirementId -replace ':(outside-network|outside-apps|outside-device)$','') -ceq $base -or $_.requirementId -ceq $base}|ForEach-Object identityIds|Sort-Object -Unique -CaseSensitive)
            $issues+=[ordered]@{requirementId=$base;code='location-enforcement-context';resolveWhenProtected=$true;policyContext=[ordered]@{requirementId=$base;policyIds=@($result.unverifiedLocationPolicyIds);identityIds=$ids;relaxedAxes=@();matchMode='potentiallyDenied'};message='Some policy locations cannot be evaluated. No protection is credited from those policies; remaining possible access in this account/request scope needs location evidence.'}
        }
    }
    $contextIndices=[Collections.Generic.List[int]]::new();$contextQueries=[Collections.Generic.List[object]]::new();$contextAnswers=@{}
    if($result.status -eq 'completeWithinModel'){
        for($i=0;$i -lt $issues.Count;$i++){
            $issue=$issues[$i]
            if(!$issue -or $issue['resolveWhenProtected'] -ne $true -or $issue['requirementId'] -notin $requirementIds -or $issue['requirementId'] -notin $gapRequirementIds -or $issue['policyContext'] -isnot [Collections.IDictionary] -or $issue['policyContext']['requirementId'] -cne $issue['requirementId']){continue}
            $query=$issue['policyContext'];$mode=$query['matchMode']
            $safeMode=($issue['code'] -eq 'pim-group-context' -and ($null -eq $mode -or $mode -ceq 'denied')) -or ($issue['code'] -ceq 'location-enforcement-context' -and $mode -ceq 'potentiallyDenied') -or ($issue['code'] -in @('session-enforcement-context','strength-enforcement-context','grant-enforcement-context','application-filter-context','location-enforcement-context') -and $mode -ceq 'applicable')
            if($safeMode){
                # A restriction whose entire policy set has validated location
                # bounds cannot deny a request that is proved to satisfy its
                # grants. Keep the stored diagnostic/evidence unchanged.
                if($mode -ceq 'applicable' -and $query['policyIds'] -is [array] -and $query['policyIds'].Count -and @($query['policyIds']|Where-Object {$_ -cnotin $result.unverifiedLocationPolicyIds}).Count -eq 0){
                    $bounded=[ordered]@{};foreach($key in $query.Keys){$bounded[$key]=$query[$key]};$bounded.matchMode='potentiallyDenied';$query=$bounded
                }
                $contextIndices.Add($i);$contextQueries.Add($query)
            }
        }
        if($contextQueries.Count){
            try{
                $answers=[CaGapAnalyzer.Engine]::RelevantPolicyContexts($modelJson,(ConvertTo-Json -InputObject @($result.gaps) -Depth 100 -Compress),(ConvertTo-Json -InputObject @($contextQueries.ToArray()) -Depth 100 -Compress),$MaxRegions,5000)|ConvertFrom-CaJson
                if(@($answers).Count -eq $contextIndices.Count){for($i=0;$i -lt $contextIndices.Count;$i++){if($answers[$i] -is [bool]){$contextAnswers[$contextIndices[$i]]=$answers[$i]}}}
            }catch{
                # Failed/unsupported/bounded context checks retain the original
                # unresolved diagnostic. Never infer irrelevance from failure.
            }
        }
    }
    $unresolvedIndices=[Collections.Generic.List[int]]::new()
    $result.coverageIssues=@(for($issueIndex=0;$issueIndex -lt $issues.Count;$issueIndex++){
        $issue=$issues[$issueIndex]
        if($null -eq $issue){continue}
        $resolved=$issue['resolveWhenProtected'] -eq $true -and $issue['code'] -in @('registration-resource-context','registration-strength-precedence','device-compliance-runtime','external-identity-context','pim-group-context','session-enforcement-context','strength-enforcement-context','grant-enforcement-context','application-filter-context','location-enforcement-context','graph-audience-context','role-schedule-context','ip-country-correlation') -and $result.status -eq 'completeWithinModel' -and $issue['requirementId'] -in $requirementIds -and $issue['requirementId'] -notin $gapRequirementIds
        if($contextAnswers.ContainsKey($issueIndex) -and $contextAnswers[$issueIndex] -eq $false){$resolved=$true}
        if($issue['code'] -eq 'resource-group-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application') -and $result.status -eq 'completeWithinModel'){
            $unknown=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownApplications']),[StringComparer]::Ordinal)
            $relevant=$false
            foreach($gap in $result.gaps){if(($gap.requirementId -replace ':(outside-network|outside-apps|outside-device)$','') -ne $issue['requirementId']){continue};foreach($app in $gap.region.application){if($unknown.Contains($app)){$relevant=$true;break}};if($relevant){break}}
            $resolved=!$relevant
        }
        if($issue['code'] -eq 'country-catalog-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network') -and $result.status -eq 'completeWithinModel'){
            $unknownNetworks=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['unknownNetworks']),[StringComparer]::Ordinal)
            $relevant=$false
            foreach($gap in $result.gaps){if(($gap.requirementId -replace ':(outside-network|outside-apps|outside-device)$','') -ne $issue['requirementId']){continue};foreach($network in $gap.region.network){if($unknownNetworks.Contains($network)){$relevant=$true;break}};if($relevant){break}}
            $resolved=!$relevant
        }
        if($issue['code'] -eq 'directory-baseline-context' -and $issue['resolveWhenProtected'] -eq $true -and $issue['requirementId'] -in $requirementIds -and $result.status -eq 'completeWithinModel' -and $Model.dimensions.Contains('directoryScopeEnforcement')){
            $relevant=@($result.gaps|Where-Object {($_.requirementId -replace ':(outside-network|outside-apps|outside-device)$','') -eq $issue['requirementId'] -and 'legacyBaseline' -in $_.region.directoryScopeEnforcement})
            $resolved=$relevant.Count -eq 0
        }
        if(!$resolved){$unresolvedIndices.Add($issueIndex);$issue}
    })
    # Preserve per-finding proofs without changing global completeness or the
    # existing exception fingerprint. One bounded batch shares the context budget.
    $gapContextAnswers=@{}
    $parentGapKeys=@{}
    $result.gapRefinement=[ordered]@{status='notNeeded';originalGroups=$result.gaps.Count;refinedGroups=$result.gaps.Count}
    if($result.status -eq 'completeWithinModel' -and $result.gaps.Count -and $contextClock.ElapsedMilliseconds -lt 5000){
        $remainingQueries=[Collections.Generic.List[object]]::new();$remainingIndices=[Collections.Generic.List[int]]::new()
        for($finalIndex=0;$finalIndex -lt $unresolvedIndices.Count;$finalIndex++){
            $originalIndex=$unresolvedIndices[$finalIndex]
            $queryIndex=$contextIndices.IndexOf($originalIndex)
            if($queryIndex -ge 0){$remainingQueries.Add($contextQueries[$queryIndex]);$remainingIndices.Add($finalIndex)}
        }
        $cuts=[Collections.Generic.List[object]]::new()
        $people=@($Model.identities|ForEach-Object id)
        foreach($issue in $result.coverageIssues){
            if($issue['requirementId'] -cin $requirementIds -and (Test-CaClassificationScope $issue)){
                $cuts.Add([ordered]@{requirementId=$issue['requirementId'];identityIds=@($issue['accountIds']);conditions=[ordered]@{}});continue
            }
            if($issue['resolveWhenProtected'] -ne $true -or $issue['requirementId'] -cnotin $requirementIds){continue}
            $axis=$null;$values=@()
            if($issue['code'] -eq 'resource-group-context' -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application')){$axis='application';$values=@($issue['unknownApplications'])}
            if($issue['code'] -eq 'country-catalog-context' -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network')){$axis='network';$values=@($issue['unknownNetworks'])}
            if($issue['code'] -eq 'directory-baseline-context' -and $Model.dimensions.Contains('directoryScopeEnforcement') -and 'legacyBaseline' -cin $Model.dimensions.directoryScopeEnforcement){$axis='directoryScopeEnforcement';$values=@('legacyBaseline')}
            if($axis){$cuts.Add([ordered]@{requirementId=$issue['requirementId'];identityIds=$people;conditions=[ordered]@{$axis=[ordered]@{include=$values}}})}
        }
        if($remainingQueries.Count -or $cuts.Count){
            try{
                $originalGaps=@($result.gaps)
                $remainingMilliseconds=[Math]::Max(1,5000-[int]$contextClock.ElapsedMilliseconds)
                $refined=[CaGapAnalyzer.Engine]::RefinePolicyContextGapsData($modelJson,(ConvertTo-Json -InputObject $originalGaps -Depth 100 -Compress),(ConvertTo-Json -InputObject @($remainingQueries.ToArray()) -Depth 100 -Compress),(ConvertTo-Json -InputObject @($cuts.ToArray()) -Depth 100 -Compress),$MaxRegions,$remainingMilliseconds)
                $result.gapRefinement=[ordered]@{status=$refined.status;originalGroups=$originalGaps.Count;refinedGroups=$refined.gaps.Count}
                if($refined.status -ceq 'complete' -and $refined.gaps.Count -gt $originalGaps.Count -and $refined.parentGapIndices.Count -eq $refined.gaps.Count){
                    $parentKeys=@{}
                    for($g=0;$g -lt $originalGaps.Count;$g++){$parentKeys[$g]=Hash ($exceptionContext+$modelHash+($result.coverageIssues|ConvertTo-Json -Depth 30 -Compress)+($originalGaps[$g]|ConvertTo-Json -Depth 100 -Compress))}
                    $result.gaps=@(foreach($typedGap in $refined.gaps){
                        $region=[System.Management.Automation.OrderedHashtable]::new();$witness=[System.Management.Automation.OrderedHashtable]::new()
                        foreach($dimension in $typedGap.Region.Keys){$region.Add($dimension,$typedGap.Region[$dimension])}
                        foreach($dimension in $typedGap.Witness.Keys){$witness.Add($dimension,$typedGap.Witness[$dimension])}
                        $record=[System.Management.Automation.OrderedHashtable]::new()
                        $record.Add('requirementId',$typedGap.RequirementId);$record.Add('identityIds',$typedGap.IdentityIds)
                        $record.Add('region',$region);$record.Add('witness',$witness)
                        $record.Add('applicablePolicyIds',$typedGap.ApplicablePolicyIds);$record.Add('nonApplicablePolicyIds',$typedGap.NonApplicablePolicyIds)
                        $record
                    })
                    for($g=0;$g -lt $result.gaps.Count;$g++){$parentGapKeys[$g]=$parentKeys[[int]$refined.parentGapIndices[$g]]}
                }
            }catch{$result.gapRefinement.status='unavailable'}
        }
        if($remainingQueries.Count -and $contextClock.ElapsedMilliseconds -lt 5000){
            try{
                $remainingMilliseconds=[Math]::Max(1,5000-[int]$contextClock.ElapsedMilliseconds)
                $matrix=[CaGapAnalyzer.Engine]::RelevantPolicyContextsByGap($modelJson,(ConvertTo-Json -InputObject @($result.gaps) -Depth 100 -Compress),(ConvertTo-Json -InputObject @($remainingQueries.ToArray()) -Depth 100 -Compress),$MaxRegions,$remainingMilliseconds)|ConvertFrom-CaJson
                if(@($matrix).Count -eq $remainingIndices.Count){
                    for($q=0;$q -lt $remainingIndices.Count;$q++){
                        if(@($matrix[$q]).Count -ne $result.gaps.Count){continue}
                        for($g=0;$g -lt $result.gaps.Count;$g++){if($matrix[$q][$g] -is [bool]){$gapContextAnswers["$($remainingIndices[$q]):$g"]=$matrix[$q][$g]}}
                    }
                }
            }catch{ # No per-finding assurance from invalid or exhausted proofs.
            }
        }
    }
    $result.contextResolutionMilliseconds=$contextClock.ElapsedMilliseconds
    $result.analysisMilliseconds=$timer.ElapsedMilliseconds
    foreach($id in $result.emptyRequirementIds){$result.coverageIssues+=[ordered]@{requirementId=$id;code='empty-requirement-scope';message="Requirement $id has no matching accounts and feasible scenarios. Check its scope before confirming coverage."}}
    if($result.coverageIssues.Count -and $result.status -eq 'completeWithinModel'){$result.engineStatus=$result.status;$result.status='unresolvedCoverage'}
    # Reuse ordinal sets across findings. A per-account scan of the full
    # unresolved account list turns large, mostly unknown directories quadratic.
    $classificationScopes=@{}
    for($i=0;$i -lt $result.coverageIssues.Count;$i++){
        $issue=$result.coverageIssues[$i]
        if($issue['requirementId'] -cin $requirementIds -and (Test-CaClassificationScope $issue)){
            $classificationScopes[$i]=[Collections.Generic.HashSet[string]]::new([string[]]@($issue['accountIds']),[StringComparer]::Ordinal)
        }
    }
    for($gapIndex=0;$gapIndex -lt $result.gaps.Count;$gapIndex++){
        $gap=$result.gaps[$gapIndex]
        $key=Hash ($exceptionContext+$modelHash+($result.coverageIssues|ConvertTo-Json -Depth 30 -Compress)+($gap|ConvertTo-Json -Depth 100 -Compress))
        $gap.key=$key;$gap.acceptance=if($Acceptances.ContainsKey($key)){Get-CaAcceptanceSummary $Acceptances[$key] $key}else{$null}
        if($parentGapKeys.ContainsKey($gapIndex) -and $Acceptances.ContainsKey($parentGapKeys[$gapIndex])){
            $parentKey=$parentGapKeys[$gapIndex];$parentAcceptance=Get-CaAcceptanceSummary $Acceptances[$parentKey] $parentKey
            if($parentAcceptance){
                if(!$gap.acceptance){$gap.acceptance=$parentAcceptance}else{
                    $gap.acceptance.recordKeys=@(@($gap.acceptance.recordKeys)+@($parentKey)|Sort-Object -Unique)
                    $gap.acceptance.exceptionCount=$gap.acceptance.recordKeys.Count
                    $gap.acceptance.reasons=@(@($gap.acceptance.reasons)+@($parentAcceptance.reason)|Sort-Object -Unique)
                }
                $gap.acceptance.matchedRefinement=$true
            }
        }
        $relevantIssues=[Collections.Generic.List[int]]::new()
        for($i=0;$i -lt $result.coverageIssues.Count;$i++){
            $issue=$result.coverageIssues[$i];$id=$issue['requirementId']
            if($id -is [string] -and $unassessedRequirementIds.Contains($id)){continue}
            $sameRequirement=$id -ceq $gap.requirementId -or @(':outside-network',':outside-apps',':outside-device').Where({$gap.requirementId -ceq ($id+$_)}).Count -gt 0
            if($id -is [string] -and $id -cin $requirementIds -and !$sameRequirement){continue}
            if($classificationScopes.ContainsKey($i) -and !$classificationScopes[$i].Overlaps([string[]]@($gap.identityIds))){continue}
            if($id -is [string] -and $id -cin $requirementIds -and $issue['resolveWhenProtected'] -eq $true){
                if($issue['code'] -eq 'resource-group-context' -and (Test-CaDiagnosticDomain $issue 'unknownApplications' 'application') -and !@($gap.region.application|Where-Object {$_ -cin $issue['unknownApplications']}).Count){continue}
                if($issue['code'] -eq 'country-catalog-context' -and (Test-CaDiagnosticDomain $issue 'unknownNetworks' 'network') -and !@($gap.region.network|Where-Object {$_ -cin $issue['unknownNetworks']}).Count){continue}
                if($issue['code'] -eq 'directory-baseline-context' -and $Model.dimensions.Contains('directoryScopeEnforcement') -and 'legacyBaseline' -cnotin $gap.region.directoryScopeEnforcement){continue}
            }
            $answerKey="$($i):$gapIndex"
            if($gapContextAnswers.ContainsKey($answerKey) -and $gapContextAnswers[$answerKey] -eq $false){continue}
            $relevantIssues.Add($i)
        }
        $engineComplete=$result.status -eq 'completeWithinModel' -or ($result.status -eq 'unresolvedCoverage' -and $result['engineStatus'] -eq 'completeWithinModel')
        $gap.assessmentStatus=if($engineComplete -and !$relevantIssues.Count){'gapWithinModel'}else{'needsInvestigation'}
        $gap.coverageIssueIndices=@($relevantIssues.ToArray())
    }
    $result.modelHash=$modelHash;$result.runAtUtc=[DateTime]::UtcNow.ToString('o')
    return $result
}
