@{
    RootModule='CA.GapAnalyzer.psm1'
    ModuleVersion='0.2.0'
    GUID='57f144dc-1cbb-4c67-bb79-1a65eb3bc0f1'
    PowerShellVersion='7.4'
    FunctionsToExport=@('Invoke-CaGapAnalysis','Invoke-CaTenantAssessment')
    CmdletsToExport=@()
    VariablesToExport=@()
    AliasesToExport=@()
    Description='Portable offline Conditional Access assessment of exported tenant snapshots and configurable requirements, with reports and run history.'
}
