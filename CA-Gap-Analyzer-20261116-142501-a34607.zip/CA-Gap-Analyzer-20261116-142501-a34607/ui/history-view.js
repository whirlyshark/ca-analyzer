'use strict';
const HistoryView={
 summary(changes){
  const c=changes||{},result={title:'First saved check',details:[],examples:[]};
  if(!c.hasPrevious)return result;
  if(!['complete','scopeChanged'].includes(c.comparisonStatus))return {title:'Changes could not be confirmed',details:[({incompleteEvidence:'One of the checks is incomplete.',baselineUpgrade:'This check starts a new comparison baseline.',boundedComparison:'The comparison reached its analysis limit.',differentSource:'The checks belong to different sources.'})[c.comparisonStatus]||'These checks could not be compared.'],examples:[]};
  const count=(n,singular,plural)=>n+' '+(n===1?singular:plural);
  const added=c.accountsWithNewGaps||0,removed=c.accountsWithReducedGaps||0;
  result.title=added||removed?'Since the previous check':'No coverage changes';
  if(added)result.details.push(count(added,'account has new gaps','accounts have new gaps'));
  if(removed)result.details.push(count(removed,'account had gaps closed','accounts had gaps closed'));
  if(c.addedAccountScopes)result.details.push(count(c.addedAccountScopes,'account/requirement check added','account/requirement checks added'));
  if(c.removedAccountScopes)result.details.push(count(c.removedAccountScopes,'account/requirement check removed','account/requirement checks removed')+'; removed checks are not fixes');
  if(c.reconfiguredRequirements?.length)result.details.push(count(c.reconfiguredRequirements.length,'requirement changed','requirements changed')+'; new baseline');
  if(c.comparisonStatus==='scopeChanged'&&!added&&!removed)result.title='Check scope changed';
  const seen=new Set();
  for(const [kind,items] of [['new',c.addedExamples],['closed',c.removedExamples]])for(const item of items||[]){const key=kind+':'+item.accountId;if(!seen.has(key)){seen.add(key);result.examples.push({kind,accountId:item.accountId});}}
  return result;
 }
};
if(typeof module!=='undefined')module.exports=HistoryView;
