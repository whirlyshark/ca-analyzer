'use strict';
// Compare unions of permitted-violation regions, not their incidental fragments.
// Saved evidence contains domain definitions, never code or credentials.
const HistoryModel={
 version:1,
 semantics:'ca-request-model-20261116-6',
 canonical(value){
  if(Array.isArray(value))return [...new Map(value.map(v=>{const c=this.canonical(v);return [JSON.stringify(c),c];})).values()].sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
  if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,this.canonical(value[k])]));
  return value;
 },
 key(value){return JSON.stringify(this.canonical(value));},
 capture(source,model,definitions){
  const definitionsById=new Map(definitions.map(r=>[r.id,r]));
  const requirements=model.requirements.map(r=>{
   const base=r.id.replace(/:(outside-network|outside-apps|outside-device)$/,''),original=definitionsById.get(r.id)||definitionsById.get(base)||{};
   const definition=structuredClone(original);
   for(const k of ['id','name','origin','accountSetId','excludeSetIds','enabled'])delete definition[k];
   if(definition.registrationContext)delete definition.registrationContext.provenance;
   if(definition.registrationContext&&definition.flows?.includes(definition.registrationContext.flow))delete definition.flows;
   definition.protections=definition.protections||[definition.outcome];
   for(const k of ['apps','platforms','clients','flows','signInRiskLevels','userRiskLevels','pendingSetup'])if(!definition[k]?.length)delete definition[k];
   if(!definition.networkMode||definition.networkMode==='any'){delete definition.networkMode;delete definition.networks;}
   for(const k of ['blockOtherApps','deviceFilter','authenticationContextId','userAction'])if(!definition[k])delete definition[k];
   if(source.historyDomain?.kind==='snapshot'){
    const G=typeof module!=='undefined'&&module.exports?require('./resource-groups.js'):ResourceGroups;
    for(const k of ['apps','networks'])if(definition[k])definition[k]=definition[k].map(G.canonical);
    if(definition.deviceFilter)definition.deviceFilter.clauses=definition.deviceFilter.clauses.map(c=>({...c,value:c.value.toLowerCase()}));
   }
   const include=new Set(r.includeUsers||['*']),exclude=new Set(r.excludeUsers||[]);
   const accountIds=model.identities.filter(u=>(r.scope!=='privileged'||u.privileged||u.pimEligible)&&(include.has('*')||include.has(u.id))&&!exclude.has('*')&&!exclude.has(u.id)).map(u=>u.id);
   return {id:r.id,definition,accountIds};
  });
  return {version:this.version,semantics:this.semantics,dimensions:model.dimensions,domain:source.historyDomain||{kind:'finite'},requirements};
 },
 prepareDomains(sides,{maxRegions=20000,deadline=Date.now()+5000}={}){
   const S=typeof module!=='undefined'&&module.exports?require('./snapshot.js'):SnapshotModel;
   const D=typeof module!=='undefined'&&module.exports?require('./device-filter.js'):DeviceFilter;
   if(!sides.length||sides.some(s=>s.domain.kind!==sides[0].domain.kind)||!['finite','snapshot'].includes(sides[0].domain.kind))throw Error('The exported domain types differ.');
   const raw=sides[0].domain.kind==='snapshot',dimensions={};
   for(const side of sides)for(const [axis,values] of Object.entries(side.dimensions))dimensions[axis]=[...new Set([...(dimensions[axis]||[]),...values])];
   const maps=sides.map(()=>new Map()),constraints=[];
   const check=()=>{if(Date.now()>deadline)throw Error('History comparison exceeded its time budget.');};
   const map=(side,axis,target,table)=>maps[side].set(axis,{axis:target,table});
   if(raw){
    // Refine IP ranges and shared country classifications. Country catchalls
    // expand when a later policy introduces a new named country.
    const cells=sides.map(s=>s.domain.networkCells||[]);
    if(cells.some(c=>!c.length))throw Error('IP partition evidence is missing.');
    const network=[],tables=sides.map(()=>new Map());
    const L=typeof module!=='undefined'&&module.exports?require('./location-model.js'):LocationModel;
    const countryCodes=[...new Set(cells.flatMap(list=>list.flatMap(c=>c.country?.codes||[])))].sort();
    const geographic=cells.some(list=>list.some(c=>c.country));
    const countryPoints=geographic?[...countryCodes,'other','unknown']:[null];
    const sideCodes=cells.map(list=>[...new Set(list.flatMap(c=>c.country?.codes||[]))]);
    for(const family of [4,6]){
     const bounds=[...new Set(cells.flatMap(list=>list.flatMap(c=>c.ranges.filter(r=>r.family===family).flatMap(r=>[r.start,(BigInt(r.end)+1n).toString()]))))].map(BigInt).sort((a,b)=>a<b?-1:a>b?1:0);
     for(let i=0;i<bounds.length-1;i++){
      for(const country of countryPoints){
       check();const start=bounds[i],end=bounds[i+1]-1n,id='ip'+family+':'+start+'-'+end+(country===null?'':':country:'+country);network.push(id);
       cells.forEach((list,side)=>{
        const matches=list.filter(c=>L.countryMatches(c,country,sideCodes[side])&&c.ranges.some(r=>r.family===family&&BigInt(r.start)<=start&&BigInt(r.end)>=end));
        if(matches.length!==1)throw Error('IP/country partition evidence is not an exact cover.');
        const values=tables[side].get(matches[0].id)||[];values.push(id);tables[side].set(matches[0].id,values);
       });
      }
     }
    }
    dimensions.network=network;tables.forEach((table,side)=>map(side,'network','network',table));
    // Application/home-tenant catchalls mean every value outside the named
    // inventory. Newly named values must also be compared with the old catchall.
    for(const [axis,other] of [['application','other-resource'],['externalTenantId','other-external-tenant']])if(dimensions[axis])sides.forEach((s,side)=>{
     const values=s.dimensions[axis];if(!values)return;
     map(side,axis,axis,new Map(values.map(v=>[v,v===other?dimensions[axis].filter(x=>x===other||!values.includes(x)):[v]])));
    });
    const rules=sides.map(s=>s.domain.deviceRules||[]),prepared=rules.map(r=>D.prepare(r,{deadline}));
    const union=D.prepare(rules.flatMap((r,side)=>r.map((x,i)=>({...x,id:'history:'+side+':'+i}))),{deadline});
    if(prepared.some(p=>p.errors.size)||union.errors.size)throw Error('Device partition evidence cannot be reconstructed.');
    for(const axis of Object.keys(dimensions).filter(k=>k.startsWith('device.')))delete dimensions[axis];
    Object.assign(dimensions,union.dimensions);
    prepared.forEach((p,side)=>{
     for(const axis of Object.keys(p.dimensions))if(this.key(p.dimensions[axis])!==this.key(sides[side].dimensions[axis]))throw Error('Saved device domains disagree with their predicate evidence.');
     for(const [property,info] of p.properties){
      const next=union.properties.get(property);
      if(info.type==='collection')info.atoms.forEach((atom,i)=>{
       const j=next.atoms.findIndex(a=>D.atomKey(a)===D.atomKey(atom));if(j<0)throw Error('Device collection refinement is incomplete.');
       map(side,info.axes[i],next.axes[j],new Map([['false',['false']],['true',['true']]]));
      });
      else{
       const table=new Map(info.cells.map(c=>[c.id,[]]));
       for(const cell of next.cells){
        const truth=info.atoms.map(a=>D.matches(cell.value,a)),old=info.cells.find(c=>(c.value===null)===(cell.value===null)&&c.truth.every((v,i)=>v===truth[i]));
        if(!old)throw Error('Device predicate refinement is incomplete.');table.get(old.id).push(cell.id);
       }
       map(side,info.axis,next.axis,table);
      }
     }
    });
    constraints.push(...union.scenarioConstraints);
    if(dimensions.directoryScopeEnforcement)constraints.push([
     {directoryScopeEnforcement:{include:['ordinary']}},
     {directoryScopeEnforcement:{include:['legacyBaseline','currentBaseline']},application:{include:['00000002-0000-0000-c000-000000000000']},accessTarget:{include:['application']}}
    ]);
    for(const s of sides)for(const role of Object.keys(s.domain.roleAliases||{}))dimensions['roleActive.'+role]||=['false','true'];
   }
   const regions=S.regions(dimensions,{maxRegions,deadline}),axes=Object.keys(dimensions),universe=Object.fromEntries(axes.map(a=>[a,dimensions[a]]));
   const intersectConstraints=(pieces,groups)=>{
    for(const group of groups){const next=[];for(const p of pieces)for(const clause of group){const overlap=regions.intersect(p,regions.from(clause));if(overlap)next.push(overlap);regions.check(next);}pieces=next;}
    return pieces;
   };
   const lift=(region,side)=>{
    check();let rectangle={...universe};
    for(const [axis,values] of Object.entries(region)){
     if(!Array.isArray(sides[side].dimensions[axis])||!Array.isArray(values)||values.some(v=>!sides[side].dimensions[axis].includes(v)))throw Error('A saved region is outside its declared domain.');
     const mapping=maps[side].get(axis),target=mapping?.axis||axis;
     if(!dimensions[target])throw Error('A saved region references an unknown axis.');
     const selected=mapping?[...new Set(values.flatMap(v=>{if(!mapping.table.has(v))throw Error('A saved region references an unknown value.');return mapping.table.get(v);} ))]:values;
     if(selected.some(v=>!dimensions[target].includes(v)))throw Error('A saved region is outside the comparison domain.');
     rectangle[target]=rectangle[target].filter(v=>selected.includes(v));if(!rectangle[target].length)return [];
    }
    let pieces=intersectConstraints([rectangle],constraints);
    // A role represented by a single group variable still means role == group.
    for(const [role,group] of Object.entries(sides[side].domain.roleAliases||{}))pieces=intersectConstraints(pieces,[['false','true'].map(v=>({['roleActive.'+role]:{include:[v]},[group]:{include:[v]}}))]);
    return pieces;
   };
   return {regions,axes,lift,check,dimensions};
 },
 compare(current,previous,{maxRegions=20000,timeoutMs=5000,maxPairs=250000}={}){
  const common={hasPrevious:!!previous,modelChanged:!!previous&&current.modelHash!==previous.modelHash};
  if(!previous)return {...common,comparisonStatus:'firstRun',newFindings:0,resolvedFindings:0};
  common.previousRunAtUtc=previous.runAtUtc;
  common.completenessChanged=current.status!==previous.status;
  const unavailable=(comparisonStatus,message)=>({...common,comparisonStatus,newFindings:null,resolvedFindings:null,message});
  if(current.sourceKey!==previous.sourceKey)return unavailable('differentSource','The saved assessments belong to different sources.');
  if(current.status!=='completeWithinModel'||previous.status!=='completeWithinModel'||current.coverageIssues?.length||previous.coverageIssues?.length)return unavailable('incompleteEvidence','One of the compared assessments is incomplete.');
  const now=current.historyEvidence,before=previous.historyEvidence;
  if(!now||!before)return unavailable('baselineUpgrade','The previous report lacks semantic history evidence. This report establishes the new baseline.');
  if(now.version!==this.version||before.version!==this.version||now.semantics!==before.semantics||now.semantics!==this.semantics)return unavailable('baselineUpgrade',"The analyzer's checks have changed. This run starts a new comparison baseline.");
  const deadline=Date.now()+timeoutMs;
  try{
   const {regions,axes,lift,check}=this.prepareDomains([before,now],{maxRegions,deadline});
   const index=(result,evidence,side)=>{
    const byRequirement=new Map(evidence.requirements.map(r=>[r.id,{...r,accounts:new Set(r.accountIds),gaps:new Map()}])),lifted=[],ids=new Map();
    for(const gap of result.gaps||[]){
     const scope=byRequirement.get(gap.requirementId);if(!scope)throw Error('A finding references a missing requirement.');
     const key=this.key(gap.region);let id=ids.get(key);
     if(id===undefined){id=lifted.length;ids.set(key,id);lifted.push(lift(gap.region,side));}
     for(const account of gap.identityIds){if(!scope.accounts.has(account))throw Error('A finding is outside its saved account scope.');const list=scope.gaps.get(account)||new Set();list.add(id);scope.gaps.set(account,list);}
    }
    return {byRequirement,lifted};
   };
   const old=index(previous,before,0),fresh=index(current,now,1),cache=new Map();
   const answer={...common,comparisonStatus:'complete',newFindings:0,resolvedFindings:0,newScopesWithGaps:0,retiredScopesWithGaps:0,addedAccountScopes:0,removedAccountScopes:0,reconfiguredRequirements:[],comparedAccountScopes:0,addedExamples:[],removedExamples:[]};
   const accountsGaining=new Set(),accountsReducing=new Set();
   const entering=(scope,accounts)=>{for(const account of accounts){check();if(scope.gaps.has(account)){answer.newScopesWithGaps++;answer.newFindings++;accountsGaining.add(account);}}};
   const leaving=(scope,accounts)=>{for(const account of accounts){check();if(scope.gaps.has(account))answer.retiredScopesWithGaps++;}};
   const gapKeys=(scope,account)=>[...(scope.gaps.get(account)||[])].sort((a,b)=>a-b),difference=(left,right)=>{let pieces=left;for(const cut of right)pieces=regions.minus(pieces,cut);return pieces;};
   for(const id of new Set([...old.byRequirement.keys(),...fresh.byRequirement.keys()])){
    check();const a=old.byRequirement.get(id),b=fresh.byRequirement.get(id);
    if(!a||!b){answer.addedAccountScopes+=b?.accounts.size||0;answer.removedAccountScopes+=a?.accounts.size||0;if(b)entering(b,b.accounts);if(a)leaving(a,a.accounts);continue;}
    const added=[...b.accounts].filter(x=>!a.accounts.has(x)),removed=[...a.accounts].filter(x=>!b.accounts.has(x));
    answer.addedAccountScopes+=added.length;answer.removedAccountScopes+=removed.length;entering(b,added);leaving(a,removed);
    if(this.key(a.definition)!==this.key(b.definition)){answer.reconfiguredRequirements.push(id);continue;}
    for(const account of b.accounts){
     if(!a.accounts.has(account))continue;check();if(++answer.comparedAccountScopes>maxPairs)throw Error('History comparison exceeded its account-scope budget.');
     const x=gapKeys(a,account),y=gapKeys(b,account),key=JSON.stringify([x,y]);let delta=cache.get(key);
     if(!delta){
      const left=x.flatMap(i=>old.lifted[i]),right=y.flatMap(i=>fresh.lifted[i]);
      const added=difference(right,left),removed=difference(left,right);
      delta={added:added.length?added[0]:null,removed:removed.length?removed[0]:null};cache.set(key,delta);
     }
     for(const [kind,count,examples] of [['added','newFindings','addedExamples'],['removed','resolvedFindings','removedExamples']])if(delta[kind]){
      answer[count]++;(kind==='added'?accountsGaining:accountsReducing).add(account);if(answer[examples].length<25)answer[examples].push({accountId:account,requirementId:id,witness:Object.fromEntries(axes.map(axis=>[axis,delta[kind][axis][0]]))});
     }
    }
   }
   if(answer.addedAccountScopes||answer.removedAccountScopes||answer.reconfiguredRequirements.length)answer.comparisonStatus='scopeChanged';
   answer.accountsWithNewGaps=accountsGaining.size;answer.accountsWithReducedGaps=accountsReducing.size;
   return answer;
  }catch(e){return unavailable(/budget/.test(e.message)?'boundedComparison':'comparisonUnavailable',e.message);}
 }
};
if(typeof module!=='undefined')module.exports=HistoryModel;
