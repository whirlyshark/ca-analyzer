'use strict';
const SnapshotStrengths=typeof module!=='undefined'&&module.exports?require('./authentication-strengths.js'):AuthenticationStrengths;
const SnapshotSessions=typeof module!=='undefined'&&module.exports?require('./session-controls.js'):SessionControls;
const SnapshotLocations=typeof module!=='undefined'&&module.exports?require('./location-model.js'):LocationModel;
const SnapshotDevices=typeof module!=='undefined'&&module.exports?require('./device-filter.js'):DeviceFilter;
const SnapshotExternal=typeof module!=='undefined'&&module.exports?require('./external-users.js'):ExternalUsers;
const SnapshotPim=typeof module!=='undefined'&&module.exports?require('./pim-groups.js'):PimGroups;
const SnapshotResources=typeof module!=='undefined'&&module.exports?require('./resource-groups.js'):ResourceGroups;
const SnapshotRoles=typeof module!=='undefined'&&module.exports?require('./role-schedules.js'):RoleSchedules;
const SnapshotModel={
 canonicalizeReferenceIds(input){
   const id=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)?value.toLowerCase():value;
   const lists=new Set(['includeUsers','excludeUsers','includeGroups','excludeGroups','includeRoles','excludeRoles','includeApplications','excludeApplications','includeLocations','excludeLocations','members','nonMembers','$referenceIds']);
   const walk=(value,key='')=>{
     // Attribute payloads contain arbitrary literal strings, including GUID-like
     // values under names ending in Id. They are not directory references.
     if(key==='customSecurityAttributes')return value===undefined?undefined:structuredClone(value);
     if(typeof value==='string'){
       if(key==='collection'){const match=/^(members|groupMembers|pimGroupEligibility|pimGroupAssignments|groupDirectMembers|strengthConfigurations):(.+)$/.exec(value);if(match)return match[1]+':'+id(match[2]);}
       return key==='id'||key.endsWith('Id')||lists.has(key)||key.endsWith('Ids')?id(value):value;
     }
     if(Array.isArray(value))return value.map(v=>walk(v,key));
     if(!value||typeof value!=='object')return value;
     if(key==='groupMembers'||key==='groupDirectMembers'){
       const entries=Object.entries(value).map(([k,v])=>[id(k),walk(v,'$referenceIds')]);
       if(new Set(entries.map(([k])=>k)).size!==entries.length)throw Error('Group membership contains duplicate spellings of the same identifier. Export a consistent snapshot.');
       return Object.fromEntries(entries);
     }
     if(key==='completeness'){
       const entries=Object.entries(value).map(([k,v])=>{const m=/^(pimGroupEligibility|pimGroupAssignments|groupDirectMembers|groupMembers|members|strengthConfigurations):(.+)$/.exec(k);return [m?m[1]+':'+id(m[2]):k,walk(v,k)];});
       if(new Set(entries.map(([k])=>k)).size!==entries.length)throw Error('Collection completeness contains duplicate spellings of the same identifier. Export a consistent snapshot.');
       return Object.fromEntries(entries);
     }
     return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,walk(v,k)]));
   };
   return walk(input);
 },
 regions(dimensions,{maxRegions=20000,deadline=Date.now()+5000}={}){
   const axes=Object.keys(dimensions),check=pieces=>{if(pieces.length>maxRegions||Date.now()>deadline)throw Error('Scenario predicate partition exceeded its budget.');return pieces;};
   const from=selectors=>{const r={};for(const axis of axes){const s=selectors[axis]||{},included=s.include?.length?s.include:dimensions[axis];r[axis]=included.filter(v=>dimensions[axis].includes(v)&&!s.exclude?.includes(v));if(!r[axis].length)return null;}return r;};
   const intersect=(a,b)=>{if(!a||!b)return null;const r={};for(const axis of axes){r[axis]=a[axis].filter(v=>b[axis].includes(v));if(!r[axis].length)return null;}return r;};
   const subtract=(a,b)=>{const overlap=intersect(a,b);if(!overlap)return [a];const remainder={...a},out=[];for(const axis of axes){const outside=remainder[axis].filter(v=>!overlap[axis].includes(v));if(outside.length)out.push({...remainder,[axis]:outside});remainder[axis]=overlap[axis];}return check(out);};
   const minus=(pieces,cut)=>{const out=[];for(const piece of pieces){out.push(...subtract(piece,cut));check(out);}return out;};
   const selectors=r=>Object.fromEntries(axes.filter(axis=>r[axis].length!==dimensions[axis].length).map(axis=>[axis,{include:r[axis]}]));
   return {from,intersect,subtract,minus,selectors,check};
 },
 normalize(input,{additionalDeviceRules=[],registrationContexts=[],additionalResourceGroups=[],additionalApplications=[]}={}){
   if(!Array.isArray(additionalApplications)||additionalApplications.some(id=>typeof id!=='string'||!id.trim()||['All','AllAgentIdResources'].includes(SnapshotResources.canonical(id))||SnapshotResources.isGroup(id)))throw Error('Additional application resources must be non-empty resource IDs, not resource groups or All.');
   additionalApplications=[...new Set(additionalApplications.map(SnapshotResources.canonical))];
   registrationContexts=registrationContexts.map(c=>({...c,resourceId:SnapshotResources.canonical(c.resourceId)}));
   if(!input||typeof input!=='object')throw Error('Choose a JSON policy export or tenant snapshot.');
   if(input.schemaVersion===1&&input.dimensions&&Array.isArray(input.identities)){
     return {key:'model:'+this.fingerprint(JSON.stringify(input)),name:'Imported model',kind:'model',model:input,records:input.identities.map(u=>({...u,privilegeKnown:Object.hasOwn(u,'privileged')||Object.hasOwn(u,'pimEligible')})),policies:input.policies,policyNames:Object.fromEntries(input.policies.map(p=>[p.id,p.id])),appNames:{},issues:[],networkEvaluationSupported:true};
   }
   input=this.canonicalizeReferenceIds(input);
   const exportedSnapshot=input.caGapSnapshotVersion===1?{...input,completeness:{...input.completeness}}:null;
   // A recorded read failure overrides an inconsistent success flag. Keep the
   // original export intact; all normalizers use this effective inventory.
   if(exportedSnapshot)for(const error of exportedSnapshot.errors||[])if(typeof error?.collection==='string')exportedSnapshot.completeness[error.collection]=false;
   const roleState=SnapshotRoles.prepare(exportedSnapshot||{}),snapshot=exportedSnapshot?roleState.snapshot:null;
   let policies=snapshot?snapshot.policies:Array.isArray(input)?input:Array.isArray(input.value)?input.value:input.id&&input.conditions?[input]:null;
   if(!Array.isArray(policies))throw Error('No Conditional Access policies found in this file.');
   const uniqueIds=(rows,name)=>{const seen=new Set();for(const row of rows){if(!row||typeof row.id!=='string'||!row.id.trim())throw Error(`Exported ${name} need non-empty IDs. Export a fresh snapshot.`);if(seen.has(row.id))throw Error(`Exported ${name} contain duplicate IDs. Export a fresh snapshot.`);seen.add(row.id);}return seen;};
   uniqueIds(policies,'policies');
   const issues=[], notes=[], policyDetails={}, note=(message,policyId)=>issues.push({message,...(policyId?{policyId}:{})});
   if(input['@odata.nextLink'])note('The policy export contains a nextLink: more policy pages are missing.');
   if(!snapshot)note('Policy-only export: users, memberships and role assignments are missing. Import a full snapshot for account coverage.');
   if(snapshot){
     for(const name of ['users','groups','roles','roleAssignments','roleEligibility'])if(!Array.isArray(snapshot[name]))throw Error(`Snapshot ${name} must be an array; export a full snapshot again.`);
     const userKeys=uniqueIds(snapshot.users,'accounts'),groupKeys=uniqueIds(snapshot.groups,'groups');uniqueIds(snapshot.roles,'role definitions');
     if([...groupKeys].some(id=>userKeys.has(id)))throw Error('An account and group share the same ID. Export a fresh, consistent snapshot.');
     if(!snapshot.groupMembers||typeof snapshot.groupMembers!=='object'||Array.isArray(snapshot.groupMembers))throw Error('Snapshot groupMembers must be a membership map.');
     const directoryCollections=['groups','groupMembers','roles','roleAssignments','roleEligibility'];
     for(const error of snapshot.errors||[])if(!['applications','namedLocations','deviceRegistrationPolicy','roleAssignmentScheduleInstances','authenticationStrengths','applicationAttributeDefinitions','applicationAttributes','compliantNetworkLocations',...directoryCollections].includes(error?.collection)&&!error?.collection?.startsWith('strengthConfigurations:')&&!/^(members|groupMembers|pimGroupEligibility|pimGroupAssignments|groupDirectMembers):/.test(error?.collection||''))note(typeof error==='string'?error:error.message||'Snapshot collection is incomplete.');
     for(const name of ['policies','users'])if(snapshot.completeness?.[name]!==true)note(`Snapshot does not confirm complete ${name} collection.`);
     const missing=directoryCollections.filter(name=>snapshot.completeness?.[name]!==true);
     if(roleState.uncertainties.length||snapshot.completeness?.roleAssignmentScheduleInstances===false)missing.push('roleAssignmentScheduleInstances');
     const failedGroups=[...new Set((snapshot.errors||[]).map(e=>e?.collection).filter(key=>/^(members|groupMembers|pimGroupEligibility|pimGroupAssignments|groupDirectMembers):/.test(key||'')))];
     const labels={groups:'groups',groupMembers:'group memberships',roles:'role definitions',roleAssignments:'active roles',roleEligibility:'eligible roles',roleAssignmentScheduleInstances:'role timing'};
     if(missing.length||failedGroups.length)notes.push({code:'directory-inventory',collections:[...missing,...failedGroups],message:`Missing directory details: ${[...missing.map(key=>labels[key]),...(failedGroups.length?[failedGroups.length+' individual group '+(failedGroups.length===1?'read':'reads')]:[])].join(', ')}. Results that depend on them are marked for investigation.`});
     for(const collection of ['applications','namedLocations'])if(snapshot.completeness?.[collection]===false)notes.push({code:'resource-inventory',collection,message:collection==='applications'?'Application names were not fully collected. Resources are assessed by ID.':'Named locations were not fully collected. Available definitions are used; missing definitions remain unverified.'});
   }
   const users=snapshot?.users||[], groups=snapshot?.groups||[], members=snapshot?.groupMembers||{}, roles=snapshot?.roles||[];
   const groupCatalogComplete=snapshot?.completeness?.groups===true,currentGroupCompleteness=new Map();
   const completeCurrentGroup=id=>{
     if(currentGroupCompleteness.has(id))return currentGroupCompleteness.get(id);
     const specific=['members:'+id,'groupMembers:'+id].filter(key=>Object.hasOwn(snapshot?.completeness||{},key));
     const complete=Array.isArray(members[id])&&members[id].every(v=>typeof v==='string')&&(specific.length?specific.every(key=>snapshot.completeness[key]===true):snapshot?.completeness?.groupMembers===true);
     currentGroupCompleteness.set(id,complete);return complete;
   };
   const completeGroupIds=groups.filter(g=>completeCurrentGroup(g.id)).map(g=>g.id),uncertainGroupIds=groups.filter(g=>!completeCurrentGroup(g.id)).map(g=>g.id);
   const currentGroupMembers=new Map(completeGroupIds.map(id=>[id,new Set(members[id])]));
   const registrationPrerequisites={devicePolicyKnown:snapshot?.completeness?.deviceRegistrationPolicy===true,deviceMfaConfiguration:snapshot?.deviceRegistrationPolicy?.multiFactorAuthConfiguration};
   // Device-registration prerequisites are checked only by requirements that
   // depend on them. Their absence must not invalidate ordinary app assessments.
   const records=users.map(u=>({...u,groupIds:[],eligibleGroupIds:[],roleIds:[],groupIdsComplete:groupCatalogComplete,eligibleGroupIdsComplete:groupCatalogComplete,roleIdsComplete:snapshot?.completeness?.roleAssignments===true&&snapshot?.completeness?.roleEligibility===true,uncertainGroupIds,completeGroupIds:groupCatalogComplete?[]:completeGroupIds,completeEligibleGroupIds:[],activeRoleIds:[],eligibleRoleIds:[],fixedActiveRoleIds:[],privilegeTimingCertain:false,privilegeTimingUncertain:false,uncertainRoleIds:[],privileged:false,pimEligible:false,privilegeKnown:snapshot?.completeness?.roleAssignments===true&&snapshot?.completeness?.roleEligibility===true}));
   const byId=new Map(records.map(r=>[r.id,r])), roleMap=new Map(roles.map(r=>[r.id,r]));
   const userIds=new Set(records.map(r=>r.id));
   if(groups.some(g=>Array.isArray(members[g.id])&&members[g.id].some(id=>!userIds.has(id))))note('Transitive user memberships reference accounts missing from the user export. Collect a fresh complete snapshot.');
   for(const g of groups){if(completeCurrentGroup(g.id))for(const id of members[g.id])if(byId.has(id))byId.get(id).groupIds.push(g.id);}
   const groupIds=new Set(groups.map(g=>g.id));
   const groupRoleAssignments=[...(snapshot?.roleAssignments||[]),...(snapshot?.roleEligibility||[])].filter(a=>groupIds.has(a.principalId));
   const privilegedGroupAssignments=groupRoleAssignments.filter(a=>roleMap.get(a.roleDefinitionId)?.isPrivileged===true);
   const certainRoles=new Map(records.map(r=>[r.id,new Set()]));
   for(const [assignments,eligible] of [[snapshot?.roleAssignments||[],false],[snapshot?.roleEligibility||[],true]])for(const assignment of assignments){
     const role=roleMap.get(assignment.roleDefinitionId), ids=userIds.has(assignment.principalId)?[assignment.principalId]:completeCurrentGroup(assignment.principalId)?members[assignment.principalId]:[];
     for(const id of ids){const record=byId.get(id);if(!record)continue;
       record.roleIds.push(assignment.roleDefinitionId);
       if(roleState.classificationUnknown.has(assignment)){if(role?.isPrivileged!==false)record.privilegeTimingUncertain=true;}
       else {certainRoles.get(id).add(assignment.roleDefinitionId);if(role?.isPrivileged===true)record.privilegeTimingCertain=true;}
       if(!role||typeof role.isPrivileged!=='boolean')record.privilegeKnown=false;
       if(assignment.directoryScopeId==='/'&&!assignment.appScopeId&&role?.isBuiltIn===true){
         const roleId=role?.templateId||assignment.roleDefinitionId;
         if(eligible)record.eligibleRoleIds.push(roleId);
         else {record.activeRoleIds.push(roleId);if(userIds.has(assignment.principalId)&&roleState.fixed.has(assignment))record.fixedActiveRoleIds.push(roleId);}
       }
       if(role?.isPrivileged===true){if(eligible)record.pimEligible=true;else record.privileged=true;}
     }
   }
   const referencedRoles=new Set(policies.filter(p=>p.state==='enabled').flatMap(p=>[...p.conditions?.users?.includeRoles||[],...p.conditions?.users?.excludeRoles||[]]));
   const unsupportedCustomRoles=new Set([...referencedRoles].filter(id=>!roles.some(r=>r.templateId===id&&r.isBuiltIn===true)&&roles.some(r=>r.isBuiltIn===false&&(r.id===id||r.templateId===id))));
   const activeDirectoryRows=new Set(snapshot?.roleAssignments||[]);
   const roleUnknownById=new Map([...referencedRoles].map(id=>[id,new Set()])),roleUnknownGroupsById=new Map([...referencedRoles].map(id=>[id,new Set()])),roleUnboundedGroupsById=new Map([...referencedRoles].map(id=>[id,new Set()])),roleInventoryReasons=new Map([...referencedRoles].map(id=>[id,new Set()]));
   const unknownRole=(id,people,message)=>{if(!roleUnknownById.has(id))return;for(const person of people)roleUnknownById.get(id).add(person);roleInventoryReasons.get(id).add(message);};
   const unknownRolePrincipal=(id,row,message)=>{
     if(!roleUnknownById.has(id))return;
     const principal=row.principalId;
     if(userIds.has(principal))unknownRole(id,[principal],message);
     else if(groupIds.has(principal)||!groupCatalogComplete){
       if(activeDirectoryRows.has(row)&&!roleState.fixed.has(row))unknownRole(id,userIds,message);
       else {(activeDirectoryRows.has(row)?roleUnknownGroupsById:roleUnboundedGroupsById).get(id).add(principal);roleInventoryReasons.get(id).add(message);}
     }
   };
   for(const role of referencedRoles){
     if(['roleAssignments','roleEligibility'].some(name=>snapshot?.completeness?.[name]!==true))unknownRole(role,userIds,'Directory role inventory is incomplete. Export active assignments and eligibility.');
   }
   for(const row of [...snapshot?.roleAssignments||[],...snapshot?.roleEligibility||[]]){
     const role=roleMap.get(row.roleDefinitionId);
     const invalidScope=(typeof row.directoryScopeId!=='string'||!row.directoryScopeId.startsWith('/'))&&!row.appScopeId||row.directoryScopeId&&row.appScopeId||row.appScopeId!=null&&typeof row.appScopeId!=='string';
     const couldBeTenantScoped=invalidScope||row.directoryScopeId==='/'&&(row.appScopeId==null||row.appScopeId==='');
     if(couldBeTenantScoped&&(!role||typeof role.isBuiltIn!=='boolean'||role.isBuiltIn&&(typeof role.templateId!=='string'||!role.templateId.trim())))for(const id of referencedRoles)unknownRolePrincipal(id,row,'CA role targeting has unresolved role definitions. Export the built-in role catalog.');
     if(role?.isBuiltIn===true){
       if(invalidScope)unknownRolePrincipal(role.templateId,row,'CA role targeting has missing or inconsistent scope metadata. Export complete assignment scopes.');
       if(!groupCatalogComplete&&!userIds.has(row.principalId)&&!groupIds.has(row.principalId))unknownRolePrincipal(role.templateId,row,'A role assignment principal is absent from the incomplete group catalog. Its user membership is unknown.');
     }
   }
   if([...roleInventoryReasons.values()].some(reasons=>reasons.size)&&!notes.some(n=>n.code==='directory-inventory'))notes.push({code:'directory-inventory',collections:['role assignment metadata'],message:'Some role definitions or assignment scopes are unresolved. Results that depend on them are marked for investigation.'});
   const directoryResource='00000002-0000-0000-c000-000000000000';
   const directoryScopeUncertain=policies.some(p=>p.state==='enabled'&&p.conditions?.users&&p.conditions?.applications?.includeApplications?.includes('All')&&p.conditions.applications.excludeApplications?.length);
   const apps=new Set(['other-resource']), appNames={'other-resource':'Other resources'};
   const deviceRegistrationResource='01cb2876-7ebd-4aa4-9cc9-d28bd4d359a9';
   const flowResourceExclusions=[];
   if(policies.some(p=>p.state==='enabled'&&p.conditions?.users&&p.conditions?.authenticationFlows)){apps.add(deviceRegistrationResource);appNames[deviceRegistrationResource]='Device Registration Service';}
   if(directoryScopeUncertain){apps.add(directoryResource);appNames[directoryResource]='Windows Azure Active Directory';}
   for(const context of registrationContexts)apps.add(context.resourceId);
   for(const id of additionalApplications)apps.add(id);
   if(additionalApplications.length)notes.push({code:'declared-resources',applicationIds:additionalApplications,message:`${additionalApplications.length} ${additionalApplications.length===1?'resource was':'resources were'} added from your requirements. Their existence and sign-in availability were not verified.`});
   for(const app of snapshot?.applications||[])if(app.appId){const id=SnapshotResources.canonical(app.appId);apps.add(id);appNames[id]=app.displayName||id;}
   const groupsOfApps=new Set([...SnapshotResources.ids,'AllAgentIdResources']);
   for(const p of policies)for(const raw of [...p.conditions?.applications?.includeApplications||[],...p.conditions?.applications?.excludeApplications||[]]){const app=SnapshotResources.canonical(raw);if(app!=='All'&&!groupsOfApps.has(app))apps.add(app);}
   const resourceModel=SnapshotResources.prepare(policies,[...apps],snapshot?.resourceGroups||[],additionalResourceGroups);
   for(const group of additionalResourceGroups)if(resourceModel.errors.has(group))note(resourceModel.errors.get(group));
   resourceModel.applications.forEach(id=>apps.add(id));
   for(const group of SnapshotResources.ids)appNames[group]=SnapshotResources.names[group];
   const dimensions={application:[...apps],network:[...(snapshot?.namedLocations||[]).map(n=>n.id),'outside-known-locations'],platform:['windows','macOS','iOS','android','linux','unknown'],client:['browser','mobileAppsAndDesktopClients','exchangeActiveSync','easSupported','other'],flow:['standard','deviceCodeFlow','authenticationTransfer'],signInRisk:['none','low','medium','high','hidden','unknownFutureValue'],userRisk:['none','low','medium','high','hidden','unknownFutureValue'],insiderRisk:['none','minor','moderate','elevated','unknownFutureValue'],compliant:['true','false'],hybridJoined:['true','false'],authentication:['password','mfa','phishingResistant']};
   const strengths=SnapshotStrengths.prepare(snapshot?.authenticationStrengths);
   const minimumStrength=strength=>strengths.minimum(strength);
   // One symbolic boolean axis per context preserves simultaneous contexts without
   // enumerating their power set. OR-targeted contexts become policy branches.
   for(const p of policies.filter(p=>p.state==='enabled'))for(const id of p.conditions?.applications?.includeAuthenticationContextClassReferences||[]){
     if(/^c[1-9]\d?$/.test(id))dimensions['authenticationContext.'+id]=['false','true'];
   }
   dimensions.accessTarget=['application','authenticationContext','userAction'];
   // Until tenant/request rollout evidence is available, assess both documented
   // baseline-scope behaviors. The legacy branch is a possible request context,
   // not an assertion that the tenant still uses legacy enforcement.
   const directoryConstraints=[];
   if(directoryScopeUncertain){
     dimensions.directoryScopeEnforcement=['ordinary','legacyBaseline','currentBaseline'];
     directoryConstraints.push([
       {directoryScopeEnforcement:{include:['ordinary']}},
       {directoryScopeEnforcement:{include:['legacyBaseline','currentBaseline']},application:{include:[directoryResource]},accessTarget:{include:['application']}}
     ]);
   }
   const targetedRoles=[...new Set(policies.filter(p=>p.state==='enabled').flatMap(p=>[...p.conditions?.users?.includeRoles||[],...p.conditions?.users?.excludeRoles||[]]))];
   const roleNames=Object.fromEntries(roles.filter(r=>r.templateId).map(r=>[r.templateId,r.displayName||r.templateId]));
   for(const id of targetedRoles)dimensions['roleActive.'+id]=['false','true'];
   Object.assign(dimensions,resourceModel.dimensions);
   const targetedGroups=[...new Set(policies.filter(p=>p.state==='enabled').flatMap(p=>[...p.conditions?.users?.includeGroups||[],...p.conditions?.users?.excludeGroups||[]]))];
   const symbolicGroupIds=new Set(targetedGroups.filter(id=>!groupIds.has(id)));
   if(!groupCatalogComplete)for(const row of [...snapshot?.roleAssignments||[],...snapshot?.roleEligibility||[]])if(!userIds.has(row.principalId)&&!groupIds.has(row.principalId))symbolicGroupIds.add(row.principalId);
   const pimSnapshot=snapshot?{...snapshot,groups:[...groups,...[...symbolicGroupIds].map(id=>({id}))]}:snapshot;
   const pimState=SnapshotPim.prepare(pimSnapshot,records,{groupIds:targetedGroups,roleIds:targetedRoles,fixedRoleAssignments:roleState.fixed,roleUnknownById,roleUnknownGroupsById,roleUnboundedGroupsById});
   const roleAxis=id=>pimState.roleAliases[id]||'roleActive.'+id;
   for(const id of targetedRoles)if(pimState.roleAliases[id])delete dimensions['roleActive.'+id];
   const groupEligibilityKnown=privilegedGroupAssignments.every(a=>pimState.completeFor(a.principalId));
   for(const [groupId,ids] of pimState.activation)if(pimState.completeFor(groupId))for(const id of ids)byId.get(id)?.eligibleGroupIds.push(groupId);
   for(const r of records)r.uncertainEligibleGroupIds=groups.filter(g=>!pimState.completeFor(g.id)).map(g=>g.id);
   if(!groupCatalogComplete){const completeEligibleGroupIds=groups.filter(g=>pimState.completeFor(g.id)).map(g=>g.id);for(const r of records)r.completeEligibleGroupIds=completeEligibleGroupIds;}
   if(privilegedGroupAssignments.some(a=>!pimState.completeFor(a.principalId)))records.forEach(r=>{r.privilegeKnown=false;});
   Object.assign(dimensions,pimState.dimensions);
   const potentialRoles=new Map(records.map(r=>[r.id,new Set()])),captured=SnapshotRoles.instant(snapshot?.capturedAtUtc),knownGroupEligibility=new Map();
   for(const row of Array.isArray(snapshot?.pimGroupEligibility)?snapshot.pimGroupEligibility:[])if(row.accessId==='member'&&SnapshotRoles.interval(row,captured)==='current'){
     if(!knownGroupEligibility.has(row.groupId))knownGroupEligibility.set(row.groupId,new Set());
     const selected=knownGroupEligibility.get(row.groupId);
     if(userIds.has(row.principalId))selected.add(row.principalId);else for(const id of pimState.fixed.get(row.principalId)||[])selected.add(id);
   }
   const currentGroupEligibility=(group,id)=>knownGroupEligibility.get(group)?.has(id)===true;
   for(const record of records)for(const group of record.eligibleGroupIds)if(!currentGroupEligibility(group,record.id)&&!pimState.fixed.get(group)?.has(record.id)&&!currentGroupMembers.get(group)?.has(record.id))record.uncertainEligibleGroupIds.push(group);
   for(const assignment of groupRoleAssignments){
     const group=assignment.principalId,role=assignment.roleDefinitionId,privilege=roleMap.get(role)?.isPrivileged,privileged=privilege===true;
     if(!pimState.completeFor(group)){for(const record of records){potentialRoles.get(record.id).add(role);if(privilege!==false)record.privilegeKnown=false;}continue;}
     for(const id of pimState.possible.get(group)||[]){const record=byId.get(id);if(!record)continue;
       if(!record.roleIds.includes(role))record.roleIds.push(role);
       if(typeof privilege!=='boolean')record.privilegeKnown=false;
       // Current membership establishes an existing assignment/eligibility.
       // For group activation, require a currently assigned role provider and a
       // known membership/eligibility source. Changing or double-eligible sources
       // stay possible until their activation relationship is established.
       const current=currentGroupMembers.get(group)?.has(id)===true;
       const certain=!roleState.classificationUnknown.has(assignment)&&(current||activeDirectoryRows.has(assignment)&&(pimState.fixed.get(group)?.has(id)||currentGroupEligibility(group,id)));
       if(certain)certainRoles.get(id).add(role);else potentialRoles.get(id).add(role);
       if(privileged){if(!activeDirectoryRows.has(assignment)||!pimState.fixed.get(group)?.has(id)||pimState.activation.get(group)?.has(id))record.pimEligible=true;else record.privileged=true;if(certain)record.privilegeTimingCertain=true;else record.privilegeTimingUncertain=true;}
     }
   }
   if(!groupCatalogComplete)for(const assignment of [...snapshot?.roleAssignments||[],...snapshot?.roleEligibility||[]])if(!userIds.has(assignment.principalId)&&!groupIds.has(assignment.principalId))for(const record of records){potentialRoles.get(record.id).add(assignment.roleDefinitionId);if(roleMap.get(assignment.roleDefinitionId)?.isPrivileged!==false)record.privilegeKnown=false;}
   for(const record of records)record.uncertainRoleIds=[...new Set([...record.roleIds,...potentialRoles.get(record.id)])].filter(id=>!certainRoles.get(record.id).has(id));
   const roleScheduleUncertainties=roleState.uncertainties.filter(u=>u.membership&&u.row.directoryScopeId==='/'&&!u.row.appScopeId&&roleMap.get(u.roleDefinitionId)?.isBuiltIn===true&&referencedRoles.has(roleMap.get(u.roleDefinitionId)?.templateId||u.roleDefinitionId)).map(u=>({...u,row:undefined,identityIds:userIds.has(u.principalId)?[u.principalId]:groupIds.has(u.principalId)?pimState.completeFor(u.principalId)?[...pimState.possible.get(u.principalId)||[]]:[...userIds]:[]})).filter(u=>u.identityIds.length);
   const groupStateUncertainties=policies.filter(p=>p.state==='enabled').map(p=>{
     const selectedGroups=[...p.conditions?.users?.includeGroups||[],...p.conditions?.users?.excludeGroups||[]],selectedRoles=[...p.conditions?.users?.includeRoles||[],...p.conditions?.users?.excludeRoles||[]];
     const timing=roleScheduleUncertainties.filter(u=>selectedRoles.includes(roleMap.get(u.roleDefinitionId)?.templateId||u.roleDefinitionId));
     const identityIds=[...new Set([...selectedGroups.flatMap(id=>[...pimState.uncertainByGroup.get(id)||[]]),...selectedRoles.flatMap(id=>[...pimState.uncertainByRole.get(id)||[]]),...timing.flatMap(u=>u.identityIds)])];
     const dependencyGroups=[...selectedGroups,...groupRoleAssignments.filter(a=>selectedRoles.includes(roleMap.get(a.roleDefinitionId)?.templateId||a.roleDefinitionId)).map(a=>a.principalId)];
     const errors=[...new Set([...dependencyGroups.flatMap(id=>[...pimState.reasons.get(id)||[]]),...selectedRoles.flatMap(id=>[...roleInventoryReasons.get(id)||[]]),...timing.map(u=>u.message)])];
     return {policyId:p.id,identityIds,message:errors.length?errors.join(' '):'Changing group-based eligibility needs activation-lifetime validation.'};
   }).filter(u=>u.identityIds.length);
   const externalModel=SnapshotExternal.prepare(policies,records),externalIdentityConditions=new Map();
   Object.assign(dimensions,externalModel.dimensions);
   for(const record of records){try{externalIdentityConditions.set(record.id,externalModel.identityConditions(record));}catch(e){note((record.displayName||record.id)+': '+e.message);externalIdentityConditions.set(record.id,{});}}
   const identityConditions=record=>({...externalIdentityConditions.get(record.id),...pimState.identity(record.id).conditions});
   const locationPartition=SnapshotLocations.build(snapshot?.namedLocations||[],{complete:snapshot?.completeness?.namedLocations===true,legacyTrustedKnown:Array.isArray(snapshot?.legacyMfaTrustedIpRanges),legacyTrustedIpRanges:snapshot?.legacyMfaTrustedIpRanges,legacyFederatedIntranetKnown:typeof snapshot?.legacyMfaFederatedIntranetEnabled==='boolean',legacyFederatedIntranetEnabled:snapshot?.legacyMfaFederatedIntranetEnabled,compliantNetworkLocations:snapshot?.compliantNetworkLocations,compliantNetworksKnown:snapshot?.completeness?.compliantNetworkLocations===true&&Array.isArray(snapshot?.compliantNetworkLocations)});
   dimensions.network=locationPartition.cells.map(c=>c.id);
   dimensions.userAction=['none','registerSecurityInformation','registerOrJoinDevices'];
   dimensions.registrationContext=['none','unspecified',...registrationContexts.map(c=>c.id)];
   const registrationConstraints=[
     {accessTarget:{include:['application','authenticationContext']},registrationContext:{include:['none']}},
     {accessTarget:{include:['userAction']},registrationContext:{include:['unspecified']}}
   ];
   for(const context of registrationContexts)registrationConstraints.push({accessTarget:{include:['userAction']},userAction:{include:[context.action]},application:{include:[context.resourceId]},flow:{include:[context.flow]},registrationContext:{include:[context.id]}});
   const deviceRules=[...policies.filter(p=>p.state==='enabled'&&p.conditions?.devices?.deviceFilter).map(p=>({id:p.id,...p.conditions.devices.deviceFilter})),...additionalDeviceRules];
   let deviceFilters;
   try{deviceFilters=SnapshotDevices.prepare(deviceRules);}catch(e){deviceFilters=SnapshotDevices.prepare([]);for(const rule of deviceRules)deviceFilters.errors.set(rule.id,e.message);}
   Object.assign(dimensions,deviceFilters.dimensions);
   const userActions={'urn:user:registersecurityinfo':'registerSecurityInformation','urn:user:registerdevice':'registerOrJoinDevices'};
   const registrationUncertainties=[];
   const securityActionStrength=policies.some(p=>p.state==='enabled'&&p.conditions?.applications?.includeUserActions?.includes('urn:user:registersecurityinfo')&&p.grantControls?.authenticationStrength);
   const compiled=[],policyNames={},policyOrigins=new Map(),roleTargets=new Map(),resourceTargets=new Map(),registrationStrengths=new Map(),strengthUncertainties=new Map(),grantUncertainties=new Map(),applicationFilterUncertainties=new Map(),rejectedPolicyEvidence=[],sessionRestrictions=new Map(),externalUncertainties=new Map();
   const emit=(policy,origin)=>{compiled.push(policy);policyOrigins.set(policy.id,origin);};
   const present=value=>value!==null&&value!==undefined&&value!==false&&value!==''&&(!Array.isArray(value)||value.length>0)&&(typeof value!=='object'||Array.isArray(value)||Object.keys(value).length>0);
   const checkKeys=(object,allowed,context)=>{for(const [key,value] of Object.entries(object||{}))if(!key.startsWith('@')&&!key.includes('@odata.')&&!allowed.includes(key)&&present(value))throw Error(`${context}: ${key} is not supported.`);};
   const resolveAssignments=(usersCondition,policyId)=>{
     checkKeys(usersCondition,['includeUsers','excludeUsers','includeGroups','excludeGroups','includeRoles','excludeRoles','includeGuestsOrExternalUsers','excludeGuestsOrExternalUsers'],'Account assignment');
     for(const field of ['includeUsers','excludeUsers','includeGroups','excludeGroups','includeRoles','excludeRoles'])if(usersCondition[field]!==undefined&&(!Array.isArray(usersCondition[field])||usersCondition[field].some(id=>typeof id!=='string'||!id.trim())))throw Error(`${field} must be a list of non-empty account, group or role IDs.`);
     const unknown={include:new Set(),exclude:new Set()},base={},legacyUnknownExclude=new Set();
     const resolve=(prefix)=>{
       const selected=new Set();
       for(const id of usersCondition[prefix+'Users']||[]){if(id==='All')records.forEach(u=>selected.add(u.id));else if(id==='None')continue;else if(id==='GuestsOrExternalUsers'){for(const record of records){const match=SnapshotExternal.legacy(record);if(match===true)selected.add(record.id);if(match===null){unknown[prefix].add(record.id);if(prefix==='exclude')legacyUnknownExclude.add(record.id);}}}else if(userIds.has(id))selected.add(id);else throw Error(`Unresolved account assignment: ${id}`);}
       for(const id of usersCondition[prefix+'Groups']||[]){if(!dimensions['groupMember.'+id])throw Error(`Unresolved group assignment: ${id}`);if(Array.isArray(members[id]))members[id].forEach(id=>{if(userIds.has(id))selected.add(id);});}
       for(const id of usersCondition[prefix+'Roles']||[]){if(unsupportedCustomRoles.has(id))throw Error('Custom directory roles cannot be targeted by Conditional Access policies.');if(!dimensions[roleAxis(id)])throw Error('Unresolved CA role assignment: '+id);records.filter(u=>u.activeRoleIds.includes(id)).forEach(u=>selected.add(u.id));}
       base[prefix]=new Set(selected);
       if(usersCondition[prefix+'GuestsOrExternalUsers']!==undefined&&usersCondition[prefix+'GuestsOrExternalUsers']!==null){const selection=SnapshotExternal.selector(usersCondition[prefix+'GuestsOrExternalUsers']);for(const record of records){const match=SnapshotExternal.matches(record,selection,snapshot?.tenantId);if(match===true)selected.add(record.id);if(match===null)unknown[prefix].add(record.id);}}
       return selected;
     };
     const included=resolve('include'),excluded=resolve('exclude'),uncertain=externalUncertainties.get(policyId)||new Set();
     for(const record of records)if(!excluded.has(record.id)&&((unknown.include.has(record.id)&&!included.has(record.id))||unknown.exclude.has(record.id)&&(included.has(record.id)||unknown.include.has(record.id)||(usersCondition.includeRoles||[]).some(id=>record.eligibleRoleIds.includes(id)||record.activeRoleIds.includes(id)))))uncertain.add(record.id);
     if(uncertain.size)externalUncertainties.set(policyId,uncertain);
     // Modern selectors are expanded into shared symbolic conditions below.
     // Only an unresolved legacy UserType still needs a lower bound here.
     return {includeUsers:[...base.include].filter(id=>!legacyUnknownExclude.has(id)),excludeUsers:[...new Set([...base.exclude,...legacyUnknownExclude])]};
   };
   for(const p of policies){
     if(!p.id||!p.conditions){rejectedPolicyEvidence.push(p);note('Malformed policy: id or conditions missing.',p.id);continue;}
     policyNames[p.id]=p.displayName||p.id;
     if(!['enabled','disabled','enabledForReportingButNotEnforced'].includes(p.state)){rejectedPolicyEvidence.push(p);note('Unrecognized policy state: '+p.state,p.id);continue;}
     if(p.state!=='enabled')continue;
     try{
       const c=p.conditions;
       if(c.clientApplications&&!c.users)continue; // Workload identities are outside the user analysis scope.
       checkKeys(p,['id','displayName','description','state','conditions','grantControls','sessionControls','createdDateTime','modifiedDateTime','templateId'],'Policy');
       checkKeys(c,['users','applications','platforms','clientAppTypes','signInRiskLevels','userRiskLevels','insiderRiskLevels','authenticationFlows','locations','devices'],'Policy conditions');
       let flowMethods=[];
       if(c.authenticationFlows!==undefined&&c.authenticationFlows!==null){
         if(typeof c.authenticationFlows!=='object'||Array.isArray(c.authenticationFlows))throw Error('Authentication-flow conditions must be an object.');
         checkKeys(c.authenticationFlows,['transferMethods'],'Authentication flows');
         if(typeof c.authenticationFlows.transferMethods!=='string'||!c.authenticationFlows.transferMethods.trim())throw Error('Authentication-flow conditions need a transfer-method selection.');
         flowMethods=c.authenticationFlows.transferMethods.split(',').map(v=>v.trim());
         if(flowMethods.length===1&&flowMethods[0]==='none')flowMethods=[];
         if(flowMethods.some(v=>!['deviceCodeFlow','authenticationTransfer'].includes(v)))throw Error('This policy transfer-method selection cannot yet be evaluated.');
       }
       if(!c.users)throw Error('User assignment is missing.');
       resolveAssignments(c.users,p.id); // Validate all role references before expanding activation states.
       roleTargets.set(p.id,{include:c.users.includeRoles||[],exclude:c.users.excludeRoles||[],includeGroups:c.users.includeGroups||[],excludeGroups:c.users.excludeGroups||[]});
       const assignment=resolveAssignments({...c.users,includeRoles:[],excludeRoles:[],includeGroups:[],excludeGroups:[]},p.id),conditions={};
       if([...(c.users.includeGroups||[]),...(c.users.excludeGroups||[]),...(c.users.includeRoles||[]),...(c.users.excludeRoles||[])].length)for(const record of records)for(const prefix of ['include','exclude']){const selection=externalModel.selectors.get(p.id)?.[prefix];if(selection&&SnapshotExternal.matches(record,selection,snapshot?.tenantId)===null){if(!externalUncertainties.has(p.id))externalUncertainties.set(p.id,new Set());externalUncertainties.get(p.id).add(record.id);}}
       const rawApplications=c.applications||{},a={...rawApplications,...(rawApplications.includeApplications?{includeApplications:rawApplications.includeApplications.map(SnapshotResources.canonical)}:{}),...(rawApplications.excludeApplications?{excludeApplications:rawApplications.excludeApplications.map(SnapshotResources.canonical)}:{})};
       checkKeys(a,['includeApplications','excludeApplications','includeAuthenticationContextClassReferences','includeUserActions','applicationFilter'],'Resource assignment');
       const unverifiedApplicationFilter=a.applicationFilter!==undefined&&a.applicationFilter!==null;
       if(unverifiedApplicationFilter){
         const filter=a.applicationFilter;
         if(!filter||typeof filter!=='object'||Array.isArray(filter)||!['include','exclude'].includes(filter.mode)||typeof filter.rule!=='string'||!filter.rule.trim())throw Error('Application filter needs an include/exclude mode and a non-empty rule.');
         checkKeys(filter,['mode','rule'],'Application filter');
       }
       const contexts=[...new Set(a.includeAuthenticationContextClassReferences||[])];
       const actions=[...new Set(a.includeUserActions||[])];
       if(flowMethods.length&&!actions.length&&!contexts.length&&!a.includeApplications?.includes('All')){
         a.excludeApplications=[...new Set([...a.excludeApplications||[],deviceRegistrationResource])];
         const exclusion={policyId:p.id,resourceId:deviceRegistrationResource,message:'Only an All-resources authentication-flow policy protects Device Registration Service.'};
         flowResourceExclusions.push(exclusion);notes.push({code:'flow-resource-scope',...exclusion});
       }
       if(unverifiedApplicationFilter&&(contexts.length||actions.length))throw Error('Mixed application-filter and action/context targets are not supported.');
       if(c.devices){checkKeys(c.devices,['deviceFilter'],'Devices');if(c.devices.deviceFilter){checkKeys(c.devices.deviceFilter,['mode','rule'],'Device filter');if(deviceFilters.errors.has(p.id))throw Error(deviceFilters.errors.get(p.id));if(actions.includes('urn:user:registerdevice'))throw Error('The device-registration action does not support device filters.');}}
       if(unverifiedApplicationFilter){
         // Upper bound only: explicit-resource/filter interaction is not yet
         // verified. Do not infer a resource exclusion or a protection from it.
         // Token resource filters can also affect registration/context requests.
         if(flowMethods.length&&!a.includeApplications?.includes('All'))conditions.application={exclude:[deviceRegistrationResource]};
       }else if(actions.length){
         if(contexts.length||a.includeApplications?.length||a.excludeApplications?.length)throw Error('Mixed app, action and context targets need separate evaluation.');
         if(actions.some(action=>!Object.hasOwn(userActions,action)))throw Error('Unrecognized user-action target.');
         conditions.accessTarget={include:['userAction']};
         conditions.userAction={include:actions.map(action=>userActions[action])};
       }else if(contexts.length){
         if(contexts.some(id=>!/^c[1-9]\d?$/.test(id)))throw Error('Unrecognized authentication context reference.');
         if(a.includeApplications?.length||a.excludeApplications?.length)throw Error('Mixed app and authentication-context targets need separate evaluation.');
         conditions.accessTarget={include:['authenticationContext']};
       }else{
         if(!a.includeApplications?.length)throw Error('No supported target resource assignment.');
         if([...a.includeApplications,...a.excludeApplications||[]].includes('00000003-0000-0000-c000-000000000000'))throw Error('Microsoft Graph is an umbrella resource. Explicit Graph targeting/exclusion needs underlying audience evidence and is not credited as a literal resource selector.');
         if([...a.includeApplications,...a.excludeApplications||[]].includes('AllAgentIdResources'))throw Error('Agent resource targeting is not supported.');
         if([...a.includeApplications,...a.excludeApplications||[]].some(id=>SnapshotResources.isGroup(id))){
           for(const group of [...a.includeApplications,...a.excludeApplications||[]].filter(id=>SnapshotResources.isGroup(id)))if(resourceModel.errors.has(group))throw Error(resourceModel.errors.get(group));
           resourceTargets.set(p.id,a);conditions.application={};
         }else conditions.application={...(a.includeApplications.includes('All')?{}:{include:a.includeApplications}),exclude:a.excludeApplications||[]};
         conditions.accessTarget={include:['application']};
       }
       const selector=(dimension,include,exclude=[])=>{
         if([...include,...exclude].some(v=>v!=='all'&&!dimensions[dimension].includes(v)))throw Error(`Unrecognized ${dimension} value.`);
         conditions[dimension]={...(include.includes('all')?{}:{include}),exclude:exclude.includes('all')?dimensions[dimension]:exclude};
       };
       if(c.platforms){checkKeys(c.platforms,['includePlatforms','excludePlatforms'],'Platforms');selector('platform',c.platforms.includePlatforms||[],c.platforms.excludePlatforms||[]);}
       if(c.clientAppTypes?.length)selector('client',c.clientAppTypes);
       if(c.signInRiskLevels?.length)selector('signInRisk',c.signInRiskLevels);
       if(c.userRiskLevels?.length)selector('userRisk',c.userRiskLevels);
       if(c.insiderRiskLevels){const risks=Array.isArray(c.insiderRiskLevels)?c.insiderRiskLevels:String(c.insiderRiskLevels).split(',').map(v=>v.trim());selector('insiderRisk',risks);}
       if(flowMethods.length)selector('flow',flowMethods);
       let unverifiedLocations=false;
       if(c.locations!==undefined&&c.locations!==null){
         if(typeof c.locations!=='object'||Array.isArray(c.locations))throw Error('Location conditions must be an object.');
         checkKeys(c.locations,['includeLocations','excludeLocations'],'Locations');
         for(const field of ['includeLocations','excludeLocations'])if(c.locations[field]!==undefined&&(!Array.isArray(c.locations[field])||c.locations[field].some(id=>typeof id!=='string'||!id.trim())))throw Error('Location selections must be lists of non-empty IDs.');
         unverifiedLocations=[...c.locations.includeLocations||[],...c.locations.excludeLocations||[]].some(id=>id!=='All'&&!Object.hasOwn(locationPartition.selectors,id));
         if(!unverifiedLocations){
           const include=SnapshotLocations.select(locationPartition,c.locations.includeLocations||[]),exclude=SnapshotLocations.select(locationPartition,c.locations.excludeLocations||[]);
           conditions.network=include.length?{include,exclude}:{exclude:dimensions.network};
         }
       }
       const details=[];
       details.push(...flowResourceExclusions.filter(e=>e.policyId===p.id).map(e=>e.message));
       if(actions.length)details.push('Protects '+actions.map(action=>userActions[action]==='registerSecurityInformation'?'security information registration':'device registration or join').join(' or ')+'. This does not establish registration completion or SSPR configuration.');
       const session=SnapshotSessions.prepare(p.sessionControls);details.push(...session.details);
       if(session.uncertain.length)sessionRestrictions.set(p.id,{controls:session.uncertain,configuration:Object.fromEntries(session.uncertain.map(key=>[key,Object.fromEntries(Object.entries(p.sessionControls[key]).filter(([field])=>!field.startsWith('@')))]))});
       const grant=p.grantControls||{};
       if(typeof grant!=='object'||Array.isArray(grant))throw Error('Grant controls must be an object.');
       checkKeys(grant,['operator','builtInControls','authenticationStrength','termsOfUse','customAuthenticationFactors'],'Grant controls');
       for(const field of ['builtInControls','termsOfUse','customAuthenticationFactors'])if(grant[field]!==undefined&&(!Array.isArray(grant[field])||grant[field].some(v=>typeof v!=='string'||!v.trim())))throw Error(`${field} must be a list of non-empty strings.`);
       if(grant.operator!==undefined&&!['AND','OR'].includes(grant.operator))throw Error('Grant operator must be AND or OR.');
       const extraGrants=['approvedApplication','compliantApplication','passwordChange','riskRemediation'];
       const builtins=grant.builtInControls||[];
       const hasStrength=grant.authenticationStrength!==undefined&&grant.authenticationStrength!==null;
       if(hasStrength&&builtins.includes('mfa'))throw Error('MFA and authentication strength cannot be combined in one Conditional Access policy.');
       if(builtins.includes('block')&&(builtins.length!==1||hasStrength||grant.termsOfUse?.length||grant.customAuthenticationFactors?.length))throw Error('Block cannot be combined with other grant controls.');
       const remediation=builtins.filter(v=>['passwordChange','riskRemediation'].includes(v));
       if(remediation.length){
         const required=remediation[0]==='passwordChange'?builtins.includes('mfa'):hasStrength;
         if(remediation.length!==1||grant.operator!=='AND'||!required||!c.userRiskLevels?.length||!a.includeApplications?.includes('All')||a.excludeApplications?.length||Object.keys(c).some(k=>!['users','applications','userRiskLevels'].includes(k)))throw Error('Risk remediation requires its documented authentication prerequisite, AND, user risk, all resources and no other conditions.');
       }
       if(actions.includes('urn:user:registerdevice')&&((grant.builtInControls||[]).some(g=>g!=='mfa')||c.clientAppTypes?.some(client=>client!=='all')))throw Error('Device registration only supports MFA/authentication-strength grants and no client-app filter.');
       if(actions.includes('urn:user:registerdevice')&&(grant.termsOfUse?.length||grant.customAuthenticationFactors?.length))throw Error('Device registration only supports MFA/authentication-strength grants.');
       const controls=[];
       const uncertainGrants=[];
       for(const control of grant.builtInControls||[]){
         if(control==='block')controls.push(null);
         else if(control==='mfa')controls.push({authentication:{include:['mfa','phishingResistant']}});
         else if(control==='compliantDevice')controls.push({compliant:{include:['true']}});
         else if(control==='domainJoinedDevice')controls.push({hybridJoined:{include:['true']}});
         else if(extraGrants.includes(control)){controls.push({});uncertainGrants.push(control);}
         else throw Error(`Unsupported grant: ${control}.`);
       }
       for(const field of ['termsOfUse','customAuthenticationFactors'])if(grant[field]?.length){controls.push({});uncertainGrants.push(field);}
       if(uncertainGrants.length){
         grantUncertainties.set(p.id,{controls:uncertainGrants,configuration:{operator:grant.operator,builtInControls:builtins,...Object.fromEntries(['termsOfUse','customAuthenticationFactors'].filter(k=>grant[k]?.length).map(k=>[k,grant[k]]))}});
         details.push('Other grant requirements are retained as unverified restrictions; they do not count as MFA, device compliance or blocked access.');
       }
       const controlsWithoutStrength=[...controls];
       if(grant.authenticationStrength!==undefined&&grant.authenticationStrength!==null){
         const strength=grant.authenticationStrength;
         if(!strength||typeof strength!=='object'||Array.isArray(strength)||typeof strength.id!=='string'||!strength.id)throw Error('Authentication-strength grant needs an object with a valid identifier.');
         let tiers;
         try{tiers=minimumStrength(strength);}catch(error){tiers=dimensions.authentication;strengthUncertainties.set(p.id,{message:error.message,evidence:strengths.evidence(strength)});details.push('Authentication-strength definition is unverified. Other grant controls are checked.');}
         controls.push({authentication:{include:tiers}});
       }
       let alternatives;
       if(controls.includes(null))alternatives=[];
       else if(!controls.length)alternatives=[{}];
       else if(grant.operator==='OR')alternatives=controls;
       else if(grant.operator==='AND'||controls.length===1){
         const merged={};for(const control of controls)for(const [key,value] of Object.entries(control))merged[key]=merged[key]?{include:merged[key].include.filter(v=>value.include.includes(v))}:value;
         if(Object.values(merged).some(s=>!s.include.length))alternatives=[];else alternatives=[merged];
       }else throw Error('Grant AND/OR operator missing.');
       // A lower bound on requests guaranteed to satisfy the grants. Unlike
       // credited protection, this may only eliminate a possible denial. An
       // unknown AND control/strength can deny anything; in OR a supported
       // alternative suffices. Authentication tiers alone do not prove that a
       // particular method satisfies a strength definition.
       const supportedGrantControls=builtins.filter(v=>['mfa','compliantDevice','domainJoinedDevice'].includes(v));
       const knownGrantAlternatives=supportedGrantControls.map(v=>v==='mfa'?{authentication:{include:['mfa','phishingResistant']}}:v==='compliantDevice'?{compliant:{include:['true']}}:{hybridJoined:{include:['true']}});
       const unknownGrantControl=hasStrength||uncertainGrants.length>0;
       let guaranteedGrants=controls.includes(null)?[]:grant.operator==='OR'?knownGrantAlternatives:unknownGrantControl?[]:alternatives;
       if(!controls.length&&!hasStrength)guaranteedGrants=[{}];
       if(session.uncertain.length)guaranteedGrants=[];
       // Missing location type/claims do not establish a Boolean network fact.
       // Keep an applicability upper bound and no protection, through the same
       // account/resource/action/role/device expansion as ordinary policies.
       if(unverifiedLocations){
         alternatives=[{}];controlsWithoutStrength.length=0;
         details.push('Location matching is unverified. No protection is credited from this policy; its other conditions limit which requests need investigation.');
         notes.push({policyId:p.id,message:'Location matching is unverified; no protection is credited from this policy. Independent policies can still prove a requirement.'});
       }
       const translated={id:p.id,state:'enabled',...assignment,conditions,grantAlternatives:alternatives,...(unverifiedLocations?{unverifiedLocations:true,guaranteedGrantAlternatives:guaranteedGrants}:{})};
       if(unverifiedApplicationFilter){
         translated.grantAlternatives=[{}];translated.unverifiedApplicationFilter=true;
         applicationFilterUncertainties.set(p.id,{mode:a.applicationFilter.mode,rule:a.applicationFilter.rule});
         details.push('Application-filter matching is unverified. No protection is credited from this policy; other policies are checked independently.');
         notes.push({policyId:p.id,message:'Application-filter matching is unverified; no protection is credited from this policy. Independent policies can still prove a requirement.'});
         emit(translated,p.id);policyDetails[p.id]=details;continue;
       }
       if(directoryScopeUncertain&&!actions.length&&!contexts.length&&a.excludeApplications?.length)conditions.directoryScopeEnforcement={include:['ordinary','currentBaseline']};
       if(!actions.length&&!contexts.length){
         const universal=a.includeApplications.includes('All')&&!a.excludeApplications?.length;
         if(!universal&&registrationContexts.length){
           const id=p.id+':registration:resource';
           emit({...translated,id,conditions:{...conditions,accessTarget:{include:['userAction']},registrationContext:{include:registrationContexts.map(c=>c.id)}}},p.id);policyNames[id]=p.displayName||p.id;
         }
         if(universal&&!(grant.authenticationStrength&&securityActionStrength))conditions.accessTarget={include:['application','userAction']};
         else if(universal){
           registrationStrengths.set(p.id,{full:alternatives,mixedOr:grant.operator==='OR'&&controlsWithoutStrength.length>0});
           // Action-targeted strength takes priority in security-info interrupt mode.
           // Until method/flow-specific precedence is resolved, omit the inherited
           // strength as a protection lower bound. AND retains the other grants;
           // OR is weakened to unrestricted rather than accidentally strengthened.
           let withoutStrength;
           if(controlsWithoutStrength.includes(null))withoutStrength=[];
           else if(!controlsWithoutStrength.length)withoutStrength=[{}];
           else if(grant.operator==='OR')withoutStrength=[{}];
           else {const merged={};for(const control of controlsWithoutStrength)Object.assign(merged,control);withoutStrength=[merged];}
           for(const [action,grants] of [['registerOrJoinDevices',alternatives],['registerSecurityInformation',withoutStrength]]){
             const id=p.id+':registration:'+action;
             const managed=registrationContexts.filter(c=>c.action===action&&c.mode==='manage').map(c=>c.id);
             emit({...translated,id,conditions:{...conditions,accessTarget:{include:['userAction']},userAction:{include:[action]},...(action==='registerSecurityInformation'&&managed.length?{registrationContext:{exclude:managed}}:{})},grantAlternatives:grants,...(unverifiedLocations?{guaranteedGrantAlternatives:[]}:{})},p.id);policyNames[id]=p.displayName||p.id;
             if(action==='registerSecurityInformation'&&managed.length){const fullId=id+':manage';emit({...translated,id:fullId,conditions:{...conditions,accessTarget:{include:['userAction']},userAction:{include:[action]},registrationContext:{include:managed}},...(unverifiedLocations?{guaranteedGrantAlternatives:[]}:{})},p.id);policyNames[fullId]=p.displayName||p.id;}
           }
           registrationUncertainties.push({...assignment,policyId:p.id,action:'registerSecurityInformation',code:'registration-strength-precedence',message:'Security-information registration can override inherited authentication strength in interrupt mode. A method/flow-specific check is needed if the remaining policies do not prove your requirement.'});
         }else registrationUncertainties.push({...assignment,policyId:p.id,code:'registration-resource-context',message:'App-specific policies and resource exclusions need the registration resource/token context. An action-only What If request cannot establish that context. Only All-resources policies without resource exclusions and explicit action policies are credited.'});
       }
       if(contexts.length){
         contexts.forEach((context,index)=>{
           const id=index===0?p.id:p.id+':context:'+context;
           emit({...translated,id,conditions:{...conditions,['authenticationContext.'+context]:{include:['true']}}},p.id);
           if(index)policyNames[id]=(p.displayName||p.id)+' (context '+context+')';
         });
         details.push('Applies when authentication context '+contexts.join(' or ')+' is requested; ordinary app access does not trigger it.');
       }else emit(translated,p.id);
       policyDetails[p.id]=details;
       if(details.some(d=>d.startsWith('Reauthentication:')))notes.push({policyId:p.id,message:`${p.displayName||p.id}: ${details.filter(d=>d.startsWith('Reauthentication:')).join(' ')} Minimum authentication and device grants are evaluated.`});
     }catch(e){rejectedPolicyEvidence.push(p);note(`${p.displayName||p.id}: ${e.message}`,p.id);}
   }
   const resourceExpanded=[];
   for(const policy of compiled){const rawId=policyOrigins.get(policy.id),selection=resourceTargets.get(rawId);if(!selection){resourceExpanded.push(policy);continue;}try{SnapshotResources.clauses(selection,dimensions).forEach((clause,index)=>{const id=index?policy.id+':resource:'+index:policy.id;resourceExpanded.push({...policy,id,conditions:{...policy.conditions,...clause}});policyOrigins.set(id,rawId);policyNames[id]=policyNames[policy.id]||rawId;});}catch(e){note((policyNames[rawId]||rawId)+': '+e.message,rawId);}}
   const resourceGroupUncertainties=[...resourceTargets].map(([policyId,a])=>{
     const groups=[...new Set([...a.includeApplications,...a.excludeApplications||[]].filter(id=>SnapshotResources.isGroup(id)).map(id=>SnapshotResources.canonical(id)))];
     const relevant=resourceExpanded.filter(p=>policyOrigins.get(p.id)===policyId&&!p.grantAlternatives.some(a=>!Object.keys(a).length));
     const target=roleTargets.get(policyId),symbolic=target?.include.length||target?.includeGroups.length||externalModel.selectors.get(policyId)?.include?.types.length;
     const identityIds=relevant.length&&symbolic?[...userIds]:[...new Set(relevant.flatMap(p=>p.includeUsers.filter(id=>!p.excludeUsers.includes(id))))];
     const excludedUsers=policies.find(p=>p.id===policyId)?.conditions.users.excludeUsers||[];
     return {policyId,groups,unknownApplications:[...new Set(groups.flatMap(id=>resourceModel.unknown.get(id)||[]))].filter(id=>!a.excludeApplications?.includes(id)),identityIds:identityIds.filter(id=>!excludedUsers.includes('All')&&!excludedUsers.includes(id))};
   }).filter(u=>u.unknownApplications.length);
   const externalIncluded=[];
   for(const policy of resourceExpanded){
     externalIncluded.push(policy);const rawId=policyOrigins.get(policy.id),selection=externalModel.selectors.get(rawId)?.include;
     if(!selection||policy.includeUsers.length===userIds.size)continue;
     const extraUsers=[...userIds].filter(id=>!policy.includeUsers.includes(id));
     SnapshotExternal.conditions(selection).forEach((clause,i)=>{const id=policy.id+':external:'+i;externalIncluded.push({...policy,id,includeUsers:extraUsers,conditions:{...policy.conditions,...clause}});policyOrigins.set(id,rawId);policyNames[id]=policyNames[policy.id]||rawId;});
   }
   const roleExpanded=[];
   for(const policy of externalIncluded){
     const target=roleTargets.get(policyOrigins.get(policy.id));
     const included=[...new Set([...(target?.include||[]).map(roleAxis),...(target?.includeGroups||[]).map(id=>'groupMember.'+id)])],excluded=[...new Set([...(target?.exclude||[]).map(roleAxis),...(target?.excludeGroups||[]).map(id=>'groupMember.'+id)])];
     if(!included.length&&!excluded.length){roleExpanded.push(policy);continue;}
     const conditions={...policy.conditions,...Object.fromEntries(excluded.map(axis=>[axis,{include:['false']}]))};
     let branches=0;
     if(policy.includeUsers.length){roleExpanded.push({...policy,conditions});branches++;}
     for(const axis of included){
       if(excluded.includes(axis))continue;
       const id=branches?policy.id+':assignment:'+axis:policy.id;
       roleExpanded.push({...policy,id,includeUsers:[...userIds],conditions:{...conditions,[axis]:{include:['true']}}});policyOrigins.set(id,policyOrigins.get(policy.id));
       policyNames[id]=policyNames[policy.id]||policy.id;branches++;
     }
   }
   const externalExpanded=[],externalPartition=this.regions(dimensions);
   for(const policy of roleExpanded){
     const rawId=policyOrigins.get(policy.id),selection=externalModel.selectors.get(rawId)?.exclude;
     if(!selection){externalExpanded.push(policy);continue;}
     try{
       const initial=externalPartition.from(policy.conditions);let remaining=initial?[initial]:[];
       for(const clause of SnapshotExternal.conditions(selection))remaining=externalPartition.minus(remaining,externalPartition.from(clause));
       remaining.forEach((region,i)=>{const id=i?policy.id+':external-exclude:'+i:policy.id;externalExpanded.push({...policy,id,conditions:externalPartition.selectors(region)});policyOrigins.set(id,rawId);policyNames[id]=policyNames[policy.id]||rawId;});
     }catch(e){note((policyNames[rawId]||rawId)+': '+e.message,rawId);}
   }
   for(const uncertainty of registrationUncertainties){
     const target=roleTargets.get(uncertainty.policyId),external=externalModel.selectors.get(uncertainty.policyId);
     if(target?.include.length||target?.includeGroups?.length)uncertainty.includeUsers=[...userIds];
     if(external?.include)uncertainty.includeUsers=[...new Set([...uncertainty.includeUsers,...records.filter(r=>SnapshotExternal.matches(r,external.include,snapshot?.tenantId)!==false).map(r=>r.id)])];
     if(external?.exclude)uncertainty.excludeUsers=[...new Set([...uncertainty.excludeUsers,...records.filter(r=>SnapshotExternal.matches(r,external.exclude,snapshot?.tenantId)===true).map(r=>r.id)])];
   }
   const filterClauses=new Map(),deviceExpanded=[],deviceClaimUncertainties=[];
   const testsFalseCompliance=node=>node.kind==='atom'?node.property==='isCompliant'&&node.value==='false':node.kind==='not'?testsFalseCompliance(node.child):testsFalseCompliance(node.left)||testsFalseCompliance(node.right);
   for(const policy of externalExpanded){
     const rawId=policyOrigins.get(policy.id);
     if(!deviceFilters.parsed.has(rawId)){deviceExpanded.push(policy);continue;}
     try{
       if(testsFalseCompliance(deviceFilters.parsed.get(rawId).ast))deviceClaimUncertainties.push({policyId:rawId,includeUsers:policy.includeUsers,excludeUsers:policy.excludeUsers});
       if(!filterClauses.has(rawId))filterClauses.set(rawId,SnapshotDevices.compile(deviceFilters,rawId));
       filterClauses.get(rawId).forEach((clause,i)=>{const id=i?policy.id+':device:'+i:policy.id;deviceExpanded.push({...policy,id,conditions:{...policy.conditions,...clause}});policyNames[id]=policyNames[policy.id]||policy.id;policyOrigins.set(id,rawId);});
     }catch(e){note((policyNames[rawId]||rawId)+': '+e.message,rawId);}
   }
   const prioritized=[],interruptContexts=registrationContexts.filter(c=>c.mode==='interrupt').map(c=>c.id);
   const rawPolicies=new Map(policies.map(p=>[p.id,p]));
   const actionStrengths=deviceExpanded.filter(p=>{const raw=rawPolicies.get(policyOrigins.get(p.id));return raw?.conditions?.applications?.includeUserActions?.includes('urn:user:registersecurityinfo')&&raw?.grantControls?.authenticationStrength;});
   const targets=(p,id)=>(p.includeUsers.includes(id)||p.includeUsers.includes('*'))&&!p.excludeUsers.includes(id)&&!p.excludeUsers.includes('*');
   const partition=this.regions(dimensions);
   for(const policy of deviceExpanded){
     const rawId=policyOrigins.get(policy.id),priority=registrationStrengths.get(rawId);
     if(!priority||!interruptContexts.length||!policy.id.includes(':registration:registerSecurityInformation')||policy.id.includes(':manage')){prioritized.push(policy);continue;}
     try{
       const pending=[{...policy,conditions:{...policy.conditions,registrationContext:{include:['unspecified']}}}],cohorts=new Map();
       for(const record of records.filter(r=>targets(policy,r.id))){const eligible=actionStrengths.map((p,i)=>targets(p,record.id)?i:-1).filter(i=>i>=0),key=eligible.join(',');if(!cohorts.has(key))cohorts.set(key,{ids:[],eligible});cohorts.get(key).ids.push(record.id);}
       let branch=0;
       const emitPriority=(region,ids,grants)=>{const id=policy.id+':interrupt:'+(branch++);pending.push({...policy,id,includeUsers:ids,excludeUsers:[],conditions:partition.selectors(region),grantAlternatives:grants});policyNames[id]=policyNames[policy.id]||rawId;policyOrigins.set(id,rawId);partition.check(pending);};
       for(const cohort of cohorts.values()){
         const initial=partition.from({...policy.conditions,registrationContext:{include:interruptContexts}});let full=initial?[initial]:[],weak=[];
         for(const index of cohort.eligible){const cut=partition.from(actionStrengths[index].conditions),remaining=[];for(const rectangle of full){const overlap=partition.intersect(rectangle,cut);if(overlap)weak.push(overlap);remaining.push(...partition.subtract(rectangle,cut));partition.check([...weak,...remaining]);}full=remaining;}
         full.forEach(region=>emitPriority(region,cohort.ids,priority.full));weak.forEach(region=>emitPriority(region,cohort.ids,policy.grantAlternatives));
       }
       prioritized.push(...pending);
       for(const uncertainty of registrationUncertainties.filter(u=>u.policyId===rawId&&u.code==='registration-strength-precedence'))uncertainty.knownInterruptResolved=!priority.mixedOr;
     }catch(e){prioritized.push(policy);note((policyNames[rawId]||rawId)+': '+e.message,rawId);}
   }
   const countryLocationIds=(snapshot?.namedLocations||[]).filter(l=>String(l['@odata.type']||'').endsWith('.countryNamedLocation')).map(l=>l.id);
   const countryPolicyTargets=prioritized.filter(p=>{
     const c=rawPolicies.get(policyOrigins.get(p.id))?.conditions?.locations;
     if(![...c?.includeLocations||[],...c?.excludeLocations||[]].some(id=>countryLocationIds.includes(id)))return false;
     // A missing-location policy uses an all-network applicability upper bound.
     // Its omitted country predicate cannot add a mapping dependency. Likewise
     // a provably empty modeled policy cannot affect any request. Requirement
     // country selections retain their separate geography/catalog safeguards.
     return !!p.conditions.network&&!!partition.from(p.conditions);
   }).map(p=>({policyId:policyOrigins.get(p.id),identityIds:p.includeUsers.filter(id=>!p.excludeUsers?.includes(id))}));
   const locationUncertainties=locationPartition.geographyUncertain?countryPolicyTargets:[];
   const diagnosticEvidence={};
   if(snapshot&&(pimState.invalid.size||roleState.uncertainties.length||[...roleUnknownById.values(),...roleUnknownGroupsById.values(),...roleUnboundedGroupsById.values()].some(s=>s.size)||['groups','groupMembers','roles','roleAssignments','roleEligibility'].some(key=>snapshot.completeness?.[key]!==true))){
     // Unknown inventory is not semantically interchangeable with a different
     // failed export. Bind exact exceptions to the underlying directory facts.
     const evidenceFields=['groups','groupMembers','groupDirectMembers','pimGroupEligibility','pimGroupAssignments','roles','roleAssignments','roleEligibility','roleAssignmentScheduleInstances'];
     const completeness=Object.fromEntries(Object.entries(snapshot.completeness||{}).filter(([key])=>evidenceFields.includes(key)||/^(members|groupMembers|groupDirectMembers|pimGroupEligibility|pimGroupAssignments):/.test(key)));
     diagnosticEvidence.directoryInventory={completeness,...Object.fromEntries(evidenceFields.map(key=>[key,input[key]??null]))};
   }
   if(rejectedPolicyEvidence.length)diagnosticEvidence.rejectedPolicies=rejectedPolicyEvidence;
   const unresolvedLocationIds=[...new Set(policies.filter(p=>p.state==='enabled').flatMap(p=>['includeLocations','excludeLocations'].flatMap(key=>Array.isArray(p.conditions?.locations?.[key])?p.conditions.locations[key]:[])).filter(id=>typeof id==='string'&&!Object.hasOwn(locationPartition.selectors,id)))].sort();
   if(snapshot&&unresolvedLocationIds.length){
     diagnosticEvidence.locationInventory={unresolvedLocationIds,namedLocations:input.namedLocations??null,catalogComplete:snapshot.completeness?.namedLocations===true,
       policies:policies.filter(p=>p.state==='enabled'&&['includeLocations','excludeLocations'].some(key=>Array.isArray(p.conditions?.locations?.[key])&&p.conditions.locations[key].some(id=>unresolvedLocationIds.includes(id)))),authenticationStrengths:input.authenticationStrengths??null};
     if(unresolvedLocationIds.includes('AllTrusted'))Object.assign(diagnosticEvidence.locationInventory,{legacyMfaTrustedIpRanges:input.legacyMfaTrustedIpRanges??null,legacyMfaFederatedIntranetEnabled:input.legacyMfaFederatedIntranetEnabled??null,compliantNetworkLocations:input.compliantNetworkLocations??null,compliantNetworksComplete:snapshot.completeness?.compliantNetworkLocations===true});
   }
   const filteredPolicies=policies.filter(p=>p.state==='enabled'&&p.conditions?.applications?.applicationFilter!=null);
   if(filteredPolicies.length)diagnosticEvidence.applicationFilters={policies:filteredPolicies,definitions:snapshot?.applicationAttributeDefinitions??null,assignments:snapshot?.applicationAttributes??null,readScope:snapshot?.applicationAttributeReadScope??null,definitionsComplete:snapshot?.completeness?.applicationAttributeDefinitions===true,assignmentsComplete:snapshot?.completeness?.applicationAttributes===true,authenticationStrengths:snapshot?.authenticationStrengths??null};
   return {key:snapshot?.tenantId?'tenant:'+snapshot.tenantId:'policies:'+this.fingerprint(JSON.stringify(policies)),name:snapshot?.tenantName||snapshot?.tenantId||'Imported policies',kind:'snapshot',original:input,declaredApplications:additionalApplications,tenantId:snapshot?.tenantId,records,policies,policyNames,policyOrigins:Object.fromEntries(policyOrigins),translatedPolicyCount:new Set(prioritized.map(p=>policyOrigins.get(p.id))).size,policyDetails,flowResourceExclusions,appNames,roleNames,groupNames:Object.fromEntries(groups.map(g=>[g.id,g.displayName||g.id])),groupStateUncertainties,roleScheduleUncertainties,resourceGroupUncertainties,locationUncertainties,countryPolicyTargets,countryLocationIds,historyDomain:{kind:'snapshot',deviceRules,networkCells:locationPartition.cells.map(c=>({id:c.id,ranges:c.ranges,...(c.country?{country:c.country}:{})})),roleAliases:pimState.roleAliases},directoryScopeUncertain,resourceGroupChoices:SnapshotResources.ids,resourceGroupUnknown:Object.fromEntries(resourceModel.unknown),externalValueNames:{externalUserType:SnapshotExternal.valueLabels(),externalTenantId:{"other-external-tenant":"Other home tenant"}},registrationContextNames:Object.fromEntries(registrationContexts.map(c=>[c.id,(appNames[c.resourceId]||c.resourceId)+' / '+c.mode+' / '+c.flow])),deviceValueNames:deviceFilters.valueNames,issues,notes,assessmentScope:'Minimum authentication, device and blocked-access requirements. Application-filter matching, session timing, downstream session enforcement and application/PIM context invocation are not verified.',registrationPrerequisites,registrationUncertainties,applicationFilterUncertainties:[...applicationFilterUncertainties].map(([policyId,filter])=>({policyId,...filter})),grantUncertainties:[...grantUncertainties].map(([policyId,data])=>({policyId,...data})),strengthUncertainties:[...strengthUncertainties].map(([policyId,data])=>({policyId,...data})),sessionRestrictions:[...sessionRestrictions].map(([policyId,data])=>({policyId,...data})),deviceClaimUncertainties,externalIdentityUncertainties:[...externalUncertainties].map(([policyId,ids])=>({policyId,identityIds:[...ids]})),privilegeClassificationIssue:privilegedGroupAssignments.length&&!groupEligibilityKnown?'PIM group eligibility is missing or incomplete for groups assigned privileged roles. Export it with IncludePimGroups.':'',networkEvaluationSupported:true,locationPartition,locationSelectors:locationPartition.selectors,locationChoices:locationPartition.choices,networkNames:Object.fromEntries(locationPartition.cells.map(c=>[c.id,c.label])),model:{schemaVersion:1,...(Object.keys(diagnosticEvidence).length?{diagnosticEvidence}:{}),dimensions,identities:records.map(u=>({id:u.id,privileged:u.privileged,pimEligible:u.pimEligible,conditions:identityConditions(u),scenarioConstraints:pimState.identity(u.id).scenarioConstraints})),scenarioConstraints:[...deviceFilters.scenarioConstraints,...resourceModel.constraints,...directoryConstraints,registrationConstraints],policies:prioritized,requirements:[]}};
 },
 fingerprint(text){let h=2166136261;for(let i=0;i<text.length;i++)h=Math.imul(h^text.charCodeAt(i),16777619);return (h>>>0).toString(16);}
};
if(typeof module!=='undefined')module.exports=SnapshotModel;

