'use strict';

const $=s=>document.querySelector(s), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const names={directoryScopeEnforcement:'Directory scope enforcement',ordinary:'Ordinary resource request',legacyBaseline:'Low-privilege scopes: legacy enforcement (unverified)',currentBaseline:'Low-privilege scopes: current enforcement',userAction:'Activity',registerSecurityInformation:'Register security information',registerOrJoinDevices:'Register or join a device',android:'Android',windows:'Windows',linux:'Linux','outside-known-locations':'Other networks',accessTarget:'Access type',authenticationContext:'Authentication context',application:'Application',authentication:'Authentication',network:'Network',platform:'Platform',client:'Client',flow:'Authentication flow',standard:'Standard flow',deviceCodeFlow:'Device-code flow',authenticationTransfer:'Authentication transfer',low:'Low',medium:'Medium',high:'High',none:'None',mfa:'MFA',phishingResistant:'Phishing-resistant MFA',password:'Single-factor authentication',compliant:'Compliant device',block:'Blocked access',browser:'Browser',desktop:'Desktop client',mobileAppsAndDesktopClients:'Mobile & desktop clients',exchangeActiveSync:'Exchange ActiveSync',other:'Other / legacy clients',office:'Office network',internet:'Public internet',vpn:'Corporate VPN',sharepoint:'SharePoint',exchange:'Exchange Online',teams:'Teams',azure:'Azure management',finance:'Finance app',hr:'HR app',crm:'CRM app','new-app':'New app','vpn-app':'VPN app',true:'Yes',false:'No',hybridJoined:'Hybrid joined',signInRisk:'Sign-in risk',userRisk:'User risk'};
Object.assign(names,{hidden:'Hidden / not disclosed',unknownFutureValue:'Unknown future value'});

const label=v=>String(v).startsWith('authenticationContext.')?'Authentication context '+String(v).slice('authenticationContext.'.length):String(v).startsWith('resourceGroup.')?'Resource group: '+appName(String(v).slice(14)):String(v).startsWith('groupMember.')?'Group: '+(source?.groupNames?.[String(v).slice(12)]||String(v).slice(12)):String(v).startsWith('groupActivation.')?'PIM activation: '+(source?.groupNames?.[String(v).slice(16)]||String(v).slice(16)):String(v).startsWith('roleActive.')?'Role active: '+(source?.roleNames?.[String(v).slice('roleActive.'.length)]||String(v).slice('roleActive.'.length)):names[v]?names[v]:String(v).startsWith('device.')?'Device '+String(v).slice(7).replace(/([A-Z])/g,letter=>' '+letter.toLowerCase()).replace(/\./g,' '):names[v]||v;

const scenarioValue=(key,value)=>key==='application'?appName(value):key==='network'?source.networkNames?.[value]||label(value):key.startsWith('resourceGroup.')?(value==='true'?'Included':'Not included'):key.startsWith('groupMember.')?(value==='true'?'Member':'Not a member'):key.startsWith('groupActivation.')?(value==='true'?'Activated':'Not activated'):key.startsWith('roleActive.')?(value==='true'?'Active':'Not active'):(key==='registrationContext'?source?.registrationContextNames?.[value]:null)||source?.externalValueNames?.[key]?.[value]||source?.deviceValueNames?.[key]?.[value]||label(value);
const accountClauseValue=c=>c.field==='accountEnabled'?(String(c.value).trim().toLowerCase()==='true'?'Enabled':'Disabled'):c.value;
const accountFieldName=field=>({userType:'User type (Member / Guest)',accountEnabled:'Account status',displayName:'Display name',userPrincipalName:'Sign-in name',mail:'Email address',otherMails:'Other email addresses',jobTitle:'Job title',department:'Department',companyName:'Company',creationType:'Account creation type',externalTenantId:'External home tenant ID',externalUserType:'External-user category',groupIds:'Group membership',eligibleGroupIds:'Eligible group membership',roleIds:'Directory role'}[field]||field);
Object.assign(names,{registrationContext:'Registration context',externalUserType:'External-user category',externalTenantId:'External home tenant','device.deviceOwnership':'Device ownership','device.deviceId':'Device ID','device.mdmAppId':'MDM application ID','device.isCompliant':'Device compliance','device.registered':'Registered device','device.trustType':'Device join type'});

let assessmentModel=null,selectedGapKey=null;
let sessionToken,source=null,profile=null,result=null,lab=null,filter='open',selection=null,editingSet=null,editingRequirement=null,manualSelection=new Set(),pendingAcceptance=null,busy=false,pollTimer=null,authGeneration=0,signinWindow=null;

async function api(path,body){const r=await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':sessionToken},body:JSON.stringify(body)});let data;try{data=await r.json();}catch{throw Error('The local service did not return a valid response.');}if(!r.ok)throw Error(data.error||'Request failed.');return data;}

function fail(e,target='#error'){const el=$(target);el.textContent=e.message||String(e);el.hidden=false;if(target==='#error')window.scrollTo({top:0,behavior:'smooth'});}

function clearError(){$('#error').hidden=true;}

function toast(text){$('#toast').textContent=text;$('#toast').hidden=false;setTimeout(()=>$('#toast').hidden=true,3500);}

function showTab(id){if(busy)return;if(id!=='data'&&!source){toast('Load a demo, snapshot or policy export first.');return;}if(id!=='data'&&!source.records.length){toast('A full snapshot with accounts is needed to continue. See the export instructions.');return;}document.querySelectorAll('.page').forEach(el=>el.hidden=el.id!==id);document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));if(id==='sets')renderSets();if(id==='requirements')renderRequirements();window.scrollTo({top:0,behavior:'smooth'});}

function download(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

async function saveProfile(next=profile){if(busy)throw Error('Wait for the coverage check to finish before changing its requirements.');await api('/api/workspace/save',{key:source.key,profile:next});profile=next;resetResults();}

function resetResults(){result=null;selection=null;$('#result-empty').hidden=false;$('#result-body').hidden=true;$('#download-results').disabled=true;}

function accountName(id){const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));return u?.displayName||u?.userPrincipalName||id;}

function appName(id){return source.appNames?.[id]||label(id);}
function selectableApps(){return [...new Set([...source.model.dimensions.application,...source.resourceGroupChoices||[]])];}

function policyName(id){return source.policyNames?.[id]||id;}

function resolvedSets(){return RequirementModel.resolve(profile.sets,source.records).resolved;}

function uniqueId(prefix){return prefix+'-'+crypto.randomUUID();}

function options(values,selected=[],formatter=label){return values.map(v=>`<option value="${esc(v)}" ${selected.includes(v)?'selected':''}>${esc(formatter(v))}</option>`).join('');}

function chosen(id){return [...$(id).selectedOptions].map(o=>o.value);}

async function adopt(next,original,{demo=false}={}){

 if(busy)throw Error('Wait for the coverage check to finish before replacing its data.');

 clearError();

 const stored=await api('/api/workspace/load',{key:next.key});let nextProfile=stored.profile||RequirementModel.defaults();

 if(!stored.profile&&demo)nextProfile.requirements=[{id:'demo-mfa',name:'All accounts require MFA',origin:'demo',accountSetId:'all',outcome:'mfa',enabled:true},{id:'demo-admin',name:'Privileged accounts require phishing-resistant MFA',origin:'demo',accountSetId:'privileged',outcome:'phishingResistant',enabled:true}];

 RequirementModel.resolve(nextProfile.sets,next.records);

 source=next;source.original=original;source.recordById=new Map(source.records.map(u=>[u.id,u]));profile=nextProfile;
 $('#edit-network-trust').hidden=!Array.isArray(original?.users)||!Array.isArray(original?.policies);

 $('#source-label').textContent=source.kind==='demo'?'Fictional tenant':source.name;

 $('#source-summary').hidden=false;$('#source-name').textContent=source.name;

 $('#source-counts').textContent=`${source.policies.length.toLocaleString()} ${source.policies.length===1?'policy':'policies'} · ${source.records.length.toLocaleString()} ${source.records.length===1?'account':'accounts'}`;

 const issues=source.issues;

 $('#source-issues').innerHTML=issues.length?`<div class="notice warning">${issues.length} coverage ${issues.length===1?'issue needs':'issues need'} review. <a href="#source-summary" id="expand-support">Show details</a></div>`:'<div class="notice">Ready to check minimum protection. Session timing is outside scope.</div>';

 if(issues.length)$('#expand-support').onclick=e=>{e.preventDefault();$('#source-summary details').open=true;};

 $('#policy-list').innerHTML=source.policies.map(p=>{const issue=issues.filter(i=>i.policyId===p.id);const state=p.state||'unknown';return `<div class="inventory-row"><strong>${esc(policyName(p.id))}</strong><span>${esc(state)}</span><span>${esc(issue.length?issue.map(i=>i.message).join(' '):state==='enabled'?((Object.hasOwn(source.policyDetails||{},p.id)||source.model.policies.some(p2=>p2.id===p.id))?'Evaluated'+(source.policyDetails?.[p.id]?.length?' · '+source.policyDetails[p.id].join(' '):''):'Outside supported user scope'):state==='reportOnly'||state==='enabledForReportingButNotEnforced'?'Report-only; not enforced':'Not enforced')}</span></div>`;}).join('')+(issues.some(i=>!i.policyId)?`<ul>${issues.filter(i=>!i.policyId).map(i=>`<li>${esc(i.message)}</li>`).join('')}</ul>`:'');

 resetResults();renderSets();renderRequirements();showTab('data');$('#source-summary').scrollIntoView({behavior:'smooth',block:'start'});

}

async function loadDemo(){

 if(busy)return;if(!lab)throw Error('Demo data is still loading. Try again in a moment.');authGeneration++;clearTimeout(pollTimer);

 const size=Number($('#demo-size').value), scenario=$('#demo-scenario').value,model=structuredClone(lab.baseline), mapping=new Map(model.identities.map(u=>[u.id,[]])), originals=model.identities, records=new Map(lab.directory.map(u=>[u.id,u]));

 model.identities=[];const directory=[];

 for(let i=0;i<size;i++){const u=originals[i%originals.length],copy=Math.floor(i/originals.length),id=copy?u.id+'-copy-'+(copy+1):u.id;model.identities.push({...u,id});directory.push({...records.get(u.id),id,privilegeKnown:true});mapping.get(u.id).push(id);}

 for(const entry of [...model.policies,...model.requirements])for(const key of ['includeUsers','excludeUsers'])if(entry[key])entry[key]=entry[key].flatMap(id=>id==='*'?['*']:mapping.get(id)||[]);

 const fault=lab.faults.find(f=>f.id===scenario);

 if(fault){let target=model.policies.find(p=>p.id===fault.policyId);for(const key of fault.path.slice(0,-1))target=target[key];target[fault.path.at(-1)]=structuredClone(fault.value);}

 const next={key:'demo:architecture',name:fault?fault.name:'Architecture lab · Clean baseline',kind:'demo',model,records:directory,policies:model.policies,policyNames:Object.fromEntries(Object.entries(lab.policyMetadata).map(([id,p])=>[id,p.name])),appNames:{},issues:[],networkEvaluationSupported:true};

 await adopt(next,model,{demo:true});toast('Demo loaded. Next: define accounts.');

}

function renderSets(){if(!source||!profile)return;const sets=resolvedSets();$('#set-list').innerHTML=`<article class="card set-card"><div class="row"><h2>All accounts</h2><span class="badge">Built-in</span></div><strong class="count">${source.records.length.toLocaleString()}</strong><p class="small">Every account present in this snapshot.</p></article>`+profile.sets.map(s=>{const resolved=sets.get(s.id);return `<article class="card set-card"><div class="row"><h2>${esc(s.name)}</h2><span class="badge ${resolved.unknown.length?'warn':''}">${s.kind==='manual'?'Selected accounts':s.kind==='privileged'?'Role-based':'Filters'}</span></div><strong class="count">${resolved.ids.length.toLocaleString()}</strong><p class="small">${s.kind==='manual'?'Selected explicitly by account ID.':s.kind==='privileged'?'Uses snapshot role classification, including PIM eligibility.':s.clauses.map(c=>`${c.not?'NOT ':''}${accountFieldName(c.field)} ${{equals:'=',startsWith:'starts with',endsWith:'ends with',contains:'contains',hasValue:'has a value'}[c.operator]} ${c.operator==='hasValue'?'':accountClauseValue(c)}`).map(esc).join(s.match==='any'?' OR ':' AND ')}${resolved.unknown.length?`<br><strong>${resolved.unknown.length} unresolved accounts</strong>`:''}</p><div class="row"><button class="text-button" data-edit-set="${esc(s.id)}">Edit definition</button>${['members','guests','privileged','breakglass'].includes(s.id)?'':`<button class="text-button" data-remove-set="${esc(s.id)}">Remove</button>`}</div></article>`;}).join('');document.querySelectorAll('[data-edit-set]').forEach(b=>b.onclick=()=>openSet(b.dataset.editSet));document.querySelectorAll('[data-remove-set]').forEach(b=>b.onclick=async()=>{try{if(profile.requirements.some(r=>r.accountSetId===b.dataset.removeSet||(r.excludeSetIds||[]).includes(b.dataset.removeSet)))throw Error('This set is used by a requirement. Update that requirement first.');await saveProfile({...profile,sets:profile.sets.filter(s=>s.id!==b.dataset.removeSet)});renderSets();}catch(e){fail(e);}});}

function clauseRow(c={field:'userType',operator:'equals',value:'Member'}){
 const row=document.createElement('div');row.className='clause';
 row.innerHTML=`<select aria-label="Account attribute">${options(RequirementModel.fields,[c.field],accountFieldName)}</select><select aria-label="Filter condition">${options(['equals','startsWith','endsWith','contains','hasValue'],[c.operator],v=>({equals:'Equals',startsWith:'Starts with',endsWith:'Ends with',contains:'Has this ID',hasValue:'Has a value'}[v]))}</select><input aria-label="Filter value" value="${esc(c.value)}" placeholder="Value or group/role ID"><select aria-label="Account status value" hidden>${options(['true','false'],[String(c.value).toLowerCase()],v=>v==='true'?'Enabled':'Disabled')}</select><button class="text-button" type="button" aria-label="Remove condition">×</button><label class="check"><input type="checkbox" ${c.not?'checked':''}>NOT</label>`;
 const selects=row.querySelectorAll('select'),value=row.querySelector('input:not([type=checkbox])'),status=selects[2];
 function update(){const boolean=selects[0].value==='accountEnabled';value.hidden=boolean;status.hidden=!boolean;
  for(const option of selects[1].options)option.disabled=boolean&&option.value!=='equals';
  if(boolean)selects[1].value='equals';value.disabled=selects[1].value==='hasValue';
  selects[1].querySelector('option[value=contains]').textContent=['groupIds','eligibleGroupIds','roleIds','otherMails','externalUserType'].includes(selects[0].value)?'Has this value':'Contains';
 }
 selects[0].onchange=update;selects[1].onchange=update;update();row.querySelector('button').onclick=()=>row.remove();return row;
}

function openSet(id=null){if(!source)return;editingSet=id;const s=profile.sets.find(s=>s.id===id)||{name:'',kind:'filter',match:'all',clauses:[{field:'userType',operator:'equals',value:'Member'}],accountIds:[]};$('#set-name').value=s.name;$('#set-kind').value=s.kind;$('#set-match').value=s.match||'all';manualSelection=new Set(s.accountIds||[]);$('#manual-search').value='';$('#clause-list').replaceChildren(...(s.clauses||[{field:'userType',operator:'equals',value:'Member'}]).map(clauseRow));$('#set-form-error').hidden=true;toggleSetKind();$('#set-dialog').showModal();}

function toggleSetKind(){$('#filter-editor').hidden=$('#set-kind').value!=='filter';$('#manual-editor').hidden=$('#set-kind').value!=='manual';renderManual();}

function renderManual(){if(!source)return;const query=$('#manual-search').value.toLowerCase();const records=source.records.filter(u=>JSON.stringify([u.displayName,u.userPrincipalName,u.id]).toLowerCase().includes(query));$('#manual-list').innerHTML=records.slice(0,150).map(u=>`<label class="check"><input type="checkbox" value="${esc(u.id)}" ${manualSelection.has(u.id)?'checked':''}>${esc(u.displayName||u.userPrincipalName||u.id)} <span class="small">${esc(u.userPrincipalName||u.id)} · ${esc(u.userType||'Unknown type')}</span></label>`).join('')+(records.length>150?'<p class="small">First 150 shown. Search to find another account.</p>':'');$('#manual-list').querySelectorAll('input').forEach(input=>input.onchange=()=>input.checked?manualSelection.add(input.value):manualSelection.delete(input.value));}

async function saveSet(e){e.preventDefault();try{const name=$('#set-name').value.trim();if(!name)throw Error('Name the account set.');const set={id:editingSet||uniqueId('set'),name,kind:$('#set-kind').value,match:$('#set-match').value,accountIds:[...manualSelection],clauses:[...$('#clause-list').children].map(row=>{const selects=row.querySelectorAll('select');return {field:selects[0].value,operator:selects[1].value,value:selects[0].value==='accountEnabled'?selects[2].value:row.querySelector('input:not([type=checkbox])').value.trim(),not:row.querySelector('input[type=checkbox]').checked};})};if(set.kind==='filter'&&set.clauses.some(c=>c.operator!=='hasValue'&&!c.value))throw Error('Enter a value for each filter.');const next={...profile,sets:[...profile.sets.filter(s=>s.id!==editingSet),set]};RequirementModel.resolve(next.sets,source.records);await saveProfile(next);$('#set-dialog').close();renderSets();toast('Account definition saved.');}catch(e){fail(e,'#set-form-error');}}

let editorChoices={apps:new Set(),networks:new Set(),clients:new Set(),platforms:new Set(),signInRiskLevels:new Set(),userRiskLevels:new Set()};
function deviceClauseRow(c={property:'deviceOwnership',operator:'eq',value:'Company'}){
 const row=document.createElement('div');row.className='clause';
 const properties=[...Object.keys(DeviceFilter.properties),...Array.from({length:15},(_,i)=>'extensionAttribute'+(i+1))];
 row.innerHTML=`<select aria-label="Device attribute">${options(properties,[c.property],v=>label('device.'+v))}</select><select aria-label="Device comparison">${options(['eq','ne','startswith','notstartswith','endswith','notendswith','contains','notcontains'],[c.operator],v=>({eq:'Equals',ne:'Does not equal',startswith:'Starts with',notstartswith:'Does not start with',endswith:'Ends with',notendswith:'Does not end with',contains:'Contains',notcontains:'Does not contain'}[v]))}</select><input aria-label="Device value" value="${esc(c.value)}" placeholder="Value"><button type="button" class="text-button" aria-label="Remove device condition">Remove</button>`;
 row.querySelector('button').onclick=()=>{row.remove();updateRequirementPreview();};return row;
}
$('#add-device-condition').onclick=()=>{$('#req-device-clauses').append(deviceClauseRow());updateRequirementPreview();};
function builderContext(){return {sets:profile.sets,appNames:Object.fromEntries(selectableApps().map(id=>[id,appName(id)])),networkNames:{...Object.fromEntries((source.model.dimensions.network||[]).map(id=>[id,label(id)])),...Object.fromEntries((source.locationChoices||[]).map(n=>[n.id,n.name])),...source.networkNames}};}
function renderRequirements(){
 if(!source||!profile)return;const resolved=resolvedSets(),context=builderContext();
 $('#requirement-list').innerHTML=profile.requirements.length?profile.requirements.map(r=>{
  let scope;try{scope=RequirementModel.scope(r,resolved);}catch{scope={confirmed:[],unknown:[]};}const count=scope.confirmed.length,scopeLabel=`${count} ${count===1?'account':'accounts'} ${scope.unknown.length?'confirmed ':''}in scope${scope.unknown.length?' / '+scope.unknown.length+(scope.unknown.length===1?' needs':' need')+' scope confirmation':''}`;
  const state=r.pendingSetup?.length?'NEEDS SETUP':r.enabled===false?'DISABLED':r.origin?.includes(':customized')?'CUSTOMIZED TEMPLATE':r.origin?.startsWith('template')?'TEMPLATE REQUIREMENT':'YOUR REQUIREMENT';
  return `<article class="card requirement-card"><div class="row"><div><div class="eyebrow">${state}</div><h2>${esc(r.name)}</h2><p class="requirement-sentence">${esc(RequirementBuilder.describe(r,context))}</p><span class="small">${esc(scopeLabel)}${r.enabled===false?' / Not included in checks':''}</span></div><div><button class="secondary" data-edit-req="${esc(r.id)}">Edit</button><button class="text-button" data-duplicate-req="${esc(r.id)}">Duplicate</button><button class="text-button" data-remove-req="${esc(r.id)}">Delete</button></div></div></article>`;
 }).join(''):'<div class="empty">Start with templates, or create a requirement of your own.</div>';
 document.querySelectorAll('[data-edit-req]').forEach(b=>b.onclick=()=>openRequirement(b.dataset.editReq));
 document.querySelectorAll('[data-remove-req]').forEach(b=>b.onclick=async()=>{try{await saveProfile({...profile,requirements:profile.requirements.filter(r=>r.id!==b.dataset.removeReq)});renderRequirements();}catch(e){fail(e);}});
 document.querySelectorAll('[data-duplicate-req]').forEach(b=>b.onclick=async()=>{try{const copy=structuredClone(profile.requirements.find(r=>r.id===b.dataset.duplicateReq));copy.id=uniqueId('req');copy.name+=' (copy)';await saveProfile({...profile,requirements:[...profile.requirements,copy]});renderRequirements();openRequirement(copy.id);}catch(e){fail(e);}});
}
function renderEditorChoices(field,values=[],nameFor=label){
 const query=field==='apps'?$('#req-app-search').value.trim().toLowerCase():'';
 const shown=values.filter(id=>!query||[nameFor(id),id].join(' ').toLowerCase().includes(query)).slice(0,100);
 $('#req-'+field).innerHTML=shown.map(id=>`<label class="check"><input type="checkbox" data-rule-choice="${field}" value="${esc(id)}" ${editorChoices[field].has(id)?'checked':''}><span>${esc(nameFor(id))}</span></label>`).join('')+(values.length>100?'<p class="small">Search to find more apps.</p>':'');
 if(field==='apps'&&source.original?.caGapSnapshotVersion===1&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(query)&&!values.includes(query)){
  const button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='Use this application ID';button.onclick=()=>{editorChoices.apps.add(query);$('#req-app-search').value='';renderEditorChoices('apps',selectableApps(),appName);updateRequirementPreview();};$('#req-apps').append(button);
 }
 document.querySelectorAll(`[data-rule-choice="${field}"]`).forEach(box=>box.onchange=()=>{if(box.checked)editorChoices[field].add(box.value);else editorChoices[field].delete(box.value);updateRequirementPreview();});
}
function readRequirementEditor(){
 const prior=profile.requirements.find(r=>r.id===editingRequirement),target=$('#req-target').value,scope=$('#req-app-scope').value,outcome=$('#req-outcome').value;
 const rule={...prior,id:editingRequirement||'preview',name:$('#req-name').value.trim(),accountSetId:$('#req-set').value,outcome,protections:[outcome,...($('#req-also-device').checked&&['mfa','phishingResistant','hybridJoined'].includes(outcome)?['compliant']:[]),...($('#req-also-hybrid').checked&&['mfa','phishingResistant','compliant'].includes(outcome)?['hybridJoined']:[])],flows:$('#req-flow-mode').value==='selected'?[...editorChoices.flows]:[],signInRiskLevels:$('#req-signin-risk-mode').value==='selected'?[...editorChoices.signInRiskLevels]:[],userRiskLevels:$('#req-user-risk-mode').value==='selected'?[...editorChoices.userRiskLevels]:[],apps:target==='apps'&&scope!=='all'?[...editorChoices.apps]:[],blockOtherApps:target==='apps'&&scope==='only',userAction:target.startsWith('action:')?target.slice(7):undefined,authenticationContextId:target.startsWith('context:')?target.slice(8)||undefined:undefined,networkMode:$('#req-network-mode').value,networks:[...editorChoices.networks],clients:[...editorChoices.clients],platforms:[...editorChoices.platforms],excludeSetIds:[...(prior?.excludeSetIds||[]).filter(id=>id!=='breakglass'),...($('#req-exclude-breakglass').checked?['breakglass']:[])],enabled:$('#req-enabled').checked};
 if($('#req-device-mode').value==='any')delete rule.deviceFilter;
 else rule.deviceFilter={mode:$('#req-device-mode').value,match:$('#req-device-match').value,clauses:[...$('#req-device-clauses').children].map(row=>({property:row.querySelectorAll('select')[0].value,operator:row.querySelectorAll('select')[1].value,value:row.querySelector('input').value.trim()}))};
 if(rule.userAction&&$('#req-registration-specific').checked){
   const context={resourceId:$('#req-registration-resource').value,mode:rule.userAction==='registerOrJoinDevices'?'deviceRegistration':$('#req-registration-mode').value,flow:$('#req-registration-flow').value};
   context.provenance=prior?.registrationContext&&['resourceId','mode','flow'].every(k=>prior.registrationContext[k]===context[k])?prior.registrationContext.provenance:{kind:'declared',description:'Context selected in the requirements builder; not an observed sign-in.'};rule.registrationContext=context;rule.flows=[];
 }else delete rule.registrationContext;
 if(rule.pendingSetup){rule.pendingSetup=RequirementBuilder.pending(rule);if(!rule.pendingSetup.length)delete rule.pendingSetup;}
 return rule;
}
function updateRequirementPreview(){
 const target=$('#req-target').value;
 $('#req-registration-context').hidden=!target.startsWith('action:');$('#req-registration-details').hidden=!$('#req-registration-specific').checked;$('#req-registration-mode-wrap').hidden=target!=='action:registerSecurityInformation';
 $('#req-device-selection').hidden=$('#req-device-mode').value==='any';
 $('#req-app-picker').hidden=target!=='apps';$('#req-app-selection').hidden=$('#req-app-scope').value==='all';$('#req-network-selection').hidden=$('#req-network-mode').value==='any';$('#req-device-wrap').hidden=!['mfa','phishingResistant','hybridJoined'].includes($('#req-outcome').value);$('#req-hybrid-wrap').hidden=!['mfa','phishingResistant','compliant'].includes($('#req-outcome').value);
 $('#req-flow-section').hidden=target.startsWith('action:')&&$('#req-registration-specific').checked;$('#req-flow-selection').hidden=$('#req-flow-mode').value!=='selected';
 const rule=readRequirementEditor();for(const [field,id] of [['signInRiskLevels','signin'],['userRiskLevels','user']]){const selected=$('#req-'+id+'-risk-mode').value==='selected';$('#req-'+id+'-risk-selection').hidden=!selected;if(selected&&!rule[field].length)rule.pendingSetup=[...new Set([...(rule.pendingSetup||[]),field])];}if(!rule.registrationContext&&$('#req-flow-mode').value==='selected'&&!rule.flows.length)rule.pendingSetup=[...new Set([...(rule.pendingSetup||[]),'flows'])];$('#req-preview').textContent=RequirementBuilder.describe(rule,builderContext());
 $('#req-app-chips').innerHTML=[...editorChoices.apps].map(id=>`<button type="button" class="chip" data-remove-app="${esc(id)}">${esc(appName(id))} / remove</button>`).join('');
 document.querySelectorAll('[data-remove-app]').forEach(b=>b.onclick=()=>{editorChoices.apps.delete(b.dataset.removeApp);renderEditorChoices('apps',selectableApps(),appName);updateRequirementPreview();});
 const pending=RequirementBuilder.pending(rule);
 $('#req-readiness').textContent=pending.length?'Finish setup: '+pending.map(f=>({apps:'choose apps',networks:'choose networks',accountSetId:'choose accounts',authenticationContextId:'choose an available context',signInRiskLevels:'choose sign-in risk levels',userRiskLevels:'choose user risk levels',flows:'choose authentication flows'}[f]||f)).join(', '):rule.userAction?'Checks registration protection, including All-resources policies. It does not check whether accounts have registered methods.':rule.networkMode!=='any'&&(!source.networkEvaluationSupported||rule.networks.some(id=>source.locationSelectors&&!Object.hasOwn(source.locationSelectors,id)))?'Not yet assessable: named-location evaluation is not available for this snapshot.':'';
}
function openRequirement(id=null){
 if(!source)return;editingRequirement=id;const r=profile.requirements.find(r=>r.id===id)||{name:'',accountSetId:'all',outcome:'mfa',enabled:true};
 $('#req-name').value=r.name;$('#req-set').innerHTML=options([...(r.accountSetId?[]:['']),'all',...profile.sets.map(s=>s.id)],[r.accountSetId||''],id=>id===''?'Choose an account set':id==='all'?'All accounts':profile.sets.find(s=>s.id===id).name);
 $('#req-outcome').value=r.outcome;$('#req-also-device').checked=(r.protections||[]).includes('compliant')&&r.outcome!=='compliant';$('#req-also-hybrid').checked=(r.protections||[]).includes('hybridJoined')&&r.outcome!=='hybridJoined';
 const contexts=Object.keys(source.model.dimensions).filter(k=>k.startsWith('authenticationContext.')).map(k=>'context:'+k.slice('authenticationContext.'.length));
 const targets=['apps','action:registerSecurityInformation','action:registerOrJoinDevices',...contexts];if(r.pendingSetup?.includes('authenticationContextId'))targets.push('context:');
 const selected=r.userAction?'action:'+r.userAction:r.authenticationContextId?'context:'+r.authenticationContextId:r.pendingSetup?.includes('authenticationContextId')?'context:':'apps';
 $('#req-target').innerHTML=options(targets,[selected],id=>id==='apps'?'Access an app':id==='action:registerSecurityInformation'?'Register security information (MFA / SSPR)':id==='action:registerOrJoinDevices'?'Register or join a device':id==='context:'?'Select an authentication context (export required)':'Authentication context '+id.slice(8));
 $('#req-registration-specific').checked=!!r.registrationContext;
 const resources=[...new Set([...source.model.dimensions.application.filter(id=>id!=='other-resource'),...(r.registrationContext?[r.registrationContext.resourceId]:[])])];
 $('#req-registration-resource').innerHTML=options(['',...resources],[r.registrationContext?.resourceId||''],id=>id?appName(id):'Choose a resource');$('#req-registration-mode').value=r.registrationContext?.mode==='interrupt'?'interrupt':'manage';$('#req-registration-flow').value=r.registrationContext?.flow||'standard';
 $('#req-app-scope').value=r.blockOtherApps?'only':r.apps?.length||r.pendingSetup?.includes('apps')?'selected':'all';$('#req-app-search').value='';
 $('#req-network-mode').value=r.networkMode||'any';$('#req-exclude-breakglass').checked=(r.excludeSetIds||[]).includes('breakglass');$('#req-exclude-breakglass').disabled=!profile.sets.some(s=>s.id==='breakglass');
 $('#req-device-mode').value=r.deviceFilter?.mode||'any';$('#req-device-match').value=r.deviceFilter?.match||'all';$('#req-device-clauses').replaceChildren(...(r.deviceFilter?.clauses||[{property:'deviceOwnership',operator:'eq',value:'Company'}]).map(c=>deviceClauseRow(c)));
 editorChoices=Object.fromEntries(['apps','networks','clients','platforms','flows','signInRiskLevels','userRiskLevels'].map(field=>[field,new Set(r[field]||[])]));
 renderEditorChoices('apps',selectableApps(),appName);
 renderEditorChoices('networks',source.locationChoices?.length?source.locationChoices.map(l=>l.id):source.model.dimensions.network,id=>builderContext().networkNames?.[id]||label(id));renderEditorChoices('clients',source.model.dimensions.client);renderEditorChoices('platforms',source.model.dimensions.platform);
 for(const [field,id,axis] of [['signInRiskLevels','signin','signInRisk'],['userRiskLevels','user','userRisk']]){$('#req-'+id+'-risk-mode').value=r[field]?.length?'selected':'any';$('#req-'+id+'-risk-mode').disabled=!source.model.dimensions[axis];renderEditorChoices(field,source.model.dimensions[axis]||[],v=>({none:'No risk',hidden:'Hidden / not disclosed',unknownFutureValue:'Unknown future value'}[v]||label(v)));}$('#req-risk-section').open=!!(r.signInRiskLevels?.length||r.userRiskLevels?.length);
 $('#req-flow-mode').value=r.flows?.length?'selected':'any';renderEditorChoices('flows',['standard','deviceCodeFlow','authenticationTransfer'],v=>({standard:'Standard / untracked sign-in',deviceCodeFlow:'Device code',authenticationTransfer:'Authentication transfer'}[v]));$('#req-flow-section').open=!!r.flows?.length;
 $('#req-enabled').checked=r.pendingSetup?.length?true:r.enabled!==false;$('#req-form-error').hidden=true;updateRequirementPreview();$('#requirement-dialog').showModal();
}
async function saveRequirement(e){
 e.preventDefault();try{
  const prior=profile.requirements.find(r=>r.id===editingRequirement),r=readRequirementEditor();r.id=editingRequirement||uniqueId('req');
  if(!r.name)r.name=(r.accountSetId==='all'?'All accounts':profile.sets.find(s=>s.id===r.accountSetId)?.name||'Accounts')+' - '+label(r.outcome);
  r.origin=prior?.origin?.startsWith('template')?prior.origin.replace(/:customized$/,'')+':customized':prior?.origin||'organization';
  for(const [field,id,name] of [['signInRiskLevels','signin','sign-in'],['userRiskLevels','user','user']])if($('#req-'+id+'-risk-mode').value==='selected'&&!r[field].length)throw Error('Select at least one '+name+' risk level.');
  if(!r.registrationContext&&$('#req-flow-mode').value==='selected'&&!r.flows.length)throw Error('Select at least one authentication flow.');
  if($('#req-target').value==='apps'&&$('#req-app-scope').value!=='all'&&!r.apps.length)throw Error('Select at least one app.');
  const next={...profile,requirements:[...profile.requirements.filter(r=>r.id!==editingRequirement),r]};if(r.enabled)RequirementModel.compile(next,source);
  await saveProfile(next);$('#requirement-dialog').close();renderRequirements();toast('Requirement saved.');
 }catch(e){fail(e,'#req-form-error');}
}
function openTemplates(){
 if(!source){toast('Load data first.');return;}
 const packs=[...new Set(RequirementBuilder.templates.map(t=>t.pack))];
 $('#template-catalog').innerHTML=packs.map(pack=>`<section class="template-pack"><h3>${esc(pack)}</h3>${RequirementBuilder.templates.filter(t=>t.pack===pack).map(t=>{const already=profile.requirements.some(r=>r.origin?.replace(/:customized$/,'')==='template:'+t.id);const preview=RequirementBuilder.create(t.id,'preview');return `<label class="template-choice"><input type="checkbox" data-template-id="${t.id}" ${already?'disabled':''}><span><strong>${esc(t.name)}${already?' / Already added':''}</strong><span class="small">${esc(t.description)}</span><span class="template-preview">${esc(RequirementBuilder.describe(preview,builderContext()))}</span>${t.setup?.length?'<span class="badge warn">Choose your apps, networks or context after adding</span>':''}</span></label>`;}).join('')}</section>`).join('');
 const update=()=>{const count=document.querySelectorAll('[data-template-id]:checked').length;$('#add-selected-templates').disabled=!count;$('#add-selected-templates').textContent=count?'Add '+count+' selected '+(count===1?'template':'templates'):'Select templates to add';};
 document.querySelectorAll('[data-template-id]').forEach(box=>box.onchange=update);update();$('#template-dialog').showModal();
}
$('#template-form').onsubmit=async e=>{e.preventDefault();try{const additions=[...document.querySelectorAll('[data-template-id]:checked')].map(box=>{const r=RequirementBuilder.create(box.dataset.templateId,uniqueId('req'));if(r.accountSetId!=='all'&&!profile.sets.some(s=>s.id===r.accountSetId)){r.accountSetId='';r.pendingSetup=[...new Set([...(r.pendingSetup||[]),'accountSetId'])];r.enabled=false;}return r;});await saveProfile({...profile,requirements:[...profile.requirements,...additions]});$('#template-dialog').close();renderRequirements();toast('Templates added. You can edit or delete any requirement.');}catch(e){fail(e);}};
function requirementFor(gap){return profile.requirements.find(r=>r.id===gap.requirementId||r.id+':outside-network'===gap.requirementId||r.id+':outside-apps'===gap.requirementId||r.id+':outside-device'===gap.requirementId);}
async function checkCoverage(){if(busy)return;try{clearError();if(!source?.records.length)throw Error('Import a full tenant snapshot with users before checking account coverage. A policy-only export cannot establish who is protected.');const compiled=RequirementModel.compile(profile,source);source=compiled.source;source.recordById=new Map(source.records.map(u=>[u.id,u]));busy=true;document.querySelectorAll('.tabs button,#run,#rerun').forEach(b=>b.disabled=true);$('#run').textContent='Checking…';const issues=[...source.issues,...compiled.issues];result=source.kind==='snapshot'?await api('/api/assess',{snapshot:source.original,profile}):await api('/api/analyze',{model:compiled.model,coverageIssues:issues,sourceKey:source.key});if(result.sourceKey){try{result.savedRuns=await api('/api/history',{sourceKey:result.sourceKey});}catch{result.savedRuns={runs:[],unavailable:true};}}assessmentModel=compiled.model;result.sourceName=source.name;result.requirements=profile.requirements;result.assessmentNotes=source.notes||[];result.assessmentScope=source.assessmentScope||'';result.evidenceScope=source.kind==='snapshot'?'Minimum-protection assessment; offline findings. Session timing is outside scope.':'Finite mock or imported model; no real sign-ins.';selection=null;selectedGapKey=null;filter='open';$('#search').value='';$('#requirement-filter').innerHTML='<option value="all">All requirements</option>'+profile.requirements.filter(r=>r.enabled!==false).map(r=>`<option value="${esc(r.id)}">${esc(r.name)}</option>`).join('');$('#result-empty').hidden=true;$('#result-body').hidden=false;$('#download-results').disabled=false;renderResults();}catch(e){fail(e);}finally{busy=false;document.querySelectorAll('.tabs button,#run,#rerun').forEach(b=>b.disabled=false);$('#run').textContent='Check coverage →';if(result)showTab('results');}}



function renderHistory(){
 const panel=$('#coverage-changes'),history=$('#coverage-history');panel.hidden=!result.changes;history.hidden=!result.savedRuns;
 if(!result.changes)return;
 const view=HistoryView.summary(result.changes),time=value=>RoleSchedules.instant(value)!==null?new Date(value).toLocaleString():'Time unavailable';
 panel.innerHTML=`<h2>${esc(view.title)}</h2>${view.details.map(text=>`<p>${esc(text)}</p>`).join('')}${result.changes.previousRunAtUtc?`<small>Compared with ${esc(time(result.changes.previousRunAtUtc))}</small>`:''}${view.examples.length?`<details><summary>Example accounts</summary><div class="chips">${view.examples.map(x=>`<span class="chip">${esc(accountName(x.accountId))} · ${x.kind==='new'?'New gaps':'Gaps closed'}</span>`).join('')}</div></details>`:''}`;
 const saved=result.savedRuns||{};
 $('#history-list').innerHTML=(saved.runs||[]).map(run=>`<div class="saved-run"><div><strong>${esc(time(run.runAtUtc))}</strong><small>${run.status!=='completeWithinModel'?'Incomplete check':`${run.score===null?'Not scored':esc(run.score)+'% coverage'} · ${esc(run.affected)} affected · ${esc(run.checked)} checked`}</small><small>Snapshot ${esc(time(run.snapshotCapturedAtUtc))}</small></div><button class="text-button" data-download-run="${esc(run.id)}">Export check</button></div>`).join('')+(saved.unavailable?'<p>Saved checks could not be loaded.</p>':saved.unreadable?'<p>Some saved checks could not be read.</p>':'')+(saved.runs?.length===saved.limit?`<p class="small">Latest ${saved.limit} checks shown.</p>`:'');
 document.querySelectorAll('[data-download-run]').forEach(button=>button.onclick=async()=>{try{const report=await api('/api/history',{sourceKey:result.sourceKey,runId:button.dataset.downloadRun});download(report,'ca-check-'+button.dataset.downloadRun);}catch(e){fail(e);}});
}
function protectionLabel(r){const controls=r?.protections||[r?.outcome||'mfa'];return controls.map(p=>p==='compliant'?'a compliant device':p==='hybridJoined'?'a hybrid-joined device':label(p)).join(' and ');}
function findingUnverified(g){return g.assessmentStatus===undefined?!result.coverageSummary?.requirements.find(r=>r.id===requirementFor(g)?.id)?.complete:g.assessmentStatus!=='gapWithinModel';}
function issueLabel(g){if(g.unassessed)return 'Requirement not checked';const r=requirementFor(g);if(g.requirementId.endsWith(':outside-device'))return 'Access from other devices is not blocked';if(g.requirementId.endsWith(':outside-apps'))return 'Access to other apps is not blocked';if(g.requirementId.endsWith(':outside-network'))return 'Access outside allowed networks';const controls=r?.protections||[r?.outcome||'mfa'],missing=[];if(controls.includes('block'))return 'Access should be blocked';if(controls.includes('phishingResistant')&&g.witness.authentication!=='phishingResistant')missing.push('Phishing-resistant MFA missing');else if(controls.includes('mfa')&&g.witness.authentication==='password')missing.push('MFA missing');if(controls.includes('compliant')&&g.witness.compliant!=='true')missing.push('Compliant device missing');if(controls.includes('hybridJoined')&&g.witness.hybridJoined!=='true')missing.push('Hybrid-joined device missing');return missing.join(' / ')||'Requirement not met';}
function scenarioScope(g){if(g.unassessed)return requirementFor(g)?.name||'Requirement not checked';if(g.witness.accessTarget==='userAction')return label(g.witness.userAction);if(g.witness.accessTarget==='authenticationContext')return 'Authentication-context request';const apps=g.region.application||[];const app=apps.length===source.model.dimensions.application.length?'All apps':apps.length===1?appName(apps[0]):'Multiple apps';const networks=g.region.network||[];const platforms=g.region.platform||[],platform=platforms.length&&platforms.length<(source.model.dimensions.platform?.length||0)?' / '+platforms.map(label).join(', '):'';return app+' / '+(networks.length===source.model.dimensions.network.length?'Any network':networks.map(n=>source.networkNames?.[n]||label(n)).join(', '))+platform;}
function renderResults(){
 const summary=CoverageSummary.build(result,assessmentModel,profile.requirements);result.coverageSummary=summary;
 const unresolved=!summary.complete;renderHistory();
 $('#result-subtitle').textContent=source.name+' / '+(source.kind==='snapshot'?(RoleSchedules.instant(source.original?.capturedAtUtc)!==null?'Snapshot '+new Date(source.original.capturedAtUtc).toLocaleString():'Snapshot time not supplied or invalid'):'Checked '+new Date(result.runAtUtc).toLocaleString())+' / Compared with your saved requirements';
 $('#result-status').className='notice '+(unresolved?'warning':summary.toReview?'danger':summary.affected?'warning':'success');
 $('#result-status').textContent=unresolved?'This check is incomplete. Some accounts or policies still need investigation.':summary.toReview?`${summary.toReview} ${summary.toReview===1?'account needs':'accounts need'} attention.`:summary.affected?`${summary.affected} ${summary.affected===1?'account has':'accounts have'} accepted exceptions.`:summary.checked?'All checked accounts meet your requirements.':'No accounts are covered by these requirements.';
 $('#metrics').innerHTML=`<div class="score-card"><span>Coverage score</span><strong>${summary.score===null?'Not scored':summary.score+'%'}</strong><progress max="100" value="${summary.score||0}" aria-label="Accounts meeting every requirement" ${summary.score===null?'hidden':''}></progress><small>${summary.complete?`${summary.passed} of ${summary.checked} checked accounts meet every requirement`:'Resolve the incomplete checks before scoring'}</small></div><div class="impact-card ${summary.affected?'':'clear'}"><span>${summary.unverifiedOnlyAffected?'Accounts flagged':'Accounts affected'}</span><strong>${summary.affected}</strong><small>${summary.unverifiedOnlyAffected?summary.confirmedAffected+' confirmed / '+summary.unverifiedOnlyAffected+' to investigate':summary.toReview+' to review'}${summary.acceptedOnly?' / '+summary.acceptedOnly+' with accepted exceptions':''}</small></div><div class="pass-card"><span>Meet all requirements</span><strong>${summary.passed===null?'--':summary.passed}</strong><small>${summary.complete?(summary.passed?'No gaps found for these accounts':'No accounts meet every requirement'):'Not confirmed while checks are incomplete'}</small></div><div><span>${summary.unassessedAccounts?'Accounts in scope':'Accounts checked'}</span><strong>${summary.checked}</strong><small>${summary.unchecked?summary.unchecked+' outside the checked scope':'All '+summary.total+' imported accounts are in scope'}</small></div>`;
 $('#coverage-issues').hidden=!result.coverageIssues?.length;$('#coverage-title').textContent=`${result.coverageIssues?.length||0} ${result.coverageIssues?.length===1?'check needs':'checks need'} investigation`;
 $('#coverage-list').innerHTML=(result.coverageIssues||[]).map(i=>`<li>${esc(i.message)}${i.accountIds?.length?' '+esc(i.accountIds.slice(0,5).map(accountName).join(', '))+(i.accountIds.length>5?' and '+(i.accountIds.length-5)+' others':''):''}</li>`).join('');
 $('#assessment-notes').hidden=!result.assessmentNotes?.length;$('#assessment-note-list').innerHTML=(result.assessmentNotes||[]).map(n=>`<li>${esc(n.message)}</li>`).join('');
 $('#analysis-detail-text').textContent=`${result.identityCount} imported accounts / ${result.identityProfileCount} distinct policy profiles / ${result.gaps.length} grouped scenarios / ${result.elapsedMilliseconds} ms engine time. Accepted exceptions remain included in the coverage score.`;
 $('#requirement-coverage-rows').innerHTML=summary.requirements.map(r=>`<div class="requirement-result"><div><strong>${esc(r.name)}</strong><small>${r.checked} ${r.checked===1?'account':'accounts'} ${r.unassessed?'in scope':'checked'}</small></div><button class="${r.affected?'affected-link':'text-button'}" data-requirement="${esc(r.id)}">${esc(CoverageSummary.requirementLabel(r))}</button></div>`).join('');
 document.querySelectorAll('[data-requirement]').forEach(b=>b.onclick=()=>{$('#requirement-filter').value=b.dataset.requirement;renderResults();$('#accounts-title').scrollIntoView({behavior:'smooth',block:'start'});});
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
 const query=$('#search').value.trim().toLowerCase(),requirementId=$('#requirement-filter').value;
 const checks=[...result.gaps,...summary.unassessedChecks.map(c=>({key:'unassessed:'+c.requirementId,requirementId:c.requirementId,identityIds:c.accountIds,messages:c.messages,unassessed:true,assessmentStatus:'needsInvestigation'}))];
 const visible=checks.filter(g=>{
  const r=requirementFor(g),template=r?.origin?.startsWith('template')&&!r?.origin?.includes(':customized');
  return (filter==='all'||(filter==='accepted'?!!g.acceptance:!g.acceptance))&&(requirementId==='all'||r?.id===requirementId)&&($('#origin-filter').value==='all'||($('#origin-filter').value==='template'?template:!template));
 });
 const accountMap=new Map();for(const gap of visible)for(const id of gap.identityIds){if(!accountMap.has(id))accountMap.set(id,[]);accountMap.get(id).push(gap);}
 const accounts=[...accountMap].filter(([id,gaps])=>{const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));return !query||[accountName(id),u?.userPrincipalName,...gaps.map(g=>requirementFor(g)?.name),...gaps.map(issueLabel)].join(' ').toLowerCase().includes(query);}).sort(([a],[b])=>{const ua=source.recordById.get(a),ub=source.recordById.get(b);return Number(!!(ub?.privileged||ub?.pimEligible))-Number(!!(ua?.privileged||ua?.pimEligible))||accountName(a).localeCompare(accountName(b));});
 if(!accounts.some(([id])=>id===selection))selection=accounts[0]?.[0];
 $('#accounts-title').textContent=filter==='accepted'?'Accounts with accepted exceptions':filter==='all'?'All affected accounts':'Accounts to review';
 $('#account-list-count').textContent=`${accounts.length} ${accounts.length===1?'account':'accounts'}`;
 $('#finding-list').innerHTML=accounts.length?accounts.slice(0,150).map(([id,gaps])=>{const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id)),privileged=u?.privileged||u?.pimEligible;return `<button class="finding account-finding ${id===selection?'selected':''}" data-account="${esc(id)}"><div class="row"><span>${esc(u?.userType||'Account')}</span>${privileged?'<span class="badge privileged">Privileged</span>':''}</div><strong>${esc(accountName(id))}</strong><p class="account-upn">${esc(u?.userPrincipalName||'')}</p><div class="issue-tags">${[...new Set(gaps.map(g=>(findingUnverified(g)&&!g.unassessed?'Check: ':'')+issueLabel(g)))].map(t=>`<span>${esc(t)}</span>`).join('')}</div></button>`;}).join('')+(accounts.length>150?'<p class="small">First 150 accounts shown. Search to find another account.</p>':''):'<div class="empty">'+(checks.length?'No accounts match these filters.':summary.complete?'Every checked account meets your requirements.':'Finish the incomplete checks to confirm coverage.')+'</div>';
 document.querySelectorAll('[data-account]').forEach(b=>b.onclick=()=>{selection=b.dataset.account;selectedGapKey=null;renderResults();if(innerWidth<760)$('#finding-detail').scrollIntoView({behavior:'smooth'});});
 renderAccount(selection,accountMap.get(selection)||[]);
}
function renderAccount(id,gaps){
 gaps=[...gaps].sort((a,b)=>Number(findingUnverified(a))-Number(findingUnverified(b)));
 if(!id||!gaps.length){$('#finding-detail').innerHTML='<div class="empty">Select an account to see what is missing.</div>';return;}
 const u=(source.recordById?.get(id)||source.records.find(record=>record.id===id));if(!gaps.some(g=>g.key===selectedGapKey))selectedGapKey=gaps[0].key;
 $('#finding-detail').innerHTML=`<div class="eyebrow">ACCOUNT REVIEW</div><h2>${esc(accountName(id))}</h2><p class="account-upn">${esc(u?.userPrincipalName||id)}</p><div class="issue-tags">${u?.privileged?'<span>Privileged role</span>':''}${u?.pimEligible?'<span>PIM eligible</span>':''}</div><div class="scenario-picker">${gaps.map(g=>`<button class="${g.key===selectedGapKey?'selected':''}" data-scenario="${esc(g.key)}"><strong>${esc((findingUnverified(g)&&!g.unassessed?'Check: ':'')+issueLabel(g))}</strong><span>${esc(scenarioScope(g))}${g.acceptance?' / Accepted':''}</span></button>`).join('')}</div><div id="scenario-detail"></div>`;
 document.querySelectorAll('[data-scenario]').forEach(b=>b.onclick=()=>{selectedGapKey=b.dataset.scenario;renderAccount(id,gaps);});renderFinding(gaps.find(g=>g.key===selectedGapKey));
}
function renderUnassessedCheck(check){
 const req=requirementFor(check);
 $('#scenario-detail').innerHTML=`<div class="eyebrow">CHECK NOT COMPLETED</div><p class="scenario-requirement">${esc(req?.name||check.requirementId)}</p><div class="notice warning">${check.messages.map(message=>`<p>${esc(message)}</p>`).join('')}</div><p class="small">Resolve the missing or unsupported details, then check again.</p>`;
}
function policyTrace(p,witness){if(p.unverifiedLocations){const permits=p.guaranteedGrantAlternatives?.some(a=>Object.entries(a).every(([key,s])=>(!s.include?.length||s.include.includes(witness[key]))&&!s.exclude?.includes(witness[key])));return permits?'Its grants allow this example regardless of location.':'May apply; location matching is unverified. No protection credited.';}return p.unverifiedApplicationFilter?'May apply; app-filter matching and its grants are unverified.':'Applies; this sign-in satisfies its grants.';}
function renderFinding(gap){if(gap?.unassessed){renderUnassessedCheck(gap);return;}if(!gap){$('#scenario-detail').innerHTML='<p>Choose a finding to inspect its sign-in conditions.</p>';return;}const unverified=findingUnverified(gap),req=requirementFor(gap), outside=gap.requirementId===req?.id+':outside-network'||gap.requirementId===req?.id+':outside-apps'||gap.requirementId===req?.id+':outside-device', outcome=outside?'block':req?.outcome||'mfa';const actual=outcome==='block'?(unverified?'Not blocked by grants':'Sign-in permitted'):(req?.protections||[outcome]).includes('compliant')?label(gap.witness.authentication)+' / '+(gap.witness.compliant==='true'?'Compliant device':'Device not compliant'):label(gap.witness.authentication);const actualDetail=actual+((req?.protections||[outcome]).includes('hybridJoined')?' / '+(gap.witness.hybridJoined==='true'?'Hybrid-joined device':'Device not hybrid joined'):'');const matched=gap.applicablePolicyIds.map(id=>source.model.policies.find(p=>p.id===id)).filter(Boolean);const trace=matched.map(p=>`<div class="trace"><strong>${esc(policyName(p.id))}</strong><span>${policyTrace(p,gap.witness)}</span></div>`).join('');$('#scenario-detail').innerHTML=`<div class="eyebrow">${unverified?'NEEDS INVESTIGATION':'WHAT IS MISSING'}</div><p class="scenario-requirement">${esc(req?.name||gap.requirementId)}</p><div class="compare"><div><span>Your requirement</span><strong>${esc(outside?'Blocked access':protectionLabel(req))}</strong></div><div><span>${unverified?'Grants allow':'Policy allows'}</span><strong>${esc(actualDetail)}</strong></div></div><div class="detail-label">${unverified?'Possible gap to investigate':'Example where protection is missing'}</div><div class="witness">${visibleScenario(gap.witness,gap.witness).filter(([key,value])=>['application','platform','client','network'].includes(key)||key==='flow'&&(req?.flows?.length||value!=='standard'||gap.region.flow?.length<source.model.dimensions.flow?.length)||['signInRisk','userRisk'].includes(key)&&((key==='signInRisk'?req?.signInRiskLevels:req?.userRiskLevels)?.length||gap.region[key]?.length<source.model.dimensions[key]?.length)||key==='directoryScopeEnforcement'&&value!=='ordinary'||key==='userAction'||key==='externalUserType'||key==='externalTenantId'||key==='registrationContext'&&value!=='unspecified'&&value!=='none'||key.startsWith('authenticationContext.')||key.startsWith('device.')||key.startsWith('roleActive.')||key.startsWith('groupMember.')||key.startsWith('resourceGroup.')).map(([key,value])=>`<div><span>${esc(label(key))}</span><strong>${esc(scenarioValue(key,value))}</strong></div>`).join('')}</div><div class="detail-label">Policies applying to this example</div>${trace||'<p>No enabled policy applies to this example sign-in.</p>'}<details><summary>Why other policies do not apply</summary>${source.model.policies.filter(p=>!gap.applicablePolicyIds.includes(p.id)).map(p=>`<div class="trace"><strong>${esc(policyName(p.id))}</strong><span>${esc(nonMatchReason(p,gap))}</span></div>`).join('')}</details><details><summary>Affected accounts (${gap.identityIds.length}) & full conditions</summary><div class="chips">${gap.identityIds.slice(0,100).map(id=>`<span class="chip">${esc(accountName(id))}</span>`).join('')}</div>${gap.identityIds.length>100?'<p class="small">First 100 shown; export contains every account ID.</p>':''}${visibleScenario(gap.region,gap.witness).map(([key,values])=>`<p class="small"><strong>${esc(label(key))}</strong>: ${values.map(v=>esc(scenarioValue(key,v))).join(', ')}</p>`).join('')}</details>${gap.acceptance?`<div class="notice">Accepted: ${esc(gap.acceptance.reason)}</div>`:''}<div class="row bottom"><span class="small">Accepting an exception does not change protection.</span><button class="secondary" id="accept-current">${gap.acceptance?'Reopen exception':'Accept exception ('+gap.identityIds.length+' '+(gap.identityIds.length===1?'account':'accounts')+')'}</button></div>`;$('#accept-current').onclick=async()=>{if(gap.acceptance){try{const removedKeys=new Set([gap.key,...(gap.acceptance.recordKeys||[])]),shared=result.gaps.some(g=>g!==gap&&g.acceptance?.recordKeys?.some(k=>removedKeys.has(k)));await api('/api/accept',{key:gap.key,reopen:true});if(shared){await checkCoverage();}else{gap.acceptance=null;renderResults();}}catch(e){fail(e);}}else{pendingAcceptance=gap.key;$('#accept-scope').innerHTML='<p>This exception applies to '+gap.identityIds.length+' '+(gap.identityIds.length===1?'account':'accounts')+' with the same scenario:</p><div class="chips">'+gap.identityIds.map(id=>'<span class="chip">'+esc(accountName(id))+'</span>').join('')+'</div>';$('#accept-reason').value='';$('#accept-dialog').showModal();}};}

function nonMatchReason(p,g){const id=g.identityIds[0];if(p.excludeUsers?.includes(id)||p.excludeUsers?.includes('*'))return 'Account explicitly excluded.';if(!p.includeUsers?.includes('*')&&!p.includeUsers?.includes(id))return 'Account not in this assignment.';const flowExclusion=source.flowResourceExclusions?.find(e=>e.policyId===(source.policyOrigins?.[p.id]||p.id)&&e.resourceId===g.witness.application);if(flowExclusion)return flowExclusion.message;for(const [key,s] of Object.entries(p.conditions||{})){const value=g.witness[key];if(s.exclude?.includes(value))return `${label(key)} excluded: ${scenarioValue(key,value)}.`;if(s.include?.length&&!s.include.includes(value))return `${label(key)} does not match: ${scenarioValue(key,value)}.`;}return 'Not applicable to this example.';}

async function startOAuth(e){

 e.preventDefault();if(busy)return;

 if(signinWindow&&!signinWindow.closed){signinWindow.focus();return;}

 clearError();

 signinWindow=window.open('about:blank','ca-gap-sign-in','popup=yes,width=520,height=720');

 if(!signinWindow){fail(Error('Allow the sign-in popup and try again.'));return;}

 $('#connect-button').disabled=true;

 try{

  const generation=++authGeneration;clearTimeout(pollTimer);

  const response=await api('/api/oauth/start',{tenantId:$('#tenant-id').value.trim(),clientId:$('#client-id').value.trim(),includePimGroups:$('#include-pim-groups').checked,includeApplicationAttributes:$('#include-application-attributes').checked});

  signinWindow.location.href=response.authorizeUrl;

  $('#connection-state').textContent='Signing in…';$('#disconnect').hidden=false;

  pollOAuth(generation);

 }catch(e){signinWindow.close();signinWindow=null;$('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;fail(e);}

}

window.addEventListener('message',event=>{

 if(event.origin!==location.origin||event.source!==signinWindow||event.data?.type!=='ca-oauth-complete')return;

 window.focus();$('#connection-state').textContent='Finishing sign-in…';

});

async function pollOAuth(generation){

 if(generation!==authGeneration)return;

 try{

  const state=await api('/api/oauth/status',{});

  if(generation!==authGeneration)return;

  if(state.status==='complete'){

   if(busy||document.querySelector('dialog[open]')){$('#connection-state').textContent='Snapshot ready. Finish the current edit or check to load it.';pollTimer=setTimeout(()=>pollOAuth(generation),1500);return;}

   if(signinWindow&&!signinWindow.closed){try{signinWindow.close();}catch{}}

   const normalized=SnapshotModel.normalize(state.snapshot);await adopt(normalized,state.snapshot);

   $('#connection-state').textContent='Connected · Read-only snapshot collected.';$('#token-connection-state').textContent='Snapshot collected.';

   $('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#cancel-token').hidden=true;signinWindow=null;return;

  }

  if(state.status==='error')throw Error(state.message);

  if(state.status==='idle')throw Error('Sign-in is no longer active. Please try again.');

  if(state.status==='signingIn'&&signinWindow?.closed){await api('/api/oauth/disconnect',{});throw Error('Sign-in cancelled. Click Sign in with Microsoft to try again.');}

  $('#connection-state').textContent=state.status==='collecting'?'Connected · Reading policies, accounts and memberships…':'Signing in…';

  pollTimer=setTimeout(()=>pollOAuth(generation),1500);

 }catch(e){

  if(generation!==authGeneration)return;

  if(signinWindow&&!signinWindow.closed)signinWindow.close();signinWindow=null;

  $('#connect-button').disabled=false;$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;fail(e);$('#connection-state').textContent='Connection needs attention.';$('#token-connection-state').textContent='Collection needs attention.';

 }

}

const fullExport=`./Export-TenantSnapshot.ps1 -TenantId (az account show --query tenantId --output tsv) -OutputPath ./ca-tenant-snapshot.json`;
const policyExport=`$ErrorActionPreference = 'Stop'
$graphToken = az account get-access-token --resource https://graph.microsoft.com/ --query accessToken --output tsv
if ($LASTEXITCODE -ne 0 -or !$graphToken) { throw 'The existing Azure CLI session could not get a Graph token.' }
$headers = @{ Authorization = "Bearer $graphToken" }
try {
    $policies = [System.Collections.Generic.List[object]]::new()
    $next = 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies'
    $visited = [System.Collections.Generic.HashSet[string]]::new()
    while ($next) {
        $target = [uri]$next
        if ($target.Scheme -ne 'https' -or $target.Host -ne 'graph.microsoft.com' -or $target.Port -ne 443 -or $target.UserInfo -or !$visited.Add($next)) { throw 'Invalid Graph pagination link.' }
        $page = Invoke-RestMethod -Method GET -Uri $next -Headers $headers
        if ($null -eq $page.value) { throw 'Graph did not return policies.' }
        foreach ($policy in $page.value) { $policies.Add($policy) }
        $next = $page.'@odata.nextLink'
    }
    ConvertTo-Json -InputObject @($policies.ToArray()) -Depth 100 | Set-Content ./ca-policies.json -Encoding utf8
} finally {
    $graphToken = $null
    $headers.Clear()
}`;
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));document.querySelectorAll('[data-next]').forEach(b=>b.onclick=()=>showTab(b.dataset.next));document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$('#'+b.dataset.close).close());

$('#edit-network-trust').onclick=()=>{
 if(busy)return;
 const raw=source.original,ranges=raw.legacyMfaTrustedIpRanges;
 $('#legacy-ip-setting').value=Array.isArray(ranges)?ranges.length?'configured':'none':'unknown';
 $('#legacy-ip-ranges').value=Array.isArray(ranges)?ranges.join('\n'):'';
 $('#legacy-ip-ranges-label').hidden=$('#legacy-ip-setting').value!=='configured';
 $('#legacy-federated-setting').value=typeof raw.legacyMfaFederatedIntranetEnabled==='boolean'?String(raw.legacyMfaFederatedIntranetEnabled):'unknown';
 $('#network-trust-error').hidden=true;$('#network-trust-dialog').showModal();
};
$('#legacy-ip-setting').onchange=()=>$('#legacy-ip-ranges-label').hidden=$('#legacy-ip-setting').value!=='configured';
$('#network-trust-form').onsubmit=async e=>{
 e.preventDefault();if(busy)return;
 try{
  const original=structuredClone(source.original),mode=$('#legacy-ip-setting').value,flag=$('#legacy-federated-setting').value;
  if(mode==='unknown')delete original.legacyMfaTrustedIpRanges;
  else{
   const ranges=mode==='none'?[]:$('#legacy-ip-ranges').value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);
   if(mode==='configured'&&!ranges.length)throw Error('Enter the trusted IPv4 ranges, or choose No trusted IP ranges.');
   LocationModel.parseLegacyTrustedRanges(ranges);original.legacyMfaTrustedIpRanges=ranges;
  }
  if(flag==='unknown')delete original.legacyMfaFederatedIntranetEnabled;else original.legacyMfaFederatedIntranetEnabled=flag==='true';
  const next=SnapshotModel.normalize(original);next.key=source.key;next.kind=source.kind;next.name=source.name;
  await adopt(next,original);$('#network-trust-dialog').close();toast('Local settings updated. Save the snapshot to keep them.');
 }catch(error){fail(error,'#network-trust-error');}
};
$('#choose-file').onclick=()=>$('#source-file').click();$('#source-file').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>10485760)throw Error('Choose a JSON file smaller than 10 MB.');let input=JSON.parse(await file.text());const evidence=input?.resourceGroupEvidenceVersion===1;if(evidence)input=ResourceGroups.merge(source?.original,input);authGeneration++;clearTimeout(pollTimer);await adopt(SnapshotModel.normalize(input),input);toast(evidence?'Resource-group evidence added. Save the snapshot to keep it.':'JSON imported. Review the snapshot support details.');}catch(e){fail(e);}finally{e.target.value='';}};

$('#load-demo').onclick=()=>loadDemo().catch(fail);$('#download-source').onclick=()=>source&&download(source.original,'ca-snapshot.json');$('#new-set').onclick=()=>openSet();$('#set-kind').onchange=toggleSetKind;$('#manual-search').oninput=renderManual;$('#add-clause').onclick=()=>$('#clause-list').append(clauseRow());$('#set-form').onsubmit=saveSet;$('#new-requirement').onclick=()=>openRequirement();$('#requirement-form').onsubmit=saveRequirement;$('#open-templates').onclick=openTemplates;$('#run').onclick=checkCoverage;$('#rerun').onclick=checkCoverage;$('#download-results').onclick=()=>result&&download(result,'ca-coverage-results.json');$('#export-profile').onclick=()=>profile&&download(profile,'ca-requirements.json');$('#import-profile').onclick=()=>$('#profile-file').click();$('#profile-file').onchange=async e=>{try{const file=e.target.files[0];if(!file)return;const next=JSON.parse(await file.text());if(next.version!==1||!Array.isArray(next.requirements))throw Error('Choose an exported requirements configuration.');RequirementModel.resolve(next.sets,source.records);if(next.requirements.some(r=>r.enabled!==false))RequirementModel.compile(next,source);await saveProfile(next);renderSets();renderRequirements();toast('Configuration imported.');}catch(e){fail(e);}finally{e.target.value='';}};document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;if(result)renderResults();});$('#search').oninput=()=>result&&renderResults();$('#origin-filter').onchange=()=>result&&renderResults();$('#accept-form').onsubmit=async e=>{e.preventDefault();try{const response=await api('/api/accept',{key:pendingAcceptance,reason:$('#accept-reason').value});result.gaps.find(g=>g.key===pendingAcceptance).acceptance=response.acceptance;$('#accept-dialog').close();renderResults();}catch(e){$('#accept-dialog').close();fail(e);}};$('#connect-form').onsubmit=startOAuth;$('#disconnect').onclick=async()=>{try{authGeneration++;clearTimeout(pollTimer);$('#collect-token').disabled=false;$('#cancel-token').hidden=true;if(signinWindow&&!signinWindow.closed)signinWindow.close();signinWindow=null;$('#connect-button').disabled=false;await api('/api/oauth/disconnect',{});$('#connection-state').textContent='Connection cleared. Loaded data remains available until you close or replace it.';$('#disconnect').hidden=true;}catch(e){fail(e);}};$('#full-export-code').textContent=fullExport;$('#policy-export-code').textContent=policyExport;$('#redirect-uri').textContent=location.origin+'/oauth/callback';$('#copy-redirect').onclick=()=>navigator.clipboard.writeText(location.origin+'/oauth/callback').then(()=>toast('Redirect URI copied.')).catch(fail);document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>navigator.clipboard.writeText($('#'+b.dataset.copy).textContent).then(()=>toast('Commands copied.')).catch(fail));

(async()=>{try{const session=await api('/api/session');sessionToken=session.token;if(session.connection){if(!$('#tenant-id').value)$('#tenant-id').value=session.connection.tenantId;if(!$('#client-id').value)$('#client-id').value=session.connection.clientId;if(!$('#token-tenant-id').value)$('#token-tenant-id').value=session.connection.tenantId;}const returning=new URL(location.href);if(returning.searchParams.get('signin')==='return'){returning.searchParams.delete('signin');history.replaceState(null,'',returning.pathname+returning.search+returning.hash);$('#disconnect').hidden=false;$('#connect-button').disabled=true;pollOAuth(++authGeneration);}lab=await api('/api/lab');$('#demo-scenario').innerHTML='<option value="baseline">Clean baseline</option>'+lab.faults.map(f=>`<option value="${esc(f.id)}">${esc(f.name)}</option>`).join('');}catch(e){fail(e);}})();



for(const selector of ['#tenant-id','#client-id'])$(selector).addEventListener('change',()=>{const tenantId=$('#tenant-id').value.trim(),clientId=$('#client-id').value.trim();const guid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;if(sessionToken&&guid.test(tenantId)&&guid.test(clientId))api('/api/connection/save',{tenantId,clientId}).catch(fail);});



function toggleRequirementTarget(){updateRequirementPreview();}

$('#req-target').onchange=toggleRequirementTarget;$('#requirement-form').addEventListener('input',updateRequirementPreview);$('#requirement-form').addEventListener('change',updateRequirementPreview);$('#req-app-search').oninput=()=>renderEditorChoices('apps',selectableApps(),appName);

function visibleScenario(object,witness){return Object.entries(object).filter(([key])=>key!=='accessTarget'&&!key.startsWith('groupActivation.')&&(witness.accessTarget==='application'||!witness.accessTarget?key!=='userAction'&&!key.startsWith('authenticationContext.'):witness.accessTarget==='userAction'?key!=='application'&&!key.startsWith('authenticationContext.'):key!=='application'&&key!=='userAction'));}


$('#requirement-filter').onchange=()=>result&&renderResults();


$('#connection-method').onchange=()=>{
 const mode=$('#connection-method').value;
 $('#direct-connection').hidden=mode!=='direct';$('#cloudshell-connection').hidden=mode!=='cloudshell';$('#token-connection').hidden=mode!=='token';
 if(mode==='token'&&!$('#token-tenant-id').value)$('#token-tenant-id').value=$('#tenant-id').value;
};
$('#show-cloudshell-export').onclick=()=>{$('#cloudshell-export').open=true;$('#cloudshell-export').scrollIntoView({behavior:'smooth',block:'start'});};
$('#token-form').onsubmit=async e=>{
 e.preventDefault();if(busy)return;clearError();const accessToken=$('#existing-token').value.trim();$('#existing-token').value='';
 if(!accessToken){fail(Error('Paste a Microsoft Graph access token.'));return;}
 $('#collect-token').disabled=true;$('#connect-button').disabled=true;$('#cancel-token').hidden=false;
 try{
  const generation=++authGeneration;clearTimeout(pollTimer);
  await api('/api/token/collect',{tenantId:$('#token-tenant-id').value.trim(),accessToken,includePimGroups:$('#include-pim-groups').checked,includeApplicationAttributes:$('#include-application-attributes').checked});
  $('#token-connection-state').textContent='Reading tenant data...';pollOAuth(generation);
 }catch(e){$('#collect-token').disabled=false;$('#connect-button').disabled=false;$('#cancel-token').hidden=true;fail(e);}
};

$('#cancel-token').onclick=()=>$('#disconnect').click();

let referenceLab=null;
$('#load-reference').onclick=async()=>{try{if(!referenceLab)referenceLab=await api('/api/reference-lab');const selected=referenceLab.scenarios.find(s=>s.id===$('#reference-scenario').value)||referenceLab.scenarios[0];const normalized=SnapshotModel.normalize(selected.snapshot);normalized.key='demo:reference';normalized.kind='reference';normalized.name='Reference lab / '+selected.name;await adopt(normalized,selected.snapshot);if(!profile.requirements.length){await saveProfile(structuredClone(referenceLab.requirements));renderSets();renderRequirements();}toast('Synthetic reference loaded. Expected with bundled requirements: '+selected.expectedAccounts.length+'.');}catch(e){fail(e);}};
api('/api/reference-lab').then(pack=>{referenceLab=pack;$('#reference-scenario').innerHTML=pack.scenarios.map(s=>`<option value="${esc(s.id)}">${esc(s.name)} (${s.expectedAccounts.length} with bundled rules)</option>`).join('');}).catch(()=>{});

let referenceUndo=null;
$('#restore-reference').onclick=async()=>{try{if(source?.key!=='demo:reference'){toast('Load the reference tenant first.');return;}referenceUndo=structuredClone(profile);await saveProfile(structuredClone(referenceLab.requirements));$('#undo-reference').hidden=false;renderSets();renderRequirements();toast('Reference requirements restored. Undo is available below the reference loader.');}catch(e){fail(e);}};
$('#undo-reference').onclick=async()=>{if(!referenceUndo)return;try{await saveProfile(referenceUndo);referenceUndo=null;$('#undo-reference').hidden=true;renderSets();renderRequirements();toast('Previous reference requirements restored.');}catch(e){fail(e);}};

function updateExportOptions(){ $('#full-export-code').textContent=fullExport+($('#include-pim-groups').checked?' -IncludePimGroups':'')+($('#include-application-attributes').checked?' -IncludeApplicationAttributes':''); }
$('#include-pim-groups').onchange=updateExportOptions;$('#include-application-attributes').onchange=updateExportOptions;



