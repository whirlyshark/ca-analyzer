'use strict';
const RequirementBuilder={
 templates:[
  {id:'essential-mfa',pack:'Essential protection',name:'MFA for all accounts',description:'Every app, every network.',rule:{name:'All accounts require MFA',accountSetId:'all',outcome:'mfa'}},
  {id:'essential-legacy',pack:'Essential protection',name:'Block legacy authentication',description:'Block legacy client types for every app.',rule:{name:'Legacy authentication must be blocked',accountSetId:'all',outcome:'block',clients:['exchangeActiveSync','other']}},
  {id:'block-device-code',pack:'Authentication flows',name:'Block device code for app access',description:'Every app. Excludes your Breakglass account set; customise approved use cases.',rule:{name:'Device-code app access must be blocked',accountSetId:'all',outcome:'block',flows:['deviceCodeFlow'],excludeSetIds:['breakglass']}},
  {id:'block-auth-transfer',pack:'Authentication flows',name:'Block authentication transfer for app access',description:'Every app. Excludes your Breakglass account set; customise approved use cases.',rule:{name:'Authentication-transfer app access must be blocked',accountSetId:'all',outcome:'block',flows:['authenticationTransfer'],excludeSetIds:['breakglass']}},
  {id:'risky-signin-pr',pack:'Risk-based protection',name:'Phishing-resistant MFA for elevated sign-in risk',description:'Medium and high sign-in risk. Authentication strength only.',rule:{name:'Elevated-risk sign-ins require phishing-resistant MFA',accountSetId:'all',outcome:'phishingResistant',signInRiskLevels:['medium','high']}},
  {id:'high-risk-block',pack:'Risk-based protection',name:'Block high-risk sign-ins',description:'A stricter option: block access when sign-in risk is high.',rule:{name:'High-risk sign-ins must be blocked',accountSetId:'all',outcome:'block',signInRiskLevels:['high']}},
  {id:'high-user-risk-pr',pack:'Risk-based protection',name:'Phishing-resistant MFA for high user risk',description:'Authentication strength only; does not assess risk remediation.',rule:{name:'High-risk users require phishing-resistant MFA',accountSetId:'all',outcome:'phishingResistant',userRiskLevels:['high']}},
  {id:'privileged-pr',pack:'Privileged access',name:'Phishing-resistant MFA for privileged accounts',description:'Includes PIM-eligible accounts.',rule:{name:'Privileged accounts require phishing-resistant MFA',accountSetId:'privileged',outcome:'phishingResistant'}},
  {id:'device-registration',pack:'Registration protection',name:'MFA for device registration',description:'Require MFA when registering or joining a device.',rule:{name:'Device registration requires MFA',accountSetId:'all',userAction:'registerOrJoinDevices',outcome:'mfa'}},
  {id:'security-registration',pack:'Registration protection',name:'MFA for security-information registration',description:'Require MFA when registering security information for MFA or SSPR.',rule:{name:'Security-information registration requires MFA',accountSetId:'all',userAction:'registerSecurityInformation',outcome:'mfa'}},
  {id:'guest-networks',pack:'Guests and contractors',name:'Guest app access from approved networks',description:'Choose apps and networks; block access outside those networks.',setup:['apps','networks'],rule:{name:'Guests require MFA from approved networks',accountSetId:'guests',outcome:'mfa',networkMode:'must'}},
  {id:'managed-apps',pack:'Managed devices',name:'MFA and a compliant device for sensitive apps',description:'Choose the apps that need both protections.',setup:['apps'],rule:{name:'Sensitive apps require MFA and a compliant device',accountSetId:'all',outcome:'mfa',protections:['mfa','compliant']}},
  {id:'hybrid-apps',pack:'Managed devices',name:'MFA and a hybrid-joined device for Windows apps',description:'Choose the apps that require both protections on Windows.',setup:['apps'],rule:{name:'Windows app access requires MFA and a hybrid-joined device',accountSetId:'all',platforms:['windows'],outcome:'mfa',protections:['mfa','hybridJoined']}},
  {id:'context-pr',pack:'Privileged access',name:'Phishing-resistant MFA for an authentication context',description:'Choose the step-up context to protect.',setup:['authenticationContextId'],rule:{name:'Authentication context requires phishing-resistant MFA',accountSetId:'all',outcome:'phishingResistant'}}
 ],
 create(id,newId){
  const template=this.templates.find(t=>t.id===id);if(!template)throw Error('Unknown template.');
  return {...structuredClone(template.rule),id:newId,name:template.rule.name,origin:'template:'+id,enabled:!template.setup?.length,...(template.setup?.length?{pendingSetup:[...template.setup]}:{})};
 },
 pending(rule){return (rule.pendingSetup||[]).filter(field=>!rule[field]||(Array.isArray(rule[field])&&!rule[field].length));},
 describe(rule,context={}){
  const join=(items,conjunction='and')=>items.length<2?items[0]||'':items.slice(0,-1).join(', ')+' '+conjunction+' '+items.at(-1);
  const sets=context.sets||[],who=rule.accountSetId==='all'?'All accounts':sets.find(s=>s.id===rule.accountSetId)?.name||'Selected accounts';
  const names=(ids,lookup)=>ids.map(id=>lookup?.[id]||id);
  let activity='accessing '+(rule.apps?.length?join(names(rule.apps,context.appNames),'or'):rule.pendingSetup?.includes('apps')?'the apps you select':'any app');
  if(rule.userAction==='registerSecurityInformation')activity='registering security information for MFA or SSPR';
  else if(rule.userAction==='registerOrJoinDevices')activity='registering or joining a device';
  else if(rule.authenticationContextId)activity='requesting authentication context '+rule.authenticationContextId;
  else if(rule.pendingSetup?.includes('authenticationContextId'))activity='requesting the authentication context you select';
  const controls=rule.protections||[rule.outcome],protections=[];
  if(controls.includes('phishingResistant'))protections.push('phishing-resistant MFA');else if(controls.includes('mfa'))protections.push('MFA');
  if(controls.includes('compliant'))protections.push('a compliant device');
  if(controls.includes('hybridJoined'))protections.push('a hybrid-joined device');
  let text=controls.includes('block')?`${who} must be blocked from ${activity}.`:`${who} must use ${join(protections)||'the selected protection'} when ${activity}.`;
  if(rule.registrationContext){const c=rule.registrationContext;const resource=context.appNames?.[c.resourceId]||c.resourceId||'the resource you select';text+=' Check '+(c.mode==='interrupt'?'registration interrupting a sign-in to ':c.mode==='manage'?'direct security-information management for ':'device registration for ')+resource+' using '+({standard:'standard sign-in',deviceCodeFlow:'device code',authenticationTransfer:'authentication transfer'}[c.flow]||c.flow)+'.';}
  if(rule.networkMode==='must')text+=' Access must come from '+(rule.networks?.length?join(names(rule.networks,context.networkNames),'or'):'the networks you select')+'. Access from every other network must be blocked.';
  else if(rule.networkMode==='when')text+=' Check this requirement only from '+(rule.networks?.length?join(names(rule.networks,context.networkNames),'or'):'the networks you select')+'. Access from other networks is outside this requirement.';
  if(rule.blockOtherApps)text+=' Access to all other apps must be blocked.';
  if(rule.deviceFilter){
   const operators={eq:'is',ne:'is not',startswith:'starts with',notstartswith:'does not start with',endswith:'ends with',notendswith:'does not end with',contains:'contains',notcontains:'does not contain'};
   const attributes={deviceOwnership:'ownership',isCompliant:'compliance',trustType:'join type',displayName:'name',operatingSystem:'operating system',mdmAppId:'MDM application ID',deviceId:'device ID'};
   const clauses=rule.deviceFilter.clauses.map(c=>(attributes[c.property]||c.property.replace(/([A-Z])/g,c=>' '+c.toLowerCase()))+' '+(operators[c.operator]||c.operator)+' “'+(c.value||'…')+'”');
   text+=' Check devices where '+join(clauses,rule.deviceFilter.match==='any'?'or':'and')+'.';
   text+=rule.deviceFilter.mode==='must'?' Access from every other device must be blocked.':' Other devices are outside this requirement.';
  }
  if(rule.platforms?.length)text+=' Applies only to '+join(rule.platforms.map(v=>({windows:'Windows',android:'Android',linux:'Linux'}[v]||v)),'or')+' devices.';
  if(rule.clients?.length)text+=' Applies only to '+join(rule.clients.map(v=>({browser:'browser',mobileAppsAndDesktopClients:'mobile/desktop',exchangeActiveSync:'Exchange ActiveSync',other:'other legacy'}[v]||v)),'or')+' clients.';
  if(!rule.registrationContext&&(rule.flows?.length||rule.pendingSetup?.includes('flows')))text+=' Applies only to '+(rule.flows?.length?join(rule.flows.map(v=>({standard:'standard/untracked sign-in',deviceCodeFlow:'device code',authenticationTransfer:'authentication transfer'}[v]||v)),'or'):'the authentication flows you select')+'.';
  const riskNames={none:'none',low:'low',medium:'medium',high:'high',hidden:'hidden',unknownFutureValue:'an unknown future value'};
  const hasRisk=field=>rule[field]?.length||rule.pendingSetup?.includes(field),riskLevels=field=>rule[field]?.length?join(rule[field].map(v=>riskNames[v]||v),'or'):'at the levels you select';
  if(hasRisk('signInRiskLevels'))text+=' Check only when sign-in risk is '+riskLevels('signInRiskLevels')+'.';
  if(hasRisk('userRiskLevels'))text+=' '+(hasRisk('signInRiskLevels')?'User risk must also be ':'Check only when user risk is ')+riskLevels('userRiskLevels')+'.';
  if(rule.excludeSetIds?.length)text+=' Excludes '+join(rule.excludeSetIds.map(id=>sets.find(s=>s.id===id)?.name||id))+'.';
  return text;
 }
};
if(typeof module!=='undefined')module.exports=RequirementBuilder;
