# Country-based locations

Import a full snapshot containing named locations. IP-derived country locations
can be selected in requirements in the same way as named IP networks. No online
name lookup or geolocation service is needed for these checks.

A failed later catalog page does not invalidate complete country definitions
already collected. Those definitions remain selectable and share the same country
classification. Missing or conflicting definitions and unfinished objects remain
unverified. Catalog completeness is still required for aggregate trusted-network
selection; retaining a country definition does not supply IP-to-country evidence.

Geography warnings follow the predicates actually used by the model. If an
unavailable location causes a policy's country predicate to be omitted from its
applicability bound, that omitted predicate does not create a separate mapping
dependency. Provably empty modeled policy conditions do not create one either.
Explicit country requirements and remaining active country predicates retain
their mapping and country-catalog safeguards. The exported definitions are kept;
no IP-to-country facts are invented.

The analyzer checks overlapping country lists, inclusion/exclusion, unknown
countries and compensation by other policies. Every policy sees the same country
classification. A country excluded from one policy does not become protected
unless another applicable policy supplies the required protection or blocks access.

## What an export can prove

Country-only rules can be checked against declared country classifications.
Known countries outside the lists and an unknown country are distinct states,
even when the current policies treat them alike. Missing lookup method defaults
to IP-derived classification; missing include-unknown defaults to false, matching
the [Graph country-location schema](https://learn.microsoft.com/en-us/graph/api/resources/countrynamedlocation?view=graph-rest-1.0).

An export does not include Microsoft's IP-to-country mapping. If IP ranges and
country rules interact, the analyzer checks all possible classifications. A clean
result across those possibilities proves the modeled protection. Remaining
possible gaps are unverified; they need mapping/request evidence. An example IP
and country from that model are not proof that Microsoft maps that address to
that country. Microsoft's mapping changes over time; see
[network assignment](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-assignment-network).

A pinned set of 248 geographic codes from the
[UNSD M49 table](https://unstats.un.org/unsd/methodology/m49/overview/) supplies
ordinary country witnesses outside policy lists. It is not a complete Microsoft
classification catalog. If the lists exhaust these witnesses, remaining catchall
gaps stay unverified instead of asserting that another supported country exists.
This uncertainty clears when other policies protect the entire remaining region
or the requirement excludes that region.

GPS locations remain unsupported: Authenticator location sharing, validity and
method/flow dependencies need additional runtime evidence. The analyzer gives no
protection credit for a policy it cannot evaluate. No GPS fixtures were created in
the lab; even report-only GPS policies can cause prompts.

## Validation and saved checks

Sixteen independently specified Member/Guest × country × IP-family cases matched
Microsoft What If. Four requests without a country supplied were retained as
observations; the offline unknown-country state reproduces those results. These
are isolated report-only applicability checks, not real sign-in/enforcement proof.
The retained test fixture replaces tenant and directory identifiers.

Independent tests also cover account/app targeting, clients/platforms, AND/OR
grants, mandatory allowed networks, missing exports and sanitized input.
History compares actual IP intervals and country classifications, including
new codes split from an earlier catchall. It does not compare generated region
labels. Older reports establish a new baseline under model semantics
`ca-request-model-20261115-4` for country support. Later PIM interpretation changes
advanced the model to `ca-request-model-20261115-6`. Trusted-network metadata
guards now advance it to `ca-request-model-20261115-7`; see
[trusted networks](NETWORK-TRUST.md).
Legacy trusted-IP union and federated-intranet guards subsequently advance the
current interpretation to `ca-request-model-20261116-1`.
Session-control grant projection subsequently advances it to
`ca-request-model-20261116-2`.
Authentication-strength consistency subsequently advances the current
interpretation to `ca-request-model-20261116-3`.
