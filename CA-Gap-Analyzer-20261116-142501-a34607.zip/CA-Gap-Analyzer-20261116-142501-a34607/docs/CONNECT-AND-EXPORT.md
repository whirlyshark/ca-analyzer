# Connect or import

The Import policies tab includes these instructions and copy buttons. The app
runs locally on `http://localhost:8765/`. It uses read-only Graph calls; the
existing recovery application is not used as the analyzer's reader identity.

For background collection without a user session, use the separate
[scheduled certificate reader](SCHEDULED-COLLECTION.md). The steps below set up
the interactive UI reader; its delegated permissions do not grant app-only access.

Tenant and client IDs are remembered in `data/connection.local.json`. When no
saved connection exists, the locally provisioned reader app supplies the defaults.
No tokens or credentials are stored in this file.

## App names and declared resources

Application-name collection is optional for ID-based policy assessment. A failed
or partial name read is shown in **What this check covers**; it does not invalidate
otherwise checkable policy coverage. Policy app IDs and the other-resources
partition remain available. This does not establish app existence, permission to
use an app, token issuance, or application-filter membership.

In a requirement's app picker, paste an application ID into **Find apps** and
choose **Use this application ID** if it is absent from the export. The requirement
is saved normally and can be assessed offline. Declared resources receive their
own request class rather than inheriting another app's protection. Removing or
disabling a declaration removes that extra class on the next compilation. The
snapshot itself is unchanged. Known resource-group membership is still used;
missing membership and Microsoft Graph audience rules remain unverified.

Missing named-location catalog reads do not erase complete definitions already
collected. Those IP/country locations can be selected in policies and requirements;
their overlap, exclusions and compensation are still evaluated. The inventory
note remains visible. Missing, conflicting, malformed or unfinished definitions
remain unverified. **All trusted** still requires the complete trusted inventory
and its other evidence; it cannot be inferred from a partially collected list.
An object containing a pagination link is not treated as a complete definition.

Microsoft's [resource targeting guide](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-cloud-apps)
distinguishes resource targeting from client-app targeting, explains All resources,
and describes special audience/resource-group behavior. The analyzer's declared
IDs represent requested-resource scenarios, not a verified application inventory.

## Account definitions and missing details

Account definitions can filter **Account status → Equals → Enabled / Disabled**.
Collection includes the `accountEnabled` user property in the snapshot, so this
filter works offline. Older exports may need collecting again. See
[Microsoft's user-property reference](https://learn.microsoft.com/en-us/graph/api/resources/user?view=graph-rest-1.0#properties).

All accounts are assessed by default, including disabled accounts. Use an
explicit account definition if a requirement should apply only to enabled
accounts. Removing an account from a requirement is a scope change, not a
Conditional Access policy fix.

If an exported account lacks a detail needed by its definition, the analyzer
assesses it as a possible target and labels dependent findings **Needs
investigation**. Confirmed targets retain definite findings. A reference to an
account absent from the export stays unresolved; the analyzer does not invent
its properties. Missing classification details withhold the overall score.

**Group membership** uses captured current membership; **Eligible group
membership** includes exported PIM membership possibilities. **Directory role**
includes current and eligible assignments, including roles obtained through PIM
group membership, regardless of whether Microsoft labels the role privileged.
The separate Privileged account definition still uses Microsoft's privilege flag.

A partial role read or missing group catalog cannot prove that an account has
no such membership. Complete individual group reads remain usable when another
group read fails. Known current/eligible facts still select accounts; missing or
changing relationships select possible targets. Double-eligible or changing
group sources stay unverified where their activation relationship is unknown.
Failed directory reads affect the definitions and policy assignments that need
them. An independent policy can still prove the required protection. Collection
notes remain visible in the UI and HTML report. Missing user/policy pages and
unidentified errors still leave the overall check incomplete. Role timing uses
the same per-policy relevance checks; an unrelated app's role-timing problem
does not invalidate a completed requirement. This does not establish successful
activation or live authentication. References:
[group-based roles](https://learn.microsoft.com/en-us/entra/identity/role-based-access-control/groups-concept),
[PIM for Groups](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/concept-pim-for-groups).

Unknown role membership stays open during analysis, including possible policy
exclusions. A known fixed role remains fixed even if an eligibility read fails.
Missing role definitions are traced to their assignment principals and group
sources; an unused definition cannot make another account privileged. Only
validated built-in template/scope metadata can establish a fixed CA role.
Duplicate directory/policy IDs and ambiguous account/group IDs are rejected.

Exceptions for incomplete directory evidence bind to those facts. A new export
time alone keeps an unchanged exception; different failed dependencies or
relationship facts require review again.

For CA group targeting and groups assigned roles, include the optional PIM group
facts; see [PIM for Groups](PIM-GROUPS.md). In the UI, select **Include PIM group
eligibility**. Missing evidence leaves group membership symbolic and dependent
remaining gaps unverified, even when current memberships were exported.

**Include app-filter attributes** exports custom attribute definitions and
service-principal assignments for offline investigation. It requires separate
read permissions/roles and does not yet enable verified filter matching. See
[application-filter status and export](APPLICATION-FILTERS.md).

## Register a reader app

1. Open Microsoft Entra admin center → App registrations → New registration.
   Name it **CA Gap Analyzer Reader**, choose accounts in this organisational
   directory only, and register it.
2. Authentication → Add a platform → **Mobile and desktop applications**.
   Add the custom redirect URI **http://localhost:8765/oauth/callback**.
   Use the URI displayed in the tool if running on another port. This is a
   public desktop client; do not create a client secret or configure a SPA.
3. API permissions → Add a permission → Microsoft Graph → **Delegated permissions**.
   Add **Policy.Read.All**, **Directory.Read.All** and
   **RoleManagement.Read.Directory**. Do not add application or write permissions.
4. Have an authorised administrator grant admin consent. On Overview, copy the
   Directory (tenant) ID and Application (client) ID into the tool. Select
   **Sign in with Microsoft**. The signing-in account also needs an appropriate
   directory reader role; Global Reader is a suitable read-only role.
5. Finish sign-in in the popup. It closes automatically and collection continues in the analyzer.
   Review collection/support issues before interpreting findings. Save the snapshot
   explicitly if you want a reusable file.

The browser flow uses authorization code with PKCE, a one-time state value,
browser-bound transaction cookie and ten-minute sign-in expiry. Tokens are held
only in the local server/collection worker's memory. No client secret, refresh
token or access token is saved in the requirements configuration or snapshot.
Clear connection stops collection and clears connection state; it does not revoke
the tenant's consent grant or delete an explicitly downloaded snapshot.

References: [policy read API and reader roles](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-list-policies?view=graph-rest-1.0),
[authorization code and PKCE](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow),
[loopback redirect rules](https://learn.microsoft.com/en-us/entra/identity-platform/reply-url).

## Export using the existing Cloud Shell session

Select **Cloud Shell - already signed in** under Connection method. Open Cloud
Shell in PowerShell mode. This uses the existing Azure CLI identity: no new app
registration, Connect-MgGraph, device-code login or consent request is performed.
Your current identity and its existing Graph access still need read permission.
A permission failure is reported rather than starting another authentication flow.

Download the standalone **Export-TenantSnapshot.ps1** from the Import tab and
upload it to Cloud Shell through Manage files. Then run:

```powershell
./Export-TenantSnapshot.ps1 -TenantId (az account show --query tenantId --output tsv) -OutputPath ./ca-tenant-snapshot.json
```

Download `ca-tenant-snapshot.json` through Manage files and choose **Choose JSON
file** in the analyzer. No Graph PowerShell module is required in this mode.
The repository copy needs `collection/TenantSnapshot.ps1` beside it; the standalone
download includes that collector.

The Policies only command block in the Import tab also reuses the current Azure
CLI session, follows every policy page and writes `ca-policies.json`. Its Graph
token stays in memory. A policy-only file supports policy review but needs directory
users, groups and roles before account-level coverage can be checked.

The full snapshot includes policies, selected user attributes, groups and transitive
user memberships, active roles, PIM role eligibility, named locations and app names.
Missing collections are recorded explicitly. `-IncludePimGroups` additionally
exports group eligibility/assignment instances and direct memberships, with their
own completeness flags. Collection is not transactionally atomic.

References: [Cloud Shell automatically authenticates](https://learn.microsoft.com/en-us/azure/cloud-shell/overview),
[Azure CLI reuses logged-in credentials](https://learn.microsoft.com/en-us/cli/azure/use-azure-cli-rest-command),
[Cloud Shell file menu](https://learn.microsoft.com/en-us/azure/cloud-shell/use-the-shell-window).

## Reuse an Entra browser session

Select **Existing Entra browser session**. This takes a **Microsoft Graph access
token**, not a cookie. It follows the same credential-input approach documented by
[CA Insight](https://github.com/emiliensocchi/entra-ca-insight/wiki/usage#authentication).
The collection and analysis code here is independently implemented.

1. In your signed-in Entra admin center, open Conditional Access > Policies.
2. Open developer tools (F12), select Network, and refresh the policy list.
3. Find the request to `https://graph.microsoft.com/.../policies`.
4. Copy the value after `Bearer` in its Authorization request header.
5. Enter the tenant ID and paste that token into the local tool's password field.
   Select Read tenant snapshot.

The field is cleared after submission. The local server holds the token only in
memory while making Graph GET requests. It is not saved in snapshots, settings,
URLs or logs; do not paste it into chat. The token's existing audience, permissions,
expiry and tenant restrictions still apply. This does not grant additional access.
A policy-reading token may lack permission for directory/PIM collections; those
remain explicit coverage issues.

For a command-line export using a token, avoid putting the token in arguments or
shell history:

```powershell
$token = Read-Host 'Paste Microsoft Graph access token' -AsSecureString
./Export-TenantSnapshot.ps1 -TenantId 'YOUR-TENANT-ID' -AccessToken $token -OutputPath ./ca-tenant-snapshot.json
$token = $null
```

Direct Graph sign-in is also still available from the script with `-InteractiveLogin`
(and optional `-ClientId`). `-UseDeviceCode` explicitly selects a device-code flow;
it is never the default export path.

## Requirements and account definitions

After loading data, define reusable account sets using AND/OR/NOT filters,
manual account IDs, or privileged-role classification. Missing attributes are
unresolved rather than automatically false. External home-tenant IDs are not
inferred from UPNs or email addresses; that filter needs explicit source data.
Select breakglass accounts manually, then explicitly exclude that set from each
applicable requirement. No classification automatically exempts accounts.

Name requirements and select account sets, apps, authentication/device/blocking
outcomes and optional network/client/platform conditions. Best-practice templates
are editable and retain their origin. Definitions are saved per tenant/model in
`data/workspaces.local.json`; export/import a configuration to move it elsewhere.

Unsupported enforced policies are omitted from the translated subset and listed
as unresolved coverage. Results are then **potential gaps**, and no absence of
findings is presented as complete protection. Named-location evaluation, real
device filters, resource-group expansion, sessions and some authentication
strengths remain unsupported. Microsoft What If/live conformance checks remain
future validation; mocked collector and OAuth protocol tests do not establish
live-tenant correctness.

## Authentication context and session timing

App access and authentication-context requests are separate targets, matching
Microsoft What If. An All resources app policy does not become a PIM activation
context policy. Requirements default to app access; choose Authentication context
c1 (or another imported context) in Applies to when checking a step-up requirement.
Context predicates use symbolic boolean dimensions, preserving OR targeting and
simultaneous context conditions without enumerating their Cartesian product.
Representative online validation covers single-context requests supported by
Microsoft What If; simultaneous-context behavior is covered by offline tests only.
The analyzer does not verify that an app or PIM configuration actually requests a
context; seeing a context-targeted CA policy is not evidence of that configuration.

Supported sign-in-frequency settings are retained and displayed. Their minimum
MFA/phishing-resistant/device grants participate in analysis; reauthentication
intervals, session freshness and prompt behavior are outside this assessment.
Unknown session controls still produce unresolved coverage. A frequency control
by itself never becomes an MFA requirement.
Known browser-persistence, token-protection, app-restriction, CAE and filtering
settings now preserve the policy's minimum grants. Remaining possible access can
still need downstream enforcement evidence; see [policies with session controls](SESSION-CONTROLS.md).

PIM eligibility contributes to privileged account definitions. Role/group
activation states are modeled from exported assignments and schedules; dependent
possible gaps remain unverified when required facts or lifetime relationships are
unresolved. PIM for Groups collection is optional: select **Include PIM group
eligibility** or use `IncludePimGroups` in the exporter. See [PIM groups](PIM-GROUPS.md)
and [role schedule timing](ROLE-SCHEDULES.md).

Sources: [authentication context targets](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-cloud-apps),
[session controls](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-session),
[What If API](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-evaluate?view=graph-rest-1.0).

For development validation, `collection/Compare-PolicyApplicability.ps1` accepts
snapshot, normalized-model and case JSON paths. It uses the currently signed-in
Azure CLI account for read-only Graph policy reads and What If evaluations. Cases
contain `name`, `userId`, `applicationId`, and optional `authenticationContextId`.
It checks policy modification timestamps against the export and records full
requests, responses and expected policy IDs in an ignored local JSON evidence file.
This proves representative applicability comparisons, not successful logins or
complete tenant equivalence. No additional permission grants are made by the script.

## Reading the coverage overview

For trusted-network exclusions and the separately exported Global Secure Access
metadata, see [trusted networks](NETWORK-TRUST.md). Global Secure Access matching
remains unverified; collecting its metadata does not enable the tenant feature.

For eligibility expiry and incomplete role-instance evidence, see
[role schedule timing](ROLE-SCHEDULES.md). Both role schedule collections are
already part of a full snapshot; they do not require the optional PIM groups flag.

For policies targeting Office 365, Microsoft Admin Portals or Azure Management,
see [resource-group evidence](RESOURCE-GROUPS.md). The optional standalone
`Export-ResourceGroupEvidence.ps1` reuses an existing Azure CLI session for
read-only What If calls. Import its evidence JSON through **Choose JSON file**
after loading the matching tenant snapshot, then save the enriched snapshot for
offline use. It does not perform a sign-in or change policies.

The coverage score is the percentage of checked accounts that meet every enabled
requirement. Each account counts once, even if it has several findings. Accounts
outside requirement scope do not inflate the score. Incomplete assessments are
not scored. This is requirement coverage, not a Microsoft Secure Score or proof
of complete tenant security. Accepted exceptions remain failures in the score;
they only move accounts out of the review queue when all their findings are accepted.

The overview shows unique affected accounts, accounts meeting all requirements,
and the checked scope. By requirement shows where protection is missing. Selecting
an account shows its failing requirements and example sign-in scenarios. Accepting
an exception can cover several accounts sharing a scenario; the confirmation lists
every account it applies to.
