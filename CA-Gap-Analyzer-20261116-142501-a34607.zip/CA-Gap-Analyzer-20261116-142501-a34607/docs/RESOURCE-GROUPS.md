# Resource groups and offline evidence

The analyzer supports Office 365, Microsoft Admin Portals and the Azure Service
Management selector. Resource groups are shared predicates across every policy
for the same resource. Includes are OR; exclusions win. Overlapping groups and
compensating policies are evaluated together. Requirements can select these
groups, including a rule that must block everything outside them.

Current service principals and display names do not establish group membership.
Missing membership stays unknown. A policy for Office 365 and another for All
resources excluding Office 365 can still prove complete MFA coverage without
knowing the membership list. Remaining findings depending on unknown membership
are unverified. A finding involving an explicitly known non-member remains a
definite resource-coverage gap when unrelated unknown resources are out of scope.

## Add membership evidence

Use the ordinary **Choose JSON file** control: load your full tenant snapshot,
then choose its resource-group evidence file. The tenant IDs must match. Save the
updated snapshot to retain the evidence for offline or scheduled assessment.
New evidence replaces the supplied groups' previous catalog entries; it does not
silently combine observations collected at different times.

The equivalent offline PowerShell command, run from the portable folder, is:

```powershell
./Merge-ResourceGroupEvidence.ps1 -SnapshotPath ./tenant.json -EvidencePath ./ca-resource-groups.json -OutputPath ./tenant.enriched.json
```

Inputs and existing outputs are never overwritten. No network call is needed to
merge or assess the result. Merge before sanitizing so all identifiers use the
same pseudonym map. Resource-group names, membership structure and the public
Azure Management selector retain their meaning through sanitization.

## Collect observations without changing policies

Use `Export-ResourceGroupEvidence.ps1` in an already authenticated Cloud Shell or
Azure CLI PowerShell session. The downloadable version in the Import tab is
standalone; it needs no modules or embedded JavaScript runtime. The signed-in
account must already be authorized to use Microsoft's What If API. Reusing its
token does not grant consent or add permissions.

Choose a reference account from the snapshot which is covered by the policies
you want to inspect. This is a hypothetical What If actor: the script does not
sign in as that person, change their credentials or edit any policy.

```powershell
$snapshot = Get-Content ./ca-tenant-snapshot.json -Raw | ConvertFrom-Json
$referenceUser = ($snapshot.users | Where-Object userPrincipalName -eq 'person@example.com').id
./Export-ResourceGroupEvidence.ps1 -SnapshotPath ./ca-tenant-snapshot.json -UserId $referenceUser -OutputPath ./ca-resource-groups.json
```

It queries the named resource IDs in the snapshot, with a default limit of 200.
For a larger inventory, explicitly select `-ResourceIds '<app-guid>','<app-guid>'`
or raise `-MaxResources`. It fails rather than silently truncating the selection.
The basic context is a Windows browser request, no sign-in/user risk and a
noncompliant device. If another condition prevents a policy from applying, its
response might supply no membership information.

Only unambiguous membership implications are saved. An applying group-only
policy can establish inclusion; an explicit application-scope failure can
establish exclusion. Direct exceptions, multiple included/excluded groups and
other conditions are considered before deriving a fact. An ambiguous OR, missing
context, changed resource selector or conflicting observation cannot become a
known membership. Every exported catalog remains partial (`complete: false`).

The JSON also retains observation/policy references for review. Keep it private.
Unobserved resources remain unknown even if their names resemble Microsoft apps.

## Explicit catalogs

An organization can supply a declared, reviewed catalog in the snapshot:

```json
{
  "resourceGroups": [{
    "id": "Office365",
    "members": ["00000003-0000-0ff1-ce00-000000000000"],
    "nonMembers": [],
    "complete": false,
    "provenance": {
      "kind": "declared",
      "description": "Reviewed membership for this exported assessment context."
    }
  }]
}
```

Supported provenance kinds are `declared`, `whatIf` and `microsoftDocumentation`;
these describe the supplied evidence, not a cryptographic verification. Set
`complete: true` only for an exhaustive catalog for the assessed context. Absence
from a partial list never means non-membership. Contradictory catalogs are rejected.

## Resource requests versus service experiences

These checks concern explicitly selected resource requests. A web portal can
request tokens for additional backend services. What If does not test those
service dependencies. The lab's Azure portal application-ID request did not match
the Azure Management policy, despite the documented relationship between the
portal and management services. That result cannot establish that using the
portal avoids the management policy. Original expectations and discrepancies are
retained separately from evidence-fed replay.

The analyzer does not infer an entire portal/session's dependencies from its
display name or extend a single-resource What If result to successful access.
Service/audience relationships and confidential-client ID tokens still need
additional context and validation. This remains a release boundary.

## Low-privilege directory scopes

When an enabled All-resources policy has resource exclusions, the analyzer also
assesses the documented legacy and current baseline-scope contexts. Both use
the Windows Azure Active Directory resource ID
`00000002-0000-0000-c000-000000000000`. Resource exclusions receive no protection
credit in the legacy context. This is a conservative request model, not a claim
that the tenant still uses legacy enforcement. Microsoft describes a phased
rollout beginning March 2026; the current date alone does not establish a
tenant/request's enforcement state.

Possible gaps in the legacy context remain **unverified**, so the assessment
cannot earn a coverage score. A universally applicable baseline without resource
exclusions, or appropriate directory-targeted protection without exclusions, can
prove coverage across both contexts. Client, identity, location, device and grant
conditions still apply: a browser-only directory policy or MFA OR compliant device
does not prove unconditional MFA. Requirements restricted to other explicit
resources do not inherit unrelated directory-scope uncertainty.

This does not yet translate an arbitrary requested scope list into every
underlying service audience. A requirement selecting Microsoft Graph therefore
checks a conservative superset of possible underlying resources. If all are
protected under the selected identity/device/network conditions, coverage is
proved for that bound. Otherwise remaining gaps are unverified until requested
scopes/audiences can be supplied. A Graph allowlist cannot yet classify other apps
and is rejected. Raw policies explicitly selecting or excluding the Graph
umbrella ID are unsupported, rather than credited as literal app-ID rules.
Whole-session coverage and exact audience expansion need further work and validation.

References: [resource targeting](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-cloud-apps),
[Office 365 catalog limitations](https://learn.microsoft.com/en-us/entra/identity/conditional-access/reference-office-365-application-contents),
[What If API](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-evaluate?view=graph-rest-1.0),
[What If service-dependency limitation](https://learn.microsoft.com/en-us/entra/identity/conditional-access/what-if-tool).
