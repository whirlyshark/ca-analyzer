# Accepted exceptions

Local exception updates are serialized across app processes sharing a folder.
Each update reads the latest store while holding an OS file lock, then replaces
the JSON through its own temporary file. Unrelated exceptions survive concurrent
saves; a failed update leaves the previous committed file intact. Workspace
profiles, tagging settings and connection settings use the same write mechanism.
Small `.lock` files remain beside local state; their presence does not mean an
app is still running. The operating system releases the lock when its handle or
process closes. Do not mix running copies of older and newer app versions in the
same workspace: older writers do not participate in these locks.

Accept a finding from **Review coverage** and give a reason. The affected account
stays in the coverage score, but moves out of the review list. Accepting a gap
does not make the account protected.

**Requirement not checked** means the analyzer could not evaluate the rule's
scope or conditions. Its known intended accounts remain in the review list;
there is no sign-in finding to accept. Resolve the missing details and check
again. Completing this check does not count as fixing a previously confirmed gap.

Grant-based refinement can separate a confirmed MFA example from an unverified
password example for the same accounts. Accepting either finding does not accept
its sibling. Identical evidence retains that exception; changed grants reopen it.
An older unresolved finding may need one review after a model upgrade because
unresolved exceptions use exact evidence fingerprints.

New exceptions survive equivalent offline exports. The analyzer compares their
tenant, exact account group, requirement and physical sign-in conditions. Adding
an unrelated app, refining an IP partition, renaming a requirement or changing an
equivalent device-filter expression does not by itself reopen an exception.
Findings can split or merge without losing an exception when their combined
scope is exactly unchanged. Multiple authorizing records are retained so that
**Reopen exception** revokes all of them; an old export cannot resurrect them.

Expanded/reduced account groups, changed requirement semantics and changed
connected request scopes require review. Separate unchanged exceptions remain
accepted. Equivalent policy changes can retain an exception because it describes
the requirement violation, rather than a frozen set of policy IDs.

Both exact keys and physical comparisons are tenant-specific. Exact keys include
physical-domain evidence: moving an IP range must not preserve an exception just
because the exported model reuses a network label. New cross-model matching is
available only for complete, supported assessments with saved scope evidence.
Unverified findings can still be explicitly accepted for an identical rerun;
changed/missing evidence reopens them. A bounded or unavailable scope comparison
never invents a match. Its status is retained as `acceptanceMatching` in reports.
Reopening is deferred if the comparison could not finish, so an unexamined
equivalent record cannot silently reactivate the exception.

The analyzer can also split a broad finding along known conditions to separate
definite and uncertain scenarios. An exception for the identical original group
continues to cover its children, including unverified findings: its original key
still binds the same tenant, physical evidence, model and diagnostics. This is
not cross-model matching. All parent and child authorizers are retained for
reopening. Reopening one shared parent refreshes every affected scenario; a
separately accepted child remains accepted under its own surviving record.

The new tenant/domain-specific exact keys require a one-time review of older
exceptions that were created without tenant/physical scope. Their records remain
in the local store, but the analyzer does not guess their intended tenant or scope.

Exceptions are local to the portable folder in `data/acceptances.local.json`.
The UI and scheduled/ad-hoc PowerShell assessments share this store unless an
explicit `AcceptancePath` is supplied. Keep it with your requirements and exported
snapshots when moving your working folder. Fresh distribution packages exclude
local exceptions, tenant exports and credentials.

Validation includes raw Graph-format snapshot comparisons, independently
enumerated finite scope cases, HTTP/PowerShell parity, 10,000-account refinement,
and reopening equivalent records. These establish offline exception behavior,
not Conditional Access enforcement during actual sign-ins.
