# Portable folder

Build a fresh copy from the development workspace:

```powershell
pwsh -NoProfile -File ./Build-Portable.ps1
```

The script prints the new folder under `dist`. You can select a new destination
with `-Destination`. An existing destination is never overwritten.

Keep the generated folder together. It includes the C# engine, local UI,
PowerShell commands, invented example data, pinned ClearScript runtime, runtime
lock and third-party licences. It requires Windows x64 and PowerShell 7.4+;
PowerShell itself is a prerequisite. It does not require Node, a .NET SDK,
package restore or internet access for offline assessment.

Fresh background collection is available through `Start-FreshAssessment.ps1`
after configuring a separate certificate reader. Its authentication code uses
PowerShell/.NET and adds no Graph SDK or other downloaded dependency. Collection
requires network access and your own reader credential; neither is needed for
offline analysis. See [scheduled collection](SCHEDULED-COLLECTION.md).

The builder copies an explicit product inventory. Saved connections, account
definitions, exceptions, tenant snapshots, tokens, certificates, recovery
provisioning, lab scripts, test logs and old dependency download caches are not
packaged. Start the copied UI with `Open-Analyzer.cmd`, import a snapshot and
your exported requirements, or use `Start-Assessment.ps1` directly.

Verify the copied files:

```powershell
pwsh -NoProfile -File ./Test-PortablePackage.ps1
```

The manifest covers every packaged file, including licences and runtime files.
SHA-256 hashes detect changed/missing files; they are not a publisher signature.
Verification does not delete user files or reset a workspace.

After using the tool, its new `data` folder contains local definitions, exceptions
and assessment history. Include that folder when moving your own workspace if
you want to retain them. Protect tenant snapshots and reports according to your
organisation's requirements. The initial portable copy contains no saved tenant
connection, so enter your tenant/app details when using direct collection.

Development validation builds another fresh copy in a path containing spaces,
checks the inventory, tests CLI reports with Node/developer paths removed and
unusable external proxies, starts its local UI, verifies every referenced asset,
checks the blank connection state and collector download, and tests detection
of an altered file. Proxy failure simulates unavailable connectivity; it is not
an OS-enforced air-gap test. Run `tests/Test-Portable.ps1` from development.

Builds are currently labelled **development**. Packaging is separate from the
full analyzer release-readiness audit.
