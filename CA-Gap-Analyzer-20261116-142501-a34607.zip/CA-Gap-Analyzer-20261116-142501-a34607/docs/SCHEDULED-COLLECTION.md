# Fresh scheduled assessments

`Start-FreshAssessment.ps1` collects a new tenant snapshot and then runs the same
offline assessment/history pipeline as the UI. It uses a dedicated application's
certificate, without a browser, user password or Graph PowerShell module. It
requires connectivity for collection; saved snapshots remain usable offline.
The authentication endpoints currently target Microsoft's global cloud.

This authenticates the **reader application**, not a simulated user sign-in.
It does not establish that a user's MFA or passkey challenge would succeed.

## Set up a dedicated reader

1. Register a separate single-tenant application named **CA Gap Analyzer Scheduled
   Reader** in Entra. No redirect URI or client secret is needed.
2. Add these Microsoft Graph **Application** permissions and have an authorized
   administrator grant consent. These are separate from the UI reader's delegated
   permissions. Do not add write permissions or directory administrator roles.

   | Permission | Data used |
   |---|---|
   | `Policy.Read.All` | CA policies, locations and authentication strengths |
   | `Directory.Read.All` | Tenant, users, groups, memberships and application names |
   | `RoleManagement.Read.Directory` | Role definitions, active/eligible roles and schedule instances |
   | `Policy.Read.DeviceConfiguration` | Device-registration prerequisites |

   If collecting PIM group facts, also consent
   `PrivilegedEligibilitySchedule.Read.AzureADGroup` and
   `PrivilegedAssignmentSchedule.Read.AzureADGroup`. Hidden membership groups
   additionally require `Member.Read.Hidden` to enumerate their membership.
   Denied/missing collections stay incomplete; consent is never granted by the runner.
   Optional `-IncludeApplicationAttributes` additionally needs
   `CustomSecAttributeDefinition.Read.All` and
   `CustomSecAttributeAssignment.Read.All` application permissions. It exports
   investigation data and does not yet enable verified application-filter matching;
   see [application-filter status](APPLICATION-FILTERS.md).
3. Create an RSA certificate for the Windows identity that will run the task.
   The certificate must be valid and its private key accessible to that identity.
   One Windows example, run as that identity:

   ```powershell
   $readerCertificate = New-SelfSignedCertificate `
     -Subject 'CN=CA Gap Analyzer Scheduled Reader' `
     -CertStoreLocation 'Cert:\CurrentUser\My' `
     -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 `
     -KeyExportPolicy NonExportable -KeySpec Signature `
     -NotAfter (Get-Date).AddYears(1)
   Export-Certificate -Cert $readerCertificate -FilePath ./scheduled-reader.cer
   $readerCertificate.Thumbprint
   ```

4. In the new app's **Certificates & secrets → Certificates**, upload the public
   `.cer` file. Keep the private key with the task identity; no private key is
   uploaded. Record the app ID, tenant ID and thumbprint.
5. Export your account definitions and requirements from **Set requirements**.

Use a separate reader for this purpose. Never use the recovery principal.
In this lab workspace the runner rejects the recovery app ID found in
`recovery/recovery.local.json`; portable copies contain no recovery metadata.
No app, consent, certificate or scheduled task is created automatically.

The device-registration read has a distinct application permission: Microsoft's
[device-registration API](https://learn.microsoft.com/en-us/graph/api/deviceregistrationpolicy-get?view=graph-rest-1.0)
lists `Policy.Read.DeviceConfiguration` for app-only access. The scheduled reader
therefore needs it even though the interactive delegated reader uses `Policy.Read.All`.
Other references: [CA policy reads](https://learn.microsoft.com/en-us/graph/api/conditionalaccessroot-list-policies?view=graph-rest-1.0),
[role schedule reads](https://learn.microsoft.com/en-us/graph/api/rbacapplication-list-roleassignmentscheduleinstances?view=graph-rest-1.0),
[PIM group eligibility](https://learn.microsoft.com/en-us/graph/api/privilegedaccessgroup-list-eligibilityscheduleinstances?view=graph-rest-1.0)
and [hidden group membership](https://learn.microsoft.com/en-us/graph/api/group-list-transitivemembers?view=graph-rest-1.0).

## Run once

From the analyzer folder:

```powershell
pwsh -NoProfile -File ./Start-FreshAssessment.ps1 `
  -TenantId '<tenant-guid>' -ClientId '<scheduled-reader-app-guid>' `
  -CertificateThumbprint '<40-character-thumbprint>' `
  -RequirementsPath ./my-requirements.json -IncludePimGroups
```

Omit `-IncludePimGroups` only when your requirements/policy targeting do not need
those facts, or when you intend to review the resulting uncertainty. A certificate
in `LocalMachine\My` can be selected with `-CertificateStore 'LocalMachine\My'`;
the task identity still needs private-key access.

For a movable workspace with an existing encrypted PFX, use `-CertificatePath`
and a `SecureString` `-CertificatePassword` instead of a store thumbprint. Do not
put a PFX password in task arguments or a requirements file. Retrieve it from
your organisation's credential store in a task wrapper. The PFX key is loaded
ephemerally and is never imported into the machine/user store by this command.
Prefer the Windows store option when no secret-retrieval wrapper is available.
If a wrapper invokes this command, end it with `exit $LASTEXITCODE` so Task
Scheduler receives the assessment outcome rather than the wrapper's default
success status.

The JSON response contains `snapshotPath` and `assessment`. Fresh snapshots are
retained under `data/snapshots/<tenant-id>/`; reports and history are under
`data/assessments/`. Override `-SnapshotDirectory`, `-StateDirectory`,
`-AcceptancePath` or `-AssessmentName` when separating workspaces. Default history
and accepted exceptions are shared with the UI. Each snapshot records collection
start/end time and reader app ID, without tokens or certificate/private-key data.
Collection spans multiple Graph reads; the recorded interval does not imply a
transactionally consistent tenant snapshot. Review incomplete or contradictory
facts, especially during active policy or PIM changes.

## Schedule

In Windows Task Scheduler, use the same Windows identity and certificate access
as the successful manual run. Choose the frequency you need and an action with:

- **Program:** the absolute path to `pwsh.exe`.
- **Arguments:** `-NoProfile -NonInteractive -File "C:\CA-Gap-Analyzer\Start-FreshAssessment.ps1" -TenantId "<tenant-guid>" -ClientId "<reader-app-guid>" -CertificateThumbprint "<thumbprint>" -RequirementsPath "C:\CA-Gap-Analyzer\my-requirements.json" -IncludePimGroups`
- **Start in:** `C:\CA-Gap-Analyzer` (use your actual folder).

Use absolute paths and keep the folder/runtime together. Choose not to start
another instance if the task is already running. A tenant collection lock also
rejects overlapping fresh runs in the same state directory.

Exit codes match `Start-Assessment.ps1`: **0** complete/no unaccepted findings,
**1** findings to review, **2** incomplete assessment, **3** collection or execution
failure. A token/tenant failure never reuses a previous export. Partial collection
is retained with completeness errors; dependent checks cannot silently pass.
An unrelated failed optional read need not invalidate an independently proved
requirement. Monitor nonzero task outcomes as well as certificate expiry.

The reader uses short-lived, independently signed assertions and renews access
tokens during collection. It retries an unauthorized GET once with a new token;
the collector separately handles bounded throttling/transient retries. Credential
requests do not follow redirects. Microsoft describes the
[certificate assertion](https://learn.microsoft.com/en-us/entra/identity-platform/certificate-credentials)
and [client credentials protocol](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-client-creds-grant-flow).

Protocol, failure paths and fresh collection-to-analysis behavior have synthetic
tests. Actual Windows Task Scheduler execution of the portable **offline** runner
is also verified, including a clock trigger, reports/history and exit codes
0/1/2/3 under the existing logged-on Windows identity. This does not prove
logged-off execution or certificate-reader authentication. Live Entra reader
acceptance and a **fresh collection** scheduled run still need validation with a
separately consented reader. The existing reader and recovery permissions were
not changed.
