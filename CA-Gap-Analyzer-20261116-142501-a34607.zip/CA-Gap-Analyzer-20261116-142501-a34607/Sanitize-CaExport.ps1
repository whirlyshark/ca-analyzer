#Requires -Version 7.4
<#
.SYNOPSIS
Creates a pseudonymised copy of a Graph Conditional Access export, entirely offline.
.EXAMPLE
./Sanitize-CaExport.ps1 -InputPath ./ca-policies.json -OutputPath ./ca-policies.sanitized.json
.EXAMPLE
./Sanitize-CaExport.ps1 -InputPath ./ca-tenant-snapshot.json -OutputPath ./lab.sanitized.json
.NOTES
Standalone: no modules, network access, credentials or lookup files required.
Mappings are consistent within one file and random between runs. No original-to-
replacement map is saved. Keep originals private. Does not modify the source.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory,Position=0)][string]$InputPath,
    [Parameter(Position=1)][string]$OutputPath,
    [switch]$Force
)
$ErrorActionPreference='Stop'
$inputFile=(Resolve-Path -LiteralPath $InputPath).ProviderPath
if(!$OutputPath){$OutputPath=Join-Path ([IO.Path]::GetDirectoryName($inputFile)) ([IO.Path]::GetFileNameWithoutExtension($inputFile)+'.sanitized.json')}
$outputFile=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
if([string]::Equals($inputFile,$outputFile,[StringComparison]::OrdinalIgnoreCase)){throw 'Choose an output file different from the original.'}
if((Test-Path -LiteralPath $outputFile) -and !$Force){throw 'Output already exists. Choose another path or explicitly use -Force.'}
if((Get-Item -LiteralPath $inputFile).Length -gt 100MB){throw 'Input exceeds the 100 MB file limit.'}
function Read-JsonValue([System.Text.Json.JsonElement]$Node,[bool]$AttributeData=$false){
    switch($Node.ValueKind.ToString()){
        'Object' {
            $map=[Collections.Hashtable]::new($(if($AttributeData){[StringComparer]::Ordinal}else{[StringComparer]::OrdinalIgnoreCase}))
            foreach($property in $Node.EnumerateObject()){
                if($map.ContainsKey($property.Name)){throw 'Ambiguous duplicate JSON property.'}
                $map.Add($property.Name,(Read-JsonValue $property.Value ($AttributeData -or $property.Name -ceq 'customSecurityAttributes')))
            }
            return ,$map
        }
        'Array' {$items=[Collections.Generic.List[object]]::new();foreach($item in $Node.EnumerateArray()){$items.Add((Read-JsonValue $item $AttributeData))};return ,$items.ToArray()}
        'String' {return $Node.GetString()}
        'Number' {$integer=0L;if($Node.TryGetInt64([ref]$integer)){return $integer};$decimal=[decimal]0;if($Node.TryGetDecimal([ref]$decimal)){return $decimal};$number=$Node.GetDouble();if(![double]::IsFinite($number)){throw 'Unsupported JSON number.'};return $number}
        'True' {return $true}
        'False' {return $false}
        'Null' {return $null}
        default {throw 'Unsupported JSON value.'}
    }
}
# Avoid PowerShell's implicit DateTime conversion: it can normalize invalid ISO
# hours/offsets before schedule validation. This reader preserves literal strings.
$document=$null
try{
    $options=[System.Text.Json.JsonDocumentOptions]::new();$options.MaxDepth=100
    $document=[System.Text.Json.JsonDocument]::Parse((Get-Content -LiteralPath $inputFile -Raw).TrimStart([char]0xFEFF),$options)
    $inputData=Read-JsonValue $document.RootElement
}catch{throw 'Could not read unambiguous valid JSON from the input file.'}finally{if($document){$document.Dispose()}}
$isSnapshot=$inputData -is [Collections.IDictionary] -and $inputData.caGapSnapshotVersion -eq 1
if($isSnapshot){$policyList=$inputData.policies}elseif($inputData -is [array]){$policyList=$inputData}elseif($inputData -is [Collections.IDictionary] -and $inputData.Contains('value')){$policyList=$inputData.value}elseif($inputData -is [Collections.IDictionary] -and $inputData.Contains('conditions')){$policyList=@($inputData)}else{throw 'Expected a policy array, Graph value envelope, single policy, or CA Gap Analyzer tenant snapshot.'}
if($null -eq $policyList){throw 'Policy collection is missing.'}
foreach($policy in $policyList){if($policy -isnot [Collections.IDictionary] -or !$policy.Contains('conditions')){throw 'Input includes objects that are not Conditional Access policies.'}}
$idMap=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
$textMap=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
$domainMap=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
$attributeText=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
$attributeClasses=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::OrdinalIgnoreCase)
$attributeDefinitions=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
$counters=@{}
$stats=@{identifiers=0;textValues=0;removedFields=0;filterExpressions=0;ipValues=0;unknownFields=0}
# Schedule windows affect offline eligibility. Replace their ordered instants,
# rather than removing them or retaining identifying calendar dates/durations.
$scheduleInstants=[Collections.Generic.SortedSet[long]]::new()
$scheduleDateMap=[Collections.Generic.Dictionary[long,string]]::new()
function Get-ScheduleInstant($Value){
    if($Value -is [DateTimeOffset]){return $Value.UtcTicks}
    if($Value -is [DateTime] -and $Value.Kind -ne [DateTimeKind]::Unspecified){return ([DateTimeOffset]$Value).UtcTicks}
    $parsedDate=[DateTimeOffset]::MinValue
    if($Value -is [string] -and $Value -match '^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,7})?(?:Z|[+-]\d\d:\d\d)$' -and [DateTimeOffset]::TryParse($Value,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsedDate)){return $parsedDate.UtcTicks}
    return $null
}
function Find-ScheduleDates($Node){
    if($Node -is [Collections.IDictionary]){foreach($key in $Node.Keys){if($key -ceq 'customSecurityAttributes'){continue};if($key -in @('capturedAtUtc','startDateTime','endDateTime')){$instant=Get-ScheduleInstant $Node[$key];if($null -ne $instant){$null=$scheduleInstants.Add($instant)}}else{Find-ScheduleDates $Node[$key]}}}
    elseif($Node -is [array]){foreach($item in $Node){Find-ScheduleDates $item}}
}
if($isSnapshot){
    Find-ScheduleDates $inputData
    $captureInstant=Get-ScheduleInstant $inputData.capturedAtUtc
    $anchorIndex=0;if($null -ne $captureInstant){foreach($instant in $scheduleInstants){if($instant -lt $captureInstant){$anchorIndex++}}}
    $syntheticAnchor=[DateTime]::SpecifyKind([DateTime]'2000-01-01',[DateTimeKind]::Utc)
    $dateIndex=0;foreach($instant in $scheduleInstants){$scheduleDateMap[$instant]=$syntheticAnchor.AddMinutes($dateIndex-$anchorIndex).ToString('o');$dateIndex++}
}
function Convert-ScheduleDate($Value){
    if($null -eq $Value){return $null}
    $instant=Get-ScheduleInstant $Value
    if($null -ne $instant -and $scheduleDateMap.ContainsKey($instant)){return $scheduleDateMap[$instant]}
    # Invalid input must stay invalid; never invent a valid schedule/capture time.
    return 'Invalid schedule timestamp'
}
$mask4=[Security.Cryptography.RandomNumberGenerator]::GetBytes(4);$mask4[0]=$mask4[0] -bor 128
$mask6=[Security.Cryptography.RandomNumberGenerator]::GetBytes(16);$mask6[0]=$mask6[0] -bor 128
# Public built-in authentication strengths are semantics, not tenant identifiers.
$publicIds=@('00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000004','797f4846-ba00-4fd7-ba43-dac1f8f63013','00000002-0000-0000-c000-000000000000','00000003-0000-0000-c000-000000000000','01cb2876-7ebd-4aa4-9cc9-d28bd4d359a9')
function Next-Label([string]$Kind){$counters[$Kind]=1+$counters[$Kind];'{0}_{1:d4}' -f $Kind,$counters[$Kind]}
function Convert-Identifier([string]$Value){
    if(!$Value){return $Value}
    $parsed=[guid]::Empty
    $canonical=if([guid]::TryParse($Value,[ref]$parsed)){$parsed.ToString()}else{$Value}
    if($canonical -in $publicIds){return $canonical}
    if(!$idMap.ContainsKey($canonical)){$idMap[$canonical]=[guid]::NewGuid().ToString();$stats.identifiers++}
    return $idMap[$canonical]
}
function Convert-Text([string]$Value,[string]$Kind='Text'){
    if(!$Value){return $Value}
    if(!$textMap.ContainsKey($Value)){$textMap[$Value]=Next-Label $Kind;$stats.textValues++}
    return $textMap[$Value]
}
function Convert-Domain([string]$Value){
    if(!$domainMap.ContainsKey($Value)){$domainMap[$Value]=(Next-Label Domain).ToLowerInvariant().Replace('_','-')+'.example.invalid';$stats.textValues++}
    return $domainMap[$Value]
}
function Convert-AttributeText([string]$Value,[ValidateSet('CsaSet','CsaName','CsaValue')][string]$Kind){
    if($Value -ceq ''){return ''}
    $key=$Kind+":"+$Value
    if($attributeText.ContainsKey($key)){return $attributeText[$key]}
    $folded=$Kind+":"+$Value
    if(!$attributeClasses.ContainsKey($folded)){
        $base=(Next-Label $Kind).Replace('_','').ToLowerInvariant()+$(if($Kind -eq 'CsaValue'){'a'*20}else{'a'*12})
        if($Kind -ne 'CsaValue' -and $base.Length -gt 32){throw 'Too many attribute names to sanitise safely.'}
        $attributeClasses[$folded]=@{base=$base;next=0L}
    }
    $group=$attributeClasses[$folded];$bits=[long]$group.next;$group.next++
    $letters=$group.base.ToCharArray()
    for($i=0;$i -lt $letters.Length;$i++){if($letters[$i] -cmatch '[a-z]'){if($bits -band 1){$letters[$i]=[char]::ToUpperInvariant($letters[$i])};$bits=$bits -shr 1}}
    if($bits){throw 'Too many case variants to sanitise safely.'}
    $replacement=-join $letters;$attributeText.Add($key,$replacement);$stats.textValues++;return $replacement
}
foreach($definition in @($inputData.applicationAttributeDefinitions)){
    if($null -eq $definition){continue}
    if($definition -isnot [Collections.IDictionary] -or $definition.attributeSet -isnot [string] -or !$definition.attributeSet -or $definition.name -isnot [string] -or !$definition.name){throw 'Custom attribute definitions need set and name strings.'}
    $qualified=$definition.attributeSet+'_'+$definition.name
    if($definition.id -and $definition.id -cne $qualified){throw 'Custom attribute definition ID disagrees with its set/name.'}
    if($attributeDefinitions.ContainsKey($qualified)){throw 'Duplicate custom attribute definition.'}
    $attributeDefinitions.Add($qualified,$definition)
}
function Resolve-AttributeProperty([string]$Token){
    $parts=$Token.Split('.')
    if($parts.Count -eq 3){$set=$parts[1];$name=$parts[2];$separator='.'}
    elseif($parts.Count -eq 2){$qualified=$parts[1];if($attributeDefinitions.ContainsKey($qualified)){$set=$attributeDefinitions[$qualified].attributeSet;$name=$attributeDefinitions[$qualified].name}else{$names=$qualified.Split('_');if($names.Count -ne 2 -or !$names[0] -or !$names[1]){throw 'Cannot resolve a custom attribute property safely.'};$set=$names[0];$name=$names[1]};$separator='_'}
    else{throw 'Unsupported custom attribute property syntax.'}
    if(!$set -or !$name){throw 'Custom attribute properties need a set and name.'}
    @{property=$parts[0]+'.'+(Convert-AttributeText $set CsaSet)+$separator+(Convert-AttributeText $name CsaName);definition=$attributeDefinitions[$set+'_'+$name]}
}
function Convert-Ip([string]$Value){
    $parts=$Value.Split('/');$address=$null
    # IPAddress.TryParse accepts shorthand, octal, brackets and zone IDs. Those
    # forms are not accepted by the analyzer and must not become valid evidence
    # as a side effect of pseudonymization.
    $literal=$parts[0]
    if($literal.Contains(':')){
        if($literal -cnotmatch '^[0-9a-fA-F:]+$'){throw 'Unsupported IPv6 syntax cannot be sanitised.'}
    }else{
        $octets=$literal.Split('.')
        if($octets.Count -ne 4 -or @($octets|Where-Object {$_ -cnotmatch '^(0|[1-9][0-9]{0,2})$' -or [int]$_ -gt 255}).Count){throw 'Unsupported IPv4 syntax cannot be sanitised.'}
    }
    if($parts.Count -eq 2 -and $parts[1] -cnotmatch '^[0-9]+$'){throw 'Unsupported CIDR prefix syntax cannot be sanitised.'}
    if($parts.Count -gt 2 -or ![Net.IPAddress]::TryParse($parts[0],[ref]$address)){throw 'An IP address or CIDR range could not be sanitised.'}
    $bytes=$address.GetAddressBytes();$mask=if($bytes.Length -eq 4){$mask4}else{$mask6}
    $prefix=$bytes.Length*8
    if($parts.Count -eq 2 -and (![int]::TryParse($parts[1],[ref]$prefix) -or $prefix -lt 0 -or $prefix -gt $bytes.Length*8)){throw 'Invalid CIDR prefix.'}
    for($i=0;$i -lt $bytes.Length;$i++){
        $bytes[$i]=$bytes[$i] -bxor $mask[$i]
        if($parts.Count -eq 2){$bits=[Math]::Clamp($prefix-8*$i,0,8);$networkMask=if($bits -eq 0){0}else{(255 -shl (8-$bits)) -band 255};$bytes[$i]=$bytes[$i] -band $networkMask}
    }
    $stats.ipValues++
    $result=[Net.IPAddress]::new([byte[]]$bytes).ToString()
    if($parts.Count -eq 2){$result+='/'+$prefix}
    return $result
}
# Unknown string values and property names are replaced, rather than trusted as
# harmless. Only explicitly listed schema vocabulary is retained.
$safeKeys=@('
id appId tenantId tenantName displayName description name value schemaVersion caGapSnapshotVersion
policies users groups groupMembers roles roleAssignments roleEligibility roleAssignmentScheduleInstances authenticationStrengths namedLocations applications authenticationContexts
applicationAttributeDefinitions applicationAttributes applicationAttributeReadScope customSecurityAttributes attributeSet isCollection isSearchable usePreDefinedValuesOnly status
pimGroupEligibility pimGroupAssignments groupDirectMembers groupId accessId assignmentScheduleId eligibilityScheduleId eligibleGroupIds
assignmentType memberType roleAssignmentOriginId roleAssignmentScheduleId roleEligibilityScheduleId
deviceRegistrationPolicy multiFactorAuthConfiguration azureADRegistration azureADJoin allowedToJoin allowedToRegister isAdminConfigurable userDeviceQuota localAdmins registeringUsers enableGlobalAdmins localAdminPassword
conditions grantControls sessionControls state operator builtInControls customAuthenticationFactors termsOfUse authenticationStrength
includeUsers excludeUsers includeGroups excludeGroups includeRoles excludeRoles includeGuestsOrExternalUsers excludeGuestsOrExternalUsers
guestOrExternalUserTypes externalTenants membershipKind members includeTenants excludeTenants
includeApplications excludeApplications includeUserActions includeAuthenticationContextClassReferences applicationFilter
clientAppTypes platforms includePlatforms excludePlatforms locations includeLocations excludeLocations
userRiskLevels signInRiskLevels servicePrincipalRiskLevels insiderRiskLevels devices deviceFilter mode rule
clientApplications includeServicePrincipals excludeServicePrincipals servicePrincipalFilter authenticationFlows transferMethods
signInFrequency persistentBrowser cloudAppSecurity applicationEnforcedRestrictions secureSignInSession
continuousAccessEvaluation disableResilienceDefaults globalSecureAccessFilteringProfile profileId cloudAppSecurityType type authenticationType frequencyInterval isEnabled
policyType requirementsSatisfied allowedCombinations combinationConfigurations allowedAAGUIDs
certificateAuthenticationMode allowedIssuerSkis allowedPolicyOIDs
templateId isBuiltIn isPrivileged roleDefinitionId principalId directoryScopeId appScopeId
userType userPrincipalName mail otherMails proxyAddresses jobTitle department companyName creationType externalTenantId
externalUserType
groupIds roleIds activeRoleIds accountIds privileged pimEligible privilegeKnown accountEnabled
visibility isAssignableToRole groupTypes membershipRule membershipRuleProcessingState
isTrusted ipRanges cidrAddress countriesAndRegions includeUnknownCountriesAndRegions countryLookupMethod compliantNetworkLocations compliantNetworkType legacyMfaTrustedIpRanges legacyMfaFederatedIntranetEnabled
completeness errors collection message scopeNotes organization capturedAtUtc
resourceGroups resourceGroupEvidenceVersion members nonMembers complete provenance kind observedAtUtc
createdDateTime modifiedDateTime deletedDateTime startDateTime endDateTime
') -split '\s+'|Where-Object {$_}
$safeKeySet=[Collections.Generic.HashSet[string]]::new([string[]]$safeKeys,[StringComparer]::OrdinalIgnoreCase)
$enums=@{
    kind=@('declared','whatIf','microsoftDocumentation')
    multiFactorAuthConfiguration=@('notRequired','required','unknownFutureValue')
    assignmentType=@('Assigned','Activated','assigned','activated','unknownFutureValue')
    memberType=@('Direct','Group','Inherited','direct','group','unknownFutureValue')
    accessId=@('member','owner','unknownFutureValue')
    externalUserType=@('none','internalGuest','b2bCollaborationGuest','b2bCollaborationMember','b2bDirectConnectUser','otherExternalUser','serviceProvider','unknownFutureValue')
    state=@('enabled','disabled','enabledForReportingButNotEnforced','reportOnly')
    operator=@('AND','OR')
    builtInControls=@('block','mfa','compliantDevice','domainJoinedDevice','approvedApplication','compliantApplication','passwordChange','riskRemediation','unknownFutureValue')
    clientAppTypes=@('all','browser','mobileAppsAndDesktopClients','exchangeActiveSync','easSupported','other','unknownFutureValue')
    includePlatforms=@('all','windows','macOS','iOS','android','linux','windowsPhone','unknownFutureValue')
    excludePlatforms=@('all','windows','macOS','iOS','android','linux','windowsPhone','unknownFutureValue')
    userRiskLevels=@('none','low','medium','high','hidden','unknownFutureValue')
    signInRiskLevels=@('none','low','medium','high','hidden','unknownFutureValue')
    servicePrincipalRiskLevels=@('none','low','medium','high','hidden','unknownFutureValue')
    insiderRiskLevels=@('none','minor','moderate','elevated','unknownFutureValue')
    includeUsers=@('All','None','GuestsOrExternalUsers');excludeUsers=@('All','None','GuestsOrExternalUsers')
    includeApplications=@('All','Office365','MicrosoftAdminPortals','AllAgentIdResources');excludeApplications=@('All','Office365','MicrosoftAdminPortals','AllAgentIdResources')
    includeLocations=@('All','AllTrusted');excludeLocations=@('All','AllTrusted')
    includeServicePrincipals=@('ServicePrincipalsInMyTenant');excludeServicePrincipals=@('ServicePrincipalsInMyTenant')
    includeUserActions=@('urn:user:registersecurityinfo','urn:user:registerdevice')
    cloudAppSecurityType=@('mcasConfigured','monitorOnly','blockDownloads');membershipKind=@('all','enumerated');mode=@('include','exclude','always','never','strictEnforcement','strictLocation','disabled')
    frequencyInterval=@('timeBased','everyTime');authenticationType=@('primaryAndSecondaryAuthentication','secondaryAuthentication')
    type=@('hours','days','mcasConfigured','monitorOnly','blockDownloads');policyType=@('builtIn','custom');requirementsSatisfied=@('none','mfa')
    userType=@('Member','Guest');creationType=@('Invitation','LocalAccount','EmailVerified','Synchronized')
    visibility=@('Public','Private','HiddenMembership');groupTypes=@('Unified','DynamicMembership');membershipRuleProcessingState=@('On','Paused')
    countryLookupMethod=@('clientIpAddress','authenticatorAppGps')
    compliantNetworkType=@('allTenantCompliantNetworks')
    transferMethods=@('none','deviceCodeFlow','authenticationTransfer','unknownFutureValue')
    guestOrExternalUserTypes=@('internalGuest','b2bCollaborationGuest','b2bCollaborationMember','b2bDirectConnectUser','otherExternalUser','serviceProvider')
    allowedCombinations=@('password','sms','voice','microsoftAuthenticatorPush','microsoftAuthenticatorPasswordless','deviceBasedPush','softwareOath','hardwareOath','fido2','windowsHelloForBusiness','x509CertificateMultiFactor','x509CertificateSingleFactor','temporaryAccessPassOneTime','temporaryAccessPassMultiUse','federatedSingleFactor','federatedMultiFactor','email','unknownFutureValue')
}
function Convert-Filter([string]$Rule){
    $stats.filterExpressions++
    $tokens=[regex]::Matches($Rule,'''(?:''''|[^''])*''|"(?:\\.|[^"\\])*"|[\p{L}_][\p{L}\p{N}\p{M}_.]*|-[A-Za-z]+|\d+(?:\.\d+)*|\s+|[()\[\],]')
    if(($tokens.Value -join '') -cne $Rule){throw 'A filter uses unsupported syntax. No sanitised output was written.'}
    $result=[Text.StringBuilder]::new();$property='';$custom=$null;$comparison=''
    foreach($token in $tokens){
        $part=$token.Value
        if($part.StartsWith("'") -or $part.StartsWith('"')){
            $quote=$part.Substring(0,1);$literal=$part.Substring(1,$part.Length-2).Replace("''","'")
            if($quote -eq '"'){$literalDocument=[System.Text.Json.JsonDocument]::Parse($part);try{$literal=$literalDocument.RootElement.GetString()}finally{$literalDocument.Dispose()}}
            if($custom){
                if($isSnapshot -and $comparison -in @('-startswith','-notstartswith','-endswith','-notendswith','-contains','-notcontains') -and $custom.definition.isCollection -ne $true){throw 'Scalar custom-attribute substring relationships cannot be preserved by this sanitizer. No output was written.'}
                $null=$result.Append("'"+(Convert-AttributeText $literal CsaValue)+"'");continue
            }
            $safe=($property -eq 'trustType' -and $literal -in @('AzureAD','ServerAD','Workplace')) -or ($property -eq 'operatingSystem' -and $literal -in @('Windows','macOS','iOS','Android','Linux')) -or ($property -eq 'deviceOwnership' -and $literal -in @('Company','Personal'))
            if($safe){$replacement=$literal}elseif([guid]::TryParse($literal,[ref]([guid]::Empty))){$replacement=Convert-Identifier $literal}else{$replacement=Convert-Text $literal FilterValue}
            $null=$result.Append("'"+$replacement.Replace("'","''")+"'")
        }elseif($part -match '^[A-Za-z_]'){
            if($part -in @('true','false','null')){$null=$result.Append($part);continue}
            $custom=$null;$comparison=''
            if($part -imatch '^CustomSecurityAttribute\.'){$custom=Resolve-AttributeProperty $part;$null=$result.Append($custom.property);continue}
            $segments=$part.Split('.');$property=$segments[-1]
            $clean=@(foreach($segment in $segments){if($segment -in @('device','app','application','user','CustomSecurityAttribute') -or $safeKeySet.Contains($segment) -or $segment -match '^(extensionAttribute(?:[1-9]|1[0-5])|deviceId|operatingSystem|operatingSystemVersion|trustType|deviceOwnership|isRooted|model|manufacturer|enrollmentProfileName|physicalIds|systemLabels|profileType|managementType|deviceCategory|isCompliant|isManaged)$'){$segment}else{Convert-Text $segment Attribute}})
            $null=$result.Append(($clean -join '.'))
        }else{if($part.StartsWith('-')){$comparison=$part.ToLowerInvariant()};$null=$result.Append($part)}
    }
    return $result.ToString()
}
function Convert-String([string]$Value,[string]$Field,[string]$Kind){
    if(!$Value){return $Value}
    if($Field -eq 'rule' -or $Field -eq 'membershipRule'){return Convert-Filter $Value}
    if($Kind -eq 'AttributeDefinition'){
        if($Field -eq 'attributeSet'){return Convert-AttributeText $Value CsaSet}
        if($Field -eq 'name'){return Convert-AttributeText $Value CsaName}
        if($Field -eq 'type' -and $Value -cin @('String','Boolean','Integer')){return $Value}
        if($Field -eq 'status' -and $Value -cin @('Available','Deprecated')){return $Value}
    }
    if($Field -eq 'applicationAttributeReadScope' -and $Value -ceq 'unverified'){return $Value}
    if($Field -eq 'collection'){
        if($Value -cin @('organization','policies','users','groups','groupMembers','roles','roleAssignments','roleEligibility','roleAssignmentScheduleInstances','authenticationStrengths','namedLocations','compliantNetworkLocations','applications','deviceRegistrationPolicy','applicationAttributeDefinitions','applicationAttributes','pimGroupEligibility','pimGroupAssignments','groupDirectMembers')){return $Value}
        if($Value -cmatch '^(members|groupMembers|strengthConfigurations|pimGroupEligibility|pimGroupAssignments|groupDirectMembers):(.+)$'){return $Matches[1]+':'+(Convert-Identifier $Matches[2])}
    }
    if($Field -eq '@odata.type' -and $Value -cmatch '^#?microsoft\.graph\.[A-Za-z][A-Za-z0-9]*$'){return $Value}
    if($Field -eq 'includeAuthenticationContextClassReferences' -or ($Field -eq 'id' -and $Kind -eq 'Context')){if($Value -cmatch '^c[1-9]\d?$'){return $Value}}
    if($Kind -eq 'ResourceGroup' -and $Field -eq 'id' -and $Value -in @('Office365','MicrosoftAdminPortals')){return $Value}
    if($Kind -eq 'ResourceGroup' -and $Field -in @('members','nonMembers')){return Convert-Identifier $Value}
    if($Field -eq 'countriesAndRegions' -and $Value -cmatch '^[A-Za-z]{2}$'){return $Value}
    if($enums.ContainsKey($Field)){
        $values=@($Value -split ','|ForEach-Object {$_.Trim()})
        if($Field -eq 'allowedCombinations' -and @($values|Where-Object {$_ -notin $enums[$Field]}).Count -eq 0){return $Value}
        if(@($values|Where-Object {$_ -cnotin $enums[$Field]}).Count -eq 0){return $Value}
    }
    if($Field -eq 'cidrAddress' -or $Field -in @('ipAddress','ipRange','legacyMfaTrustedIpRanges')){return Convert-Ip $Value}
    if($Field -in @('directoryScopeId','appScopeId') -and $Value -eq '/'){return '/'}
    if($Field -in @('directoryScopeId','appScopeId') -and $Value.StartsWith('/')){
        $scopeParts=@($Value.Trim('/').Split('/')|ForEach-Object {if($_ -in @('administrativeUnits','applications','servicePrincipals','users','groups','AccessPackageCatalog')){$_}else{Convert-Identifier $_}})
        return '/'+($scopeParts -join '/')
    }
    $guid=[guid]::Empty
    if([guid]::TryParse($Value,[ref]$guid)){return Convert-Identifier $Value}
    if($Field -eq 'allowedAAGUIDs'){throw 'An authenticator AAGUID is not a GUID.'}
    if($Field -match '(?i)(Id|Ids)$' -or $Field -in @('id','includeUsers','excludeUsers','includeGroups','excludeGroups','includeRoles','excludeRoles','includeApplications','excludeApplications','includeLocations','excludeLocations','includeServicePrincipals','excludeServicePrincipals','includeTenants','excludeTenants','groupMembers')){return Convert-Identifier $Value}
    if($Value -match '^[^\s@]+@([^\s@]+)$'){
        $domain=Convert-Domain $Matches[1];return (Convert-Text $Value User)+'@'+$domain
    }
    if($Field -in @('domainName','verifiedDomain','publisherDomain')){return Convert-Domain $Value}
    if($Value -match '^https?://'){
        $uri=$null
        if([uri]::TryCreate($Value,[UriKind]::Absolute,[ref]$uri)){return 'https://'+(Convert-Domain $uri.Host)+'/'+(Convert-Text $Value Resource)}
    }
    if($Field -eq 'displayName' -or $Field -eq 'name'){return Convert-Text $Value $Kind}
    if($Field -eq 'tenantName'){return Convert-Text $Value Tenant}
    return Convert-Text $Value Text
}
function Convert-Node($Node,[string]$Field='',[string]$Kind='Text'){
    if($null -eq $Node){return $null}
    if($Field -ceq '$attributeSet' -and $Node -isnot [Collections.IDictionary]){throw 'Custom attribute sets must be objects or null.'}
    if($Field -ceq '$attributeValue' -and $Node -is [Collections.IDictionary]){throw 'Custom attribute values must be scalars or arrays.'}
    if($Node -is [Collections.IDictionary]){
        if($Field -eq 'customSecurityAttributes'){
            $mapped=[System.Management.Automation.OrderedHashtable]::new()
            foreach($key in $Node.Keys){if($key -ceq '@odata.type'){continue};$mapped[(Convert-AttributeText $key CsaSet)]=Convert-Node $Node[$key] '$attributeSet' $Kind}
            return $mapped
        }
        if($Field -ceq '$attributeSet'){
            $mapped=[System.Management.Automation.OrderedHashtable]::new()
            foreach($key in $Node.Keys){
                if($key -ceq '@odata.type'){if($Node[$key] -notin @('#Microsoft.DirectoryServices.CustomSecurityAttributeValue','#microsoft.graph.customSecurityAttributeValue')){throw 'Unknown custom attribute metadata type.'};$mapped[$key]=$Node[$key];continue}
                if($key.EndsWith('@odata.type',[StringComparison]::Ordinal)){if($Node[$key] -notin @('#Collection(String)','#Collection(Boolean)','#Collection(Int32)','#Collection(Int64)')){throw 'Unknown custom attribute collection annotation.'};$mapped[(Convert-AttributeText $key.Substring(0,$key.Length-11) CsaName)+'@odata.type']=$Node[$key];continue}
                $mapped[(Convert-AttributeText $key CsaName)]=Convert-Node $Node[$key] '$attributeValue' $Kind
            }
            return $mapped
        }
        if($Node.Contains('conditions')){$Kind='Policy'}
        $result=[ordered]@{}
        foreach($key in $Node.Keys){
            if($Kind -eq 'AttributeDefinition' -and $key -eq 'id'){$result[$key]=(Convert-AttributeText $Node.attributeSet CsaSet)+'_'+(Convert-AttributeText $Node.name CsaName);continue}
            if($key -like '*@odata.nextLink' -and $Node[$key]){throw 'Export contains a pagination link. Export every page before sanitising.'}
            if($isSnapshot -and $key -in @('capturedAtUtc','startDateTime','endDateTime')){$result[$key]=Convert-ScheduleDate $Node[$key];continue}
            if(($key -match '@odata\.' -and $key -ne '@odata.type') -or $key -match '^(?i:createdDateTime|modifiedDateTime|deletedDateTime|startDateTime|endDateTime|capturedAtUtc|observedAtUtc|passwordCredentials|keyCredentials|secretText|clientSecret|accessToken|refreshToken|idToken|access_token|refresh_token|id_token|privateKey|certificate)$'){$stats.removedFields++;continue}
            $cleanKey=$key;$childField=$key
            if($Field -in @('groupMembers','groupDirectMembers')){$cleanKey=Convert-Identifier $key;$childField='groupMembers'}
            elseif($key -match '^(members|groupMembers|strengthConfigurations|pimGroupEligibility|pimGroupAssignments|groupDirectMembers):(.+)$'){$cleanKey=$Matches[1]+':'+(Convert-Identifier $Matches[2])}
            elseif([guid]::TryParse($key,[ref]([guid]::Empty))){$cleanKey=Convert-Identifier $key}
            elseif(!$safeKeySet.Contains($key) -and $key -ne '@odata.type'){$cleanKey=Convert-Text $key Field;$stats.unknownFields++}
            $childKind=switch($key){policies {'Policy'};users {'Account'};groups {'Group'};roles {'Role'};applications {'Application'};applicationAttributes {'Application'};applicationAttributeDefinitions {'AttributeDefinition'};resourceGroups {'ResourceGroup'};namedLocations {'Location'};compliantNetworkLocations {'Location'};authenticationContexts {'Context'};authenticationStrength {'Strength'};signInFrequency {'SignInFrequency'};default {$Kind}}
            $result[$cleanKey]=Convert-Node $Node[$key] $childField $childKind
        }
        return $result
    }
    if($Node -is [array]){
        $result=[Collections.Generic.List[object]]::new()
        foreach($item in $Node){$result.Add((Convert-Node $item $Field $Kind))}
        return ,$result.ToArray()
    }
    if($Node -is [string]){if($Field -ceq '$attributeValue'){return Convert-AttributeText $Node CsaValue};return Convert-String $Node $Field $Kind}
    if($Node -is [bool]){return $Node}
    if($Node -is [ValueType]){
        if($Field -in @('caGapSnapshotVersion','schemaVersion','userDeviceQuota') -or ($Field -eq 'value' -and $Kind -eq 'SignInFrequency')){return $Node}
        if($Field -match '(?i)(Id|Ids)$'){return Convert-Identifier ([string]$Node)}
        $stats.textValues++;return 0
    }
    throw 'Unsupported JSON value.'
}
$sanitized=Convert-Node $inputData
$json=ConvertTo-Json -InputObject $sanitized -Depth 100
# Validate before creating output; failures never leave a partially sanitised file.
$null=ConvertFrom-Json -InputObject $json -AsHashtable -NoEnumerate -Depth 100
[IO.File]::WriteAllText($outputFile,$json,[Text.UTF8Encoding]::new($false))
Write-Host "Sanitised export saved. $($stats.identifiers) identifiers and $($stats.textValues) text values replaced; $($stats.removedFields) metadata/credential fields removed."
if($stats.filterExpressions){Write-Warning 'Filter expressions were sanitised. Text prefix/substring relationships may change; review filters before using them as correctness fixtures.'}
if($stats.ipValues){Write-Warning 'IP ranges were remapped with overlap/prefix relationships preserved. Geolocation and private/public address categories are not preserved. Synthetic addresses must not be used online.'}
if($stats.unknownFields){Write-Warning 'Unrecognised property names were also replaced. Unsupported features may need review in the analyzer.'}
