# CA Gap Analyzer — development package

Keep this folder together. Requires Windows x64 and PowerShell 7.4 or later.

- Double-click Open-Analyzer.cmd for the local browser interface.
- Start-Assessment.ps1 assesses a snapshot and exported requirements offline.
- Test-PortablePackage.ps1 verifies packaged file hashes.
- See docs/UNATTENDED-ASSESSMENTS.md for examples and scheduling.

No Node, .NET SDK, package restore or internet connection is needed for offline
assessment. Connecting/exporting from a tenant is optional and uses separate
read-only authentication. This copy contains no tenant connection, saved account
definitions, accepted exceptions, tenant exports, tokens or recovery credentials.
User data is created locally after use. Keep that data with the folder if you
move an existing workspace.

This is a development build. Unsupported behavior and missing data must remain
visible; a passing finite-model result is not proof of successful authentication,
method availability or every Entra runtime behavior. Release validation is ongoing.
