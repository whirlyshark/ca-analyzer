# Opt-in streamed UI assessments. The existing JSON endpoints remain compatible.
# The worker owns assessment state; the HTTP loop only reads its event queue.
function Send-CaAssessmentStream($Context,$Body,[string]$Root,[bool]$Snapshot){
    $response=$Context.Response
    $response.ContentType='application/x-ndjson; charset=utf-8';$response.SendChunked=$true
    $response.Headers['Cache-Control']='no-store';$response.Headers['X-Content-Type-Options']='nosniff'
    $queue=[Collections.Concurrent.ConcurrentQueue[string]]::new()
    $worker=[powershell]::Create();$handle=$null
    function Write-Event($Event){
        $bytes=[Text.Encoding]::UTF8.GetBytes(($Event|ConvertTo-Json -Depth 100 -Compress)+"`n")
        $response.OutputStream.Write($bytes,0,$bytes.Length);$response.OutputStream.Flush()
    }
    try{
        Write-Event @{type='progress';stage='prepare';message='Starting your coverage check'}
        $null=$worker.AddScript({param($root,$body,$queue,$snapshot)
            $ErrorActionPreference='Stop'
            Import-Module (Join-Path $root 'CA.GapAnalyzer.psd1') -Force
            . (Join-Path $root 'engine/Interactive.ps1')
            . (Join-Path $root 'engine/Assessment.ps1')
            . (Join-Path $root 'engine/LocalState.ps1')
            $progress={param($event);$event.type='progress';$queue.Enqueue(($event|ConvertTo-Json -Depth 8 -Compress))}
            $null=& $progress @{stage='prepare';message='Reading your exported data'}
            if($body -is [string]){$body=$body|ConvertFrom-CaJson}
            if($snapshot){Invoke-CaInteractiveAssessment $body.snapshot $body.profile -Progress $progress}
            else{
                $accepted=Read-CaLocalState -Path (Join-Path $root 'data/acceptances.local.json')
                Invoke-CaAssessmentCore -Model $body.model -CoverageIssues @($body.coverageIssues) -Acceptances $accepted -SourceKey ([string]$body.sourceKey) -AcceptanceEvidence $body.acceptanceEvidence -Progress $progress
            }
        }).AddArgument($Root).AddArgument($Body).AddArgument($queue).AddArgument($Snapshot)
        $handle=$worker.BeginInvoke()
        while(!$handle.IsCompleted){
            $entry=$null
            while($queue.TryDequeue([ref]$entry)){Write-Event ($entry|ConvertFrom-Json -AsHashtable)}
            Write-Event @{type='heartbeat'}
            Start-Sleep -Milliseconds 200
        }
        $output=@($worker.EndInvoke($handle))
        if($worker.HadErrors){throw $worker.Streams.Error[0]}
        if($output.Count -ne 1){throw 'The coverage check did not return a complete result.'}
        $entry=$null
        while($queue.TryDequeue([ref]$entry)){Write-Event ($entry|ConvertFrom-Json -AsHashtable)}
        $result=$output[0]
        Write-Event @{type='result';result=$result}
        return $result
    }catch{
        # A closed tab cannot receive an error. Never send a partial result.
        try{Write-Event @{type='error';message=$_.Exception.Message}}catch{}
        return $null
    }finally{
        if($handle -and !$handle.IsCompleted){$worker.Stop()}
        $worker.Dispose();$response.Close()
    }
}
