using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;

namespace CaGapAnalyzer
{
    // A finite, explicit model. This is not a Microsoft Graph policy parser.
    public sealed class Model
    {
        public int SchemaVersion { get; set; }
        public Dictionary<string, string[]> Dimensions { get; set; } = new();
        public Identity[] Identities { get; set; } = Array.Empty<Identity>();
        public Policy[] Policies { get; set; } = Array.Empty<Policy>();
        public Requirement[] Requirements { get; set; } = Array.Empty<Requirement>();
        // Supplemental unresolved source facts bind exception fingerprints.
        // They are never interpreted as grants or applicability predicates.
        public JsonElement DiagnosticEvidence { get; set; }
        // AND of groups; each group is an OR of valid scenario rectangles.
        // This preserves relationships between claims rather than independently
        // combining impossible device, authentication or activation states.
        public Dictionary<string, Selector>[][] ScenarioConstraints { get; set; } = Array.Empty<Dictionary<string, Selector>[]>();
    }
    public sealed class Identity
    {
        public string Id { get; set; } = "";
        public bool Privileged { get; set; }
        public bool PimEligible { get; set; }
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // Per-person AND groups of OR rectangles, for coupled eligibility and
        // activation facts that cannot be represented by independent axes.
        public Dictionary<string, Selector>[][] ScenarioConstraints { get; set; } = Array.Empty<Dictionary<string, Selector>[]>();
    }
    public sealed class Selector
    {
        public string[] Include { get; set; } = Array.Empty<string>();
        public string[] Exclude { get; set; } = Array.Empty<string>();
    }
    public sealed class Policy
    {
        public string Id { get; set; } = "";
        public string State { get; set; } = "enabled";
        public string[] IncludeUsers { get; set; } = new[] { "*" };
        public string[] ExcludeUsers { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // OR of alternatives; dimensions within each alternative are ANDed.
        // [] = block; [{}] = no additional grant restriction.
        public Dictionary<string, Selector>[] GrantAlternatives { get; set; } = Array.Empty<Dictionary<string, Selector>>();
        public bool UnverifiedApplicationFilter { get; set; }
        public bool UnverifiedLocations { get; set; }
        // Null is legacy/unknown evidence, not proof of passive IP matching.
        public bool? LocationMatchingOnly { get; set; }
        // The app grants remain valid for app access. Registration without a
        // resource needs a separate applicability upper bound, never a grant.
        public bool RegistrationResourceContext { get; set; }
        // Proof of permitted grants only; never used to credit protection.
        // Absent/empty means no request is proved immune to a possible denial.
        public Dictionary<string, Selector>[] GuaranteedGrantAlternatives { get; set; }
        public Dictionary<string, Selector>[] GuaranteedRegistrationGrantAlternatives { get; set; }
    }
    public sealed class Requirement
    {
        public string Id { get; set; } = "";
        public string Scope { get; set; } = "all";
        public string[] IncludeUsers { get; set; } = new[] { "*" };
        public string[] ExcludeUsers { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
        // OR clauses, intersected with Conditions. Null means no extra bound;
        // an empty array deliberately means an empty scenario scope.
        public Dictionary<string, Selector>[] ConditionAlternatives { get; set; }
        public string[] AllowedAuthentication { get; set; } = Array.Empty<string>();
        public bool MustBlock { get; set; }
        public Dictionary<string, Selector>[] RequiredAlternatives { get; set; }
    }
    public sealed class Gap
    {
        public string RequirementId { get; set; } = "";
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public Dictionary<string, string[]> Region { get; set; } = new();
        public Dictionary<string, string> Witness { get; set; } = new();
        public string[] ApplicablePolicyIds { get; set; } = Array.Empty<string>();
        public string[] NonApplicablePolicyIds { get; set; } = Array.Empty<string>();
    }
    public sealed class Analysis
    {
        public string EngineVersion { get; set; } = "0.3.0-rc.1";
        public string Status { get; set; } = "completeWithinModel";
        public string Limitation { get; set; } = "Exhaustive only over the supplied finite normalized model; no claim of complete Entra semantics or real sign-in reachability.";
        public int IdentityCount { get; set; }
        public int IdentityProfileCount { get; set; }
        public bool ProfileGroupingEnabled { get; set; }
        public long RegionSubtractionCount { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public List<Gap> Gaps { get; set; } = new();
        public string[] EmptyRequirementIds { get; set; } = Array.Empty<string>();
        public string[] UnverifiedApplicationFilterPolicyIds { get; set; } = Array.Empty<string>();
        public string[] UnverifiedLocationPolicyIds { get; set; } = Array.Empty<string>();
        public string[] RegistrationResourcePolicyIds { get; set; } = Array.Empty<string>();
    }
    internal sealed class Region
    {
        public HashSet<string>[] Axes;
        public Region(HashSet<string>[] axes) { Axes = axes; }
        public Region Copy() => new Region(Axes.Select(x => new HashSet<string>(x, StringComparer.Ordinal)).ToArray());
    }
    internal sealed class ContextPolicyScope
    {
        public HashSet<string> People;
        public Region Condition;
        public Region[] Grants;
    }
    public sealed class PolicyContextQuery
    {
        public string RequirementId { get; set; } = "";
        public string[] PolicyIds { get; set; } = Array.Empty<string>();
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public string[] RelaxedAxes { get; set; } = Array.Empty<string>();
        public string MatchMode { get; set; } = "denied";
        public Dictionary<string, string[]> PolicyIdentityBindings { get; set; }
    }
    public sealed class GapRefinementCut
    {
        public string RequirementId { get; set; } = "";
        public string[] IdentityIds { get; set; } = Array.Empty<string>();
        public Dictionary<string, Selector> Conditions { get; set; } = new();
    }
    public sealed class GapRefinementResult
    {
        public string Status { get; set; } = "complete";
        public int OriginalGroups { get; set; }
        public Gap[] Gaps { get; set; } = Array.Empty<Gap>();
        public int[] ParentGapIndices { get; set; } = Array.Empty<int>();
    }
    public static class Engine
    {
        private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            UnmappedMemberHandling = System.Text.Json.Serialization.JsonUnmappedMemberHandling.Disallow
        };
        // Could an uncertain policy change any remaining permitted violation?
        // Only PIM membership/role coordinates may be relaxed. Other request
        // conditions and grant alternatives remain exact. The applicable mode
        // checks downstream session effects without relaxing any coordinates.
        // Null means unproved.
        public static string RelevantPolicyContexts(string modelJson, string gapsJson, string queriesJson, int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => RelevantPolicyContextsCore(modelJson, gapsJson, queriesJson, maxRegions, timeoutMilliseconds, false);
        // Same proof, preserving the individual gap answers. A row is published
        // only after every policy has been checked; invalid/bounded rows stay null.
        public static string RelevantPolicyContextsByGap(string modelJson, string gapsJson, string queriesJson, int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => RelevantPolicyContextsCore(modelJson, gapsJson, queriesJson, maxRegions, timeoutMilliseconds, true);
        private static string RelevantPolicyContextsCore(string modelJson, string gapsJson, string queriesJson, int maxRegions, int timeoutMilliseconds, bool byGap)
        {
            if (maxRegions < 1 || timeoutMilliseconds < 1) throw new ArgumentException("Limits must be positive.");
            var model = JsonSerializer.Deserialize<Model>(modelJson, JsonOptions) ?? throw new ArgumentException("Missing model.");
            Validate(model);
            var gaps = JsonSerializer.Deserialize<Gap[]>(gapsJson, JsonOptions) ?? throw new ArgumentException("Missing gaps.");
            var queries = JsonSerializer.Deserialize<PolicyContextQuery[]>(queriesJson, JsonOptions) ?? throw new ArgumentException("Missing queries.");
            if (byGap && (long)queries.Length * gaps.Length > maxRegions) throw new ArgumentException("Per-gap context matrix exceeds the configured limit.");
            var results = new bool?[queries.Length];
            var matrix = byGap ? queries.Select(_ => new bool?[gaps.Length]).ToArray() : null;
            var clock = Stopwatch.StartNew();
            var names = model.Dimensions.Keys.OrderBy(x => x, StringComparer.Ordinal).ToArray();
            var universe = new Region(names.Select(n => new HashSet<string>(model.Dimensions[n], StringComparer.Ordinal)).ToArray());
            var identities = model.Identities.Select(u => u.Id).ToHashSet(StringComparer.Ordinal);
            // Retain sparse bounds. Copying every app/network domain for every
            // person would undo the analyzer's identity-profile grouping.
            var identityBounds = model.Identities.ToDictionary(u => u.Id, u => u.Conditions, StringComparer.Ordinal);
            var policies = model.Policies.ToDictionary(p => p.Id, StringComparer.Ordinal);
            var requirements = model.Requirements.Select(r => r.Id).ToHashSet(StringComparer.Ordinal);
            void Check(int count = 0) { if (count > maxRegions || clock.ElapsedMilliseconds >= timeoutMilliseconds) throw new BudgetException("contextLimit"); }
            var gapRegions = gaps.Select(g => {
                if (g == null || !requirements.Contains(g.RequirementId) || g.Region == null || g.Region.Count != names.Length || g.IdentityIds == null || g.IdentityIds.Length == 0 || g.IdentityIds.Any(id => !identities.Contains(id))) throw new ArgumentException("Invalid gap evidence.");
                return new Region(names.Select((n,i) => {
                    if (!g.Region.TryGetValue(n, out var values) || values == null || values.Length == 0 || values.Any(v => !universe.Axes[i].Contains(v))) throw new ArgumentException("Invalid gap domain.");
                    return values.ToHashSet(StringComparer.Ordinal);
                }).ToArray());
            }).ToArray();
            for (int q = 0; q < queries.Length; q++)
            {
                try
                {
                    Check();
                    var query = queries[q];
                    if (!ValidPolicyContext(query, model, policies, requirements, identities, out var people)) continue;
                    bool relevant = false;
                    var gapAnswers = byGap ? new bool[gaps.Length] : null;
                    foreach (var policyId in query.PolicyIds.Distinct(StringComparer.Ordinal))
                    {
                        Check();
                        var scope = GetContextPolicyScope(query, policies[policyId], people, identityBounds, universe, names, Check);
                        if (scope == null) continue;
                        for (int i = 0; i < gaps.Length; i++)
                        {
                            Check(); var gap = gaps[i];
                            if (byGap && gapAnswers[i]) continue;
                            bool sameRequirement = gap.RequirementId == query.RequirementId || new[] { ":outside-network", ":outside-apps", ":outside-device" }.Any(s => gap.RequirementId == query.RequirementId + s);
                            if (!sameRequirement || !gap.IdentityIds.Any(scope.People.Contains)) continue;
                            var overlap = Intersect(gapRegions[i], scope.Condition);
                            if (overlap == null) continue;
                            if (query.MatchMode == "applicable") { relevant = true; if (byGap) { gapAnswers[i] = true; continue; } break; }
                            var remaining = new List<Region> { overlap };
                            foreach (var grant in scope.Grants)
                            {
                                var next = new List<Region>();
                                foreach (var region in remaining) { next.AddRange(Subtract(region, grant)); Check(next.Count); }
                                remaining = next;
                                if (remaining.Count == 0) break;
                            }
                            if (remaining.Count > 0) { relevant = true; if (byGap) { gapAnswers[i] = true; continue; } break; }
                        }
                        if (relevant && !byGap) break;
                    }
                    results[q] = relevant;
                    if (byGap) matrix[q] = gapAnswers.Select(value => (bool?)value).ToArray();
                }
                catch (BudgetException) { break; }
            }
            return byGap ? JsonSerializer.Serialize(matrix) : JsonSerializer.Serialize(results);
        }
        private static bool SameRequirement(string gap, string query) => gap == query || new[] { ":outside-network", ":outside-apps", ":outside-device" }.Any(s => gap == query + s);
        private static ContextPolicyScope GetContextPolicyScope(PolicyContextQuery query, Policy policy, HashSet<string> people, Dictionary<string, Dictionary<string, Selector>> identityBounds, Region universe, string[] names, Action<int> check)
        {
            check(0);
            var original = Select(universe, names, policy.Conditions);
            if (policy.State != "enabled" || original == null) return null;
            var relaxed = query.RelaxedAxes.ToHashSet(StringComparer.Ordinal);
            if (query.MatchMode == "registrationResource") relaxed.UnionWith(names.Where(n => n == "application" || n == "accessTarget" || n == "registrationContext" || n == "directoryScopeEnforcement" || n.StartsWith("resourceGroup.", StringComparison.Ordinal)));
            var condition = Select(universe, names, policy.Conditions.Where(e => !relaxed.Contains(e.Key)).ToDictionary(e => e.Key,e => e.Value));
            if (query.MatchMode == "registrationResource") condition = Select(condition, names, new Dictionary<string,Selector> { ["accessTarget"] = new Selector { Include = new[] { "userAction" } }, ["registrationContext"] = new Selector { Include = new[] { "unspecified" } } });
            var targets = new TargetSet(policy.IncludeUsers, policy.ExcludeUsers);
            var coordinates = policy.Conditions.Keys.Where(n => relaxed.Contains(n) && query.MatchMode != "registrationResource").Select(n => (Name:n,Index:Array.IndexOf(names,n))).ToArray();
            var selectedPeople = query.PolicyIdentityBindings == null ? people : query.PolicyIdentityBindings[policy.Id].ToHashSet(StringComparer.Ordinal);
            // Confirmed per-person bounds still constrain relaxed PIM axes.
            var affected = selectedPeople.Where(id => {
                check(0);
                return targets.Contains(id) && coordinates.All(c => !identityBounds[id].TryGetValue(c.Name,out var bound) || original.Axes[c.Index].Any(v => (bound.Include.Length == 0 || bound.Include.Contains(v,StringComparer.Ordinal)) && !bound.Exclude.Contains(v,StringComparer.Ordinal)));
            }).ToHashSet(StringComparer.Ordinal);
            if (affected.Count == 0) return null;
            var grantAlternatives = query.MatchMode == "registrationResource" ? (policy.LocationMatchingOnly == true ? policy.GuaranteedRegistrationGrantAlternatives : null) ?? Array.Empty<Dictionary<string,Selector>>() : query.MatchMode == "potentiallyDenied" ? (policy.LocationMatchingOnly == true ? policy.GuaranteedGrantAlternatives : null) ?? Array.Empty<Dictionary<string,Selector>>() : policy.GrantAlternatives;
            var grants = query.MatchMode == "applicable" ? Array.Empty<Region>() : grantAlternatives.Where(a => a.Where(e => relaxed.Contains(e.Key)).All(e => {
                var selected = Select(universe,names,new Dictionary<string,Selector> { [e.Key]=e.Value });
                return selected != null && selected.Axes[Array.IndexOf(names,e.Key)].SetEquals(universe.Axes[Array.IndexOf(names,e.Key)]);
            })).Select(a => Select(universe,names,a.Where(e => !relaxed.Contains(e.Key)).ToDictionary(e => e.Key,e => e.Value))).Where(r => r != null).ToArray();
            return new ContextPolicyScope { People=affected, Condition=condition, Grants=grants };
        }
        private static bool ValidPolicyContext(PolicyContextQuery query, Model model, Dictionary<string, Policy> policies, HashSet<string> requirements, HashSet<string> identities, out HashSet<string> people)
        {
            people = null;
            if (query == null || !(query.MatchMode == "denied" || query.MatchMode == "applicable" || query.MatchMode == "potentiallyDenied" || query.MatchMode == "registrationResource") || !requirements.Contains(query.RequirementId) || query.PolicyIds == null || query.PolicyIds.Length == 0 || query.PolicyIds.Any(id => id == null || !policies.ContainsKey(id)) || query.IdentityIds == null || query.IdentityIds.Length == 0 || query.IdentityIds.Any(id => !identities.Contains(id)) || query.RelaxedAxes == null || (query.MatchMode == "denied" ? query.RelaxedAxes.Length == 0 : query.RelaxedAxes.Length != 0) || query.RelaxedAxes.Any(n => n == null || !model.Dimensions.ContainsKey(n) || !(n.StartsWith("groupMember.", StringComparison.Ordinal) || n.StartsWith("roleActive.", StringComparison.Ordinal)))) return false;
            if (query.MatchMode == "registrationResource" && query.PolicyIds.Any(id => !policies[id].RegistrationResourceContext)) return false;
            if (query.MatchMode == "potentiallyDenied" && query.PolicyIds.Any(id => !policies[id].UnverifiedLocations)) return false;
            people = query.IdentityIds.ToHashSet(StringComparer.Ordinal);
            var knownPeople = people;
            return query.PolicyIdentityBindings == null || !(query.PolicyIdentityBindings.Keys.Any(id => !query.PolicyIds.Contains(id, StringComparer.Ordinal)) || query.PolicyIds.Any(id => !query.PolicyIdentityBindings.TryGetValue(id, out var bound) || bound == null || bound.Length == 0 || bound.Any(user => !knownPeople.Contains(user))));
        }
        // Refine presentation groups only. The represented account/request set
        // must remain exactly equal; neither a grant nor a diagnosis is inferred.
        // Publish atomically, reverting to the original groups on any limit.
        public static string RefinePolicyContextGaps(string modelJson, string gapsJson, string queriesJson, string cutsJson = "[]", int maxRegions = 20000, int timeoutMilliseconds = 5000)
            => JsonSerializer.Serialize(RefinePolicyContextGapsData(modelJson,gapsJson,queriesJson,cutsJson,maxRegions,timeoutMilliseconds),JsonOptions);
        // The PowerShell adapter consumes typed strings/arrays directly so a
        // repeated identity list is not decoded once per refined request cell.
        public static GapRefinementResult RefinePolicyContextGapsData(string modelJson, string gapsJson, string queriesJson, string cutsJson = "[]", int maxRegions = 20000, int timeoutMilliseconds = 5000)
        {
            if (maxRegions < 1 || timeoutMilliseconds < 1) throw new ArgumentException("Limits must be positive.");
            var clock = Stopwatch.StartNew();
            var model = JsonSerializer.Deserialize<Model>(modelJson, JsonOptions) ?? throw new ArgumentException("Missing model."); Validate(model);
            var gaps = JsonSerializer.Deserialize<Gap[]>(gapsJson, JsonOptions) ?? throw new ArgumentException("Missing gaps.");
            var queries = JsonSerializer.Deserialize<PolicyContextQuery[]>(queriesJson, JsonOptions) ?? throw new ArgumentException("Missing queries.");
            var cuts = JsonSerializer.Deserialize<GapRefinementCut[]>(cutsJson, JsonOptions) ?? throw new ArgumentException("Missing cuts.");
            var result = new GapRefinementResult { OriginalGroups = gaps.Length, Gaps = gaps, ParentGapIndices = Enumerable.Range(0,gaps.Length).ToArray() };
            var names = model.Dimensions.Keys.OrderBy(n => n, StringComparer.Ordinal).ToArray();
            var universe = new Region(names.Select(n => model.Dimensions[n].ToHashSet(StringComparer.Ordinal)).ToArray());
            var identities = model.Identities.Select(u => u.Id).ToHashSet(StringComparer.Ordinal);
            var policies = model.Policies.ToDictionary(p => p.Id, StringComparer.Ordinal);
            var requirements = model.Requirements.Select(r => r.Id).ToHashSet(StringComparer.Ordinal);
            var cells = gaps.Select((g,parent) => {
                if (g == null || !requirements.Contains(g.RequirementId) || g.Region == null || g.Region.Count != names.Length || g.IdentityIds == null || g.IdentityIds.Length == 0 || g.IdentityIds.Distinct(StringComparer.Ordinal).Count() != g.IdentityIds.Length || g.IdentityIds.Any(id => !identities.Contains(id))) throw new ArgumentException("Invalid gap evidence.");
                var region = new Region(names.Select((n,i) => {
                    if (!g.Region.TryGetValue(n, out var values) || values == null || values.Length == 0 || values.Any(v => !universe.Axes[i].Contains(v))) throw new ArgumentException("Invalid gap domain.");
                    return values.ToHashSet(StringComparer.Ordinal);
                }).ToArray());
                return (RequirementId: g.RequirementId, People: g.IdentityIds, Region: region, Parent: parent);
            }).ToList();
            // Keep identity-profile grouping useful while refining many request
            // cells. Bound the expanded report as well as its rectangle count.
            long identityLimit = Math.Max(cells.Sum(cell => (long)cell.People.Length), (long)maxRegions * 64);
            var uncertain = new List<(string RequirementId, string[] People, Region Region, int Parent)>();
            long uncertainIdentities = 0;
            var identityBounds = model.Identities.ToDictionary(u => u.Id,u => u.Conditions,StringComparer.Ordinal);
            void Check(int count) { if (count > maxRegions) throw new BudgetException("regionLimit"); if (clock.ElapsedMilliseconds >= timeoutMilliseconds) throw new BudgetException("timeout"); }
            void Split(string requirement, HashSet<string> people, Region cut)
            {
                if (cut == null || people.Count == 0 || cells.Count == 0) return;
                var next = new List<(string RequirementId, string[] People, Region Region, int Parent)>();
                var partitions = new Dictionary<string[], (string[] Selected, string[] Other)>();
                long nextIdentities = uncertainIdentities;
                void Add((string RequirementId, string[] People, Region Region, int Parent) cell, bool matched = false) {
                    nextIdentities += cell.People.Length;
                    if (nextIdentities > identityLimit) throw new BudgetException("identityReferenceLimit");
                    if (matched) { uncertain.Add(cell); uncertainIdentities += cell.People.Length; }
                    else next.Add(cell);
                    Check(next.Count + uncertain.Count);
                }
                foreach (var cell in cells)
                {
                    Check(next.Count + uncertain.Count);
                    var overlap = SameRequirement(cell.RequirementId, requirement) ? Intersect(cell.Region, cut) : null;
                    if (overlap == null) { Add(cell); continue; }
                    if (!partitions.TryGetValue(cell.People, out var partition)) {
                        var selectedPeople = cell.People.Where(people.Contains).ToArray();
                        partition = selectedPeople.Length == cell.People.Length ? (cell.People, Array.Empty<string>()) : (selectedPeople, cell.People.Where(id => !people.Contains(id)).ToArray());
                        partitions[cell.People] = partition;
                    }
                    var selected = partition.Selected;
                    if (selected.Length == 0) { Add(cell); continue; }
                    if (partition.Other.Length > 0) Add((cell.RequirementId, partition.Other, cell.Region, cell.Parent));
                    foreach (var outside in Subtract(cell.Region, cut)) Add((cell.RequirementId, selected, outside, cell.Parent));
                    // A point reached by any unresolved scope is already in the
                    // union. Do not split it again at every overlapping policy.
                    Add((cell.RequirementId, selected, overlap, cell.Parent), true);
                }
                Check(next.Count + uncertain.Count); cells = next;
            }
            try
            {
                Check(cells.Count);
                foreach (var query in queries)
                {
                    Check(cells.Count + uncertain.Count);
                    if (!ValidPolicyContext(query, model, policies, requirements, identities, out var people)) continue;
                    foreach (var policyId in query.PolicyIds.Distinct(StringComparer.Ordinal).OrderBy(id => id, StringComparer.Ordinal))
                    {
                        if (cells.Count == 0) break;
                        var scope = GetContextPolicyScope(query,policies[policyId],people,identityBounds,universe,names,Check);
                        if (scope == null) continue;
                        var regions = new List<Region> { scope.Condition };
                        foreach (var grant in scope.Grants) {
                            var next = new List<Region>();
                            foreach (var region in regions) { next.AddRange(Subtract(region,grant)); Check(next.Count); }
                            regions = next;
                            if (regions.Count == 0) break;
                        }
                        foreach (var region in regions) Split(query.RequirementId,scope.People,region);
                    }
                }
                foreach (var cut in cuts)
                {
                    Check(cells.Count + uncertain.Count);
                    if (cut == null || !requirements.Contains(cut.RequirementId) || cut.IdentityIds == null || cut.IdentityIds.Length == 0 || cut.IdentityIds.Any(id => !identities.Contains(id)) || cut.Conditions == null || cut.Conditions.Any(e => !model.Dimensions.ContainsKey(e.Key) || e.Value == null || e.Value.Include == null || e.Value.Exclude == null || e.Value.Include.Concat(e.Value.Exclude).Any(v => !model.Dimensions[e.Key].Contains(v)))) continue;
                    Split(cut.RequirementId, cut.IdentityIds.ToHashSet(StringComparer.Ordinal), Select(universe, names, cut.Conditions));
                }
                cells = uncertain.Concat(cells).ToList();
                Check(cells.Count);
                if (cells.Count != gaps.Length)
                {
                    var enabled = model.Policies.Where(p => p.State == "enabled").ToArray();
                    var bounds = enabled.ToDictionary(p => p.Id, p => Select(universe, names, p.Conditions));
                    var targets = enabled.ToDictionary(p => p.Id, p => new TargetSet(p.IncludeUsers, p.ExcludeUsers));
                    result.Gaps = cells.Select(cell => {
                        Check(cells.Count);
                        var witness = names.Select((n,i) => (Name:n, Value:cell.Region.Axes[i].OrderBy(v => v, StringComparer.Ordinal).First())).ToDictionary(e => e.Name,e => e.Value);
                        var applied = enabled.Where(p => targets[p.Id].Contains(cell.People[0]) && Contains(bounds[p.Id], names, witness)).Select(p => p.Id).ToArray();
                        return new Gap { RequirementId=cell.RequirementId, IdentityIds=cell.People.OrderBy(id => id, StringComparer.Ordinal).ToArray(), Region=names.Select((n,i) => (Name:n,Values:cell.Region.Axes[i].OrderBy(v => v,StringComparer.Ordinal).ToArray())).ToDictionary(e => e.Name,e => e.Values), Witness=witness, ApplicablePolicyIds=applied, NonApplicablePolicyIds=enabled.Select(p=>p.Id).Except(applied).ToArray() };
                    }).ToArray();
                    result.ParentGapIndices = cells.Select(cell => cell.Parent).ToArray();
                }
            }
            catch (BudgetException e) { result.Status = "bounded:" + e.Message; result.Gaps = gaps; result.ParentGapIndices = Enumerable.Range(0,gaps.Length).ToArray(); }
            return result;
        }
        public static string Analyze(string json, int maxRegions = 100000, int timeoutSeconds = 60, bool groupIdentities = true, Action<int,int> progress = null)
        {
            if (maxRegions < 1 || timeoutSeconds < 1) throw new ArgumentException("Limits must be positive.");
            var model = JsonSerializer.Deserialize<Model>(json, JsonOptions) ?? throw new ArgumentException("Missing model.");
            Validate(model);
            var clock = Stopwatch.StartNew();
            var names = model.Dimensions.Keys.OrderBy(x => x, StringComparer.Ordinal).ToArray();
            var universe = new Region(names.Select(n => new HashSet<string>(model.Dimensions[n], StringComparer.Ordinal)).ToArray());
            var result = new Analysis { IdentityCount = model.Identities.Length, ProfileGroupingEnabled = groupIdentities,
                UnverifiedApplicationFilterPolicyIds = model.Policies.Where(p => p.State == "enabled" && p.UnverifiedApplicationFilter).Select(p => p.Id).ToArray(),
                UnverifiedLocationPolicyIds = model.Policies.Where(p => p.State == "enabled" && p.UnverifiedLocations).Select(p => p.Id).ToArray(),
                RegistrationResourcePolicyIds = model.Policies.Where(p => p.State == "enabled" && p.RegistrationResourceContext).Select(p => p.Id).ToArray() };
            void Check(int regions)
            {
                if (regions > maxRegions) throw new BudgetException("regionLimit");
                if (clock.Elapsed.TotalSeconds > timeoutSeconds) throw new BudgetException("timeout");
            }
            List<Region> SubtractAll(List<Region> source, Region cut)
            {
                var output = new List<Region>();
                foreach (var region in source)
                {
                    result.RegionSubtractionCount++;
                    output.AddRange(Subtract(region, cut));
                    Check(output.Count);
                }
                return output;
            }
            List<Region> IntersectAll(List<Region> source, List<Region> allowed)
            {
                var output = new List<Region>();
                foreach (var region in source) foreach (var bound in allowed)
                {
                    var overlap = Intersect(region, bound);
                    if (overlap != null) output.Add(overlap);
                    Check(output.Count);
                }
                return output;
            }
            List<Region> DisjointUnion(IEnumerable<Dictionary<string, Selector>> clauses)
            {
                var union = new List<Region>();
                foreach (var clause in clauses)
                {
                    var rectangle = Select(universe, names, clause);
                    if (rectangle == null) continue;
                    var pieces = new List<Region> { rectangle };
                    foreach (var existing in union) pieces = SubtractAll(pieces, existing);
                    union.AddRange(pieces); Check(union.Count);
                }
                return union;
            }
            var enabled = model.Policies.Where(p => p.State == "enabled").ToArray();
            var policyTargets = enabled.ToDictionary(p => p.Id, p => new TargetSet(p.IncludeUsers, p.ExcludeUsers));
            var requirementTargets = model.Requirements.ToDictionary(r => r.Id, r => new TargetSet(r.IncludeUsers, r.ExcludeUsers));
            bool AppliesIndexed(Requirement r, Identity u) => requirementTargets[r.Id].Contains(u.Id) && (r.Scope == "all" || u.Privileged || u.PimEligible);
            // Exact equivalence under all identity-dependent predicates in this model.
            var profiles = model.Identities.GroupBy(u =>
                string.Concat(enabled.Select(p => policyTargets[p.Id].Contains(u.Id) ? '1' : '0')) + ":" +
                string.Concat(model.Requirements.Select(r => AppliesIndexed(r, u) ? '1' : '0')) + ":" +
                JsonSerializer.Serialize(u.Conditions.OrderBy(e => e.Key, StringComparer.Ordinal).Select(e => new { e.Key, Include=e.Value.Include.OrderBy(v=>v,StringComparer.Ordinal).ToArray(), Exclude=e.Value.Exclude.OrderBy(v=>v,StringComparer.Ordinal).ToArray() })) +
                ":" + JsonSerializer.Serialize(u.ScenarioConstraints) +
                (groupIdentities ? "" : ":" + u.Id)).ToArray();
            result.IdentityProfileCount = profiles.Length;
            int completedAccounts = 0;
            progress?.Invoke(0, model.Identities.Length);
            try
            {
                var validUniverse = new List<Region> { universe };
                foreach (var group in model.ScenarioConstraints)
                {
                    validUniverse = IntersectAll(validUniverse, DisjointUnion(group));
                }
                if (validUniverse.Count == 0) throw new ArgumentException("Scenario constraints leave no valid scenarios.");
                var requirementRegions = model.Requirements.ToDictionary(r => r.Id, r => {
                    var bound = Select(universe, names, r.Conditions);
                    if (bound == null) return new List<Region>();
                    var regions = new List<Region> { bound };
                    return r.ConditionAlternatives == null ? regions : IntersectAll(regions, DisjointUnion(r.ConditionAlternatives));
                });
                var nonemptyRequirements = new HashSet<string>(StringComparer.Ordinal);
                var conditionRegions = enabled.ToDictionary(p => p.Id, p => Select(universe, names, p.Conditions));
                var forbidden = new Dictionary<string, List<Region>>();
                foreach (var policy in enabled)
                {
                    Check(0);
                    var match = conditionRegions[policy.Id];
                    var denied = match == null ? new List<Region>() : new List<Region> { match };
                    foreach (var alternative in policy.GrantAlternatives)
                    {
                        var allowed = Select(universe, names, alternative);
                        if (allowed != null) denied = SubtractAll(denied, allowed);
                    }
                    forbidden[policy.Id] = denied;
                }
                foreach (var profile in profiles)
                {
                    Check(0);
                    var representative = profile.First();
                    var identityRegion = Select(universe, names, representative.Conditions);
                    var validProfile = identityRegion == null ? new List<Region>() : IntersectAll(validUniverse, new List<Region> { identityRegion });
                    foreach (var group in representative.ScenarioConstraints)
                        validProfile = IntersectAll(validProfile, DisjointUnion(group));
                    if (validProfile.Count == 0) throw new ArgumentException("Identity conditions leave no valid scenarios: " + representative.Id);
                    var policies = enabled.Where(p => policyTargets[p.Id].Contains(representative.Id)).ToArray();
                    foreach (var requirement in model.Requirements.Where(r => AppliesIndexed(r, representative)))
                    {
                        var gaps = IntersectAll(requirementRegions[requirement.Id], validProfile);
                        if (gaps.Count == 0) continue;
                        nonemptyRequirements.Add(requirement.Id);
                        if (!requirement.MustBlock)
                        {
                            if (requirement.RequiredAlternatives != null)
                            {
                                foreach (var alternative in requirement.RequiredAlternatives)
                                {
                                    var satisfies = Select(universe, names, alternative);
                                    if (satisfies != null) gaps = SubtractAll(gaps, satisfies);
                                }
                            }
                            else
                            {
                                var satisfies = Select(universe, names, new Dictionary<string, Selector> { ["authentication"] = new Selector { Include = requirement.AllowedAuthentication } });
                                if (satisfies != null) gaps = SubtractAll(gaps, satisfies);
                            }
                        }
                        foreach (var policy in policies)
                            foreach (var cut in forbidden[policy.Id]) gaps = SubtractAll(gaps, cut);
                        foreach (var gap in gaps)
                        {
                            Check(result.Gaps.Count + 1);
                            var witness = names.Select((n, i) => new { Name = n, Value = gap.Axes[i].OrderBy(x => x, StringComparer.Ordinal).First() })
                                .ToDictionary(x => x.Name, x => x.Value);
                            var applied = policies.Where(p => Contains(conditionRegions[p.Id], names, witness)).Select(p => p.Id).ToArray();
                            result.Gaps.Add(new Gap {
                                RequirementId = requirement.Id,
                                IdentityIds = profile.Select(u => u.Id).OrderBy(x => x, StringComparer.Ordinal).ToArray(),
                                Region = names.Select((n,i) => new { Name=n, Values=gap.Axes[i].OrderBy(x => x, StringComparer.Ordinal).ToArray() }).ToDictionary(x => x.Name,x => x.Values),
                                Witness = witness,
                                ApplicablePolicyIds = applied,
                                NonApplicablePolicyIds = enabled.Select(p => p.Id).Except(applied).ToArray()
                            });
                        }
                    }
                    completedAccounts += profile.Count();
                    progress?.Invoke(completedAccounts, model.Identities.Length);
                }
                result.EmptyRequirementIds = model.Requirements.Where(r => !nonemptyRequirements.Contains(r.Id)).Select(r => r.Id).ToArray();
                if (result.EmptyRequirementIds.Length > 0) result.Status = "incomplete:emptyRequirementScope";
            }
            catch (BudgetException e) { result.Status = "incomplete:" + e.Message; }
            result.ElapsedMilliseconds = clock.ElapsedMilliseconds;
            return JsonSerializer.Serialize(result, JsonOptions);
        }
        private sealed class TargetSet
        {
            private readonly HashSet<string> include, exclude;
            private readonly bool includeAll, excludeAll;
            public TargetSet(string[] included, string[] excluded)
            {
                include = new HashSet<string>(included, StringComparer.Ordinal);
                exclude = new HashSet<string>(excluded, StringComparer.Ordinal);
                includeAll = include.Contains("*"); excludeAll = exclude.Contains("*");
            }
            public bool Contains(string id) => (includeAll || include.Contains(id)) && !excludeAll && !exclude.Contains(id);
        }
        private static bool Contains(Region region, string[] names, Dictionary<string,string> point) => region != null && names.Select((n,i) => region.Axes[i].Contains(point[n])).All(x => x);
        private static Region Select(Region universe, string[] names, Dictionary<string,Selector> conditions)
        {
            var result = universe.Copy();
            foreach (var entry in conditions)
            {
                var axis = result.Axes[Array.IndexOf(names, entry.Key)];
                if (entry.Value.Include.Length > 0) axis.IntersectWith(entry.Value.Include);
                axis.ExceptWith(entry.Value.Exclude);
                if (axis.Count == 0) return null;
            }
            return result;
        }
        private static List<Region> Subtract(Region source, Region cut)
        {
            var intersection = source.Copy();
            for (int i=0; i<source.Axes.Length; i++)
            {
                intersection.Axes[i].IntersectWith(cut.Axes[i]);
                if (intersection.Axes[i].Count == 0) return new List<Region> { source };
            }
            // Peel disjoint slabs off the overlap, one dimension at a time.
            var remainder = source.Copy();
            var output = new List<Region>();
            for (int i=0; i<source.Axes.Length; i++)
            {
                var outside = new HashSet<string>(remainder.Axes[i], StringComparer.Ordinal);
                outside.ExceptWith(intersection.Axes[i]);
                if (outside.Count > 0) { var slab = remainder.Copy(); slab.Axes[i] = outside; output.Add(slab); }
                remainder.Axes[i] = intersection.Axes[i];
            }
            return output;
        }
        private static Region Intersect(Region source, Region bound)
        {
            var result = source.Copy();
            for (int i=0; i<result.Axes.Length; i++)
            {
                result.Axes[i].IntersectWith(bound.Axes[i]);
                if (result.Axes[i].Count == 0) return null;
            }
            return result;
        }
        private static void Validate(Model m)
        {
            if (m.SchemaVersion != 1) throw new ArgumentException("Only schemaVersion 1 is supported.");
            if (!m.Dimensions.ContainsKey("authentication")) throw new ArgumentException("Missing authentication dimension.");
            foreach (var d in m.Dimensions)
                if (string.IsNullOrWhiteSpace(d.Key) || d.Value == null || d.Value.Length == 0 || d.Value.Any(string.IsNullOrWhiteSpace) || d.Value.Distinct().Count() != d.Value.Length)
                    throw new ArgumentException("Dimension values must be nonempty and unique.");
            if (m.Identities.Any(u => string.IsNullOrWhiteSpace(u.Id)) || m.Identities.Select(u=>u.Id).Distinct().Count() != m.Identities.Length) throw new ArgumentException("Identity IDs must be nonempty and unique.");
            var identityIds = new HashSet<string>(m.Identities.Select(u => u.Id), StringComparer.Ordinal);
            void Conditions(Dictionary<string,Selector> conditions)
            {
                foreach (var entry in conditions)
                {
                    if (!m.Dimensions.ContainsKey(entry.Key)) throw new ArgumentException("Unknown dimension: " + entry.Key);
                    if (entry.Value == null || entry.Value.Include == null || entry.Value.Exclude == null) throw new ArgumentException("Null selector.");
                    if (entry.Value.Include.Concat(entry.Value.Exclude).Any(v => !m.Dimensions[entry.Key].Contains(v))) throw new ArgumentException("Unknown dimension value: " + entry.Key);
                }
            }
            void Users(string[] include, string[] exclude)
            {
                if (include == null || exclude == null || include.Concat(exclude).Any(x => x != "*" && !identityIds.Contains(x))) throw new ArgumentException("Unknown identity reference.");
            }
            void Constraints(Dictionary<string,Selector>[][] groups)
            {
                if (groups == null || groups.Any(g=>g == null || g.Length == 0)) throw new ArgumentException("Scenario constraint groups cannot be empty or null.");
                foreach (var group in groups) foreach (var clause in group) { if (clause == null) throw new ArgumentException("Null scenario clause."); Conditions(clause); }
            }
            Constraints(m.ScenarioConstraints);
            foreach (var identity in m.Identities) { if (identity.Conditions == null) throw new ArgumentException("Null identity conditions."); Conditions(identity.Conditions); Constraints(identity.ScenarioConstraints); }
            if (m.Policies.Select(p=>p.Id).Distinct().Count() != m.Policies.Length || m.Requirements.Select(r=>r.Id).Distinct().Count() != m.Requirements.Length) throw new ArgumentException("Duplicate policy or requirement ID.");
            foreach (var p in m.Policies)
            {
                if (string.IsNullOrWhiteSpace(p.Id) || !new[]{"enabled","disabled","reportOnly"}.Contains(p.State)) throw new ArgumentException("Invalid policy ID or state.");
                if (p.LocationMatchingOnly == false && (!p.UnverifiedLocations || (p.GuaranteedGrantAlternatives?.Length ?? 0) != 0 || (p.GuaranteedRegistrationGrantAlternatives?.Length ?? 0) != 0)) throw new ArgumentException("Location acquisition uncertainty cannot carry permission proofs or verified location protection.");
                if (p.RegistrationResourceContext && (!p.Conditions.TryGetValue("accessTarget", out var appTarget) || appTarget.Include.Length != 1 || appTarget.Include[0] != "application" || appTarget.Exclude.Length != 0 || !m.Dimensions.TryGetValue("accessTarget", out var targetValues) || !targetValues.Contains("userAction", StringComparer.Ordinal) || !m.Dimensions.TryGetValue("registrationContext", out var contextValues) || !contextValues.Contains("unspecified", StringComparer.Ordinal))) throw new ArgumentException("Registration resource context requires an app-only policy and unspecified registration domain.");
                if (p.UnverifiedApplicationFilter && (p.GrantAlternatives == null || p.GrantAlternatives.Length != 1 || p.GrantAlternatives[0] == null || p.GrantAlternatives[0].Count != 0))
                    throw new ArgumentException("Unverified application-filter policies cannot carry protection grants.");
                if (p.UnverifiedLocations && (p.GrantAlternatives == null || p.GrantAlternatives.Length != 1 || p.GrantAlternatives[0] == null || p.GrantAlternatives[0].Count != 0))
                    throw new ArgumentException("Unverified location policies cannot carry protection grants.");
                if (p.GuaranteedGrantAlternatives != null)
                {
                    if (!p.UnverifiedLocations) throw new ArgumentException("Guaranteed grant bounds require unverified location scope.");
                    foreach (var bound in p.GuaranteedGrantAlternatives)
                    {
                        if (bound == null || bound.Keys.Any(n => n != "authentication" && n != "compliant" && n != "hybridJoined")) throw new ArgumentException("Invalid guaranteed grant bound.");
                        Conditions(bound);
                    }
                }
                Users(p.IncludeUsers,p.ExcludeUsers); Conditions(p.Conditions);
                foreach (var alt in p.GrantAlternatives) Conditions(alt);
                if (p.GuaranteedRegistrationGrantAlternatives != null)
                {
                    if (!p.RegistrationResourceContext) throw new ArgumentException("Registration grant bounds require registration resource context.");
                    foreach (var bound in p.GuaranteedRegistrationGrantAlternatives)
                    {
                        if (bound == null || bound.Keys.Any(n => n != "authentication" && n != "compliant" && n != "hybridJoined")) throw new ArgumentException("Invalid guaranteed registration grant bound.");
                        Conditions(bound);
                        bool Allows(Selector selector, string value) => selector == null || ((selector.Include.Length == 0 || selector.Include.Contains(value, StringComparer.Ordinal)) && !selector.Exclude.Contains(value, StringComparer.Ordinal));
                        // Each asserted permission must satisfy at least one
                        // complete necessary grant route. Mere overlap cannot
                        // turn a stronger AND grant into a permission proof.
                        if (!p.GrantAlternatives.Any(alt => alt.All(entry => m.Dimensions[entry.Key].Where(v => Allows(bound.GetValueOrDefault(entry.Key),v)).All(v => Allows(entry.Value,v)))))
                            throw new ArgumentException("Registration permission does not satisfy a necessary grant route.");
                    }
                }
            }
            foreach (var r in m.Requirements)
            {
                if (string.IsNullOrWhiteSpace(r.Id) || !new[]{"all","privileged"}.Contains(r.Scope)) throw new ArgumentException("Invalid requirement ID or scope.");
                Users(r.IncludeUsers,r.ExcludeUsers); Conditions(r.Conditions);
                if (r.ConditionAlternatives != null) foreach (var clause in r.ConditionAlternatives) { if (clause == null) throw new ArgumentException("Null requirement condition clause."); Conditions(clause); }
                if (!r.MustBlock && r.RequiredAlternatives == null && (r.AllowedAuthentication.Length == 0 || r.AllowedAuthentication.Any(x=>!m.Dimensions["authentication"].Contains(x)))) throw new ArgumentException("Invalid allowed authentication.");
                if (r.RequiredAlternatives != null)
                {
                    if (r.RequiredAlternatives.Length == 0) throw new ArgumentException("A control requirement needs an alternative; use MustBlock for denied access.");
                    foreach (var alternative in r.RequiredAlternatives) Conditions(alternative);
                }
            }
        }
        private sealed class BudgetException : Exception { public BudgetException(string reason) : base(reason) {} }
    }
}
