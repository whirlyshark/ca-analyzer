# Performance measurements

Development measurement, 2026-11-16. Release acceptance is still pending.

The fresh-process offline command was measured against fictional exports containing 21 raw policies and seven requirements. Policies include overlapping Member/Guest groups, active and eligible roles, explicit exclusions and compensating protection, app-specific grants, legacy/flow blocks, IPv4/IPv6 networks, registration actions, authentication context, disabled and report-only policies. Six equivalent account profiles were found; this represents a patterned organisation, not every worst-case unique-identity policy set.

| Accounts | Case | Full CLI and JSON/HTML export | Engine | Peak process memory | Confirmed accounts needing attention |
|---|---|---:|---:|---:|---:|
| 1,000 | Covered | 3.90 seconds | 24 ms | 289 MiB | 0 |
| 1,000 | MFA AND compliance weakened to OR | 3.98 seconds | 28 ms | 294 MiB | 750 |
| 10,000 | Covered | 21.49 seconds | 135 ms | 704 MiB | 0 |
| 10,000 | MFA AND compliance weakened to OR | 23.64 seconds | 143 ms | 683 MiB | 7,500 |

Environment: Windows 10.0.26300 x64, 16 logical processors, PowerShell 7.6.9, .NET 10.0.14. Measurements ran while the separate validation suite was active, so these are observed results under concurrent local load, not a controlled performance guarantee. Input fixture generation is excluded; fresh PowerShell startup, input reading, V8 normalization/compilation, history evidence construction, .NET analysis, summaries and report export are included. History saving is disabled and the benchmark uses a new empty acceptance path. The child process has no Node/SDK on PATH and uses unusable external proxies; this is not an OS-enforced air gap.

A second frozen all-options run on PowerShell 7.4.22 / .NET 8.0.33 measured the same cases at 3.41 / 3.50 seconds for 1,000 accounts and 18.50 / 18.86 seconds for 10,000 accounts, retaining the exact independent results and input hashes. Peak memory was 283 / 294 / 651 / 680 MiB respectively. Evidence: `data/release-audit-20261116-213756.local/full-validation-02/release-journey-scale/results.json`. Use the final candidate's validation evidence for its exact measured timings rather than treating earlier observations as a service-level promise.

Independent expectations require the complete exact affected-account union and requirement, confirmed certainty, summary agreement, expected CLI exit status, HTML report and unchanged inputs. The changed policy permits MFA OR a compliant device, which leaves noncompliant requirements uncovered for six of the eight fictional account cohorts. Report findings retain four separate scenario regions; region count is not the affected-account count.

Reproduce from development source:

```powershell
pwsh -NoProfile -File tests/Measure-ReleaseJourney.ps1 -OutputDirectory ./data/new-release-measurement.local
```

Choose a new output folder. Evidence includes input hashes, logs, exported reports, environment and measurements. The all-options validation runner also includes this measurement. Initial evidence is under `data/release-audit-20261116-213756.local/release-journey-scale-01/results.json`.

Time depends on distinct account profiles, overlapping condition boundaries, policy alternatives and requirement complexity, not just account count. Region/time limits must result in an incomplete assessment; increasing them does not expand supported Entra semantics. Attribution has its own bounded limits and must withhold partial coverage claims when exceeded. Additional scale fixtures exercise PIM, unknown directory data, resource groups, risk, history and other partitions; their results belong to the specific validation run, not the table above.

Interactive snapshot/account-set file selection is capped at 10 MiB. The offline module accepts 100 MiB per input file; full-snapshot UI assessment requests have a 100 MiB combined-body limit, and other API requests have a 10 MiB limit. Full snapshots use the same default 100,000-region / 60-second engine limits in the UI and CLI. Generic normalized-model UI checks use 20,000 / 30 seconds. Those engine timers do not cover the whole startup, translation or report-export pipeline. Attribution defaults to 20,000 regions and 750 ms and withholds coverage when bounded. These are explicit resource limits, not correctness shortcuts or promises of real sign-in feasibility.
