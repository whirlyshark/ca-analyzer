'use strict';
// Presentation only: these helpers never change findings, scopes or scores.
const ReviewPresentation={
 page(items,index=0,size=50){
  if(!Number.isInteger(size)||size<1)throw Error('Page size must be a positive integer.');
  const pages=Math.max(1,Math.ceil(items.length/size)),current=Math.min(Math.max(0,Number.isInteger(index)?index:0),pages-1),offset=current*size;
  return {items:items.slice(offset,offset+size),index:current,pages,total:items.length,label:items.length?(offset+1).toLocaleString()+'–'+Math.min(offset+size,items.length).toLocaleString()+' of '+items.length.toLocaleString():'0 matches'};
 },
 accountSetMemberships(sets,resolved){
  const memberships=new Map();
  for(const set of sets)for(const id of resolved.get(set.id)?.ids||[]){if(!memberships.has(id))memberships.set(id,[]);memberships.get(id).push({id:set.id,name:set.name});}
  return memberships;
 },

 scenarioSentence(gap,context={}){
  const w=gap.witness||{},axes=new Set(context.axes||Object.keys(w)),format=context.format||((key,value)=>String(value)),axisName=context.axisName||(key=>key),quote=value=>'“'+value+'”';
  const subject=context.accountName?quote(context.accountName):'the selected account',target=w.accessTarget||'application',app=w.application?format('application',w.application):null,appPhrase=app&&/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(app)?'the app with ID '+quote(app):app?quote(app):'the app shown below';
  let action=target==='userAction'?({registerSecurityInformation:'register security information',registerOrJoinDevices:'register or join a device'}[w.userAction]||'perform '+quote(format('userAction',w.userAction))):target==='authenticationContext'?'use an action protected by authentication context '+quote(context.authenticationContext||Object.keys(w).filter(k=>k.startsWith('authenticationContext.')&&w[k]==='true').map(k=>k.slice(22)).join(', ')||'shown below'):'access '+appPhrase;
  const client={browser:'in a browser',desktop:'in a desktop app',mobileAppsAndDesktopClients:'in a mobile or desktop app',other:'through a legacy client',legacy:'through a legacy client',exchangeActiveSync:'through Exchange ActiveSync',easSupported:'through a supported Exchange ActiveSync client'}[w.client];if(client)action+=' '+client;
  if(w.platform&&w.platform!=='unknown')action+=' on '+(['android','ios','iOS'].includes(w.platform)?'an ':'a ')+format('platform',w.platform)+' device';
  const device=[];if(axes.has('compliant')&&['true','false'].includes(w.compliant))device.push(w.compliant==='true'?'marked compliant':'not marked compliant');if(axes.has('hybridJoined')&&['true','false'].includes(w.hybridJoined))device.push(w.hybridJoined==='true'?'hybrid joined':'not hybrid joined');if(device.length)action+=(w.platform&&w.platform!=='unknown'?' that is ':' on a device that is ')+device.join(' and ');
  if(w.network){const network=format('network',w.network);action+=w.network==='outside-known-locations'||network==='Outside configured IP locations'?' from outside the configured network locations':' from '+quote(network);}
  if(w.flow&&w.flow!=='standard')action+=' '+({deviceCodeFlow:'through device-code sign-in',deviceCode:'through device-code sign-in',authenticationTransfer:'through an authentication-transfer session',transfer:'through an authentication-transfer session'}[w.flow]||'through '+quote(format('flow',w.flow)));
  const authentication={password:'using single-factor authentication',mfa:'using MFA',phishingResistant:'using phishing-resistant MFA'}[w.authentication];if(authentication)action+=' '+authentication;
  const extra=[];
  for(const key of axes){const value=w[key];if(value===undefined)continue;
   if(['signInRisk','userRisk'].includes(key)){const kind=key==='signInRisk'?'sign-in risk':'user risk';extra.push(value==='hidden'?kind+' not disclosed':value==='none'?'no reported '+kind:value==='unknownFutureValue'?kind+' not recognised':format(key,value)+' '+kind);}
   else if(key.startsWith('roleActive.'))extra.push('the role '+quote(axisName(key).replace(/^Role active: /,''))+' '+(value==='true'?'active':'inactive'));
   else if(key.startsWith('groupMember.'))extra.push((value==='true'?'membership':'no membership')+' in '+quote(axisName(key).replace(/^Group: /,'')));
   else if(key.startsWith('resourceGroup.'))extra.push('the app '+(value==='true'?'included':'not included')+' in '+quote(axisName(key).replace(/^Resource group: /,'')));
   else if(key.startsWith('device.'))extra.push(axisName(key)+' set to '+quote(format(key,value)));
   else if(key==='externalTenantId')extra.push('home organisation '+quote(format(key,value)));
   else if(key==='externalUserType')extra.push('external-user type '+quote(format(key,value)));
   else if(key==='registrationContext'&&!['none','unspecified'].includes(value))extra.push('registration step '+quote(format(key,value)));
   else if(key==='directoryScopeEnforcement'&&value!=='ordinary')extra.push('directory-request rules '+quote(format(key,value)));
  }
  if(extra.length)action+=', with '+extra.join(', ');
  const uncertain=context.unverified===undefined?gap.assessmentStatus!=='gapWithinModel':context.unverified!==false;
  if(uncertain)return 'This example needs verification: '+subject+' attempts to '+action+'; we cannot yet confirm '+(context.outcome==='block'?'whether access would be blocked as required.':'whether the required protection is enforced.');
  return 'In this simulated example, the policies allow '+subject+' to '+action+', even though '+(context.outcome==='block'?'this access must be blocked.':'the requirement calls for '+(context.requiredProtection||'stronger protection')+'.');
 },
 accountGroups(result,model,summary){
  const scoped=new Set(),affected=new Set(),attention=new Set(),confirmed=new Set(),unassessed=new Set(summary.unassessedChecks.flatMap(c=>c.accountIds));
  const belongs=(id,base)=>id===base||[':outside-network',':outside-apps',':outside-device'].some(s=>id===base+s);
  for(const rule of model.requirements||[]){const include=new Set(rule.includeUsers||['*']),exclude=new Set(rule.excludeUsers||[]);for(const account of model.identities||[])if((rule.scope!=='privileged'||account.privileged||account.pimEligible)&&(include.has('*')||include.has(account.id))&&!exclude.has('*')&&!exclude.has(account.id))scoped.add(account.id);}
  for(const id of unassessed){scoped.add(id);affected.add(id);attention.add(id);}
  for(const gap of result.gaps||[]){const definite=gap.assessmentStatus==='gapWithinModel'||gap.assessmentStatus===undefined&&(summary.complete||summary.requirements.some(r=>r.complete&&belongs(gap.requirementId,r.id)));for(const id of gap.identityIds){affected.add(id);if(!gap.acceptance)attention.add(id);if(definite)confirmed.add(id);}}
  const remaining=[...scoped].filter(id=>!affected.has(id)),acceptedAny=new Set((result.gaps||[]).filter(g=>g.acceptance).flatMap(g=>g.identityIds));
  return {scope:scoped,attention,confirmed,unknown:new Set([...affected].filter(id=>!confirmed.has(id))),met:new Set(summary.complete?remaining:[]),unconfirmed:new Set(summary.complete?[]:remaining),acceptedAny,accepted:new Set([...affected].filter(id=>!attention.has(id))),outside:new Set((model.identities||[]).map(a=>a.id).filter(id=>!scoped.has(id)))};
 },
 requirementAccounts(result,model,definition,summary,scope,records){
  const belongs=id=>id===definition.id||[':outside-network',':outside-apps',':outside-device'].some(s=>id===definition.id+s),gapsByAccount=new Map();
  for(const gap of result.gaps||[])if(belongs(gap.requirementId))for(const id of gap.identityIds){if(!gapsByAccount.has(id))gapsByAccount.set(id,[]);gapsByAccount.get(id).push(gap);}
  const included=new Set([...scope.include,...scope.unknown]),assessed=new Set((model.identities||[]).map(u=>u.id)),unknown=new Set(scope.unknown);
  return records.filter(u=>included.has(u.id)).map(account=>{
   const gaps=gapsByAccount.get(account.id)||[],accountScope={include:[account.id],unknown:unknown.has(account.id)?[account.id]:[]},status=this.accountRequirements({...result,gaps},{identities:assessed.has(account.id)?[{id:account.id}]:[]},[definition],account.id,summary,()=>accountScope)[0];
   const acceptedOnly=['gap','unknown'].includes(status.kind)&&gaps.length>0&&gaps.every(g=>g.acceptance)&&!unknown.has(account.id);
   return {account,status,hasAccepted:gaps.some(g=>g.acceptance),acceptedOnly,needsAttention:['gap','unknown'].includes(status.kind)&&!acceptedOnly};
  });
 },
 checkIssues(result,requirementId,accountId){
  const belongs=id=>id===requirementId||[':outside-network',':outside-apps',':outside-device'].some(s=>id===requirementId+s);
  return (result.coverageIssues||[]).filter(issue=>(!requirementId||!issue.requirementId||belongs(issue.requirementId))&&(!accountId||!Array.isArray(issue.accountIds)||issue.accountIds.includes(accountId)));
 },
 accountRequirements(result,model,definitions,accountId,summary,scopeFor){
  const belongs=(id,base)=>id===base||[':outside-network',':outside-apps',':outside-device'].some(s=>id===base+s);
  const assessed=(model.identities||[]).some(u=>u.id===accountId);
  return definitions.map(r=>{
   const base={id:r.id,name:r.name,gapKeys:[]};
   const status=(kind,label,detail,extra={})=>({...base,kind,label,detail,...extra});
   if(r.enabled===false)return r.pendingSetup?.length?status('unknown','Setup needed','Finish configuring this requirement before checking it.'):status('disabled','Disabled','This requirement was turned off for this check.');
   let scope;try{scope=scopeFor(r);}catch{return status('unknown','Cannot confirm','The account definition could not be resolved.');}
   if(scope.unknown.includes(accountId))return status('unknown','Cannot confirm','We cannot yet tell whether this account belongs in this requirement.');
   if(!scope.include.includes(accountId))return status('na','Not applicable','This account is outside the requirement’s account set or is excluded.');
   if(!assessed)return status('unknown','Not checked','This account was not included in the assessed data.');
   const row=summary.requirements.find(s=>s.id===r.id);
   const gaps=(result.gaps||[]).filter(g=>belongs(g.requirementId,r.id)&&g.identityIds.includes(accountId));
   const confirmed=gaps.filter(g=>g.assessmentStatus==='gapWithinModel'||g.assessmentStatus===undefined&&row?.complete);
   if(confirmed.length&&r.outcome==='permit')return status('gap','Not met','Conditional Access denies at least one of the sign-ins you require.',{gapKeys:gaps.map(g=>g.key)});
   if(confirmed.length)return status('gap','Not met','At least one sign-in scenario is missing the required protection.'+(confirmed.every(g=>g.acceptance)?' The confirmed gaps have accepted exceptions; protection is still missing.':''),{gapKeys:gaps.map(g=>g.key)});
   if(gaps.length)return status('unknown','Cannot confirm','Some sign-in scenarios need more information before protection can be confirmed.',{gapKeys:gaps.map(g=>g.key)});
   if(row?.complete&&r.outcome==='permit')return status('met','Met','Conditional Access permits the selected modeled sign-ins after MFA.');
   if(row?.complete)return status('met','Met',r.outcome==='block'?'The required access is blocked in the checked scenarios.':'No missing protection was found in the checked scenarios.');
   const issue=this.checkIssues(result,r.id,accountId)[0];
   return status('unknown','Cannot confirm',issue?this.issue(issue,model).title+'.':'The check did not establish whether this requirement is enforced for this account.');
  });
 },
 gapStatus(unverified){return {label:unverified===false?'Gap found':'Cannot confirm',kind:unverified===false?'gap':'unknown'};},
 requirementStatus(row,definition){
  if(row.complete&&row.checked>0&&row.affected===0)return {label:definition?.outcome==='block'?'Access blocked':'Requirement met',kind:'met'};
  if(!row.complete||!row.checked)return {label:row.confirmedAffected?'Gap found · Cannot confirm all checks':'Cannot confirm',kind:'unknown'};
  return {label:'Gap found',kind:'gap'};
 },
 readiness(input){
  const snapshot=input&&!Array.isArray(input)&&input.caGapSnapshotVersion?input:null,errors=snapshot?.errors||[],flags=snapshot?.completeness||{};
  const rows=[['policies','Policies'],['users','Accounts'],['groupMembers','Memberships'],['namedLocations','Locations']];
  return rows.map(([id,label])=>{
   let present=Array.isArray(snapshot?.[id]),count=present?snapshot[id].length:0;
   if(id==='policies'&&!snapshot){const policies=Array.isArray(input)?input:Array.isArray(input?.value)?input.value:input?.conditions?[input]:null;present=!!policies;count=policies?.length||0;}
   if(id==='groupMembers'){present=!!snapshot?.groupMembers&&typeof snapshot.groupMembers==='object'&&!Array.isArray(snapshot.groupMembers)&&Array.isArray(snapshot.groups);count=present?snapshot.groups.reduce((sum,g)=>sum+new Set(Array.isArray(snapshot.groupMembers[g.id])?snapshot.groupMembers[g.id]:[]).size,0):0;}
   const failed=errors.some(e=>e?.collection===id||id==='groupMembers'&&/^(members|groupMembers|pimGroupEligibility|pimGroupAssignments|groupDirectMembers):/.test(e?.collection||''));
   const membershipComplete=id!=='groupMembers'||flags.groups===true&&snapshot.groups.every(g=>Array.isArray(snapshot.groupMembers[g.id]));
   const complete=present&&flags[id]===true&&!failed&&membershipComplete;
   return {id,label,kind:complete?'met':'unknown',text:complete?'Collected':present?(flags[id]===false||failed||!membershipComplete?'Partial':'Imported'):'Not included',count:present?count:null};
  });
 },
 scope(gap,dimensions,format){
  if(gap.unassessed)return [];
  const rows=[],region=gap.region||{},witness=gap.witness||{},target=witness.accessTarget||'application';
  const add=(axis,all)=>{const values=region[axis];if(!values?.length||axis==='registrationContext'&&values.every(v=>['none','unspecified'].includes(v)))return;const full=values.length===dimensions[axis]?.length&&values.every(v=>dimensions[axis].includes(v));if(full&&!all)return;const formatted=values.map(v=>format(axis,v));const same=expected=>values.length===expected.length&&expected.every(v=>values.includes(v));const clients=axis==='client'?(same(['browser','mobileAppsAndDesktopClients'])?'Modern clients':same(['exchangeActiveSync','easSupported','other'])?'Legacy clients':same(['exchangeActiveSync','easSupported'])?'Exchange ActiveSync':null):null;rows.push({axis,text:full&&all?all:clients||formatted.slice(0,2).join(' or ')+(formatted.length>2?' +'+(formatted.length-2):''),detail:formatted.join(', ')});};
  if(target==='application')add('application','All apps');else if(target==='userAction')add('userAction');else for(const axis of Object.keys(region).filter(k=>k.startsWith('authenticationContext.')))add(axis);
  add('client','Any client');add('network','Any network');add('authentication');
  for(const axis of ['flow','platform','compliant','hybridJoined','signInRisk','userRisk','registrationContext','directoryScopeEnforcement'])add(axis);
  for(const axis of Object.keys(region).filter(k=>/^(device\.|roleActive\.|groupMember\.|resourceGroup\.|external)/.test(k)))add(axis);
  return rows;
 },
 issue(issue,model){
  const catalog={
   'account-classification':['We can’t confirm who belongs in this account set','Import the account details used by this set, or change its definition.','sets'],
   'directory-inventory':['Directory data is incomplete','Import accounts, memberships and role assignments.','data'],
   'resource-inventory':['Resource data is incomplete','Import the referenced resources and named locations.','data'],
   'registration-resource-context':['Registration resource is unknown','Specify the registration resource and flow.','requirements'],
   'registration-strength-precedence':['Registration authentication is unverified','Specify the registration experience and validate strength enforcement.','requirements'],
   'application-filter-context':['App-filter matching is unverified','Review this filter in Entra. CALens cannot verify its matching yet, even with exported app attributes.','data'],
   'location-enforcement-context':['Location definition is incomplete','Import the referenced named locations.','data'],
   'pim-group-context':['PIM membership is incomplete','Import active and eligible PIM group memberships.','data'],
   'external-identity-context':['External-account details are missing','Import the account’s home-tenant and external-user details.','data'],
   'resource-group-context':['App-group membership is incomplete','Import resource-group membership evidence.','data'],
   'country-catalog-context':['Country coverage is unverified','Review country definitions and location evidence.','data'],
   'ip-country-correlation':['IP-to-country mapping is unverified','Validate the sign-in country for the relevant IP addresses.','data'],
   'directory-baseline-context':['Directory resource enforcement is unverified','Validate access to the affected directory resource.','data'],
   'device-compliance-runtime':['Device compliance claim needs validation','Validate this device filter with a controlled sign-in.','data'],
   'grant-enforcement-context':['Grant enforcement is unverified','Validate this control with a controlled sign-in.','data'],
   'strength-enforcement-context':['Authentication strength is unverified','Validate a method that satisfies the required strength.','data'],
   'session-enforcement-context':['Session enforcement is unverified','Validate the session control with a controlled sign-in.','data'],
   'requirement-not-evaluated':['Requirement could not be checked','Review this requirement’s setup and supported conditions.','requirements'],
   'empty-requirement-scope':['No accounts or requests match','Review the account definition and requirement conditions.','requirements'],
   'flow-resource-scope':['Flow protection needs resource evidence','Review the target resource and authentication flow.','requirements'],
   'graph-audience-context':['Resource audience is unverified','Import resource audience evidence.','data'],
   'declared-resources':['Resource inventory needs review','Review the declared resources against your export.','data']
  };
  let [title,action,pane]=catalog[issue?.code]||['Additional evidence is needed','Review the requirement and imported data.','data'];
  if(issue?.code==='location-enforcement-context'&&(model?.policies||[]).some(p=>issue.policyContext?.policyIds?.includes(p.id)&&p.locationMatchingOnly===false)){
   title='Location collection needs validation';action='Review location definitions and GPS location-sharing evidence.';
  }
  return {title,action,pane,details:issue?.message||''};
 }
};
if(typeof module!=='undefined')module.exports=ReviewPresentation;
